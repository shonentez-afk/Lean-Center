(() => {
  // src/modules/master-data/people-directory.js
  var personKey = (value) => String(value ?? "").normalize("NFKC").toLocaleLowerCase("ru-RU").replaceAll("\u0451", "\u0435").trim();
  var aliases = {
    instructor: ["instructor", "trainer", "internal_trainer", "internal trainer", "twi_instructor", "\u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 twi", "\u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440", "\u0432\u0442"],
    mentor: ["mentor", "\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", "twi_mentor"],
    trainee: ["trainee", "learner", "\u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0441\u0442\u0430\u0436\u0435\u0440", "twi_trainee"],
    evaluator: ["evaluator", "assessor", "\u043E\u0446\u0435\u043D\u0449\u0438\u043A", "\u0430\u0443\u0434\u0438\u0442\u043E\u0440"]
  };
  function roleKind(code, name) {
    for (const value of [name, code]) {
      const key3 = personKey(value).replaceAll("-", "_");
      for (const [kind, values] of Object.entries(aliases)) if (values.includes(key3)) return kind;
    }
    return null;
  }
  function directoryPeople(db, day) {
    const all = rows(db, `SELECT p.id,p.employee_code,p.display_name,COALESCE(pos.name,prof.name,'') position,COALESCE(u.name,'') unit FROM person p
 LEFT JOIN person_assignment a ON a.id=(SELECT a2.id FROM person_assignment a2 WHERE a2.person_id=p.id AND a2.valid_from<=? AND (a2.valid_to IS NULL OR a2.valid_to>=?) ORDER BY a2.valid_from DESC,a2.id LIMIT 1)
 LEFT JOIN position pos ON pos.id=a.position_id LEFT JOIN profession prof ON prof.id=a.profession_id LEFT JOIN org_unit u ON u.id=a.unit_id
 WHERE p.archived=0 ORDER BY p.display_name,p.employee_code`, [day, day]);
    const assigned = rows(db, `SELECT a.person_id,b.code,b.name FROM role_assignment a JOIN business_role b ON b.id=a.role_id WHERE b.archived=0 AND a.valid_from<=? AND (a.valid_to IS NULL OR a.valid_to>=?) ORDER BY b.name`, [day, day]);
    const index = /* @__PURE__ */ new Map();
    for (const x of assigned) {
      if (!index.has(x.person_id)) index.set(x.person_id, []);
      index.get(x.person_id).push({ code: x.code, name: x.name, kind: roleKind(x.code, x.name) });
    }
    return all.map((p) => ({ ...p, roles: index.get(p.id) || [] }));
  }

  // src/modules/library/linked-materials.js
  var str = (x) => typeof x === "string" ? x : "";
  var part = (x) => x === null || x === void 0 || String(x).trim() === "" ? 0 : Number(x);
  var twiFields = [
    ["prepare", "purpose", "\u0426\u0435\u043B\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"],
    ["prepare", "known", "\u041E\u043F\u044B\u0442 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E"],
    ["prepare", "prep", "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430"],
    ["prepare", "interest", "\u041C\u043E\u0442\u0438\u0432\u0430\u0446\u0438\u044F"],
    ["present", "round1", "\u041F\u0435\u0440\u0432\u044B\u0439 \u043F\u043E\u043A\u0430\u0437"],
    ["present", "round2", "\u0428\u0430\u0433\u0438 \u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B"],
    ["present", "round3", "\u041F\u0440\u0438\u0447\u0438\u043D\u044B"],
    ["tryOut", "perform", "\u041F\u0440\u043E\u0431\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435"],
    ["tryOut", "explain", "\u041E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435 \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u043E\u043C"],
    ["tryOut", "check", "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F"],
    ["tryOut", "correct", "\u0418\u0441\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043E\u0448\u0438\u0431\u043E\u043A"],
    ["followUp", "help", "\u041A \u043A\u043E\u043C\u0443 \u043E\u0431\u0440\u0430\u0449\u0430\u0442\u044C\u0441\u044F"],
    ["followUp", "control", "\u041F\u043E\u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C"],
    ["followUp", "observe", "\u0427\u0442\u043E \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u044C"],
    ["followUp", "close", "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"]
  ];
  function sopTwiInput(s) {
    const meta2 = s.meta || {};
    return { operation: meta2.operation, executor: meta2.executor, workplace: meta2.workplace, safety: meta2.safety, ...meta2.tools ? { tools: meta2.tools } : {}, ...meta2.material ? { material: meta2.material } : {}, steps: (s.steps || []).map((v, i) => ({ stepNumber: i + 1, action: v.action, keyPoints: Array.isArray(v.keyMoments) ? v.keyMoments.filter(Boolean) : [], reason: v.reason, successCriteria: v.successCriteria, decisionPoints: v.decisionPoints })) };
  }
  function sopTwiSignature(s) {
    const raw = JSON.stringify(sopTwiInput(s));
    let a = 2166136261, b = 0;
    for (let i = 0; i < raw.length; i++) {
      const n = raw.charCodeAt(i);
      a = Math.imul(a ^ n, 16777619) >>> 0;
      b = b + n >>> 0;
      b = b + (b << 10 >>> 0) >>> 0;
      b ^= b >>> 6;
    }
    b = b + (b << 3 >>> 0) >>> 0;
    b ^= b >>> 11;
    b = b + (b << 15 >>> 0) >>> 0;
    return "sop1:" + raw.length + ":" + a.toString(16) + ":" + (b >>> 0).toString(16);
  }
  function linkedTwi(s) {
    const t = s.twi || {}, fields = twiFields.map(([section, key3, label]) => ({ section, key: key3, label, value: str(t[section]?.[key3] ?? (key3 === "control" ? t[section]?.frequency : "")) }));
    const exists = fields.some((f) => f.value.trim()), signature = t.sourceSignature;
    return { exists, filled: fields.filter((f) => f.value.trim()).length, fields, trainer: str(t.trainer), trainee: str(t.trainee), status: !exists ? "\u041D\u0435 \u0441\u043E\u0437\u0434\u0430\u043D" : !signature ? "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438" : signature !== sopTwiSignature(s) ? "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u0430\u043A\u0442\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438" : "\u0421\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D", outdated: !!(exists && signature && signature !== sopTwiSignature(s)) };
  }
  function linkedFrv(s) {
    const totals = { seconds: 0, vdc: 0, m1: 0, m2: 0, unclassified: 0, distance: 0 };
    let start = 0;
    const rows2 = (s.steps || []).map((v, i) => {
      const f = v.frv || {}, seconds = v.durationSeconds, m1 = part(f.m1), m2 = part(f.m2), distance = part(f.move);
      const valid = [seconds, m1, m2, distance].every((x) => Number.isFinite(x) && x >= 0) && m1 + m2 <= seconds + 1e-4;
      const vdc = valid ? f.vdc === true ? Math.max(0, seconds - m1 - m2) : 0 : null;
      const unclassified = valid ? Math.max(0, seconds - vdc - m1 - m2) : null;
      const row = { position: i + 1, action: str(v.action), start, seconds, valid, vdc, m1: valid ? m1 : null, m2: valid ? m2 : null, unclassified, distance: valid ? distance : null, comment: str(f.comment) || v.keyMoments?.filter(Boolean).join("; ") || "" };
      if (Number.isFinite(seconds) && seconds >= 0) {
        start += seconds;
        totals.seconds += seconds;
      }
      if (valid) {
        for (const k of ["vdc", "m1", "m2", "unclassified", "distance"]) totals[k] += row[k];
      }
      return row;
    });
    return { rows: rows2, totals, invalid: rows2.filter((x) => !x.valid).length, exists: rows2.some((x) => x.action.trim()), meta: s.frvMeta || {} };
  }

  // src/modules/library/sop-review.js
  var text = (x, n = 500) => typeof x === "string" && x.trim() && x.length <= n;
  var sha = (x) => typeof x === "string" && /^[0-9a-f]{64}$/.test(x);
  var exact = (p, ks) => invariant(p && typeof p === "object" && !Array.isArray(p) && Object.keys(p).length === ks.length && ks.every((k) => Object.hasOwn(p, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F");
  var SOP_CHECKLIST_CODE = "SOP_APP4";
  function validDate(x) {
    return typeof x === "string" && /^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x;
  }
  function reviewDue(changed) {
    invariant(validDate(changed), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0421\u041E\u041F");
    const [y, m, d] = changed.split("-").map(Number);
    const day = Math.min(d, new Date(Date.UTC(y + 1, m, 0)).getUTCDate());
    return String(y + 1).padStart(4, "0") + "-" + String(m).padStart(2, "0") + "-" + String(day).padStart(2, "0");
  }
  function validateChecklist(p) {
    exact(p, ["format", "title", "source_sha256", "criteria"]);
    invariant(p.format === "lean-sop-checklist-v1" && text(p.title, 200) && sha(p.source_sha256) && Array.isArray(p.criteria) && p.criteria.length === 20, "\u041D\u0443\u0436\u043D\u0430 \u0444\u043E\u0440\u043C\u0430 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F \u0438\u0437 20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    p.criteria.forEach((q, i) => {
      exact(q, ["code", "question"]);
      invariant(q.code === i + 1 && text(q.question, 2500), "\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u044F \u0438\u043B\u0438 \u0442\u0435\u043A\u0441\u0442 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u044F " + (i + 1));
    });
    return p;
  }
  function sopMethods(db) {
    return rows(db, "SELECT v.*,c.name FROM checklist_version v JOIN checklist c ON c.id=v.checklist_id WHERE c.code=? ORDER BY version_no DESC", [SOP_CHECKLIST_CODE]);
  }
  function sopCriteria(db, id) {
    return rows(db, "SELECT * FROM checklist_criterion WHERE version_id=? ORDER BY position", [id]);
  }
  function evaluationResult(responses) {
    const rated = responses.filter((r) => r.value === 0 || r.value === 1);
    const yes = rated.filter((r) => r.value === 1).length;
    return { rated: rated.length, yes, no: rated.length - yes, total: 20, fraction: rated.length === 20 ? yes / 20 : null };
  }
  function applySopMethod(db, e, old) {
    invariant(e.operation === "create" && !old, "\u0412\u0435\u0440\u0441\u0438\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
    const p = validateChecklist(e.payload);
    const methods = sopMethods(db);
    invariant(!methods.some((m) => {
      const d = JSON.parse(m.methodology_json);
      return canonical(d.criteria) === canonical(p.criteria) && d.source_sha256 === p.source_sha256;
    }), "\u0422\u0430\u043A\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0443\u0436\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430");
    let c = one(db, "SELECT * FROM checklist WHERE code=?", [SOP_CHECKLIST_CODE]);
    if (!c) {
      db.run("INSERT INTO checklist(id,code,name) VALUES(?,?,?)", [e.id, SOP_CHECKLIST_CODE, "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F"]);
      c = { id: e.id };
    }
    const n = methods.length ? methods[0].version_no + 1 : 1;
    db.run("INSERT INTO checklist_version(id,checklist_id,version_no,state,methodology_json,rev) VALUES(?,?,?,'draft',?,1)", [e.entity_id, c.id, n, canonical(p)]);
    for (const q of p.criteria) db.run("INSERT INTO checklist_criterion(id,version_id,code,section_code,position,question) VALUES(?,?,?,?,?,?)", [e.entity_id + ":" + q.code, e.entity_id, String(q.code), "SOP", q.code, q.question]);
    db.run("UPDATE checklist_version SET state='retired',rev=rev+1 WHERE checklist_id=? AND state='active'", [c.id]);
    db.run("UPDATE checklist_version SET state='active' WHERE id=?", [e.entity_id]);
  }
  function applySopEvaluation(db, e, old) {
    invariant(e.operation === "create" && !old, "\u0417\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E");
    const p = e.payload;
    exact(p, ["revision_id", "method_id", "actor_id", "evaluated_on", "place", "source_sha256", "responses"]);
    invariant(isId(p.revision_id) && isId(p.method_id) && isId(p.actor_id) && validDate(p.evaluated_on) && text(p.place, 500) && sha(p.source_sha256), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0434\u0430\u0442\u0443, \u043C\u0435\u0441\u0442\u043E, \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u0435\u043C\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u0438 \u043E\u0446\u0435\u043D\u0449\u0438\u043A\u0430");
    const rev = one(db, "SELECT * FROM document_revision WHERE id=?", [p.revision_id]);
    invariant(rev && JSON.parse(rev.payload_json).source.sha256 === p.source_sha256, "\u0412\u0435\u0440\u0441\u0438\u044F \u0421\u041E\u041F \u0438\u043B\u0438 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C");
    const person2 = one(db, "SELECT display_name FROM person WHERE id=? AND archived=0", [p.actor_id]);
    invariant(person2, "\u041E\u0446\u0435\u043D\u0449\u0438\u043A \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442");
    invariant(sopMethods(db).some((m) => m.id === p.method_id && m.state === "active"), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F");
    const criteria = sopCriteria(db, p.method_id);
    invariant(criteria.length === 20 && Array.isArray(p.responses) && p.responses.length === 20, "\u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043E\u0442\u0432\u0435\u0442\u0438\u0442\u044C \u043D\u0430 \u0432\u0441\u0435 20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    p.responses.forEach((q, i) => {
      exact(q, ["criterion_id", "value", "note"]);
      invariant(q.criterion_id === criteria[i].id && (q.value === 0 || q.value === 1) && typeof q.note === "string" && q.note.length <= 2e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 " + (i + 1));
    });
    db.run("INSERT INTO sop_evaluation(id,revision_id,method_id,actor_id,evaluated_on,place,actor_name,source_sha256,recorded_at,rev) VALUES(?,?,?,?,?,?,?,?,?,1)", [e.entity_id, p.revision_id, p.method_id, p.actor_id, p.evaluated_on, p.place.trim(), person2.display_name, p.source_sha256, e.occurred_at]);
    for (const q of p.responses) db.run("INSERT INTO sop_evaluation_response(evaluation_id,method_id,criterion_id,value,note) VALUES(?,?,?,?,?)", [e.entity_id, p.method_id, q.criterion_id, q.value, q.note]);
  }

  // src/modules/training/domain.js
  var TRAINING_TYPES = Object.freeze({
    mentor_credential: "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u043E \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0435",
    mentor_appointment: "\u041F\u0440\u0438\u043A\u0430\u0437\u044B \u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0438",
    mentor_authorization: "\u041F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u044F \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430",
    training_program: "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F",
    training_enrollment: "\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430",
    training_task_result: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B",
    training_assignment: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F",
    training_session: "\u0424\u0430\u043A\u0442 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430",
    training_verification: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0437\u043D\u0430\u043D\u0438\u0439",
    assessment_session: "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 / \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F",
    admission_decision: "\u0420\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435",
    role_requirement: "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435 \u043A \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438",
    coverage_requirement: "\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C \u0432 \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u0438",
    development_plan: "\u041F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F",
    development_goal: "\u0426\u0435\u043B\u044C \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F"
  });
  var PRACTICAL_CODE = "PRACTICAL_APP8";
  var isTrainingEvent = (e) => Object.hasOwn(TRAINING_TYPES, e.entity_type) || e.entity_type === "checklist_version" && e.payload?.format === "lean-practical-checklist-v1";
  var exact2 = (p, keys) => invariant(p && typeof p === "object" && !Array.isArray(p) && Object.keys(p).length === keys.length && keys.every((k) => Object.hasOwn(p, k)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u043F\u043E\u043B\u044F LC4");
  var text2 = (x, n = 2e3) => typeof x === "string" && x.length <= n;
  var required = (x, n = 500) => text2(x, n) && x.trim().length > 0;
  var integer = (x, min = 0, max = 1e5) => Number.isSafeInteger(x) && x >= min && x <= max;
  var date = (x) => validDate(x);
  var period = (a, b) => date(a) && (b === null || date(b) && b >= a);
  var plusDays = (day, n) => {
    const v = /* @__PURE__ */ new Date(day + "T00:00:00Z");
    v.setUTCDate(v.getUTCDate() + n);
    return v.toISOString().slice(0, 10);
  };
  var within = (x, a, b) => a <= x && (!b || b >= x);
  var beforeRevocation = (x, d) => !x || x.slice(0, 10) > d;
  var sha2 = (x) => typeof x === "string" && /^[0-9a-f]{64}$/.test(x);
  var roles = ["instructor", "mentor", "internal_trainer"];
  var programKinds = { entry: "\u0412\u0432\u043E\u0434 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E", internship: "\u0421\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0430", production: "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435" };
  var parts = { general: "\u041E\u0431\u0449\u0430\u044F \u0447\u0430\u0441\u0442\u044C", individual: "\u0418\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C", practice: "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043D\u0430\u0432\u044B\u043A\u0438", knowledge: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0437\u043D\u0430\u043D\u0438\u0439" };
  var variants = { classic: "\u041A\u043B\u0430\u0441\u0441\u0438\u0447\u0435\u0441\u043A\u0438\u0439", special: "\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u043D\u0430\u0432\u044B\u043A\u0438", smed: "\u0421\u043B\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u043F\u043E\u0432\u0442\u043E\u0440\u0430 / SMED", hazardous: "\u041E\u0441\u043E\u0431\u044B\u0435 \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438" };
  var conclusions = { not_meet: "\u041D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442", basic: "\u0421\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0431\u0430\u0437\u043E\u0432\u043E\u043C\u0443 \u0443\u0440\u043E\u0432\u043D\u044E", exceeds: "\u041F\u0440\u0435\u0432\u043E\u0441\u0445\u043E\u0434\u0438\u0442 \u0431\u0430\u0437\u043E\u0432\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C" };
  var prepare = [["prepare", "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430"]];
  var show = [["show1", "\u041F\u043E\u043A\u0430\u0437: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F"], ["show2", "\u041F\u043E\u043A\u0430\u0437: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B"], ["show3", "\u041F\u043E\u043A\u0430\u0437: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F, \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u044B"]];
  var practice = [["try1", "\u041F\u0440\u043E\u0431\u0430: \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435"], ["try2", "\u041F\u0440\u043E\u0431\u0430: \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439"], ["try3", "\u041F\u0440\u043E\u0431\u0430: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B"], ["try4", "\u041F\u0440\u043E\u0431\u0430: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F, \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u044B"]];
  var support = [["support", "\u0421\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u0438 \u043F\u043E\u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430"], ...Array.from({ length: 5 }, (_, i) => ["follow" + (i + 1), "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 " + (i + 1)])];
  function jiStages(variant) {
    invariant(Object.hasOwn(variants, variant), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0432\u0438\u0434 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430");
    let middle;
    if (variant === "classic") middle = [...show, ...practice];
    if (variant === "special") middle = [...show.map(([k, v]) => [k, v + " \xB7 \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0442\u043E\u0440 \u0438 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440"]), ...practice];
    if (variant === "smed") middle = [...Array.from({ length: 3 }, (_, i) => ["show_sim" + (i + 1), "\u041F\u043E\u043A\u0430\u0437: \u0438\u043C\u0438\u0442\u0430\u0446\u0438\u044F " + (i + 1)]), ["show_real", "\u041F\u043E\u043A\u0430\u0437: \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435"], ...Array.from({ length: 3 }, (_, i) => ["try_sim" + (i + 1), "\u041F\u0440\u043E\u0431\u0430: \u0438\u043C\u0438\u0442\u0430\u0446\u0438\u044F " + (i + 1)]), ["try_real", "\u041F\u0440\u043E\u0431\u0430: \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435"]];
    if (variant === "hazardous") middle = [["show_explanation", "\u041F\u043E\u043A\u0430\u0437 / \u0432\u0438\u0434\u0435\u043E\u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B \u0441 \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435\u043C"], ["try_preparatory", "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0440\u0430\u0431\u043E\u0442\u044B / \u0442\u0440\u0435\u043D\u0430\u0436\u0451\u0440"], ["try_individual", "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430: \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u043C \u0443\u0441\u043B\u043E\u0432\u0438\u044F\u043C"], ["try_team", "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \u0432 \u043A\u043E\u043C\u0430\u043D\u0434\u0435"]];
    return [...prepare, ...middle, ...support].map(([code, label]) => ({ code, label, phase: code.startsWith("follow") ? "followup" : code === "support" ? "support" : code.startsWith("try") ? "practice" : code.startsWith("show") ? "presentation" : "prepare" }));
  }
  function progressFor(db, a) {
    const stages = jiStages(a.method_variant), facts = rows(db, "SELECT * FROM training_session WHERE assignment_id=? AND stage_code IS NOT NULL ORDER BY held_at,recorded_at,id", [a.id]);
    const done = new Set(facts.filter((x) => x.result === "completed").map((x) => x.stage_code)), next = stages.find((x) => !done.has(x.code)) || null;
    const intro = stages.filter((x) => !["support", "followup"].includes(x.phase)).every((x) => done.has(x.code));
    const followup = stages.filter((x) => x.phase === "followup" && done.has(x.code)).length;
    const supportOn = facts.find((x) => x.stage_code === "support" && x.result === "completed")?.held_at.slice(0, 10) || null;
    let followupDue = null;
    if (supportOn) {
      const [y, m, d] = supportOn.split("-").map(Number);
      const end = new Date(Date.UTC(y, m, Math.min(d, new Date(Date.UTC(y, m + 1, 0)).getUTCDate())));
      followupDue = end.toISOString().slice(0, 10);
    }
    return { stages, facts, done, next, intro, followup, followupDue, complete: !next, completed: stages.filter((x) => done.has(x.code)).length };
  }
  var active = (db, table, id) => {
    invariant(isId(id), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u0430\u043F\u0438\u0441\u044C: " + table);
    const x = one(db, "SELECT * FROM " + table + " WHERE id=?", [id]);
    invariant(x && !x.archived, "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430: " + table);
    return x;
  };
  var person = (db, id) => active(db, "person", id);
  var optional = (db, table, id) => id === null ? null : active(db, table, id);
  var eventDay = (e) => new Date(Date.parse(e.occurred_at) + 14 * 36e5).toISOString().slice(0, 10);
  function roleMatches(db, id, day, allowed) {
    return directoryPeople(db, day).find((x) => x.id === id)?.roles.some((x) => {
      const vt = [x.code, x.name].some((v) => ["internal_trainer", "internal trainer", "\u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440", "\u0432\u0442"].includes(personKey(v).replaceAll("-", "_")));
      return allowed.includes(x.kind) || allowed.includes("internal_trainer") && vt;
    });
  }
  function hasRole(db, id, day, allowed) {
    person(db, id);
    invariant(roleMatches(db, id, day, allowed), "\u0423 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u043D\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043D\u0443\u0436\u043D\u043E\u0439 \u0440\u043E\u043B\u0438");
  }
  function roleForCredential(role) {
    return role === "internal_trainer" ? ["internal_trainer"] : role === "mentor" ? ["mentor"] : ["instructor"];
  }
  function level(db, scale, levelValue) {
    active(db, "rating_scale", scale);
    invariant(integer(levelValue, 0, 1e3) && one(db, "SELECT value FROM rating_level WHERE scale_id=? AND value=?", [scale, levelValue]), "\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0439 \u0448\u043A\u0430\u043B\u0435");
  }
  function currentStandard(db, revisionId) {
    const r = one(db, "SELECT r.*,d.operation_id,d.code,d.title,d.archived FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.id=? AND d.kind=?", [revisionId, "sop"]);
    if (!r) return null;
    return { ...r, source: JSON.parse(r.payload_json).source };
  }
  function isCurrentStandard(db, revisionId) {
    const r = currentStandard(db, revisionId);
    return !!(r && r.state === "effective" && !r.archived);
  }
  function effective(db, revisionId) {
    const r = currentStandard(db, revisionId);
    invariant(r && r.state === "effective" && !r.archived && r.operation_id && r.source?.kind === "sop", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044E \u0421\u041E\u041F, \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u043D\u0443\u044E \u043A \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
    active(db, "operation", r.operation_id);
    return r;
  }
  function names(db, ids) {
    return Object.fromEntries(Object.entries(ids).map(([k, id]) => [k, id ? person(db, id).display_name : ""]));
  }
  function certificateValid(db, id, day) {
    const x = one(db, "SELECT * FROM mentor_credential WHERE id=?", [id]);
    return x && x.kind === "certificate" && within(day, x.issued_on, x.valid_until) && beforeRevocation(x.revoked_at, day) ? x : null;
  }
  function appointmentValid(db, id, day) {
    const x = one(db, "SELECT * FROM mentor_appointment WHERE id=?", [id]);
    if (!x || !within(day, x.valid_from, x.valid_to) || x.acknowledged_on > day || !beforeRevocation(x.revoked_at, day)) return null;
    const c = certificateValid(db, x.credential_id, day);
    return c && c.person_id === x.person_id && c.role === x.role ? x : null;
  }
  function authorizationValid(db, id, day) {
    const a = one(db, "SELECT * FROM mentor_authorization WHERE id=?", [id]);
    if (!a || !a.credential_id || !a.appointment_id || !within(day, a.valid_from, a.valid_to) || !beforeRevocation(a.revoked_at, day)) return false;
    const o = appointmentValid(db, a.appointment_id, day), c = certificateValid(db, a.credential_id, day);
    return !!(o && c && o.person_id === a.person_id && c.person_id === a.person_id && o.credential_id === c.id && roleMatches(db, a.person_id, day, roleForCredential(c.role)) && one(db, "SELECT id FROM operation WHERE id=? AND archived=0", [a.operation_id]));
  }
  function activeAuthorizations(db, operationId, day) {
    return rows(db, "SELECT * FROM mentor_authorization WHERE operation_id=? ORDER BY valid_from DESC,id", [operationId]).filter((x) => authorizationValid(db, x.id, day));
  }
  function practicalMethods(db) {
    return rows(db, "SELECT v.* FROM checklist_version v JOIN checklist c ON c.id=v.checklist_id WHERE c.code=? ORDER BY v.version_no DESC", [PRACTICAL_CODE]);
  }
  function practicalCriteria(db, id) {
    return rows(db, "SELECT * FROM checklist_criterion WHERE version_id=? ORDER BY position", [id]);
  }
  function practicalResult(responses) {
    const rated = responses.filter((x) => x.value === 0 || x.value === 1), yes = rated.filter((x) => x.value === 1).length;
    return { rated: rated.length, yes, total: 11, fraction: rated.length === 11 ? yes / 11 : null };
  }
  function validatePracticalMethod(p) {
    exact2(p, ["format", "title", "source_sha256", "criteria"]);
    invariant(p.format === "lean-practical-checklist-v1" && required(p.title, 200) && sha2(p.source_sha256) && Array.isArray(p.criteria) && p.criteria.length === 11, "\u041D\u0443\u0436\u043D\u0430 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0438\u0437 11 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    p.criteria.forEach((x, i) => {
      exact2(x, ["code", "section", "question"]);
      invariant(x.code === i + 1 && required(x.section, 100) && required(x.question, 2500), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0439 " + (i + 1));
    });
    return p;
  }
  function verifyTrainingSource(e, source, raw) {
    invariant(e.entity_type === "training_assignment" && e.operation === "create" && source.kind === "sop" && canonical(source) === canonical(e.payload.source), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F");
    const t = linkedTwi(raw.constructor);
    invariant(t.exists && !t.outdated && e.payload.plan_reviewed === true, "\u0421\u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0439\u0442\u0435 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0439 \u043F\u043B\u0430\u043D TWI \u0432 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0438 \u0421\u041E\u041F");
  }
  function createOnly(e, old) {
    invariant(e.operation === "create" && !old, "\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435");
  }
  function changeOnly(e, old) {
    invariant(e.operation === "update" && old, "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u0430\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441 \u0437\u0430\u043F\u0438\u0441\u044C\u044E");
  }
  function assignment(db, id) {
    const a = one(db, "SELECT * FROM training_assignment WHERE id=? AND source_sha256 IS NOT NULL", [id]);
    invariant(a, "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E");
    return a;
  }
  function freshAssignment(db, p) {
    const a = assignment(db, p.assignment_id);
    invariant(integer(p.assignment_rev, 1) && p.assignment_rev === a.rev, "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0443\u044E \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443.");
    return a;
  }
  function latest(db, table, where, args, dayColumn) {
    return one(db, "SELECT * FROM " + table + " WHERE " + where + " ORDER BY " + dayColumn + " DESC,recorded_at DESC,id DESC LIMIT 1", args);
  }
  function latestVerification(db, id, kind) {
    return latest(db, "training_verification", "assignment_id=? AND kind=?", [id, kind], "evaluated_on");
  }
  function latestAssessment(db, id, kind) {
    return latest(db, "assessment_session", "assignment_id=? AND assessment_kind=? AND state='confirmed'", [id, kind], "assessed_at");
  }
  function admissionRecordStatus(db, a, day) {
    if (!a) return { record: null, status: "\u041D\u0435\u0442 \u0440\u0435\u0448\u0435\u043D\u0438\u044F", current: false };
    if (a.decision === "denied") return { record: a, status: "\u041D\u0435 \u0434\u043E\u043F\u0443\u0449\u0435\u043D", current: false };
    if (!beforeRevocation(a.revoked_at, day)) return { record: a, status: "\u041E\u0442\u043E\u0437\u0432\u0430\u043D", current: false };
    if (a.valid_until && a.valid_until < day) return { record: a, status: "\u0421\u0440\u043E\u043A \u0438\u0441\u0442\u0451\u043A", current: false };
    const current = isCurrentStandard(db, a.revision_id);
    if (!current) return { record: a, status: "\u0414\u043E\u043F\u0443\u0441\u043A \u043F\u043E \u043F\u0440\u0435\u0436\u043D\u0435\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \xB7 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0430\u043D\u0430\u043B\u0438\u0437", current: false };
    const item = one(db, "SELECT * FROM assessment_item WHERE session_id=?", [a.qualification_id]);
    if (item?.valid_until && item.valid_until < day) return { record: a, status: "\u0421\u0440\u043E\u043A \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0438 \u0438\u0441\u0442\u0451\u043A \xB7 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0430\u043D\u0430\u043B\u0438\u0437", current: false };
    const q = latestAssessment(db, a.assignment_id, "qualification"), p = latestAssessment(db, a.assignment_id, "practical"), s = latestVerification(db, a.assignment_id, "safety"), t = latestVerification(db, a.assignment_id, "theory");
    if (q?.id !== a.qualification_id || p?.id !== a.practical_id || s?.id !== a.safety_id || t?.id !== a.theory_id) return { record: a, status: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C \xB7 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u0435", current: false };
    return { record: a, status: "\u0414\u043E\u043F\u0443\u0441\u043A \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D", current: true };
  }
  function admissionStatus(db, personId, operationId, day) {
    return admissionRecordStatus(db, latest(db, "admission_decision", "person_id=? AND operation_id=? AND decided_on<=?", [personId, operationId, day], "decided_on"), day);
  }
  function enrollmentTasks(db, enrollment) {
    return rows(db, "SELECT * FROM training_program_task WHERE program_id=? ORDER BY position", [enrollment.program_id]).map((task) => {
      const a = latestTaskAssignment(db, enrollment.id, task.id), result = latest(db, "training_task_result", "enrollment_id=? AND task_id=?", [enrollment.id, task.id], "held_on");
      return { ...task, assignment: a, result, done: task.sop_revision_id ? a?.state === "completed" : result?.result === "completed" };
    });
  }
  function latestTaskAssignment(db, enrollmentId, taskId) {
    return one(db, "SELECT * FROM training_assignment WHERE enrollment_id=? AND program_task_id=? AND state<>'cancelled' ORDER BY assigned_on DESC,id DESC LIMIT 1", [enrollmentId, taskId]);
  }
  function store(db, table, data) {
    const ks = Object.keys(data);
    db.run("INSERT INTO " + table + "(" + ks.join(",") + ") VALUES(" + ks.map(() => "?").join(",") + ")", ks.map((k) => data[k]));
  }
  function update(db, table, id, data) {
    const ks = Object.keys(data);
    db.run("UPDATE " + table + " SET " + ks.map((k) => k + "=?").join(",") + ",rev=rev+1 WHERE id=?", [...ks.map((k) => data[k]), id]);
  }
  function revoke(db, table, e, old) {
    changeOnly(e, old);
    exact2(e.payload, ["command", "reason"]);
    invariant(e.payload.command === "revoke" && required(e.payload.reason) && !old.revoked_at, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0442\u0437\u044B\u0432\u0430");
    update(db, table, old.id, { revoked_at: e.occurred_at });
  }
  function noFuture(day, e) {
    invariant(date(day) && day <= eventDay(e), "\u0414\u0430\u0442\u0430 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u0432 \u0431\u0443\u0434\u0443\u0449\u0435\u043C");
  }
  function validClock(s) {
    return typeof s === "string" && /^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d$/.test(s) && date(s.slice(0, 10));
  }
  function exactAssignmentTarget(db, p, r) {
    const skill = active(db, "skill", p.skill_id);
    invariant(skill.operation_id === r.operation_id, "\u041D\u0430\u0432\u044B\u043A \u0434\u043E\u043B\u0436\u0435\u043D \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u044C\u0441\u044F \u043A \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u0421\u041E\u041F");
    level(db, p.scale_id, p.target_level);
  }
  function applyTrainingEvent(db, e, old) {
    const p = e.payload, id = e.entity_id, t = e.entity_type;
    if (t === "checklist_version") {
      createOnly(e, old);
      validatePracticalMethod(p);
      const methods = practicalMethods(db);
      invariant(!methods.some((m) => canonical(JSON.parse(m.methodology_json)) === canonical(p)), "\u0422\u0430\u043A\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0443\u0436\u0435 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430");
      let c = one(db, "SELECT * FROM checklist WHERE code=?", [PRACTICAL_CODE]);
      if (!c) {
        c = { id: e.id };
        store(db, "checklist", { id: c.id, code: PRACTICAL_CODE, name: "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430" });
      }
      store(db, t, { id, checklist_id: c.id, version_no: (methods[0]?.version_no || 0) + 1, state: "draft", methodology_json: canonical(p), rev: 1 });
      p.criteria.forEach((q) => store(db, "checklist_criterion", { id: id + ":" + q.code, version_id: id, code: String(q.code), section_code: q.section, position: q.code, question: q.question }));
      db.run("UPDATE checklist_version SET state='retired',rev=rev+1 WHERE checklist_id=? AND state='active'", [c.id]);
      db.run("UPDATE checklist_version SET state='active' WHERE id=?", [id]);
      return;
    }
    if (t === "mentor_credential") {
      if (old) return revoke(db, t, e, old);
      createOnly(e, old);
      exact2(p, ["person_id", "kind", "role", "number", "issuer", "issued_on", "valid_until", "evidence", "registered_by"]);
      person(db, p.person_id);
      person(db, p.registered_by);
      noFuture(p.issued_on, e);
      invariant(["certificate", "attendance"].includes(p.kind) && roles.includes(p.role) && required(p.number, 200) && required(p.issuer) && required(p.evidence) && period(p.issued_on, p.valid_until), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043E \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0435");
      store(db, t, { id, ...p, rev: 1 });
      return;
    }
    if (t === "mentor_appointment") {
      if (old) return revoke(db, t, e, old);
      createOnly(e, old);
      exact2(p, ["person_id", "credential_id", "role", "order_number", "order_on", "approved_by", "valid_from", "valid_to", "acknowledged_on", "evidence"]);
      person(db, p.person_id);
      person(db, p.approved_by);
      noFuture(p.order_on, e);
      noFuture(p.acknowledged_on, e);
      invariant(roles.includes(p.role) && period(p.valid_from, p.valid_to) && p.order_on <= p.valid_from && p.acknowledged_on >= p.order_on && required(p.order_number, 200) && required(p.evidence), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 \u0438 \u043E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435");
      const c = certificateValid(db, p.credential_id, p.valid_from);
      invariant(c && c.person_id === p.person_id && c.role === p.role, "\u041D\u0443\u0436\u0435\u043D \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u044D\u0442\u043E\u0439 \u0440\u043E\u043B\u0438, \u043D\u0435 \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u043E \u043F\u0440\u043E\u0441\u043B\u0443\u0448\u0438\u0432\u0430\u043D\u0438\u0438");
      store(db, t, { id, ...p, rev: 1 });
      return;
    }
    if (t === "mentor_authorization") {
      if (old) return revoke(db, t, e, old);
      createOnly(e, old);
      exact2(p, ["person_id", "operation_id", "approved_by", "valid_from", "valid_to", "credential_id", "appointment_id"]);
      person(db, p.approved_by);
      active(db, "operation", p.operation_id);
      invariant(period(p.valid_from, p.valid_to), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043F\u0435\u0440\u0438\u043E\u0434 \u043F\u0440\u0430\u0432\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C");
      const o = appointmentValid(db, p.appointment_id, p.valid_from), c = certificateValid(db, p.credential_id, p.valid_from);
      invariant(o && c && o.person_id === p.person_id && o.credential_id === c.id, "\u041F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u0430 \u0438 \u043F\u0440\u0438\u043A\u0430\u0437\u0430");
      hasRole(db, p.person_id, p.valid_from, roleForCredential(c.role));
      invariant(!rows(db, "SELECT * FROM mentor_authorization WHERE person_id=? AND operation_id=?", [p.person_id, p.operation_id]).some((a) => !a.revoked_at && a.valid_from <= (p.valid_to || "9999-12-31") && (!a.valid_to || a.valid_to >= p.valid_from)), "\u0415\u0441\u0442\u044C \u043F\u0435\u0440\u0435\u0441\u0435\u043A\u0430\u044E\u0449\u0435\u0435\u0441\u044F \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0435 \u043F\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
      store(db, t, { id, ...p, rev: 1 });
      return;
    }
    if (t === "training_program") {
      if (old) {
        changeOnly(e, old);
        exact2(p, ["command", "reason"]);
        invariant(p.command === "retire" && required(p.reason) && old.state === "active", "\u0412\u0435\u0440\u0441\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0443\u0436\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430");
        update(db, t, id, { state: "retired" });
        return;
      }
      createOnly(e, old);
      exact2(p, ["code", "kind", "title", "profession_id", "position_id", "created_by", "tasks"]);
      invariant(required(p.code, 100) && required(p.title) && Object.hasOwn(programKinds, p.kind) && Array.isArray(p.tasks) && p.tasks.length > 0 && p.tasks.length <= 100, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443 \u0438 \u0437\u0430\u0434\u0430\u043D\u0438\u044F");
      optional(db, "profession", p.profession_id);
      optional(db, "position", p.position_id);
      person(db, p.created_by);
      if (p.kind === "internship") invariant(Object.keys(parts).every((k) => p.tasks.some((x) => x.part === k)), "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438 \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u0432\u0441\u0435 \u0447\u0435\u0442\u044B\u0440\u0435 \u0447\u0430\u0441\u0442\u0438");
      p.tasks.forEach((x) => {
        exact2(x, ["part", "title", "hours", "day_offset", "sop_revision_id", "skill_id", "scale_id", "target_level"]);
        invariant(Object.hasOwn(parts, x.part) && required(x.title) && typeof x.hours === "number" && Number.isFinite(x.hours) && x.hours >= 0 && x.hours <= 1e3 && integer(x.day_offset, 0, 3660), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
        if (x.sop_revision_id) {
          const r = effective(db, x.sop_revision_id);
          exactAssignmentTarget(db, x, r);
        } else invariant(x.skill_id === null && x.scale_id === null && x.target_level === null, "\u0414\u043B\u044F \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0441 \u0446\u0435\u043B\u0435\u0432\u043E\u0439 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0435\u0439 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0421\u041E\u041F");
      });
      const previous = rows(db, "SELECT * FROM training_program").filter((x) => foldKey(x.code) === foldKey(p.code));
      invariant(previous.every((x) => x.kind === p.kind), "\u041A\u043E\u0434 \u0443\u0436\u0435 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0434\u0440\u0443\u0433\u043E\u043C\u0443 \u0432\u0438\u0434\u0443 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
      const version = Math.max(0, ...previous.map((x) => x.version_no)) + 1, code = previous[0]?.code || p.code.trim();
      for (const x of previous.filter((x2) => x2.state === "active")) update(db, t, x.id, { state: "retired" });
      store(db, t, { id, code, version_no: version, kind: p.kind, title: p.title.trim(), profession_id: p.profession_id, position_id: p.position_id, created_by: p.created_by, created_at: e.occurred_at, state: "active", rev: 1 });
      p.tasks.forEach((x, i) => store(db, "training_program_task", { id: id + ":" + (i + 1), program_id: id, position: i + 1, ...x }));
      return;
    }
    if (t === "training_enrollment") {
      if (!old) {
        createOnly(e, old);
        exact2(p, ["program_id", "trainee_id", "mentor_id", "manager_id", "start_on", "due_on", "reason"]);
        const program = one(db, "SELECT * FROM training_program WHERE id=? AND state=?", [p.program_id, "active"]);
        invariant(program && period(p.start_on, p.due_on) && p.due_on && required(p.reason), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u0443\u044E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443, \u0441\u0440\u043E\u043A\u0438 \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u0443");
        invariant(rows(db, "SELECT day_offset FROM training_program_task WHERE program_id=?", [program.id]).every((x) => plusDays(p.start_on, x.day_offset) <= p.due_on), "\u0421\u0440\u043E\u043A \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0434\u043E\u043B\u0436\u0435\u043D \u0432\u043A\u043B\u044E\u0447\u0430\u0442\u044C \u0432\u0441\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F");
        hasRole(db, p.trainee_id, p.start_on, ["trainee"]);
        hasRole(db, p.mentor_id, p.start_on, ["mentor", "instructor"]);
        person(db, p.manager_id);
        invariant(p.trainee_id !== p.mentor_id, "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u0441\u0435\u0431\u044F");
        const a = one(db, "SELECT * FROM person_assignment WHERE person_id=? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? ORDER BY valid_from DESC LIMIT 1", [p.trainee_id, p.start_on, p.start_on]);
        invariant((!program.profession_id || a?.profession_id === program.profession_id) && (!program.position_id || a?.position_id === program.position_id), "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u043C\u0443 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
        invariant(!one(db, "SELECT id FROM training_enrollment WHERE program_id=? AND trainee_id=? AND state='active'", [p.program_id, p.trainee_id]), "\u0422\u0430\u043A\u0430\u044F \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u0443\u0436\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u0430");
        store(db, t, { id, ...p, state: "active", rev: 1 });
        return;
      }
      changeOnly(e, old);
      exact2(p, ["command", "actor_id", "conclusion", "feedback"]);
      person(db, p.actor_id);
      invariant(old.state === "active" && ["finish", "cancel"].includes(p.command) && required(p.feedback), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0438\u0442\u043E\u0433 \u0438 \u043E\u0431\u0440\u0430\u0442\u043D\u0443\u044E \u0441\u0432\u044F\u0437\u044C");
      if (p.command === "finish") invariant(Object.hasOwn(conclusions, p.conclusion) && enrollmentTasks(db, old).every((x) => x.done), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0438 \u0443\u043A\u0430\u0436\u0438\u0442\u0435 \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435");
      else invariant(p.conclusion === null, "\u041E\u0442\u043C\u0435\u043D\u0430 \u043D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u043C \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435\u043C");
      if (p.command === "cancel") invariant(!one(db, "SELECT id FROM training_assignment WHERE enrollment_id=? AND state IN('planned','in_progress')", [id]), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u043D\u0435\u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u044B\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
      update(db, t, id, { state: p.command === "finish" ? "completed" : "cancelled", conclusion: p.conclusion, feedback: p.feedback, finished_by: p.actor_id, finished_at: e.occurred_at });
      return;
    }
    if (t === "training_task_result") {
      createOnly(e, old);
      exact2(p, ["enrollment_id", "task_id", "actor_id", "held_on", "result", "minutes", "evidence", "enrollment_rev"]);
      person(db, p.actor_id);
      noFuture(p.held_on, e);
      const n = one(db, "SELECT * FROM training_enrollment WHERE id=?", [p.enrollment_id]), task = one(db, "SELECT * FROM training_program_task WHERE id=?", [p.task_id]);
      invariant(n?.state === "active" && n.rev === p.enrollment_rev && task?.program_id === n.program_id && !task.sop_revision_id && p.held_on >= n.start_on && ["completed", "incomplete"].includes(p.result) && integer(p.minutes, 0, 1440) && required(p.evidence), "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435 / \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442. \u0417\u0430\u0434\u0430\u043D\u0438\u044F \u043F\u043E \u0421\u041E\u041F \u0437\u0430\u043A\u0440\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u0444\u0430\u043A\u0442\u043E\u043C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430.");
      const { enrollment_rev, ...data } = p;
      store(db, t, { id, ...data, recorded_at: e.occurred_at, rev: 1 });
      update(db, "training_enrollment", n.id, { state: n.state });
      return;
    }
    if (t === "training_assignment") {
      if (!old) {
        createOnly(e, old);
        exact2(p, ["trainee_id", "mentor_id", "supervisor_id", "authorization_id", "revision_id", "source", "skill_id", "scale_id", "target_level", "assigned_by", "assigned_on", "due_on", "reason", "variant", "shift_id", "enrollment_id", "program_task_id", "plan_reviewed"]);
        const r = effective(db, p.revision_id);
        invariant(canonical(r.source) === canonical(p.source) && p.plan_reviewed === true, "\u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u0435\u043D \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0439 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0438 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u043C\u0443 TWI");
        invariant(period(p.assigned_on, p.due_on) && p.due_on && required(p.reason) && Object.hasOwn(variants, p.variant), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0430\u0442\u044B, \u0432\u0438\u0434 \u0438 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F");
        invariant(r.effective_at && p.assigned_on >= r.effective_at.slice(0, 10), "\u041D\u0430\u0447\u0430\u043B\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u043F\u0440\u0435\u0434\u0448\u0435\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0432\u0441\u0442\u0443\u043F\u043B\u0435\u043D\u0438\u044E \u0421\u041E\u041F \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435");
        hasRole(db, p.trainee_id, p.assigned_on, ["trainee"]);
        person(db, p.assigned_by);
        invariant(p.trainee_id !== p.mentor_id, "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 \u0434\u043E\u043B\u0436\u043D\u044B \u0440\u0430\u0437\u043B\u0438\u0447\u0430\u0442\u044C\u0441\u044F");
        const auth = one(db, "SELECT * FROM mentor_authorization WHERE id=?", [p.authorization_id]);
        invariant(auth?.person_id === p.mentor_id && auth.operation_id === r.operation_id && authorizationValid(db, auth.id, p.assigned_on), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0441 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u043F\u0440\u0430\u0432\u043E\u043C \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u044D\u0442\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
        if (p.supervisor_id) {
          hasRole(db, p.supervisor_id, p.assigned_on, ["mentor", "instructor"]);
          invariant(p.supervisor_id !== p.trainee_id, "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 \u0434\u043E\u043B\u0436\u043D\u044B \u0440\u0430\u0437\u043B\u0438\u0447\u0430\u0442\u044C\u0441\u044F");
        }
        optional(db, "work_shift", p.shift_id);
        exactAssignmentTarget(db, p, r);
        if (p.enrollment_id !== null || p.program_task_id !== null) {
          const n = one(db, "SELECT * FROM training_enrollment WHERE id=?", [p.enrollment_id]), task = one(db, "SELECT * FROM training_program_task WHERE id=?", [p.program_task_id]);
          invariant(n?.state === "active" && n.trainee_id === p.trainee_id && task?.program_id === n.program_id && task.sop_revision_id === r.id && task.skill_id === p.skill_id && task.scale_id === p.scale_id && task.target_level === p.target_level && p.assigned_on >= n.start_on && p.due_on <= n.due_on && !latestTaskAssignment(db, n.id, task.id), "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0437\u0430\u0434\u0430\u043D\u0438\u044E \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
        }
        invariant(!one(db, "SELECT id FROM training_assignment WHERE trainee_id=? AND sop_revision_id=? AND skill_id=? AND state IN('planned','in_progress')", [p.trainee_id, r.id, p.skill_id]), "\u0423 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0443\u0436\u0435 \u0435\u0441\u0442\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u044D\u0442\u043E\u043C\u0443 \u043D\u0430\u0432\u044B\u043A\u0443 \u0438 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0438");
        store(db, t, { id, trainee_id: p.trainee_id, mentor_id: p.mentor_id, supervisor_id: p.supervisor_id, operation_id: r.operation_id, sop_revision_id: r.id, twi_revision_id: r.id, due_on: p.due_on, state: "planned", rev: 1, source_sha256: r.source.sha256, skill_id: p.skill_id, scale_id: p.scale_id, target_level: p.target_level, assigned_by: p.assigned_by, assigned_on: p.assigned_on, reason: p.reason, method_variant: p.variant, method_version: "JI-1", authorization_id: p.authorization_id, shift_id: p.shift_id, enrollment_id: p.enrollment_id, program_task_id: p.program_task_id, recorded_names_json: canonical(names(db, { trainee: p.trainee_id, instructor: p.mentor_id, supervisor: p.supervisor_id, assignedBy: p.assigned_by })) });
        return;
      }
      changeOnly(e, old);
      invariant(old.source_sha256 && ["planned", "in_progress"].includes(old.state), "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0437\u0430\u043A\u0440\u044B\u0442\u043E \u0438\u043B\u0438 \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0441\u044F \u043A legacy");
      if (p.command === "approve") {
        exact2(p, ["command", "responsible_id", "head_id", "approved_on", "note"]);
        person(db, p.responsible_id);
        person(db, p.head_id);
        noFuture(p.approved_on, e);
        const r = effective(db, old.sop_revision_id);
        invariant(r.effective_at && p.approved_on >= r.effective_at.slice(0, 10) && text2(p.note) && !old.approval_json, "\u041F\u043B\u0430\u043D \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u043C \u0438 \u0435\u0449\u0451 \u043D\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D. \u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u043E\u043F\u0443\u0441\u043A\u0430\u0435\u0442\u0441\u044F \u0434\u043E \u043F\u043B\u0430\u043D\u043E\u0432\u043E\u0433\u043E \u043D\u0430\u0447\u0430\u043B\u0430 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F.");
        update(db, t, id, { approval_json: canonical({ ...p, names: names(db, { responsible: p.responsible_id, head: p.head_id }) }) });
        return;
      }
      if (p.command === "reschedule") {
        exact2(p, ["command", "due_on", "reason"]);
        invariant(date(p.due_on) && p.due_on >= old.assigned_on && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043D\u043E\u0432\u044B\u0439 \u0441\u0440\u043E\u043A \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u0443");
        if (old.enrollment_id) {
          const n = one(db, "SELECT * FROM training_enrollment WHERE id=?", [old.enrollment_id]);
          invariant(n?.state === "active" && p.due_on <= n.due_on, "\u0421\u0440\u043E\u043A \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0432\u044B\u0445\u043E\u0434\u0438\u0442\u044C \u0437\u0430 \u043F\u0440\u0435\u0434\u0435\u043B\u044B \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
        }
        update(db, t, id, { due_on: p.due_on, change_reason: p.reason, approval_json: null });
        return;
      }
      exact2(p, ["command", "reason"]);
      invariant(p.command === "cancel" && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043F\u0440\u0438\u0447\u0438\u043D\u0443 \u043E\u0442\u043C\u0435\u043D\u044B");
      update(db, t, id, { state: "cancelled", change_reason: p.reason });
      return;
    }
    if (t === "training_session") {
      createOnly(e, old);
      exact2(p, ["assignment_id", "assignment_rev", "stage_code", "held_at", "duration_minutes", "result", "notes", "witness_id", "mentor_ack", "trainee_ack"]);
      const a = freshAssignment(db, p), day = String(p.held_at).slice(0, 10), pr = progressFor(db, a), stage = pr.stages.find((x) => x.code === p.stage_code);
      invariant(a.state !== "cancelled" && a.approval_json && isCurrentStandard(db, a.sop_revision_id), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u0443\u0439\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435. \u0414\u043B\u044F \u0438\u0437\u043C\u0435\u043D\u0451\u043D\u043D\u043E\u0433\u043E \u0421\u041E\u041F \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440.");
      invariant(stage && validClock(p.held_at) && day >= a.assigned_on && day >= JSON.parse(a.approval_json).approved_on && day <= eventDay(e) && integer(p.duration_minutes, 1, 1440) && ["completed", "incomplete"].includes(p.result) && required(p.notes), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u044D\u0442\u0430\u043F, \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443/\u0432\u0440\u0435\u043C\u044F, \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442");
      invariant(!pr.facts.some((f) => f.held_at > p.held_at), "\u0424\u0430\u043A\u0442\u044B \u0434\u043E\u043B\u0436\u043D\u044B \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u0432 \u0445\u0440\u043E\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u043F\u043E\u0440\u044F\u0434\u043A\u0435");
      invariant(pr.done.has(stage.code) || stage.code === pr.next?.code, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u043F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0438\u0439 \u044D\u0442\u0430\u043F; \u043F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u044F \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u044B");
      invariant(authorizationValid(db, a.authorization_id, day), "\u041F\u0440\u0430\u0432\u043E \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043D\u0435\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043D\u0430 \u0434\u0430\u0442\u0443 \u0444\u0430\u043A\u0442\u0430");
      invariant(p.mentor_ack === true && p.trainee_ack === true, "\u041D\u0443\u0436\u043D\u044B \u043E\u0442\u043C\u0435\u0442\u043A\u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043E\u0431\u0435\u0438\u0445 \u0441\u0442\u043E\u0440\u043E\u043D (\u043D\u0435 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0434\u043F\u0438\u0441\u044C)");
      const witness = optional(db, "person", p.witness_id);
      if (a.method_variant === "special" && stage.phase === "presentation") invariant(witness && witness.id !== a.trainee_id, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0430");
      if (a.method_variant === "hazardous" && stage.phase === "practice") {
        const safety = latestVerification(db, a.id, "safety");
        invariant(safety?.result === "pass" && safety.evaluated_on <= day, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438");
      }
      store(db, t, { id, assignment_id: a.id, mentor_id: a.mentor_id, held_at: p.held_at, notes: p.notes, result: p.result, steps_json: canonical({ version: a.method_version, variant: a.method_variant, stage: stage.code, label: stage.label, repeat: pr.done.has(stage.code) }), rev: 1, stage_code: stage.code, duration_minutes: p.duration_minutes, witness_id: p.witness_id, witness_name: witness?.display_name || null, mentor_ack: 1, trainee_ack: 1, recorded_at: e.occurred_at });
      const done = progressFor(db, a);
      update(db, "training_assignment", a.id, { state: done.complete ? "completed" : "in_progress" });
      if (a.enrollment_id) {
        const n = one(db, "SELECT * FROM training_enrollment WHERE id=?", [a.enrollment_id]);
        if (n?.state === "active") update(db, "training_enrollment", n.id, { state: n.state });
      }
      return;
    }
    if (t === "training_verification") {
      createOnly(e, old);
      exact2(p, ["assignment_id", "assignment_rev", "kind", "evaluator_id", "evaluated_on", "result", "evidence", "feedback"]);
      const a = freshAssignment(db, p);
      person(db, p.evaluator_id);
      noFuture(p.evaluated_on, e);
      invariant(a.state !== "cancelled" && a.approval_json && isCurrentStandard(db, a.sop_revision_id) && p.evaluator_id !== a.trainee_id && p.evaluated_on >= a.assigned_on && p.evaluated_on >= JSON.parse(a.approval_json).approved_on && ["safety", "theory"].includes(p.kind) && ["pass", "fail"].includes(p.result) && required(p.evidence) && required(p.feedback), "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F, \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043E\u0446\u0435\u043D\u0449\u0438\u043A\u0430, \u0434\u0430\u0442\u044B, \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430 \u0438 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u044F");
      const prev = latestVerification(db, a.id, p.kind);
      invariant(!prev || p.evaluated_on >= prev.evaluated_on, "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0434\u043C\u0435\u043D\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0431\u043E\u043B\u0435\u0435 \u0440\u0430\u043D\u043D\u0435\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u043E\u0439");
      const { assignment_rev, ...data } = p;
      store(db, t, { id, ...data, recorded_at: e.occurred_at, rev: 1 });
      update(db, "training_assignment", a.id, { state: a.state });
      return;
    }
    if (t === "assessment_session") {
      createOnly(e, old);
      const a = freshAssignment(db, p);
      person(db, p.evaluator_id);
      noFuture(p.assessed_on, e);
      invariant(a.state !== "cancelled" && a.approval_json && isCurrentStandard(db, a.sop_revision_id) && p.evaluator_id !== a.trainee_id && p.assessed_on >= a.assigned_on && p.assessed_on >= JSON.parse(a.approval_json).approved_on && required(p.feedback), "\u041D\u0443\u0436\u043D\u0430 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C, \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u043E\u0446\u0435\u043D\u0449\u0438\u043A \u0438 \u043E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C");
      const prev = latestAssessment(db, a.id, p.command);
      invariant(!prev || p.assessed_on >= prev.assessed_at.slice(0, 10), "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0434\u043C\u0435\u043D\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0431\u043E\u043B\u0435\u0435 \u0440\u0430\u043D\u043D\u0435\u0439 \u043E\u0446\u0435\u043D\u043A\u043E\u0439");
      const pr = progressFor(db, a), latestTrial = pr.facts.filter((x) => x.stage_code.startsWith("try") && x.result === "completed").at(-1);
      invariant(pr.intro && latestTrial && p.assessed_on >= latestTrial.held_at.slice(0, 10), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0432\u0432\u043E\u0434\u043D\u0443\u044E \u0447\u0430\u0441\u0442\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 \u0438 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0440\u043E\u0431\u044B");
      const common = { id, person_id: a.trainee_id, evaluator_id: p.evaluator_id, training_session_id: latestTrial.id, operation_id: a.operation_id, standard_revision_id: a.sop_revision_id, assessed_at: p.assessed_on, state: "draft", assignment_id: a.id, assessment_kind: p.command, feedback: p.feedback, recorded_at: e.occurred_at, recorded_names_json: canonical(names(db, { trainee: a.trainee_id, evaluator: p.evaluator_id })), rev: 1 };
      if (p.command === "practical") {
        exact2(p, ["command", "assignment_id", "assignment_rev", "evaluator_id", "assessed_on", "method_id", "responses", "conclusion", "feedback"]);
        invariant(practicalMethods(db).some((x) => x.id === p.method_id && x.state === "active") && Object.hasOwn(conclusions, p.conclusion), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 \u0438 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435");
        const c = practicalCriteria(db, p.method_id);
        invariant(c.length === 11 && Array.isArray(p.responses) && p.responses.length === 11, "\u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043E\u0442\u0432\u0435\u0442\u0438\u0442\u044C \u043D\u0430 \u0432\u0441\u0435 11 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
        p.responses.forEach((x, i) => {
          exact2(x, ["criterion_id", "value", "note"]);
          invariant(x.criterion_id === c[i].id && (x.value === 0 || x.value === 1) && text2(x.note), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043E\u0446\u0435\u043D\u043A\u0438");
        });
        store(db, t, { ...common, method_id: p.method_id, responses_json: canonical(p.responses), conclusion: p.conclusion });
      } else {
        exact2(p, ["command", "assignment_id", "assignment_rev", "evaluator_id", "assessed_on", "practical_id", "observation_state", "level", "valid_until", "evidence", "feedback"]);
        invariant(p.command === "qualification" && ["rated", "not_observed", "not_applicable"].includes(p.observation_state) && required(p.evidence), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E\u0431 \u0443\u0440\u043E\u0432\u043D\u0435 \u043D\u0430\u0432\u044B\u043A\u0430");
        const practical = latestAssessment(db, a.id, "practical");
        invariant(practical && practical.id === p.practical_id && p.assessed_on >= practical.assessed_at.slice(0, 10), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u044E\u044E \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u043E\u0446\u0435\u043D\u043A\u0443 \u044D\u0442\u043E\u0433\u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F");
        invariant(p.valid_until === null || period(p.assessed_on, p.valid_until), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0441\u0440\u043E\u043A \u0443\u0440\u043E\u0432\u043D\u044F");
        if (p.observation_state === "rated") level(db, a.scale_id, p.level);
        else invariant(p.level === null && p.valid_until === null, "\u041D\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u043B\u043E\u0441\u044C / \u043D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E \u2014 \u043D\u0435 \u0447\u0438\u0441\u043B\u043E\u0432\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430");
        store(db, t, { ...common, practical_id: practical.id, notes: p.evidence });
        store(db, "assessment_item", { id: e.id, session_id: id, skill_id: a.skill_id, scale_id: a.scale_id, level: p.level, observation_state: p.observation_state, valid_until: p.valid_until, evidence_note: p.evidence });
      }
      db.run("UPDATE assessment_session SET state='confirmed' WHERE id=?", [id]);
      update(db, "training_assignment", a.id, { state: a.state });
      return;
    }
    if (t === "admission_decision") {
      if (old) {
        changeOnly(e, old);
        exact2(p, ["command", "reason"]);
        invariant(p.command === "revoke" && old.decision === "granted" && !old.revoked_at && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0442\u0437\u044B\u0432\u0430 \u0434\u043E\u043F\u0443\u0441\u043A\u0430");
        update(db, t, id, { revoked_at: e.occurred_at, revoke_reason: p.reason });
        return;
      }
      createOnly(e, old);
      exact2(p, ["assignment_id", "assignment_rev", "actor_id", "decided_on", "valid_until", "decision", "evidence", "feedback"]);
      const a = freshAssignment(db, p);
      person(db, p.actor_id);
      noFuture(p.decided_on, e);
      invariant(a.state !== "cancelled" && a.approval_json && isCurrentStandard(db, a.sop_revision_id) && p.actor_id !== a.trainee_id && p.decided_on >= a.assigned_on && p.decided_on >= JSON.parse(a.approval_json).approved_on && period(p.decided_on, p.valid_until) && ["granted", "denied"].includes(p.decision) && required(p.evidence) && required(p.feedback), "\u0414\u043E\u043F\u0443\u0441\u043A \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u044F\u0432\u043D\u043E\u0433\u043E \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E, \u0434\u0430\u0442\u044B, \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u043E\u0431\u0440\u0430\u0442\u043D\u043E\u0439 \u0441\u0432\u044F\u0437\u0438");
      const q = latestAssessment(db, a.id, "qualification"), pr = latestAssessment(db, a.id, "practical"), s = latestVerification(db, a.id, "safety"), th = latestVerification(db, a.id, "theory");
      const previous = latest(db, "admission_decision", "person_id=? AND operation_id=?", [a.trainee_id, a.operation_id], "decided_on");
      invariant(!previous || p.decided_on >= previous.decided_on, "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0434\u043C\u0435\u043D\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0431\u043E\u043B\u0435\u0435 \u0440\u0430\u043D\u043D\u0438\u043C \u0440\u0435\u0448\u0435\u043D\u0438\u0435\u043C");
      if (p.decision === "granted") {
        const item = q && one(db, "SELECT * FROM assessment_item WHERE session_id=?", [q.id]);
        invariant(pr && q && q.practical_id === pr.id && pr.conclusion !== "not_meet" && item?.observation_state === "rated" && (!item.valid_until || item.valid_until >= p.decided_on) && s?.result === "pass" && th?.result === "pass" && [q.assessed_at, pr.assessed_at, s.evaluated_on, th.evaluated_on].every((x) => x.slice(0, 10) <= p.decided_on), "\u041D\u0443\u0436\u043D\u044B \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430, \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C, \u043F\u043E\u043B\u043E\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u041E\u0422 \u0438 \u0442\u0435\u043E\u0440\u0438\u0438. \u041F\u0440\u043E\u0446\u0435\u043D\u0442 \u0441\u0430\u043C \u043F\u043E \u0441\u0435\u0431\u0435 \u043D\u0435 \u0432\u044B\u0434\u0430\u0451\u0442 \u0434\u043E\u043F\u0443\u0441\u043A.");
      } else invariant(p.valid_until === null, "\u041E\u0442\u043A\u0430\u0437 \u043D\u0435 \u0438\u043C\u0435\u0435\u0442 \u0441\u0440\u043E\u043A\u0430 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F");
      const { assignment_rev, ...data } = p;
      store(db, t, { id, ...data, person_id: a.trainee_id, operation_id: a.operation_id, revision_id: a.sop_revision_id, qualification_id: q?.id || null, practical_id: pr?.id || null, safety_id: s?.id || null, theory_id: th?.id || null, recorded_at: e.occurred_at, rev: 1 });
      update(db, "training_assignment", a.id, { state: a.state });
      return;
    }
    if (t === "role_requirement") {
      if (old) {
        changeOnly(e, old);
        exact2(p, ["command", "valid_to"]);
        invariant(p.command === "close" && !old.valid_to && period(old.valid_from, p.valid_to) && p.valid_to, "\u0417\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0434\u0430\u0442\u043E\u0439");
        update(db, t, id, { valid_to: p.valid_to });
        return;
      }
      createOnly(e, old);
      exact2(p, ["profession_id", "skill_id", "scale_id", "required_level", "criticality", "valid_from", "valid_to"]);
      active(db, "profession", p.profession_id);
      active(db, "skill", p.skill_id);
      level(db, p.scale_id, p.required_level);
      invariant(period(p.valid_from, p.valid_to) && ["normal", "important", "critical"].includes(p.criticality) && !one(db, "SELECT id FROM role_requirement WHERE profession_id=? AND skill_id=? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=?", [p.profession_id, p.skill_id, p.valid_to || "9999-12-31", p.valid_from]), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0438\u043B\u0438 \u043F\u0435\u0440\u0435\u0441\u0435\u043A\u0430\u044E\u0449\u0435\u0435\u0441\u044F \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435");
      store(db, t, { id, ...p, rev: 1 });
      return;
    }
    if (t === "coverage_requirement") {
      exact2(p, ["unit_id", "skill_id", "shift_code", "min_people", "scale_id", "required_level"]);
      active(db, "org_unit", p.unit_id);
      active(db, "skill", p.skill_id);
      level(db, p.scale_id, p.required_level);
      invariant(text2(p.shift_code, 100) && (!p.shift_code || one(db, "SELECT id FROM work_shift WHERE code=? AND archived=0", [p.shift_code])) && integer(p.min_people, 0, 1e5), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u044F");
      if (old) {
        changeOnly(e, old);
        invariant(old.unit_id === p.unit_id && old.skill_id === p.skill_id && old.shift_code === p.shift_code, "\u041E\u0431\u043B\u0430\u0441\u0442\u044C \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
        update(db, t, id, p);
      } else {
        createOnly(e, old);
        store(db, t, { id, ...p, rev: 1 });
      }
      return;
    }
    if (t === "development_plan") {
      if (!old) {
        createOnly(e, old);
        exact2(p, ["person_id", "title", "start_on", "due_on"]);
        person(db, p.person_id);
        invariant(required(p.title) && period(p.start_on, p.due_on) && p.due_on, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0446\u0435\u043B\u044C \u0438 \u043F\u0435\u0440\u0438\u043E\u0434 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F");
        store(db, t, { id, ...p, state: "active", rev: 1 });
        return;
      }
      changeOnly(e, old);
      exact2(p, ["command", "reason"]);
      invariant(old.state === "active" && ["finish", "cancel"].includes(p.command) && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043F\u043E \u043F\u043B\u0430\u043D\u0443");
      if (p.command === "finish") invariant(!!one(db, "SELECT id FROM development_goal WHERE plan_id=?", [id]) && !one(db, "SELECT id FROM development_goal WHERE plan_id=? AND state='open'", [id]), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0446\u0435\u043B\u0438 \u043F\u043B\u0430\u043D\u0430");
      if (p.command === "cancel") db.run("UPDATE development_goal SET state='cancelled',rev=rev+1 WHERE plan_id=? AND state='open'", [id]);
      update(db, t, id, { state: p.command === "finish" ? "completed" : "cancelled" });
      return;
    }
    if (t === "development_goal") {
      if (!old) {
        createOnly(e, old);
        exact2(p, ["plan_id", "skill_id", "scale_id", "target_level", "title", "due_on"]);
        const plan = one(db, "SELECT * FROM development_plan WHERE id=? AND state=?", [p.plan_id, "active"]);
        invariant(plan && required(p.title) && period(plan.start_on, p.due_on) && p.due_on && p.due_on <= plan.due_on, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u043F\u043B\u0430\u043D \u0438 \u0441\u0440\u043E\u043A \u0446\u0435\u043B\u0438");
        if (p.skill_id) {
          active(db, "skill", p.skill_id);
          level(db, p.scale_id, p.target_level);
        } else invariant(p.scale_id === null && p.target_level === null, "\u0411\u0435\u0437 \u043D\u0430\u0432\u044B\u043A\u0430 \u043D\u0435 \u0432\u044B\u0431\u0438\u0440\u0430\u0435\u0442\u0441\u044F \u0443\u0440\u043E\u0432\u0435\u043D\u044C");
        store(db, t, { id, plan_id: p.plan_id, skill_id: p.skill_id, title: p.title, target_json: canonical({ scale_id: p.scale_id, target_level: p.target_level }), due_on: p.due_on, state: "open", rev: 1 });
        return;
      }
      changeOnly(e, old);
      exact2(p, ["command", "reason"]);
      invariant(old.state === "open" && ["finish", "cancel"].includes(p.command) && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0446\u0435\u043B\u0438");
      update(db, t, id, { state: p.command === "finish" ? "completed" : "cancelled" });
      return;
    }
    invariant(false, "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435 LC4");
  }
  function matrixData(db, day) {
    const people = rows(db, `SELECT p.id,p.display_name,p.employee_code,a.profession_id,a.position_id,a.unit_id,a.shift_id,a.shift_code FROM person p LEFT JOIN person_assignment a ON a.id=(SELECT id FROM person_assignment a2 WHERE a2.person_id=p.id AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? ORDER BY valid_from DESC,id LIMIT 1) WHERE p.archived=0 ORDER BY p.display_name,p.employee_code`, [day, day]);
    const skills = rows(db, "SELECT s.*,c.name category FROM skill s JOIN skill_category c ON c.id=s.category_id WHERE s.archived=0 AND c.archived=0 ORDER BY c.name,s.name");
    const requirements = rows(db, "SELECT * FROM role_requirement WHERE valid_from<=? AND coalesce(valid_to,'9999-12-31')>=?", [day, day]);
    const req = new Map(requirements.map((x) => [x.profession_id + ":" + x.skill_id, x]));
    const facts = rows(db, `SELECT * FROM (SELECT i.*,s.person_id,s.assessed_at,s.standard_revision_id,s.evaluator_id,s.assignment_id,s.recorded_at,
 ROW_NUMBER() OVER(PARTITION BY s.person_id,i.skill_id ORDER BY s.assessed_at DESC,coalesce(s.recorded_at,'') DESC,s.id DESC) rn
 FROM assessment_item i JOIN assessment_session s ON s.id=i.session_id WHERE s.state='confirmed' AND substr(s.assessed_at,1,10)<=?) WHERE rn=1`, [day]);
    const observed = new Map(facts.map((x) => [x.person_id + ":" + x.skill_id, x]));
    const records = rows(db, `SELECT * FROM (SELECT a.*,ROW_NUMBER() OVER(PARTITION BY person_id,operation_id ORDER BY decided_on DESC,recorded_at DESC,id DESC) rn FROM admission_decision a WHERE decided_on<=?) WHERE rn=1`, [day]);
    const admissions = new Map(records.map((a) => [a.person_id + ":" + a.operation_id, admissionRecordStatus(db, a, day)]));
    const current = new Set(rows(db, "SELECT r.id FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.state='effective' AND d.archived=0").map((x) => x.id));
    const cells = /* @__PURE__ */ new Map();
    for (const p of people) for (const s of skills) {
      const goal = req.get(p.profession_id + ":" + s.id) || null, fact = observed.get(p.id + ":" + s.id) || null, same = !goal || fact?.scale_id === goal.scale_id;
      const valid = !!(fact?.observation_state === "rated" && (!fact.valid_until || fact.valid_until >= day)), revisionCurrent = !s.operation_id || !!(fact?.standard_revision_id && current.has(fact.standard_revision_id));
      const adm = s.operation_id ? admissions.get(p.id + ":" + s.operation_id) || { record: null, status: "\u041D\u0435\u0442 \u0440\u0435\u0448\u0435\u043D\u0438\u044F", current: false } : null;
      cells.set(p.id + ":" + s.id, { goal, fact, same, valid, revisionCurrent, admission: adm, gap: !!(goal && (!valid || !same || !revisionCurrent || fact.level < goal.required_level)), qualified: !!(valid && same && revisionCurrent && (!goal || fact.level >= goal.required_level) && (!adm || adm.current && adm.record.revision_id === fact.standard_revision_id)) });
    }
    return { people, skills, cells };
  }
  function coverageData(db, day, matrix = matrixData(db, day)) {
    return rows(db, "SELECT * FROM coverage_requirement ORDER BY unit_id,skill_id,shift_code").map((r) => {
      const skill = matrix.skills.find((s) => s.id === r.skill_id), scope = matrix.people.filter((p) => p.unit_id === r.unit_id && (!r.shift_code || p.shift_code === r.shift_code || one(db, "SELECT code FROM work_shift WHERE id=?", [p.shift_id])?.code === r.shift_code));
      const actual = scope.filter((p) => {
        const c = matrix.cells.get(p.id + ":" + r.skill_id);
        return c?.valid && c.revisionCurrent && c.fact.scale_id === r.scale_id && c.fact.level >= r.required_level && (!skill?.operation_id || c.admission?.current && c.admission.record.revision_id === c.fact.standard_revision_id);
      }).length;
      return { ...r, actual, deficit: Math.max(0, r.min_people - actual), fraction: r.min_people ? actual / r.min_people : null, scope: scope.length };
    });
  }

  // src/modules/library/stage43-checklist.js
  var scores = [0, 0.3, 0.7, 1];
  var origins = ["seed", "auto", "manual", "legacy"];
  var text3 = (v, n) => typeof v === "string" && v.length <= n;
  var exact3 = (x, ks) => x && typeof x === "object" && !Array.isArray(x) && Object.keys(x).length === ks.length && ks.every((k) => Object.hasOwn(x, k));
  function validateRows(data) {
    invariant(Array.isArray(data) && data.length === 13, "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 Stage43 \u0434\u043E\u043B\u0436\u0435\u043D \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C 13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    data.forEach((x, i) => invariant(exact3(x, ["id", "req", "weight", "score", "comment", "scoreSource"]) && x.id === i + 1 && text3(x.req, 2500) && x.req.trim() && Number.isFinite(x.weight) && x.weight > 0 && x.weight <= 100 && scores.includes(x.score) && text3(x.comment, 2e3) && origins.includes(x.scoreSource), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0439 Stage43 " + (i + 1)));
    return data;
  }
  function stage43Checklist(constructor) {
    const raw = constructor?.checklist;
    if (raw == null) return [];
    invariant(Array.isArray(raw), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0430");
    if (!raw.length) return [];
    return validateRows(raw.map((x) => ({ id: x.id, req: x.req, weight: x.weight, score: x.score, comment: x.comment ?? "", scoreSource: origins.includes(x.scoreSource) ? x.scoreSource : "legacy" })));
  }
  function weightedResult(data) {
    const weight = data.reduce((n, x) => n + x.weight, 0), points = data.reduce((n, x) => n + x.score * x.weight, 0);
    return { weight, points, fraction: weight ? points / weight : null, seed: data.filter((x) => x.scoreSource === "seed").length };
  }
  function stage43Checks(db, revisionId) {
    return rows(db, "SELECT * FROM sop_stage43_checklist WHERE revision_id=? ORDER BY updated_at DESC", [revisionId]);
  }
  function verifyStage43Checklist(p, original) {
    invariant(exact3(p, ["revision_id", "source", "rows", "actor_id"]) && isId(p.revision_id) && (p.actor_id === null || isId(p.actor_id)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430");
    const proposed = validateRows(p.rows), base = stage43Checklist(original);
    invariant(base.length === 13, "\u0423 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0421\u041E\u041F \u043D\u0435\u0442 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430 Stage43");
    proposed.forEach((x, i) => {
      const y = base[i];
      invariant(x.id === y.id && x.req === y.req && x.weight === y.weight, "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u0432\u0435\u0441\u0430 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0439 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u044B");
      invariant(x.scoreSource === "manual" || x.scoreSource === y.scoreSource && x.score === y.score, "\u0418\u0437\u043C\u0435\u043D\u0451\u043D\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043E\u0442\u043C\u0435\u0447\u0435\u043D\u0430 \u043A\u0430\u043A \u0440\u0443\u0447\u043D\u0430\u044F");
    });
    return proposed;
  }
  function applyStage43Checklist(db, e, old) {
    const p = e.payload;
    invariant(exact3(p, ["revision_id", "source", "rows", "actor_id"]) && isId(p.revision_id) && (p.actor_id === null || isId(p.actor_id)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430");
    const data = validateRows(p.rows), v = one(db, "SELECT r.payload_json,d.archived FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.id=? AND d.kind=?", [p.revision_id, "sop"]);
    invariant(v && !v.archived && p.source?.kind === "sop" && canonical(JSON.parse(v.payload_json).source) === canonical(p.source), "\u0418\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u0421\u041E\u041F \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D");
    const person2 = p.actor_id ? one(db, "SELECT display_name FROM person WHERE id=? AND archived=0", [p.actor_id]) : null;
    invariant(!p.actor_id || person2, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u043E\u0446\u0435\u043D\u0449\u0438\u043A\u0430");
    if (e.operation === "create") {
      invariant(!old && !one(db, "SELECT id FROM sop_stage43_checklist WHERE revision_id=? AND source_sha256=?", [p.revision_id, p.source.sha256]), "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u044D\u0442\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0443\u0436\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D");
      db.run("INSERT INTO sop_stage43_checklist(id,revision_id,source_sha256,rows_json,actor_id,actor_name,updated_at,rev) VALUES(?,?,?,?,?,?,?,1)", [e.entity_id, p.revision_id, p.source.sha256, canonical(data), p.actor_id, person2?.display_name || "", e.occurred_at]);
    } else {
      invariant(e.operation === "update" && old && old.revision_id === p.revision_id && old.source_sha256 === p.source.sha256, "\u041D\u0435\u043B\u044C\u0437\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0443 \u0438\u043B\u0438 \u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0447\u0435\u043A-\u043B\u0438\u0441\u0442");
      const prior = validateRows(JSON.parse(old.rows_json));
      data.forEach((x, i) => invariant(x.id === prior[i].id && x.req === prior[i].req && x.weight === prior[i].weight, "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430"));
      db.run("UPDATE sop_stage43_checklist SET rows_json=?,actor_id=?,actor_name=?,updated_at=?,rev=rev+1 WHERE id=?", [canonical(data), p.actor_id, person2?.display_name || "", e.occurred_at, e.entity_id]);
    }
  }

  // src/modules/library/domain.js
  var DOMAIN_TYPES = Object.freeze({ document: "\u0411\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0421\u041E\u041F", frv_study: "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u0424\u0420\u0412", checklist_version: "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F", sop_evaluation: "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F", sop_stage43_checklist: "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 Stage43", ...TRAINING_TYPES });
  var MAX_CONTENT = 30 * 1024 * 1024;
  var MIME = { sop: "application/vnd.lean.stage43.sop+json", frv: "application/vnd.lean.stage43.frv+json" };
  var encoder = new TextEncoder();
  var obj = (x) => x && typeof x === "object" && !Array.isArray(x);
  var string = (x, max = 2e4) => typeof x === "string" && x.length <= max;
  var nonempty = (x, max = 500) => string(x, max) && x.trim().length > 0;
  var date2 = (x) => string(x, 10) && /^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x;
  var digest = (x) => typeof x === "string" && /^[0-9a-f]{64}$/.test(x);
  var types = /* @__PURE__ */ new Set(["VA", "NVA_Necessary", "NVA_Waste", "WAIT", "BREAK", "OTHER"]);
  var exact4 = (p, keys) => invariant(obj(p) && Object.keys(p).length === keys.length && keys.every((k) => Object.hasOwn(p, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u0441\u043E\u0431\u044B\u0442\u0438\u044F LC3");
  var num = (x) => typeof x === "number" && Number.isFinite(x) && x >= 0;
  var safeImage = (x) => string(x, MAX_CONTENT) && /^data:image\/(?:jpeg|png|webp|gif);base64,[A-Za-z0-9+/]+={0,2}$/i.test(x);
  function validateRef(ref) {
    exact4(ref, ["sha256", "size", "kind"]);
    invariant(digest(ref.sha256) && Number.isSafeInteger(ref.size) && ref.size > 0 && ref.size <= MAX_CONTENT && Object.hasOwn(MIME, ref.kind), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0441\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B");
    return ref;
  }
  async function checkContent(ref, text4) {
    validateRef(ref);
    invariant(typeof text4 === "string" && text4.length <= MAX_CONTENT, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0432\u0435\u043B\u0438\u043A");
    const bytes = encoder.encode(text4);
    invariant(bytes.length === ref.size && await sha256(bytes) === ref.sha256, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D: " + ref.sha256);
    return text4;
  }
  function verifyPeople(source, kind) {
    const refs = source.leanCenterPeople;
    if (refs === void 0) return;
    invariant(Array.isArray(refs) && refs.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0441\u0441\u044B\u043B\u043A\u0438 \u043D\u0430 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432");
    const seen = /* @__PURE__ */ new Set(), single = /* @__PURE__ */ new Set();
    for (const x of refs) {
      exact4(x, ["slot", "person_id", "employee_code", "display_name", "position", "unit"]);
      invariant(isId(x.person_id) && nonempty(x.display_name, 500) && nonempty(x.employee_code, 200) && string(x.position, 500) && string(x.unit, 500) && string(x.slot, 100), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0441\u043D\u0438\u043C\u043E\u043A \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
      const key3 = x.slot + ":" + x.person_id;
      invariant(!seen.has(key3), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u0441\u044B\u043B\u043A\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
      seen.add(key3);
      if (x.slot !== "sop_observer") {
        invariant(!single.has(x.slot), "\u0414\u0432\u0430 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0432 \u043E\u0434\u043D\u043E\u043C \u043F\u043E\u043B\u0435");
        single.add(x.slot);
      }
      let name, post = null;
      if (kind === "frv") {
        invariant(["operator", "observer"].includes(x.slot), "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u0430\u044F \u0440\u043E\u043B\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0432 \u0424\u0420\u0412");
        name = source[x.slot];
      } else if (x.slot === "approver") {
        name = source.meta.approverName;
        post = source.meta.approverPost || "";
      } else if (x.slot === "sop_observer") {
        invariant(String(source.frvMeta?.observers || "").split(/\r?\n/).includes(x.display_name), "\u0421\u043D\u0438\u043C\u043E\u043A \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u0435\u043B\u044F \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043F\u0435\u0447\u0430\u0442\u043D\u043E\u043C\u0443 \u043F\u043E\u043B\u044E");
        continue;
      } else if (["trainer", "trainee"].includes(x.slot)) name = source.twi?.[x.slot];
      else {
        const m = /^(workgroup|agree):(\d+)$/.exec(x.slot);
        invariant(m, "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u0430\u044F \u0440\u043E\u043B\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0432 \u0421\u041E\u041F");
        if (m[1] === "workgroup") name = source.responsibles?.[Number(m[2])];
        else {
          const a = source.agreedList?.[Number(m[2])];
          name = a?.name;
          post = a?.post || "";
        }
      }
      invariant(name === x.display_name && (post === null || post === x.position), "\u0421\u043D\u0438\u043C\u043E\u043A \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043F\u0435\u0447\u0430\u0442\u043D\u044B\u043C \u043F\u043E\u043B\u044F\u043C");
    }
  }
  async function inspectSource(text4, kind) {
    invariant(Object.hasOwn(MIME, kind) && typeof text4 === "string" && text4.length <= MAX_CONTENT, "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u0438\u043F \u0438\u043B\u0438 \u0440\u0430\u0437\u043C\u0435\u0440 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430");
    const bytes = encoder.encode(text4);
    invariant(bytes.length > 0 && bytes.length <= MAX_CONTENT, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u043D\u0435 \u0434\u043E\u043B\u0436\u0435\u043D \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0442\u044C 30 \u041C\u0411");
    const p = JSON.parse(text4);
    invariant(obj(p), "\u041E\u0436\u0438\u0434\u0430\u043B\u0441\u044F JSON Stage43");
    let projection;
    if (kind === "sop") {
      invariant(p.schemaVersion === 2 && obj(p.document) && Object.hasOwn(p, "constructor") && obj(p.constructor) && Array.isArray(p.constructor.steps) && obj(p.photoAssets) && p.integrity?.algorithm === "SHA-256" && digest(p.integrity.sha256), "\u041E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u0421\u041E\u041F Stage43 \u0441 SHA-256");
      const base = { schemaVersion: p.schemaVersion, document: p.document, constructor: p.constructor, photoAssets: p.photoAssets };
      invariant(await sha256(JSON.stringify(base)) === p.integrity.sha256, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C\u043E\u0433\u043E \u0421\u041E\u041F \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
      const s = p.constructor, d = p.document, seen = /* @__PURE__ */ new Set();
      invariant(obj(s.meta) && s.steps.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0448\u0430\u0433\u0438 \u0421\u041E\u041F");
      verifyPeople(s, "sop");
      const steps = s.steps.map((st) => {
        invariant(obj(st) && Number.isSafeInteger(st.id) && st.id > 0 && !seen.has(st.id) && string(st.action) && Array.isArray(st.keyMoments) && st.keyMoments.length <= 5 && st.keyMoments.every((x) => string(x)) && string(st.reason) && num(st.durationSeconds) && typeof st.hasPhoto === "boolean", "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0448\u0430\u0433 \u0421\u041E\u041F");
        seen.add(st.id);
        if (st.hasPhoto) {
          const a = p.photoAssets[String(st.id)];
          invariant(obj(a) && safeImage(a.original) && (!a.rendered || safeImage(a.rendered)), "\u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u043D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u043E\u0435 \u0444\u043E\u0442\u043E \u0448\u0430\u0433\u0430 " + st.id);
        }
        return { source_id: String(st.id), action: st.action, key_points: st.keyMoments, reason: st.reason, seconds: st.durationSeconds, photo: st.hasPhoto };
      });
      invariant(Object.keys(p.photoAssets).every((k) => steps.some((st) => st.source_id === k && st.photo)), "\u0415\u0441\u0442\u044C \u0444\u043E\u0442\u043E \u0431\u0435\u0437 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u0448\u0430\u0433\u0430");
      projection = { title: String(s.meta.operation || "").slice(0, 500), number: String(d.number || s.meta.sopNumber || "").slice(0, 200), legacy_id: String(d.id || "").slice(0, 200), legacy_version: String(d.version ?? "").slice(0, 50), legacy_status: String(d.status || "").slice(0, 80), photos: steps.filter((x) => x.photo).length, twi: !!s.twi?.enabled, steps };
    } else {
      invariant(["FRV-1.2", "FRV-1.3"].includes(p.schemaVersion) && obj(p.study) && Array.isArray(p.cycles) && p.cycles.length <= 1e3, "\u041E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C \u043A\u043E\u043F\u0438\u044F \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u0424\u0420\u0412 FRV-1.2/1.3");
      verifyPeople(p.study, "frv");
      const seen = /* @__PURE__ */ new Set(), measurements = [];
      let complete = 0, unmeasured = 0, count = 0;
      for (const [i, c] of p.cycles.entries()) {
        invariant(obj(c) && Array.isArray(c.observations) && c.observations.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0446\u0438\u043A\u043B \u0424\u0420\u0412");
        let full = c.observations.length > 0;
        const phase = ["baseline", "improved", "unassigned"].includes(c.phase) ? c.phase : "unassigned";
        for (const o of c.observations) {
          count++;
          invariant(count <= 5e3 && obj(o) && nonempty(o.id, 200) && !seen.has(o.id) && string(o.actionRaw) && (!o.valueType || types.has(o.valueType)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435 \u0424\u0420\u0412");
          seen.add(o.id);
          const v = o.durationSec;
          invariant(v == null || num(v), "\u0412\u0440\u0435\u043C\u044F \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u0447\u0438\u0441\u043B\u043E\u043C \u0441\u0435\u043A\u0443\u043D\u0434 \u0438\u043B\u0438 null");
          if (v == null || !o.actionRaw.trim()) {
            unmeasured++;
            full = false;
            continue;
          }
          if (v === 0) full = false;
          measurements.push({ source_id: o.id, cycle: i + 1, phase, action: o.actionRaw, category: o.valueType || "OTHER", seconds: v });
        }
        if (full) complete++;
      }
      projection = { title: String(p.study.operationId || p.study.processDescription || p.study.studyId || "").slice(0, 500), number: String(p.study.studyId || "").slice(0, 200), legacy_id: String(p.study.libraryId || "").slice(0, 200), legacy_version: String(p.study.version || "").slice(0, 50), legacy_status: String(p.study.status || "").slice(0, 80), cycles: p.cycles.length, complete, unmeasured, measurements };
    }
    invariant(encoder.encode(canonical(projection)).length <= 2 * 1024 * 1024, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u0430\u044F \u043F\u0440\u043E\u0435\u043A\u0446\u0438\u044F \u0434\u043B\u044F \u043E\u0434\u043D\u043E\u0433\u043E \u043F\u0430\u043A\u0435\u0442\u0430; \u0440\u0430\u0437\u0434\u0435\u043B\u0438\u0442\u0435 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A");
    return { source: { sha256: await sha256(bytes), size: bytes.length, kind }, projection };
  }
  function refsForEvents(events) {
    const out = /* @__PURE__ */ new Map();
    for (const e of events || []) if (Object.hasOwn(DOMAIN_TYPES, e.entity_type) && e.payload?.source) {
      const r = validateRef(e.payload.source);
      out.set(r.sha256, r);
    }
    return [...out.values()];
  }
  function frvOriginSnapshot(db, revisionId) {
    const x = one(db, `SELECT o.study_id,o.source_sha256,o.created_at,f.title,f.state,f.context_json,a.byte_size,a.mime
 FROM sop_frv_origin o JOIN frv_study f ON f.id=o.study_id JOIN attachment a ON a.sha256=o.source_sha256
 WHERE o.revision_id=?`, [revisionId]);
    if (!x) return null;
    invariant(x.mime === MIME.frv, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0442\u0438\u043F \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0437\u0430\u043C\u0435\u0440\u043E\u0432");
    const source = validateRef({ sha256: x.source_sha256, size: x.byte_size, kind: "frv" });
    return { study_id: x.study_id, title: x.title, state: x.state, created_at: x.created_at, source, current: JSON.parse(x.context_json).source.sha256 === source.sha256 };
  }
  function refsForDb(db) {
    return rows(db, "SELECT sha256,byte_size,mime FROM attachment WHERE mime IN (?,?) ORDER BY sha256", [MIME.sop, MIME.frv]).map((x) => validateRef({ sha256: x.sha256, size: x.byte_size, kind: x.mime === MIME.sop ? "sop" : "frv" }));
  }
  function unionRefs(...groups) {
    const m = /* @__PURE__ */ new Map();
    for (const refs of groups) for (const ref of refs) {
      validateRef(ref);
      const old = m.get(ref.sha256);
      invariant(!old || canonical(old) === canonical(ref), "\u041D\u0435\u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430");
      m.set(ref.sha256, ref);
    }
    return [...m.values()];
  }
  async function verifyDomainEvents(events, readContent3) {
    const checked = /* @__PURE__ */ new Map();
    for (const e of events || []) {
      if (!Object.hasOwn(DOMAIN_TYPES, e.entity_type) || !e.payload?.source) continue;
      const ref = validateRef(e.payload.source);
      invariant(typeof readContent3 === "function", "\u041F\u0430\u043A\u0435\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043F\u043E\u043B\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432");
      let result = checked.get(ref.sha256);
      if (!result) {
        const text4 = await checkContent(ref, await readContent3(ref));
        result = await inspectSource(text4, ref.kind);
        result.raw = JSON.parse(text4);
        checked.set(ref.sha256, result);
      }
      if (isTrainingEvent(e)) {
        verifyTrainingSource(e, result.source, result.raw);
        continue;
      }
      if (e.entity_type === "sop_stage43_checklist") {
        invariant(ref.kind === "sop" && canonical(result.source) === canonical(ref), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430");
        verifyStage43Checklist(e.payload, result.raw.constructor);
        continue;
      }
      invariant(canonical(result.source) === canonical(ref) && canonical(result.projection) === canonical(e.payload.projection), "\u041F\u0440\u043E\u0435\u043A\u0446\u0438\u044F \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u043C \u0444\u0430\u0439\u043B\u043E\u043C");
    }
  }
  function register(db, ref) {
    validateRef(ref);
    const old = one(db, "SELECT * FROM attachment WHERE sha256=?", [ref.sha256]);
    if (old) {
      invariant(old.mime === MIME[ref.kind] && old.byte_size === ref.size, "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E");
      return;
    }
    db.run("INSERT INTO attachment(sha256,mime,byte_size,original_name) VALUES(?,?,?,?)", [ref.sha256, MIME[ref.kind], ref.size, ref.sha256 + ".json"]);
  }
  function link(db, ref, type, id) {
    register(db, ref);
    db.run("DELETE FROM attachment_link WHERE entity_type=? AND entity_id=? AND purpose='stage43-source'", [type, id]);
    db.run("INSERT INTO attachment_link(id,sha256,entity_type,entity_id,purpose) VALUES(?,?,?,?,?)", [id + ":source", ref.sha256, type, id, "stage43-source"]);
  }
  function active2(db, table, id) {
    invariant(isId(id) && one(db, "SELECT id FROM " + table + " WHERE id=? AND archived=0", [id]), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u0437\u0430\u043F\u0438\u0441\u044C: " + table);
  }
  function operation(db, id) {
    if (id !== null) active2(db, "operation", id);
  }
  function sourcePayload(p, kind) {
    validateRef(p.source);
    invariant(p.source.kind === kind && obj(p.projection) && nonempty(p.title) && string(p.projection.title, 500), "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435");
    return canonical({ source: p.source, projection: p.projection });
  }
  function docSteps(db, rid, p) {
    invariant(Array.isArray(p.projection.steps) && p.projection.steps.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0448\u0430\u0433\u0438");
    db.run("DELETE FROM document_step WHERE revision_id=?", [rid]);
    for (const [i, s] of p.projection.steps.entries()) {
      invariant(string(s.action) && Array.isArray(s.key_points) && s.key_points.every((x) => string(x)) && string(s.reason) && num(s.seconds), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0448\u0430\u0433");
      db.run("INSERT INTO document_step(id,revision_id,position,action_text,key_points_json,reason_text,duration_seconds) VALUES(?,?,?,?,?,?,?)", [rid + ":" + (i + 1), rid, i + 1, s.action, canonical(s.key_points), s.reason, s.seconds]);
    }
  }
  function revision(db, id, docId) {
    const r = one(db, "SELECT * FROM document_revision WHERE id=? AND document_id=?", [id, docId]);
    invariant(r, "\u0412\u0435\u0440\u0441\u0438\u044F \u043D\u0435 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0443");
    return r;
  }
  function openRevision(db, id) {
    return one(db, "SELECT id FROM document_revision WHERE document_id=? AND state IN ('draft','review','approved')", [id]);
  }
  function newRevision(db, e, p, version) {
    const payload = sourcePayload(p, "sop");
    register(db, p.source);
    db.run("INSERT INTO document_revision(id,document_id,version_no,state,payload_json,created_at) VALUES(?,?,?,'draft',?,?)", [e.id, e.entity_id, version, payload, e.occurred_at]);
    docSteps(db, e.id, p);
    link(db, p.source, "document_revision", e.id);
  }
  function applyDomainEvent(db, e, old) {
    const p = e.payload, id = e.entity_id;
    if (isTrainingEvent(e)) return applyTrainingEvent(db, e, old);
    if (e.entity_type === "checklist_version") return applySopMethod(db, e, old);
    if (e.entity_type === "sop_evaluation") return applySopEvaluation(db, e, old);
    if (e.entity_type === "sop_stage43_checklist") return applyStage43Checklist(db, e, old);
    if (e.entity_type === "document") {
      if (e.operation === "create") {
        exact4(p, ["command", "code", "title", "operation_id", "source", "projection"]);
        invariant(!old && p.command === "create" && nonempty(p.code, 200) && nonempty(p.title), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043D\u043E\u0432\u044B\u0439 \u0421\u041E\u041F");
        operation(db, p.operation_id);
        invariant(!rows(db, "SELECT code FROM document").some((x) => foldKey(x.code) === foldKey(p.code)), "\u041D\u043E\u043C\u0435\u0440 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442");
        db.run("INSERT INTO document(id,code,kind,operation_id,title,rev) VALUES(?,?,'sop',?,?,1)", [id, p.code.trim(), p.operation_id, p.title.trim()]);
        newRevision(db, e, p, 1);
        return;
      }
      invariant(old && !old.archived && old.kind === "sop", "\u0421\u041E\u041F \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D");
      if (e.operation === "archive") {
        invariant(p === null && !one(db, "SELECT id FROM document_revision WHERE document_id=? AND state NOT IN ('superseded','withdrawn')", [id]), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0432\u0435\u0434\u0438\u0442\u0435 \u0432\u0435\u0440\u0441\u0438\u0438 \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F");
        db.run("UPDATE document SET archived=1,rev=rev+1 WHERE id=?", [id]);
        return;
      }
      invariant(e.operation === "update" && obj(p), "\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441 \u0421\u041E\u041F");
      if (p.command === "passport") {
        exact4(p, ["command", "revision_id", "print_format", "changed_on"]);
        const v2 = revision(db, p.revision_id, id);
        invariant(v2.state === "draft", "\u041F\u0430\u0441\u043F\u043E\u0440\u0442 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0443 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430");
        invariant(["portrait", "landscape"].includes(p.print_format) && validDate(p.changed_on) && p.changed_on <= e.occurred_at.slice(0, 10), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u043E\u0440\u043C\u0430\u0442 \u0438 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
        const steps = rows(db, "SELECT * FROM document_step WHERE revision_id=?", [v2.id]);
        invariant(steps.length <= (p.print_format === "portrait" ? 9 : 12), "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0448\u0430\u0433\u043E\u0432 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u04103");
        const op = old.operation_id ? one(db, "SELECT * FROM operation WHERE id=? AND archived=0", [old.operation_id]) : null;
        const w = op?.workplace_id ? one(db, "SELECT * FROM workplace WHERE id=? AND archived=0", [op.workplace_id]) : null;
        const equipment = op?.equipment_id ? one(db, "SELECT * FROM equipment WHERE id=?", [op.equipment_id]) : null;
        db.run("UPDATE document_revision SET print_format=?,changed_on=?,review_due=?,workplace_id=?,workplace_name=?,equipment_name=? WHERE id=?", [p.print_format, p.changed_on, reviewDue(p.changed_on), w?.id || null, w?.name || null, equipment?.name || null, v2.id]);
        db.run("UPDATE document SET rev=rev+1 WHERE id=?", [id]);
        return;
      }
      if (p.command === "origin") {
        exact4(p, ["command", "revision_id", "study_id", "source_sha256"]);
        const v2 = revision(db, p.revision_id, id);
        invariant(v2.state === "draft", "\u0421\u0432\u044F\u0437\u044C \u0424\u0420\u0412 \u0437\u0430\u0434\u0430\u0451\u0442\u0441\u044F \u0443 \u043D\u043E\u0432\u043E\u0433\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430");
        const f = one(db, "SELECT * FROM frv_study WHERE id=?", [p.study_id]);
        invariant(f && f.state !== "archived" && f.operation_id === old.operation_id && JSON.parse(f.context_json).source.sha256 === p.source_sha256, "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C \u0438\u043B\u0438 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
        invariant(!one(db, "SELECT revision_id FROM sop_frv_origin WHERE revision_id=?", [v2.id]), "\u0421\u0432\u044F\u0437\u044C \u0441 \u0424\u0420\u0412 \u0443\u0436\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430");
        db.run("INSERT INTO sop_frv_origin VALUES(?,?,?,?)", [v2.id, f.id, p.source_sha256, e.occurred_at]);
        db.run("UPDATE document SET rev=rev+1 WHERE id=?", [id]);
        return;
      }
      if (p.command === "save" || p.command === "revise") {
        exact4(p, ["command", "revision_id", "title", "operation_id", "source", "projection"]);
        operation(db, p.operation_id);
        const payload = sourcePayload(p, "sop");
        if (p.command === "save") {
          const v2 = revision(db, p.revision_id, id);
          invariant(v2.state === "draft", "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A");
          db.run("UPDATE document_revision SET payload_json=?,print_format=NULL,changed_on=NULL,review_due=NULL,workplace_id=NULL,workplace_name=NULL,equipment_name=NULL WHERE id=?", [payload, v2.id]);
          docSteps(db, v2.id, p);
          link(db, p.source, "document_revision", v2.id);
        } else {
          invariant(p.revision_id === null && !openRevision(db, id), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E");
          const version = one(db, "SELECT max(version_no) n FROM document_revision WHERE document_id=?", [id]).n + 1;
          newRevision(db, e, p, version);
        }
        invariant(old.operation_id === p.operation_id || !one(db, "SELECT id FROM document_revision WHERE document_id=? AND state IN ('approved','effective','superseded','withdrawn')", [id]), "\u0421\u0432\u044F\u0437\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u043E\u0432\u0430\u0432\u0448\u0435\u0433\u043E \u0421\u041E\u041F \u0441 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0435\u0439 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
        db.run("UPDATE document SET title=?,operation_id=?,rev=rev+1 WHERE id=?", [p.title.trim(), p.operation_id, id]);
        return;
      }
      exact4(p, ["command", "revision_id", "actor_id", "note"]);
      const v = revision(db, p.revision_id, id);
      invariant(string(p.note, 2e3), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u043F\u0440\u0438\u043C\u0435\u0447\u0430\u043D\u0438\u0435");
      active2(db, "person", p.actor_id);
      const transitions = { submit: ["draft", "review"], return: ["review", "draft"], approve: ["review", "approved"], effect: ["approved", "effective"], withdraw: ["effective", "withdrawn"] };
      const tr = Object.hasOwn(transitions, p.command) && transitions[p.command];
      invariant(tr && v.state === tr[0], "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u043F\u0435\u0440\u0435\u0445\u043E\u0434 \u0441\u0442\u0430\u0442\u0443\u0441\u0430");
      if (["submit", "approve", "effect"].includes(p.command)) {
        active2(db, "operation", old.operation_id);
        const steps = rows(db, "SELECT action_text FROM document_step WHERE revision_id=?", [v.id]);
        invariant(steps.length && steps.every((s) => s.action_text.trim()), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0432\u0441\u0435\u0445 \u0448\u0430\u0433\u043E\u0432");
        invariant(v.print_format && v.changed_on && v.review_due, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043F\u0430\u0441\u043F\u043E\u0440\u0442: \u0444\u043E\u0440\u043C\u0430\u0442 \u04103 \u0438 \u0434\u0430\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
        invariant(steps.length <= (v.print_format === "portrait" ? 9 : 12), "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0448\u0430\u0433\u043E\u0432 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u0444\u043E\u0440\u043C\u0430\u0442 \u04103");
        invariant(v.workplace_id && one(db, "SELECT workplace_id FROM operation WHERE id=?", [old.operation_id])?.workplace_id === v.workplace_id, "\u041F\u0430\u0441\u043F\u043E\u0440\u0442: \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
        if (p.command !== "submit") {
          const src = JSON.parse(v.payload_json).projection;
          invariant(src.steps.every((s) => s.seconds > 0 && s.key_points.some((k) => k.trim()) && s.reason.trim() && s.photo), "\u041F\u0435\u0440\u0435\u0434 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435\u043C \u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0432\u0440\u0435\u043C\u044F, \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B, \u043F\u0440\u0438\u0447\u0438\u043D\u044B \u0438 \u0432\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044E \u0432\u0441\u0435\u0445 \u0448\u0430\u0433\u043E\u0432");
        }
      }
      if (p.command === "return" || p.command === "withdraw") invariant(p.note.trim(), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043F\u0440\u0438\u0447\u0438\u043D\u0443");
      if (p.command === "effect") {
        db.run("UPDATE document_revision SET state='superseded' WHERE document_id=? AND state='effective'", [id]);
        db.run("UPDATE document_revision SET state='effective',effective_at=? WHERE id=?", [e.occurred_at, v.id]);
      } else db.run("UPDATE document_revision SET state=? WHERE id=?", [tr[1], v.id]);
      if (p.command === "approve" || p.command === "return") db.run("INSERT INTO document_approval(id,revision_id,actor_id,decision,decided_at,note) VALUES(?,?,?,?,?,?)", [e.id, v.id, p.actor_id, p.command === "approve" ? "approved" : "returned", e.occurred_at, p.note]);
      db.run("UPDATE document SET rev=rev+1 WHERE id=?", [id]);
      return;
    }
    invariant(e.entity_type === "frv_study", "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435");
    if (e.operation === "archive") {
      invariant(old && old.state !== "archived" && p === null, "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E");
      db.run("UPDATE frv_study SET state='archived',rev=rev+1 WHERE id=?", [id]);
      return;
    }
    if (e.operation === "update" && p?.command === "finalize") {
      exact4(p, ["command", "actor_id", "note"]);
      active2(db, "person", p.actor_id);
      invariant(old?.state === "draft" && string(p.note, 2e3), "\u0424\u0438\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430");
      active2(db, "operation", old.operation_id);
      invariant(JSON.parse(old.context_json).projection.complete > 0, "\u041D\u0435\u0442 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u043D\u043E\u0433\u043E \u0446\u0438\u043A\u043B\u0430");
      db.run("UPDATE frv_study SET state='final',rev=rev+1 WHERE id=?", [id]);
      return;
    }
    exact4(p, ["command", "title", "operation_id", "observed_at", "source", "projection"]);
    invariant(date2(p.observed_at), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F");
    operation(db, p.operation_id);
    const context = sourcePayload(p, "frv");
    invariant(e.operation === "create" ? !old && p.command === "create" : old?.state === "draft" && p.command === "save", "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0424\u0420\u0412");
    if (!old) db.run("INSERT INTO frv_study(id,operation_id,title,observed_at,state,context_json,rev) VALUES(?,?,?,?,'draft',?,1)", [id, p.operation_id, p.title.trim(), p.observed_at, context]);
    else db.run("UPDATE frv_study SET operation_id=?,title=?,observed_at=?,context_json=?,rev=rev+1 WHERE id=?", [p.operation_id, p.title.trim(), p.observed_at, context, id]);
    db.run("DELETE FROM frv_measurement WHERE study_id=?", [id]);
    invariant(Array.isArray(p.projection.measurements) && p.projection.measurements.length <= 5e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F");
    for (const [i, m] of p.projection.measurements.entries()) {
      invariant(nonempty(m.action, 2e4) && types.has(m.category) && num(m.seconds), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0435");
      db.run("INSERT INTO frv_measurement(id,study_id,position,activity,category,duration_seconds,raw_json) VALUES(?,?,?,?,?,?,?)", [id + ":" + (i + 1), id, i + 1, m.action, m.category, m.seconds, canonical(m)]);
    }
    link(db, p.source, "frv_study", id);
  }

  // src/core/db.js
  var SCHEMA_VERSION = 7;
  var migration3 = null;
  var migration4 = null;
  var migration5 = null;
  var migration6 = null;
  var migration7 = null;
  function configureMigrations(sql, next, last, assessment, training) {
    invariant(typeof sql === "string" && sql.includes("PRAGMA user_version=3") && typeof next === "string" && next.includes("PRAGMA user_version=4") && typeof last === "string" && last.includes("PRAGMA user_version=5"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0439 LC2/LC3");
    migration3 = sql;
    migration4 = next;
    migration5 = last;
    invariant(typeof assessment === "string" && assessment.includes("PRAGMA user_version=6"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430");
    migration6 = assessment;
    invariant(typeof training === "string" && training.includes("PRAGMA user_version=7"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 LC4");
    migration7 = training;
  }
  var MAX_DB = 100 * 1024 * 1024;
  var MAX_PACKAGE = 5 * 1024 * 1024;
  var uuid = () => crypto.randomUUID();
  var now = () => (/* @__PURE__ */ new Date()).toISOString();
  var isId = (x) => typeof x === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x);
  var invariant = (ok, msg) => {
    if (!ok) throw new Error(msg);
  };
  var canonical = (x) => x === null || typeof x !== "object" ? JSON.stringify(x) : Array.isArray(x) ? "[" + x.map(canonical).join(",") + "]" : "{" + Object.keys(x).sort().map((k) => JSON.stringify(k) + ":" + canonical(x[k])).join(",") + "}";
  async function sha256(data) {
    const b = typeof data === "string" ? new TextEncoder().encode(data) : data;
    return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", b)), (x) => x.toString(16).padStart(2, "0")).join("");
  }
  function encode(bytes) {
    let s = "";
    for (let i = 0; i < bytes.length; i += 16384) s += String.fromCharCode(...bytes.subarray(i, i + 16384));
    return btoa(s);
  }
  function decode(s) {
    invariant(typeof s === "string" && s.length <= MAX_DB * 1.4, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0444\u0430\u0439\u043B \u0431\u0430\u0437\u044B");
    return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  }
  function rows(db, sql, args = []) {
    const st = db.prepare(sql);
    try {
      st.bind(args);
      const result = [];
      while (st.step()) result.push(st.getAsObject());
      return result;
    } finally {
      st.free();
    }
  }
  var one = (db, sql, args = []) => rows(db, sql, args)[0] || null;
  var meta = (db, key3) => one(db, "SELECT value FROM meta WHERE key=?", [key3])?.value || null;
  var setMeta = (db, key3, value) => db.run("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", [key3, value]);
  function tx(db, fn) {
    db.run("BEGIN IMMEDIATE");
    try {
      const value = fn();
      db.run("COMMIT");
      return value;
    } catch (e) {
      db.run("ROLLBACK");
      throw e;
    }
  }
  function bytesOf(db) {
    const bytes = db.export();
    db.run("PRAGMA foreign_keys=ON");
    return bytes;
  }
  function verifyDb(db, version = SCHEMA_VERSION) {
    invariant(one(db, "PRAGMA integrity_check")?.integrity_check === "ok", "\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u0430 \u0446\u0435\u043B\u043E\u0441\u0442\u043D\u043E\u0441\u0442\u044C SQLite");
    invariant(rows(db, "PRAGMA foreign_key_check").length === 0, "\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u044B \u0441\u0432\u044F\u0437\u0438 \u0431\u0430\u0437\u044B");
    invariant(Number(meta(db, "schema_version")) === version && one(db, "PRAGMA user_version").user_version === version, "\u0412\u0435\u0440\u0441\u0438\u044F \u0431\u0430\u0437\u044B \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F");
    invariant(isId(meta(db, "database_id")), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 ID \u0431\u0430\u0437\u044B");
    const p = meta(db, "publication_id");
    invariant(!p || one(db, "SELECT id FROM publication WHERE id=?", [p]), "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438");
  }
  function upgradeDb(db) {
    const version = Number(meta(db, "schema_version"));
    invariant([2, 3, 4, 5, 6, SCHEMA_VERSION].includes(version), "\u0412\u0435\u0440\u0441\u0438\u044F \u0431\u0430\u0437\u044B \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F: " + version);
    verifyDb(db, version);
    if (version === 2) {
      invariant(migration3, "\u041C\u0438\u0433\u0440\u0430\u0446\u0438\u044F LC2 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0430");
      invariant(!one(db, "SELECT person_id FROM person_role LIMIT 1"), "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u0440\u043E\u043B\u0438 legacy v1/v2. \u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u044F\u0432\u043D\u043E\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u0435\u0440\u0435\u0434 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0435\u0439; \u0438\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430.");
      db.run(migration3);
      verifyDb(db, 3);
    }
    if (version < 4) {
      invariant(migration4, "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 LC3");
      invariant(!one(db, "SELECT id FROM document LIMIT 1") && !one(db, "SELECT id FROM frv_study LIMIT 1"), "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u0440\u0430\u043D\u0435\u0435 \u043D\u0435 \u0438\u043D\u0442\u0435\u0433\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/\u0424\u0420\u0412; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u044F");
      db.run(migration4);
      verifyDb(db, 4);
    }
    if (version < 5) {
      db.run(migration5);
      verifyDb(db, 5);
    }
    if (version < 6) {
      db.run(migration6);
      verifyDb(db, 6);
    }
    if (version < 7) {
      db.run(migration7);
      verifyDb(db);
    }
    return db;
  }
  function openDb(SQL2, bytes, { upgrade = true } = {}) {
    invariant(bytes instanceof Uint8Array && bytes.length > 100 && bytes.length <= MAX_DB, "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u0440\u0430\u0437\u043C\u0435\u0440 \u0431\u0430\u0437\u044B");
    const d = new SQL2.Database(bytes);
    try {
      d.run("PRAGMA foreign_keys=ON");
      if (upgrade) upgradeDb(d);
      else verifyDb(d, Number(meta(d, "schema_version")));
      return d;
    } catch (e) {
      d.close();
      throw e;
    }
  }
  function createDb(SQL2, schema, migration, id = uuid()) {
    const d = new SQL2.Database();
    try {
      d.run(schema);
      d.run(migration);
      setMeta(d, "database_id", id);
      return upgradeDb(d);
    } catch (e) {
      d.close();
      throw e;
    }
  }
  var definitions = {
    org_unit: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, kind: { label: "\u0422\u0438\u043F", options: ["\u041F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", "\u0426\u0435\u0445", "\u0423\u0447\u0430\u0441\u0442\u043E\u043A", "\u0421\u043B\u0443\u0436\u0431\u0430", "\u0413\u0440\u0443\u043F\u043F\u0430"], required: true }, parent_id: { label: "\u0420\u043E\u0434\u0438\u0442\u0435\u043B\u044C", ref: "org_unit" } } },
    person: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438", fields: { employee_code: { label: "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440", required: true }, display_name: { label: "\u0424\u0418\u041E / \u0438\u043C\u044F", required: true } } },
    profession: { label: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    equipment: { label: "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    workplace: { label: "\u0420\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u0435\u0441\u0442\u0430", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    operation: { label: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u0438", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, equipment_id: { label: "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", ref: "equipment" }, workplace_id: { label: "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E", ref: "workplace" }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, criticality: { label: "\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u043E\u0441\u0442\u044C", options: ["normal", "important", "critical"], required: true } } },
    position: { label: "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    work_shift: { label: "\u0421\u043C\u0435\u043D\u044B", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    business_role: { label: "\u0420\u043E\u043B\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    person_assignment: { label: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", history: true, fields: { person_id: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ref: "person", required: true }, unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, profession_id: { label: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", ref: "profession" }, position_id: { label: "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", ref: "position" }, shift_id: { label: "\u0421\u043C\u0435\u043D\u0430", ref: "work_shift" }, shift_code: { label: "\u041A\u043E\u0434 \u0441\u043C\u0435\u043D\u044B LC1", legacy: true }, valid_from: { label: "\u041D\u0430\u0447\u0430\u043B\u043E", date: true, required: true }, valid_to: { label: "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", date: true } } },
    role_assignment: { label: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0440\u043E\u043B\u0435\u0439", history: true, fields: { person_id: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ref: "person", required: true }, role_id: { label: "\u0420\u043E\u043B\u044C", ref: "business_role", required: true }, valid_from: { label: "\u041D\u0430\u0447\u0430\u043B\u043E", date: true, required: true }, valid_to: { label: "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", date: true } } },
    skill_category: { label: "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043D\u0430\u0432\u044B\u043A\u043E\u0432", fields: { name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    skill: { label: "\u041D\u0430\u0432\u044B\u043A\u0438", fields: { category_id: { label: "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F", ref: "skill_category", required: true }, operation_id: { label: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", ref: "operation" }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    rating_scale: { label: "\u0428\u043A\u0430\u043B\u044B \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u043D\u0438\u044F", immutable: true, fields: { name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, version_no: { label: "\u0412\u0435\u0440\u0441\u0438\u044F", required: true, integer: true }, levels: { label: "\u0423\u0440\u043E\u0432\u043D\u0438 (\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435)", required: true, multiline: true, virtual: true } } }
  };
  var legacyTypes = /* @__PURE__ */ new Set(["org_unit", "person", "profession", "equipment", "operation", "person_assignment"]);
  var foldKey = (x) => String(x ?? "").normalize("NFKC").trim().toLocaleLowerCase("ru-RU");
  function parseLevels(text4) {
    invariant(typeof text4 === "string" && text4.length <= 5e3, "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u0435\u0439");
    const lines = text4.split(/\r?\n/).filter((x) => x.trim());
    invariant(lines.length >= 2 && lines.length <= 20, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0442 2 \u0434\u043E 20 \u0443\u0440\u043E\u0432\u043D\u0435\u0439");
    const levels = lines.map((line) => {
      const m = line.match(/^\s*(-?\d+)\s*:\s*(\S.*)$/);
      invariant(m, "\u041A\u0430\u0436\u0434\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C: \u0447\u0438\u0441\u043B\u043E: \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435");
      const value = Number(m[1]), label = m[2].trim();
      invariant(Number.isSafeInteger(value) && value >= 0 && value <= 1e3 && label.length <= 200, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C");
      return { value, label };
    });
    invariant(new Set(levels.map((x) => x.value)).size === levels.length, "\u041F\u043E\u0432\u0442\u043E\u0440 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0443\u0440\u043E\u0432\u043D\u044F");
    return levels.sort((a, b) => a.value - b.value);
  }
  function recordPayload(type, record) {
    const d = definitions[type];
    return Object.fromEntries(Object.entries(d.fields).map(([k, f]) => [k, record[k] == null ? null : String(record[k])]));
  }
  function list(db, type) {
    invariant(Object.hasOwn(definitions, type), "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A");
    const result = rows(db, "SELECT * FROM " + type + " ORDER BY " + (type === "person" ? "display_name" : definitions[type].history ? "valid_from DESC" : type === "rating_scale" ? "name,version_no" : "name"));
    if (type === "rating_scale") for (const v of result) v.levels = rows(db, "SELECT value,label FROM rating_level WHERE scale_id=? ORDER BY value", [v.id]).map((x) => x.value + ": " + x.label).join("\n");
    return result;
  }
  function identityKey(type, v) {
    if (type === "person") return foldKey(v.employee_code);
    if (type === "person_assignment") return [v.person_id, v.valid_from].join("|");
    if (type === "role_assignment") return [v.person_id, v.role_id, v.valid_from].join("|");
    if (type === "skill_category") return foldKey(v.name);
    if (type === "skill") return [v.category_id, foldKey(v.name)].join("|");
    if (type === "rating_scale") return [foldKey(v.name), Number(v.version_no)].join("|");
    if (["equipment", "operation", "workplace"].includes(type)) return [v.unit_id, foldKey(v.code)].join("|");
    return foldKey(v.code);
  }
  function normalize(db, type, p, id, old) {
    const def = definitions[type];
    invariant(def && p && typeof p === "object" && !Array.isArray(p), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u0438\u043F \u0437\u0430\u043F\u0438\u0441\u0438");
    const legacy = type === "person_assignment" && !Object.hasOwn(p, "position_id") && !Object.hasOwn(p, "shift_id");
    if (legacy) p = { ...p, position_id: old?.position_id ?? null, shift_id: old?.shift_id ?? null };
    if (type === "operation" && !Object.hasOwn(p, "workplace_id")) p = { ...p, workplace_id: old?.workplace_id ?? null };
    invariant(Object.keys(p).length === Object.keys(def.fields).length && Object.keys(p).every((k) => Object.hasOwn(def.fields, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u0437\u0430\u043F\u0438\u0441\u0438");
    const v = {};
    for (const [k, f] of Object.entries(def.fields)) {
      let x = p[k];
      invariant(x === null || typeof x === "string", "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: " + f.label);
      x = typeof x === "string" ? x.trim() : null;
      if (!x) x = null;
      invariant(!f.required || x !== null, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435: " + f.label);
      if (x !== null) {
        invariant(x.length <= (f.multiline ? 5e3 : 500), "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0434\u043B\u0438\u043D\u043D\u043E\u0435 \u043F\u043E\u043B\u0435");
        if (f.integer) invariant(/^\d+$/.test(x) && Number.isSafeInteger(Number(x)) && Number(x) > 0 && Number(x) <= 1e5, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0432\u0435\u0440\u0441\u0438\u0438");
        if (f.options) invariant(f.options.includes(x), "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: " + f.label);
        if (f.date) invariant(/^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0434\u0430\u0442\u0430");
        if (f.ref) {
          invariant(isId(x), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440");
          const ref = one(db, "SELECT * FROM " + f.ref + " WHERE id=?", [x]);
          invariant(ref && (!ref.archived || old?.[k] === x), "\u0421\u0441\u044B\u043B\u043A\u0430 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430: " + f.label);
        }
      }
      v[k] = x;
    }
    if (type === "org_unit") {
      let x = v.parent_id;
      const seen = /* @__PURE__ */ new Set([id]);
      while (x) {
        invariant(!seen.has(x), "\u0426\u0438\u043A\u043B \u0432 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0435");
        seen.add(x);
        x = one(db, "SELECT parent_id FROM org_unit WHERE id=?", [x])?.parent_id;
      }
    }
    if (type === "operation" && v.equipment_id) invariant(one(db, "SELECT unit_id FROM equipment WHERE id=?", [v.equipment_id])?.unit_id === v.unit_id, "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F");
    if (type === "operation" && v.workplace_id) invariant(one(db, "SELECT unit_id FROM workplace WHERE id=?", [v.workplace_id])?.unit_id === v.unit_id, "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F");
    if (type === "operation" && old && (v.workplace_id !== old.workplace_id || v.unit_id !== old.unit_id || v.equipment_id !== old.equipment_id)) invariant(!one(db, "SELECT r.id FROM document_revision r JOIN document d ON d.id=r.document_id WHERE d.operation_id=? AND r.state IN ('review','approved','effective','superseded','withdrawn') LIMIT 1", [id]), "\u041D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0441 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u044B\u043C\u0438 \u0421\u041E\u041F; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E");
    if (type === "workplace" && old && v.unit_id !== old.unit_id) invariant(!one(db, "SELECT id FROM operation WHERE workplace_id=? LIMIT 1", [id]), "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0441\u0432\u044F\u0437\u0430\u043D\u043E \u0441 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C\u0438");
    if (type === "equipment" && old && v.unit_id !== old.unit_id) invariant(!one(db, "SELECT id FROM operation WHERE equipment_id=? LIMIT 1", [id]), "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0442\u0438 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0441 \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u043C\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C\u0438");
    if (type === "person_assignment") {
      invariant(!v.valid_to || v.valid_to >= v.valid_from, "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 \u0440\u0430\u043D\u044C\u0448\u0435 \u043D\u0430\u0447\u0430\u043B\u0430");
      invariant(!v.shift_id || !v.shift_code, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043C\u0435\u043D\u0443 \u0438\u0437 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u043B\u0438\u0431\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043A\u043E\u0434, \u043D\u0435 \u043E\u0431\u0430");
      if (old) {
        for (const k of ["person_id", "unit_id", "profession_id", "position_id", "shift_id", "shift_code", "valid_from"]) invariant(old[k] === v[k], "\u0418\u0441\u0442\u043E\u0440\u0438\u044E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435");
        invariant(!old.valid_to || old.valid_to === v.valid_to, "\u0417\u0430\u043A\u0440\u044B\u0442\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u043E");
      }
      invariant(!one(db, "SELECT id FROM person_assignment WHERE person_id=? AND id<>? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? LIMIT 1", [v.person_id, id, v.valid_to || "9999-12-31", v.valid_from]), "\u041F\u0435\u0440\u0435\u0441\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
    }
    if (type === "role_assignment") {
      invariant(!v.valid_to || v.valid_to >= v.valid_from, "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 \u0440\u0430\u043D\u044C\u0448\u0435 \u043D\u0430\u0447\u0430\u043B\u0430");
      if (old) {
        for (const k of ["person_id", "role_id", "valid_from"]) invariant(old[k] === v[k], "\u0418\u0441\u0442\u043E\u0440\u0438\u044E \u0440\u043E\u043B\u0438 \u043D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435");
        invariant(!old.valid_to || old.valid_to === v.valid_to, "\u0417\u0430\u043A\u0440\u044B\u0442\u0430\u044F \u0440\u043E\u043B\u044C \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
      }
      invariant(!one(db, "SELECT id FROM role_assignment WHERE person_id=? AND role_id=? AND id<>? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? LIMIT 1", [v.person_id, v.role_id, id, v.valid_to || "9999-12-31", v.valid_from]), "\u041F\u0435\u0440\u0435\u0441\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043E\u0434\u043D\u043E\u0439 \u0440\u043E\u043B\u0438");
    }
    if (type === "rating_scale") {
      invariant(!old, "\u0428\u043A\u0430\u043B\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E");
      parseLevels(v.levels);
    }
    const key3 = identityKey(type, v);
    if (!old || identityKey(type, old) !== key3) invariant(!list(db, type).some((x) => x.id !== id && identityKey(type, x) === key3), "\u0414\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u043A\u043B\u044E\u0447\u0430 / UNIQUE");
    return v;
  }
  function validateEvent(e) {
    invariant(e && Object.keys(e).every((k) => ["id", "entity_type", "entity_id", "operation", "expected_revision", "payload", "occurred_at"].includes(k)) && isId(e.id) && isId(e.entity_id) && (Object.hasOwn(definitions, e.entity_type) || Object.hasOwn(DOMAIN_TYPES, e.entity_type)) && ["create", "update", "archive"].includes(e.operation) && Number.isSafeInteger(e.expected_revision) && e.expected_revision >= 0 && typeof e.occurred_at === "string" && !isNaN(Date.parse(e.occurred_at)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435");
  }
  function applyEvent(db, e, packageId = null) {
    validateEvent(e);
    const prev = one(db, "SELECT * FROM change_event WHERE id=?", [e.id]);
    if (prev) {
      invariant(prev.entity_type === e.entity_type && prev.entity_id === e.entity_id && prev.operation === e.operation && prev.expected_revision === e.expected_revision && prev.occurred_at === e.occurred_at && canonical(JSON.parse(prev.payload_json)) === canonical(e.payload), "\u041F\u043E\u0432\u0442\u043E\u0440 ID \u0441 \u0434\u0440\u0443\u0433\u0438\u043C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u044B\u043C");
      return false;
    }
    const t = e.entity_type, old = one(db, "SELECT * FROM " + t + " WHERE id=?", [e.entity_id]);
    invariant((old?.rev || 0) === e.expected_revision, "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0432\u0435\u0440\u0441\u0438\u0438: " + (definitions[t]?.label || DOMAIN_TYPES[t]) + " / " + e.entity_id + " (\u043E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C " + e.expected_revision + ", \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F " + (old?.rev || 0) + ")");
    if (Object.hasOwn(DOMAIN_TYPES, t)) applyDomainEvent(db, e, old);
    else if (e.operation === "create" || e.operation === "update") {
      invariant(e.operation === "create" ? !old : !!old && !old.archived, "\u041D\u0435\u043B\u044C\u0437\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u044D\u0442\u0443 \u0437\u0430\u043F\u0438\u0441\u044C");
      const p = normalize(db, t, e.payload, e.entity_id, old);
      const keys = Object.keys(p).filter((k) => !definitions[t].fields[k].virtual);
      const values = keys.map((k) => p[k]);
      if (!old) {
        db.run("INSERT INTO " + t + "(id," + keys.join(",") + ",rev) VALUES(" + Array(keys.length + 2).fill("?").join(",") + ")", [e.entity_id, ...values, 1]);
        if (t === "rating_scale") for (const l of parseLevels(p.levels)) db.run("INSERT INTO rating_level(scale_id,value,label) VALUES(?,?,?)", [e.entity_id, l.value, l.label]);
      } else db.run("UPDATE " + t + " SET " + keys.map((k) => k + "=?").join(",") + ",rev=rev+1 WHERE id=?", [...values, e.entity_id]);
    } else {
      invariant(old && !old.archived && !definitions[t].history && e.payload === null, "\u041D\u0435\u043B\u044C\u0437\u044F \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C");
      const date3 = e.occurred_at.slice(0, 10);
      const active4 = " AND (valid_to IS NULL OR valid_to>=?)";
      const deps = {
        org_unit: [["org_unit", "parent_id", false], ["equipment", "unit_id", false], ["workplace", "unit_id", false], ["operation", "unit_id", false], ["person_assignment", "unit_id", true]],
        person: [["person_assignment", "person_id", true], ["role_assignment", "person_id", true]],
        profession: [["person_assignment", "profession_id", true]],
        position: [["person_assignment", "position_id", true]],
        work_shift: [["person_assignment", "shift_id", true]],
        business_role: [["role_assignment", "role_id", true]],
        equipment: [["operation", "equipment_id", false]],
        workplace: [["operation", "workplace_id", false]],
        operation: [["skill", "operation_id", false]],
        skill_category: [["skill", "category_id", false]]
      };
      if (t === "person") invariant(!one(db, "SELECT id FROM training_assignment WHERE state IN('planned','in_progress') AND (trainee_id=? OR mentor_id=? OR supervisor_id=?) LIMIT 1", [e.entity_id, e.entity_id, e.entity_id]) && !one(db, "SELECT id FROM training_enrollment WHERE state='active' AND (trainee_id=? OR mentor_id=? OR manager_id=?) LIMIT 1", [e.entity_id, e.entity_id, e.entity_id]), "\u0417\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
      if (t === "skill" || t === "rating_scale") {
        const key3 = t === "skill" ? "skill_id" : "scale_id";
        invariant(!one(db, "SELECT id FROM training_assignment WHERE " + key3 + "=? AND state IN('planned','in_progress') LIMIT 1", [e.entity_id]) && !one(db, "SELECT id FROM role_requirement WHERE " + key3 + "=? AND coalesce(valid_to,'9999-12-31')>=? LIMIT 1", [e.entity_id, date3]) && !one(db, "SELECT id FROM coverage_requirement WHERE " + key3 + "=? LIMIT 1", [e.entity_id]), "\u0417\u0430\u043F\u0438\u0441\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F\u0445 \u0438\u043B\u0438 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0438");
      }
      if (t === "operation") invariant(!one(db, "SELECT id FROM document WHERE operation_id=? AND archived=0 LIMIT 1", [e.entity_id]) && !one(db, "SELECT id FROM frv_study WHERE operation_id=? AND state<>'archived' LIMIT 1", [e.entity_id]), "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441\u0432\u044F\u0437\u0430\u043D\u0430 \u0441 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u043C\u0438 \u0438\u043B\u0438 \u0424\u0420\u0412");
      for (const [table, column, history] of deps[t] || []) invariant(!one(db, "SELECT id FROM " + table + " WHERE " + column + "=?" + (history ? active4 : " AND archived=0") + " LIMIT 1", history ? [e.entity_id, date3] : [e.entity_id]), "\u0417\u0430\u043F\u0438\u0441\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0441\u0432\u044F\u0437\u044F\u0445; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u0443\u0439\u0442\u0435 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438");
      db.run("UPDATE " + t + " SET archived=1,rev=rev+1 WHERE id=?", [e.entity_id]);
    }
    db.run("INSERT INTO change_event(id,package_id,entity_type,entity_id,operation,expected_revision,payload_json,occurred_at) VALUES(?,?,?,?,?,?,?,?)", [e.id, packageId, t, e.entity_id, e.operation, e.expected_revision, canonical(e.payload), e.occurred_at]);
    return true;
  }
  async function makePackage(db, events, device) {
    invariant(events.length > 0 && events.length <= 2e3, "\u041D\u0435\u0442 \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u0438\u043B\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u043F\u0430\u043A\u0435\u0442\u0430");
    const body = { format: "lean-change-v1", id: uuid(), database_id: meta(db, "database_id"), base_publication_id: meta(db, "publication_id"), schema_version: SCHEMA_VERSION, device_id: device, created_at: now(), events: structuredClone(events) };
    const hash = await sha256(canonical(body));
    invariant(new TextEncoder().encode(canonical(body)).length < MAX_PACKAGE, "\u041F\u0430\u043A\u0435\u0442 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 5 \u041C\u0411");
    return { ...body, hash };
  }
  async function checkPackage(p) {
    invariant(p && typeof p === "object" && Object.keys(p).length === 9 && p.format === "lean-change-v1" && isId(p.id) && isId(p.database_id) && isId(p.device_id) && (p.base_publication_id === null || isId(p.base_publication_id)) && [2, 3, 4, 5, 6, SCHEMA_VERSION].includes(p.schema_version) && typeof p.created_at === "string" && !isNaN(Date.parse(p.created_at)) && Array.isArray(p.events) && p.events.length > 0 && p.events.length <= 2e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043F\u0430\u043A\u0435\u0442");
    const { hash, ...body } = p;
    invariant(new TextEncoder().encode(canonical(body)).length < MAX_PACKAGE, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u043F\u0430\u043A\u0435\u0442");
    invariant(await sha256(canonical(body)) === hash, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 \u043F\u0430\u043A\u0435\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
    p.events.forEach((e) => {
      validateEvent(e);
      if (p.schema_version < 7) invariant(!isTrainingEvent(e), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC4");
      if (p.schema_version < 6) invariant(e.entity_type !== "sop_stage43_checklist", "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC3.5");
      if (p.schema_version < 4) invariant(!Object.hasOwn(DOMAIN_TYPES, e.entity_type), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC3");
      if (p.schema_version < 5) invariant(!["workplace", "checklist_version", "sop_evaluation"].includes(e.entity_type) && !(e.entity_type === "operation" && e.payload && Object.hasOwn(e.payload, "workplace_id")) && !(e.entity_type === "document" && ["passport", "origin"].includes(e.payload?.command)), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC3.1");
      if (p.schema_version === 2) invariant(legacyTypes.has(e.entity_type) && (e.entity_type !== "person_assignment" || e.payload === null || !Object.hasOwn(e.payload, "position_id") && !Object.hasOwn(e.payload, "shift_id")), "\u041F\u0430\u043A\u0435\u0442 v2 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u043F\u043E\u043B\u044F LC2");
    });
    invariant(new Set(p.events.map((e) => e.id)).size === p.events.length, "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u0432 \u043F\u0430\u043A\u0435\u0442\u0435");
  }
  async function mergePackage(db, p, readContent3) {
    await checkPackage(p);
    invariant(p.database_id === meta(db, "database_id"), "\u041F\u0430\u043A\u0435\u0442 \u0434\u0440\u0443\u0433\u043E\u0439 \u0431\u0430\u0437\u044B");
    const known = one(db, "SELECT * FROM exchange_package WHERE id=?", [p.id]);
    if (known) {
      invariant(known.manifest_sha256 === p.hash, "\u041F\u043E\u0432\u0442\u043E\u0440 ID \u043F\u0430\u043A\u0435\u0442\u0430 \u0441 \u0438\u043D\u044B\u043C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u044B\u043C");
      return { duplicate: true, count: 0 };
    }
    invariant(!p.base_publication_id || one(db, "SELECT id FROM publication WHERE id=?", [p.base_publication_id]), "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F");
    await verifyDomainEvents(p.events, readContent3);
    return tx(db, () => {
      db.run("INSERT INTO exchange_package(id,base_publication_id,schema_version,database_id,device_id,created_at,state,manifest_sha256) VALUES(?,?,?,?,?,?,?,?)", [p.id, p.base_publication_id, p.schema_version, p.database_id, p.device_id, p.created_at, "applied", p.hash]);
      let count = 0;
      for (const e of p.events) if (applyEvent(db, e, p.id)) count++;
      return { duplicate: false, count };
    });
  }
  var Workspace = class {
    constructor(SQL2, base, { pending = [], device = uuid(), dirty = false } = {}) {
      this.SQL = SQL2;
      this.base = base;
      this.pending = structuredClone(pending);
      this.device = device;
      this.dirty = dirty;
      this.rebuild();
    }
    rebuild() {
      this.working?.close();
      this.working = openDb(this.SQL, bytesOf(this.base));
      this.conflicts = [];
      const remaining = [];
      for (const e of this.pending) {
        if (this.conflicts.length) {
          remaining.push(e);
          continue;
        }
        try {
          tx(this.working, () => applyEvent(this.working, e));
          if (!one(this.base, "SELECT id FROM change_event WHERE id=?", [e.id])) remaining.push(e);
        } catch (err) {
          remaining.push(e);
          this.conflicts.push({ event: e, error: err.message });
        }
      }
      this.pending = remaining;
    }
    edit(type, id, payload, operation2) {
      invariant(Object.hasOwn(definitions, type), "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0441\u0435\u0440\u0432\u0438\u0441 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430");
      invariant(!this.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439");
      invariant(this.pending.length < 2e3, "\u0414\u043E\u0441\u0442\u0438\u0433\u043D\u0443\u0442 \u043B\u0438\u043C\u0438\u0442 \u043E\u0447\u0435\u0440\u0435\u0434\u0438. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0439\u0442\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F.");
      const old = id ? one(this.working, "SELECT * FROM " + (Object.hasOwn(definitions, type) ? type : "invalid") + " WHERE id=?", [id]) : null;
      const e = { id: uuid(), entity_type: type, entity_id: id || uuid(), operation: operation2 || (old ? "update" : "create"), expected_revision: old?.rev || 0, payload, occurred_at: now() };
      tx(this.working, () => applyEvent(this.working, e));
      this.pending.push(e);
      return e.entity_id;
    }
    // Whole import is committed locally in one SQLite transaction, with checked revisions.
    applyBatch(events) {
      invariant(events.every((e) => Object.hasOwn(definitions, e.entity_type)), "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432");
      return this._applyBatch(events);
    }
    async applyContentEvents(events, readContent3) {
      await verifyDomainEvents(events, readContent3);
      return this._applyBatch(events);
    }
    _applyBatch(events) {
      invariant(!this.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B");
      invariant(Array.isArray(events) && events.length > 0 && this.pending.length + events.length <= 2e3, "\u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u043E\u0447\u0435\u0440\u0435\u0434\u0438 (2000)");
      invariant(new TextEncoder().encode(canonical([...this.pending, ...events])).length < MAX_PACKAGE - 4096, "\u041E\u0447\u0435\u0440\u0435\u0434\u044C \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043B\u0438\u043C\u0438\u0442 \u043F\u0430\u043A\u0435\u0442\u0430");
      tx(this.working, () => {
        for (const e of events) {
          invariant(applyEvent(this.working, e), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u0438\u043C\u043F\u043E\u0440\u0442\u0430");
        }
      });
      this.pending.push(...structuredClone(events));
      return events.length;
    }
    async package() {
      return makePackage(this.base, this.pending, this.device);
    }
    async accept(p, readContent3) {
      invariant(!this.pending.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0440\u0438\u043C\u0438\u0442\u0435 \u0438\u043B\u0438 \u044D\u043A\u0441\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u0438 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
      const r = await mergePackage(this.base, p, readContent3);
      if (!r.duplicate) this.dirty = true;
      this.rebuild();
      return r;
    }
    async acceptOwn(readContent3) {
      invariant(!this.conflicts.length, "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0442");
      if (!this.pending.length) return 0;
      const p = await this.package();
      const r = await mergePackage(this.base, p, readContent3);
      this.dirty = true;
      this.rebuild();
      return r.count;
    }
    discardPending() {
      this.pending = [];
      this.rebuild();
    }
    resolveConflict(choice) {
      invariant(this.conflicts.length === 1 && ["discard", "reapply"].includes(choice), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0430\u0435\u043C\u043E\u0433\u043E \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0430");
      const e = this.conflicts[0].event, i = this.pending.findIndex((x) => x.id === e.id);
      invariant(i >= 0, "\u0421\u043E\u0431\u044B\u0442\u0438\u0435 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442");
      if (choice === "discard") {
        this.pending.splice(i, 1);
        this.rebuild();
        return;
      }
      invariant(!Object.hasOwn(DOMAIN_TYPES, e.entity_type), "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430: \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u0432\u0440\u0443\u0447\u043D\u0443\u044E");
      const old = one(this.working, "SELECT * FROM " + e.entity_type + " WHERE id=?", [e.entity_id]);
      const next = { ...e, id: uuid(), expected_revision: old?.rev || 0, occurred_at: now() };
      invariant(e.operation === "create" ? !old : !!old && !old.archived, "\u0417\u0430\u043F\u0438\u0441\u044C \u0443\u0434\u0430\u043B\u0435\u043D\u0430, \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0438\u043B\u0438 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442; \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0440\u0443\u0447\u043D\u043E\u0435 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435");
      tx(this.working, () => applyEvent(this.working, next));
      this.pending.splice(i, 1, next);
      this.rebuild();
    }
    replaceBase(db) {
      try {
        invariant(meta(db, "database_id") === meta(this.base, "database_id"), "\u0414\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430");
        const current = meta(this.base, "publication_id");
        let p = meta(db, "publication_id"), found = !current;
        const seen = /* @__PURE__ */ new Set();
        while (p) {
          invariant(!seen.has(p), "\u0426\u0438\u043A\u043B \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
          seen.add(p);
          if (p === current) found = true;
          const row = one(db, "SELECT parent_id FROM publication WHERE id=?", [p]);
          invariant(row, "\u0420\u0430\u0437\u043E\u0440\u0432\u0430\u043D\u0430 \u0446\u0435\u043F\u043E\u0447\u043A\u0430 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
          p = row.parent_id;
        }
        invariant(found, "\u0421\u043D\u0438\u043C\u043E\u043A \u0443\u0441\u0442\u0430\u0440\u0435\u043B \u0438\u043B\u0438 \u0438\u043C\u0435\u0435\u0442 \u0434\u0440\u0443\u0433\u0443\u044E \u0432\u0435\u0442\u043A\u0443");
        if (this.dirty) {
          for (const e of rows(this.base, "SELECT * FROM change_event")) invariant(canonical(one(db, "SELECT * FROM change_event WHERE id=?", [e.id])) === canonical(e), "\u0415\u0441\u0442\u044C \u043D\u0435\u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
          for (const e of rows(this.base, "SELECT * FROM exchange_package")) invariant(canonical(one(db, "SELECT * FROM exchange_package WHERE id=?", [e.id])) === canonical(e), "\u0415\u0441\u0442\u044C \u043D\u0435\u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u0430\u043A\u0435\u0442\u044B");
        }
        const prev = this.base;
        this.base = db;
        this.dirty = false;
        this.rebuild();
        prev.close();
      } catch (e) {
        if (this.base !== db) db.close();
        throw e;
      }
    }
    state() {
      return { base: bytesOf(this.base), pending: structuredClone(this.pending), device: this.device, dirty: this.dirty };
    }
    close() {
      this.working.close();
      this.base.close();
    }
  };
  async function prepareSnapshot(ws2) {
    invariant(!ws2.pending.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0440\u0438\u043C\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
    const db = openDb(ws2.SQL, bytesOf(ws2.base));
    try {
      const descriptor = { format: "lean-snapshot-v1", id: uuid(), database_id: meta(db, "database_id"), parent_id: meta(db, "publication_id"), schema_version: SCHEMA_VERSION, created_at: now() };
      const descriptor_hash = await sha256(canonical(descriptor));
      db.run("INSERT INTO publication(id,parent_id,created_at,schema_version,manifest_sha256) VALUES(?,?,?,?,?)", [descriptor.id, descriptor.parent_id, descriptor.created_at, SCHEMA_VERSION, descriptor_hash]);
      setMeta(db, "publication_id", descriptor.id);
      verifyDb(db);
      const bytes = bytesOf(db);
      return { bytes, manifest: { ...descriptor, descriptor_hash, snapshot_sha256: await sha256(bytes), size: bytes.length } };
    } finally {
      db.close();
    }
  }
  async function readSnapshot(SQL2, manifest, bytes) {
    invariant(manifest && manifest.format === "lean-snapshot-v1" && isId(manifest.id) && isId(manifest.database_id) && (manifest.parent_id === null || isId(manifest.parent_id)) && [2, 3, 4, 5, 6, SCHEMA_VERSION].includes(manifest.schema_version) && manifest.size === bytes.length && bytes.length <= MAX_DB, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442");
    const { descriptor_hash, snapshot_sha256, size, ...descriptor } = manifest;
    invariant(await sha256(canonical(descriptor)) === descriptor_hash && await sha256(bytes) === snapshot_sha256, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D \u0441\u043D\u0438\u043C\u043E\u043A");
    const db = openDb(SQL2, bytes, { upgrade: false });
    try {
      const p = one(db, "SELECT * FROM publication WHERE id=?", [manifest.id]);
      invariant(Number(meta(db, "schema_version")) === manifest.schema_version && p?.schema_version === manifest.schema_version && meta(db, "database_id") === manifest.database_id && meta(db, "publication_id") === manifest.id && p?.manifest_sha256 === descriptor_hash && p.parent_id === manifest.parent_id, "\u0421\u043D\u0438\u043C\u043E\u043A \u0438 \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442");
      return upgradeDb(db);
    } catch (e) {
      db.close();
      throw e;
    }
  }
  async function backup(ws2) {
    const s = ws2.state();
    const body = { format: "lean-backup-v1", base: encode(s.base), pending: s.pending, device: s.device, dirty: s.dirty };
    return { ...body, hash: await sha256(canonical(body)) };
  }
  async function restore(SQL2, obj2, readContent3) {
    const { hash, ...body } = obj2;
    invariant(body.format === "lean-backup-v1" && Array.isArray(body.pending) && body.pending.length <= 2e3 && isId(body.device) && typeof body.dirty === "boolean" && await sha256(canonical(body)) === hash, "\u0420\u0435\u0437\u0435\u0440\u0432\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0435\u043D\u0430");
    body.pending.forEach(validateEvent);
    await verifyDomainEvents(body.pending, readContent3);
    return new Workspace(SQL2, openDb(SQL2, decode(body.base)), body);
  }

  // src/ui/people-picker.js
  var key = (x) => String(x ?? "").normalize("NFKC").toLocaleLowerCase("ru-RU").replaceAll("\u0451", "\u0435").trim();
  var ROLE_LABELS = { instructor: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", mentor: "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", trainee: "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", evaluator: "\u041E\u0446\u0435\u043D\u0449\u0438\u043A" };
  var tokens = (x) => key(x).split(/[\s,;]+/u).filter(Boolean);
  function matchesPerson(p, query2) {
    const words = tokens([p.display_name, p.employee_code, p.position, p.unit].join(" "));
    return tokens(query2).every((q) => words.some((w) => w.startsWith(q)));
  }
  function filterPeople(people, query2 = "", allowed = null, role = "") {
    return people.filter((p) => (!allowed || p.roles?.some((x) => allowed.includes(x.kind))) && (!role || p.roles?.some((x) => x.kind === role)) && matchesPerson(p, query2));
  }
  var active3 = null;
  var serial = 0;
  var node = (tag, text4, cls) => {
    const e = document.createElement(tag);
    if (text4 !== void 0) e.textContent = text4;
    if (cls) e.className = cls;
    return e;
  };
  function closePeopleDropdown() {
    active3?.close();
  }
  function openPeopleDropdown(trigger, { people, onChoose, allowed = null, roleOptions = ["instructor", "mentor", "trainee", "evaluator"], optional: optional2 = true, selectedId = "", label = "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A" }) {
    if (active3?.trigger === trigger) {
      active3.close();
      return;
    }
    closePeopleDropdown();
    if (trigger.disabled || !trigger.isConnected) return;
    const popup = node("div", void 0, "lc-picker-popup");
    popup.id = "lc-picker-" + ++serial;
    popup.setAttribute("role", "dialog");
    popup.setAttribute("aria-label", "\u0412\u044B\u0431\u043E\u0440: " + label);
    const header = node("div", label, "lc-picker-heading"), search = node("input"), role = node("select"), results = node("div", void 0, "lc-picker-results");
    search.type = "search";
    search.placeholder = "\u041F\u0435\u0440\u0432\u044B\u0435 \u0431\u0443\u043A\u0432\u044B \u0424\u0418\u041E \u0438\u043B\u0438 \u0442\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440";
    search.setAttribute("aria-label", "\u041F\u043E\u0438\u0441\u043A \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
    search.autocomplete = "off";
    search.setAttribute("aria-controls", popup.id + "-results");
    role.setAttribute("aria-label", "\u0420\u043E\u043B\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
    results.id = popup.id + "-results";
    const roles2 = allowed || roleOptions;
    const option = (value, label2) => {
      const o = node("option", label2);
      o.value = value;
      role.append(o);
    };
    if (roles2.length !== 1) option("", allowed ? "\u0412\u0441\u0435 \u043F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0440\u043E\u043B\u0438" : "\u0412\u0441\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438");
    roles2.forEach((r) => option(r, ROLE_LABELS[r] || r));
    if (roles2.length === 1) role.value = roles2[0];
    popup.append(header);
    if (roles2.length > 1 || !allowed) popup.append(role);
    popup.append(search);
    const footer = node("div", void 0, "lc-picker-footer");
    const cancel = node("button", "\u0417\u0430\u043A\u0440\u044B\u0442\u044C");
    cancel.type = "button";
    cancel.onclick = () => close(true);
    if (optional2) {
      const clear = node("button", "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0432\u044B\u0431\u043E\u0440");
      clear.type = "button";
      clear.onclick = () => {
        close(true);
        onChoose(null);
      };
      footer.append(clear);
    }
    footer.append(cancel);
    popup.append(results, footer);
    document.body.append(popup);
    trigger.setAttribute("aria-haspopup", "dialog");
    trigger.setAttribute("aria-expanded", "true");
    trigger.setAttribute("aria-controls", popup.id);
    function options() {
      return Array.from(results.querySelectorAll("button.lc-person-option"));
    }
    function draw() {
      const list2 = filterPeople(people(), search.value, allowed, role.value);
      results.replaceChildren();
      if (!list2.length) {
        results.append(node("p", search.value ? "\u041D\u0435\u0442 \u0441\u043E\u0432\u043F\u0430\u0434\u0435\u043D\u0438\u0439 \u043F\u043E \u043F\u0435\u0440\u0432\u044B\u043C \u0431\u0443\u043A\u0432\u0430\u043C." : allowed || role.value ? "\u041D\u0435\u0442 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0441 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\u043C \u044D\u0442\u043E\u0439 \u0440\u043E\u043B\u0438. \u041D\u0430\u0437\u043D\u0430\u0447\u044C\u0442\u0435 \u0440\u043E\u043B\u044C \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0435 \u0446\u0435\u043D\u0442\u0440\u0430." : "\u041D\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432. \u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0438\u0445 \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0446\u0435\u043D\u0442\u0440\u0430.", "lc-picker-empty"));
        return;
      }
      for (const p of list2.slice(0, 100)) {
        const btn2 = node("button", void 0, "lc-person-option");
        btn2.type = "button";
        btn2.dataset.personId = p.id;
        btn2.setAttribute("aria-label", p.display_name + " \xB7 " + p.employee_code);
        if (p.id === selectedId) btn2.classList.add("lc-person-current");
        btn2.append(node("strong", p.display_name), node("span", [p.employee_code, p.position, p.unit, ...(p.roles || []).map((x) => x.name)].filter(Boolean).join(" \xB7 "), "lc-picker-meta"));
        btn2.onclick = () => {
          close(true);
          onChoose(p, role.value || null);
        };
        results.append(btn2);
      }
      if (list2.length > 100) results.append(node("p", "\u041F\u0435\u0440\u0432\u044B\u0435 100 \u0438\u0437 " + list2.length + ". \u0423\u0442\u043E\u0447\u043D\u0438\u0442\u0435 \u043F\u043E\u0438\u0441\u043A.", "lc-picker-empty"));
    }
    function place() {
      if (!trigger.isConnected || trigger.getBoundingClientRect().height === 0) {
        close();
        return;
      }
      const a = trigger.getBoundingClientRect(), w = Math.min(Math.max(a.width, 360), window.innerWidth - 16), below = window.innerHeight - a.bottom - 12, above = a.top - 12;
      popup.style.width = w + "px";
      popup.style.left = Math.max(8, Math.min(a.left, window.innerWidth - w - 8)) + "px";
      const height = Math.min(390, Math.max(150, Math.max(below, above)));
      popup.style.maxHeight = Math.min(window.innerHeight - 16, height) + "px";
      const actual = popup.getBoundingClientRect().height;
      popup.style.top = Math.max(8, Math.min(window.innerHeight - actual - 8, below >= Math.min(actual, 220) || below >= above ? a.bottom + 4 : a.top - actual - 4)) + "px";
    }
    function outside(e) {
      if (!popup.contains(e.target) && !trigger.contains(e.target)) close();
    }
    function keyboard(e) {
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        close(true);
        return;
      }
      if (!popup.contains(e.target)) return;
      const opts = options(), i = opts.indexOf(document.activeElement);
      if (e.key === "ArrowDown" && e.target !== role) {
        e.preventDefault();
        opts[Math.min(i + 1, opts.length - 1)]?.focus();
      } else if (e.key === "ArrowUp" && e.target !== role) {
        e.preventDefault();
        if (i <= 0) search.focus();
        else opts[i - 1]?.focus();
      } else if (e.key === "Enter" && e.target === search && opts.length) {
        e.preventDefault();
        opts[0].click();
      }
    }
    function close(focus = false) {
      if (active3?.popup !== popup) return;
      active3 = null;
      popup.remove();
      trigger.setAttribute("aria-expanded", "false");
      trigger.removeAttribute("aria-controls");
      document.removeEventListener("pointerdown", outside, true);
      document.removeEventListener("keydown", keyboard, true);
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
      observer.disconnect();
      if (focus && trigger.isConnected) trigger.focus({ preventScroll: true });
    }
    search.oninput = () => {
      draw();
      place();
    };
    role.onchange = () => {
      draw();
      place();
      search.focus();
    };
    const observer = new MutationObserver(() => {
      if (!trigger.isConnected) close();
    });
    observer.observe(document.body, { childList: true, subtree: true });
    active3 = { trigger, popup, close, refresh: () => {
      draw();
      place();
    } };
    document.addEventListener("pointerdown", outside, true);
    document.addEventListener("keydown", keyboard, true);
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    draw();
    place();
    search.focus({ preventScroll: true });
  }

  // src/modules/training/screens.js
  var TRAINING_PAGES = ["twi", "programs", "internship", "instruction", "retraining", "journal", "skills", "practical", "development", "mentoring", "certification", "appointments", "my_plan"];
  var route = {};
  function resetTrainingRoute() {
    route = {};
  }
  function setTrainingRoute(page2, options = {}) {
    route = { page: page2, ...options };
  }
  var statuses = { planned: "\u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043E", in_progress: "\u0412 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435", completed: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E", cancelled: "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E", active: "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442", retired: "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F" };
  var credentialRoles = { instructor: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", mentor: "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", internal_trainer: "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440" };
  var observationLabels = { rated: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D", not_observed: "\u041D\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u043B\u043E\u0441\u044C", not_applicable: "\u041D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E" };
  var decisionLabels = { granted: "\u0414\u043E\u043F\u0443\u0441\u043A \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D", denied: "\u041D\u0435 \u0434\u043E\u043F\u0443\u0449\u0435\u043D" };
  var resultLabels = { completed: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E", incomplete: "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u044F", pass: "\u041F\u0440\u043E\u0439\u0434\u0435\u043D\u043E", fail: "\u041D\u0435 \u043F\u0440\u043E\u0439\u0434\u0435\u043D\u043E" };
  var safe = (x) => String(x ?? "");
  var nullable = (x) => x || null;
  var dateTime = () => {
    const d = /* @__PURE__ */ new Date(), local = new Date(d.getTime() - d.getTimezoneOffset() * 6e4);
    return local.toISOString().slice(0, 16);
  };
  function trainingScreen(main, page2, c) {
    if (route.page !== page2) route = { page: page2 };
    const { ws: ws2, el: el2, add: add2, btn: btn2, pane: pane2, tableOf: tableOf2, inputField: inputField2, fieldInput: fieldInput2, refName: refName2, refOption: refOption2, today: today2, run: run2, render: render2, go, goDocument: goDocument2, readContent: readContent3, pick: pick2, downloadBytes: downloadBytes2 } = c, db = ws2.working;
    const blocked = !!ws2.conflicts.length, day = today2(), n = (type, id) => refName2(type, id), stack = (...x) => add2(el2("div", void 0, "stack"), ...x), row = (...x) => add2(el2("div", void 0, "row"), ...x), grid = (...x) => add2(el2("div", void 0, "formgrid"), ...x);
    const msg = (s, cls = "muted") => el2("p", s, cls);
    const action = (label, fn, kind = "primary", disabled = false) => btn2(label, fn, kind, disabled || blocked);
    const goLocal = (options = {}) => {
      route = { page: page2, ...options };
      render2();
    };
    const back = () => btn2("\u041A \u0441\u043F\u0438\u0441\u043A\u0443", () => goLocal());
    const select = (name, options, value = "", emptyLabel = "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014") => {
      const s = el2("select");
      s.name = name;
      if (emptyLabel !== null) {
        const o = el2("option", emptyLabel);
        o.value = "";
        s.append(o);
      }
      for (const [id, label] of options) {
        const o = el2("option", safe(label));
        o.value = safe(id);
        s.append(o);
      }
      s.value = safe(value);
      if (s.selectedIndex < 0 && emptyLabel === null) s.selectedIndex = 0;
      return s;
    };
    const simple = (name, values, value = "", empty2 = null) => select(name, Object.entries(values), value, empty2);
    const ref = (type, name, value = "", emptyLabel = "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", filter = () => true) => select(name, list(db, type).filter((x) => !x.archived && filter(x)).map((x) => [x.id, refOption2(type, x)]), value, emptyLabel);
    const date3 = (name, value = day) => fieldInput2(name, value, "date");
    const num2 = (name, value = "", min = 0, max = 1e4, step = 1) => {
      const i = fieldInput2(name, value, "number");
      i.min = String(min);
      i.max = String(max);
      i.step = String(step);
      return i;
    };
    const note = (name, value = "", placeholder = "") => {
      const i = el2("textarea");
      i.name = name;
      i.rows = 2;
      i.maxLength = 2e3;
      i.value = value;
      i.placeholder = placeholder;
      return i;
    };
    const check = (name, label) => {
      const i = el2("input");
      i.type = "checkbox";
      i.name = name;
      return { input: i, element: add2(el2("label", void 0, "row lc4-check"), i, el2("span", label)) };
    };
    const f = (label, input) => inputField2(label, input);
    function person2(name, label, initial = "", { allowed = null, optional: optional2 = false, filter = () => true, onChange = () => {
    }, at = () => day } = {}) {
      let id = initial;
      const button = btn2("", () => openPeopleDropdown(button, { people: () => directoryPeople(db, at() || day).filter(filter), allowed, optional: optional2, label, selectedId: id, onChoose: (p) => {
        id = p?.id || "";
        refresh2();
        onChange(id);
      } }), "lc-directory-trigger");
      button.name = name;
      button.setAttribute("aria-label", "\u0412\u044B\u0431\u0440\u0430\u0442\u044C: " + label);
      button.setAttribute("aria-haspopup", "dialog");
      button.setAttribute("aria-expanded", "false");
      function refresh2() {
        button.textContent = (id ? n("person", id) : "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430") + " \u25BE";
      }
      refresh2();
      return { get value() {
        return id;
      }, element: add2(el2("div", void 0, "field"), el2("span", label), button), button, set(v) {
        id = v;
        refresh2();
      } };
    }
    function event(type, payload, old = null) {
      return { id: uuid(), entity_type: type, entity_id: old?.id || uuid(), operation: old ? "update" : "create", expected_revision: old?.rev || 0, payload, occurred_at: (/* @__PURE__ */ new Date()).toISOString() };
    }
    async function write(type, payload, old = null) {
      const e = event(type, payload, old);
      await ws2.applyContentEvents([e], readContent3);
      return e.entity_id;
    }
    function save2(label, type, payload, old = null, done = () => {
    }, disabled = false) {
      return action(label, () => run2(async () => {
        const id = await write(type, typeof payload === "function" ? payload() : payload, old);
        done(id);
        return "\u0417\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
      }), "primary", disabled);
    }
    const reasonInput = () => note("reason", "", "\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
    function closeRecord(label, type, old, command) {
      const reason = reasonInput(), d = el2("details");
      d.append(el2("summary", label), f("\u041F\u0440\u0438\u0447\u0438\u043D\u0430", reason), save2(label, type, () => ({ command, reason: reason.value }), old));
      return d;
    }
    const revs = () => rows(db, "SELECT r.id,r.version_no,r.payload_json,d.id document_id,d.code,d.title,d.operation_id FROM document_revision r JOIN document d ON d.id=r.document_id JOIN operation o ON o.id=d.operation_id WHERE d.kind='sop' AND d.archived=0 AND r.state='effective' AND o.archived=0 ORDER BY d.code");
    const revLabel = (id) => {
      const x = currentStandard(db, id);
      return x ? x.code + " \xB7 " + x.title + " \xB7 v" + x.version_no : "\u2014";
    };
    const revPicker = (name, id = "") => select(name, revs().map((x) => [x.id, x.code + " \xB7 " + x.title + " \xB7 v" + x.version_no]), id);
    const scalePicker = (name, id = "") => ref("rating_scale", name, id);
    function levelPicker(name, scaleId, initial = "") {
      return select(name, rows(db, "SELECT value,label FROM rating_level WHERE scale_id=? ORDER BY value", [scaleId]).map((x) => [x.value, x.value + " \u2014 " + x.label]), initial);
    }
    function replaceOptions(dest, source) {
      dest.replaceChildren(...Array.from(source.children));
      dest.value = source.value;
    }
    function scaleFields(prefix, scaleId = "", target = null) {
      const scale = scalePicker(prefix + "_scale", scaleId), level2 = levelPicker(prefix + "_level", scale.value, target ?? "");
      scale.onchange = () => replaceOptions(level2, levelPicker(level2.name, scale.value));
      return { scale, level: level2, element: grid(f("\u0428\u043A\u0430\u043B\u0430", scale), f("\u0426\u0435\u043B\u0435\u0432\u043E\u0439 / \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u043C\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C", level2)), set(s, l) {
        scale.value = s || "";
        replaceOptions(level2, levelPicker(level2.name, scale.value, l ?? ""));
      } };
    }
    function currentAuths(op, at = day) {
      return activeAuthorizations(db, op, at);
    }
    function asgns() {
      return rows(db, "SELECT * FROM training_assignment WHERE source_sha256 IS NOT NULL ORDER BY due_on,assigned_on,id");
    }
    function enrollmentList() {
      return rows(db, "SELECT * FROM training_enrollment ORDER BY due_on,start_on,id");
    }
    const assignmentName = (a) => (JSON.parse(a.recorded_names_json || "{}").trainee || n("person", a.trainee_id)) + " \xB7 " + revLabel(a.sop_revision_id);
    const enrollmentPage = (id) => one(db, "SELECT p.kind FROM training_enrollment e JOIN training_program p ON p.id=e.program_id WHERE e.id=?", [id])?.kind === "internship" ? "internship" : "programs";
    const stateLabel = (a) => a.state === "planned" ? a.approval_json ? "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043E" : "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F" : statuses[a.state] || a.state;
    const sameRevision = (a) => isCurrentStandard(db, a.sop_revision_id);
    const activePlan = (a) => ["planned", "in_progress"].includes(a.state);
    const expired = (a) => activePlan(a) && a.due_on < day;
    const table = (headers, data, empty2 = "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439.") => data.length ? tableOf2(headers, data) : msg(empty2);
    async function exportTable(name, headers, data) {
      const w = new ExcelJS.Workbook(), s = w.addWorksheet("\u041E\u0442\u0447\u0451\u0442", { pageSetup: { orientation: "landscape", fitToPage: true, fitToWidth: 1, fitToHeight: 0, paperSize: 9 } });
      s.columns = headers.map((h) => ({ width: Math.max(14, Math.min(52, safe(h).length + 14)) }));
      s.addRow(headers);
      s.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
      s.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242E40" } };
      for (const line of data) {
        const r = s.addRow(line.map((x) => x ?? ""));
        r.alignment = { vertical: "top", wrapText: true };
        r.height = Math.max(22, Math.min(90, 15 * Math.ceil(Math.max(1, ...line.map((x) => safe(x).length / 38)))));
      }
      s.views = [{ state: "frozen", ySplit: 1 }];
      s.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: headers.length } };
      downloadBytes2(name + ".xlsx", await w.xlsx.writeBuffer());
    }
    const exportButton = (name, headers, items) => btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C XLSX", () => run2(async () => {
      await exportTable(name, headers, items);
      return "\u041E\u0442\u0447\u0451\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false }));
    function filterList(out, input, items, searchText, draw) {
      const update2 = () => {
        const q = input.value.trim().toLocaleLowerCase("ru-RU");
        out.replaceChildren(draw(items.filter((x) => searchText(x).toLocaleLowerCase("ru-RU").includes(q))));
      };
      input.oninput = update2;
      update2();
    }
    function searchInput(name = "lc4_search") {
      const i = fieldInput2(name, "", "search");
      i.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0443, \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u043D\u043E\u043C\u0435\u0440\u0443";
      return i;
    }
    function evidenceSummary(a) {
      const p = latestAssessment(db, a.id, "practical"), q = latestAssessment(db, a.id, "qualification"), s = latestVerification(db, a.id, "safety"), t = latestVerification(db, a.id, "theory");
      return { p, q, s, t, ad: admissionStatus(db, a.trainee_id, a.operation_id, day) };
    }
    function assignmentRows(items) {
      return table(["\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0421\u041E\u041F / \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u0426\u0435\u043B\u044C", "\u0421\u0440\u043E\u043A", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436", ""], items.map((a) => {
        const p = progressFor(db, a), e = el2("span", stateLabel(a) + (expired(a) ? " \xB7 \u043F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043E" : "") + (!sameRevision(a) ? " \xB7 \u0421\u041E\u041F \u0438\u0437\u043C\u0435\u043D\u0451\u043D" : ""), expired(a) || !sameRevision(a) ? "warn" : "");
        return [n("person", a.trainee_id), revLabel(a.sop_revision_id), n("person", a.mentor_id), a.target_level + " \xB7 " + n("skill", a.skill_id), a.due_on, e, p.completed + "/" + p.stages.length, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => go(page2 === "instruction" ? "instruction" : "twi", { id: a.id, tab: page2 === "instruction" ? "instruction" : "overview" }), "primary")];
      }));
    }
    function assignmentList() {
      const items = asgns(), q = searchInput(), out = el2("div"), filter = select("training_filter", [["all", "\u0412\u0441\u0435"], ["open", "\u041E\u0442\u043A\u0440\u044B\u0442\u044B\u0435"], ["overdue", "\u041F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043D\u044B\u0435"], ["completed", "\u0417\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u044B\u0435"], ["changed", "\u0418\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F \u0421\u041E\u041F"]], route.filter || "all", null);
      const display = () => {
        const text4 = q.value.toLocaleLowerCase("ru-RU").trim();
        const filtered = items.filter((a) => (filter.value === "all" || filter.value === "open" && activePlan(a) || filter.value === "overdue" && expired(a) || filter.value === "completed" && a.state === "completed" || filter.value === "changed" && !sameRevision(a)) && assignmentName(a).toLocaleLowerCase("ru-RU").includes(text4));
        out.replaceChildren(assignmentRows(filtered));
        route.filter = filter.value;
      };
      q.oninput = display;
      filter.onchange = display;
      display();
      const controls = row(action("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { mode: "new" })), btn2("\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0438", () => go("programs")), btn2("\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0438 TWI", () => go("instruction")), q, filter);
      return pane2(page2 === "instruction" ? "\u0420\u0435\u0435\u0441\u0442\u0440 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439 TWI" : "\u041F\u043B\u0430\u043D \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", msg("\u041E\u0434\u0438\u043D \u0441\u043F\u0438\u0441\u043E\u043A \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439. \u0424\u0430\u043A\u0442 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430, \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430, \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F \u0438 \u0434\u043E\u043F\u0443\u0441\u043A \u0443\u0447\u0438\u0442\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E."), controls, out, exportButton("\u041F\u043B\u0430\u043D-\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", ["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0421\u041E\u041F", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u041D\u0430\u0432\u044B\u043A", "\u0426\u0435\u043B\u044C", "\u041D\u0430\u0447\u0430\u043B\u043E", "\u0421\u0440\u043E\u043A", "\u0421\u0442\u0430\u0442\u0443\u0441"], items.map((a) => [n("person", a.trainee_id), revLabel(a.sop_revision_id), n("person", a.mentor_id), n("skill", a.skill_id), a.target_level, a.assigned_on, a.due_on, stateLabel(a)])));
    }
    function assignmentForm() {
      const preset = route, rev = revPicker("training_revision", preset.revisionId || ""), assigned = date3("assigned_on", preset.startOn || day), due = date3("due_on", preset.dueOn || day);
      const trainee = person2("training_trainee", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", preset.traineeId || "", { allowed: ["trainee"], at: () => assigned.value });
      const instructor = person2("training_instructor", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", preset.instructorId || "", { allowed: ["instructor", "mentor"], at: () => assigned.value, filter: (p) => currentAuths(currentStandard(db, rev.value)?.operation_id, assigned.value).some((a) => a.person_id === p.id) });
      const supervisor = person2("training_supervisor", "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", preset.supervisorId || "", { allowed: ["mentor", "instructor"], optional: true, at: () => assigned.value });
      const actor = person2("training_assigner", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0437\u0430 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"), skill = ref("skill", "training_skill", preset.skillId || "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", (s) => s.operation_id === currentStandard(db, rev.value)?.operation_id);
      const target = scaleFields("training_target", preset.scaleId || "", preset.targetLevel ?? null), shift = ref("work_shift", "training_shift", preset.shiftId || "", "\u2014 \u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430 \u2014");
      const reason = note("training_reason", preset.reason || ""), variant = simple("training_variant", variants, preset.variant || "classic"), review = check("plan_reviewed", "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u043B \u043F\u043B\u0430\u043D TWI \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0421\u041E\u041F \u0438 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F");
      const sourceInfo = el2("div");
      let epoch = 0;
      async function refreshSource() {
        const seq = ++epoch, r = currentStandard(db, rev.value);
        sourceInfo.replaceChildren(msg(r ? "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043F\u043B\u0430\u043D\u0430 TWI\u2026" : "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0421\u041E\u041F \u0441 \u043F\u043B\u0430\u043D\u043E\u043C TWI."));
        review.input.checked = false;
        review.input.disabled = true;
        if (!r) return;
        try {
          const raw = JSON.parse(await readContent3(r.source)), x = linkedTwi(raw.constructor);
          if (seq !== epoch || !sourceInfo.isConnected) return;
          sourceInfo.replaceChildren(msg("\u041F\u043B\u0430\u043D TWI: " + x.status + " \xB7 " + x.filled + "/15 \u043F\u043E\u043B\u0435\u0439", x.outdated || !x.exists ? "warn" : "muted"), btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u0421\u041E\u041F", () => goDocument2(r.document_id, r.id)));
          review.input.disabled = !x.exists || x.outdated;
        } catch (e) {
          if (seq === epoch) sourceInfo.replaceChildren(msg(e.message, "bad"));
        }
      }
      rev.onchange = () => {
        replaceOptions(skill, ref("skill", "training_skill", "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", (s) => s.operation_id === currentStandard(db, rev.value)?.operation_id));
        instructor.set("");
        void refreshSource();
      };
      assigned.onchange = () => {
        instructor.set("");
        if (!preset.programTaskId) {
          trainee.set("");
          supervisor.set("");
        }
      };
      if (preset.programTaskId) {
        rev.disabled = true;
        skill.disabled = true;
        target.scale.disabled = true;
        target.level.disabled = true;
        trainee.button.disabled = true;
      }
      const form2 = pane2("\u041D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", row(back()), msg("\u0414\u043B\u044F \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0421\u041E\u041F, \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 TWI, \u0446\u0435\u043B\u044C \u043F\u043E \u043D\u0430\u0432\u044B\u043A\u0443 \u0438 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u043F\u0440\u0430\u0432\u043E \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u044D\u0442\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438."), f("\u0421\u041E\u041F \u0438 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F", rev), sourceInfo, review.element, grid(trainee.element, instructor.element, supervisor.element, actor.element), grid(f("\u041D\u0430\u0432\u044B\u043A", skill), f("\u0421\u043C\u0435\u043D\u0430", shift), f("\u0412\u0438\u0434 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", variant), f("\u041D\u0430\u0447\u0430\u043B\u043E", assigned), f("\u0421\u0440\u043E\u043A", due)), target.element, f("\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", reason), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", "training_assignment", () => {
        const r = currentStandard(db, rev.value), auth = currentAuths(r?.operation_id, assigned.value).find((x) => x.person_id === instructor.value);
        invariant(r && auth, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0421\u041E\u041F \u0438 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0441 \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0435\u043C");
        return { trainee_id: trainee.value, mentor_id: instructor.value, supervisor_id: nullable(supervisor.value), authorization_id: auth.id, revision_id: r.id, source: r.source, skill_id: skill.value, scale_id: target.scale.value, target_level: target.level.value === "" ? null : Number(target.level.value), assigned_by: actor.value, assigned_on: assigned.value, due_on: due.value, reason: reason.value, variant: variant.value, shift_id: nullable(shift.value), enrollment_id: preset.enrollmentId || null, program_task_id: preset.programTaskId || null, plan_reviewed: review.input.checked };
      }, null, (id) => {
        route = { page: page2, id, tab: "overview" };
      }));
      void Promise.resolve().then(refreshSource);
      return form2;
    }
    function overview(a) {
      const s = currentStandard(db, a.sop_revision_id), p = progressFor(db, a), e = evidenceSummary(a), name = JSON.parse(a.recorded_names_json || "{}");
      const panel = pane2("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", tableOf2(["\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442", "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435"], [["\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", name.trainee || n("person", a.trainee_id)], ["\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", name.instructor || n("person", a.mentor_id)], ["\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", name.supervisor || n("person", a.supervisor_id)], ["\u0421\u041E\u041F", revLabel(a.sop_revision_id)], ["\u041D\u0430\u0432\u044B\u043A \u0438 \u0446\u0435\u043B\u044C", n("skill", a.skill_id) + " \xB7 " + a.target_level + " \xB7 " + n("rating_scale", a.scale_id)], ["\u0412\u0438\u0434 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", variants[a.method_variant]], ["\u0421\u043C\u0435\u043D\u0430", n("work_shift", a.shift_id)], ["\u041F\u0435\u0440\u0438\u043E\u0434", a.assigned_on + " \u2014 " + a.due_on], ["\u041F\u0440\u0438\u0447\u0438\u043D\u0430", a.reason], ["\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", stateLabel(a)], ["\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436", p.completed + " / " + p.stages.length], ["\u0414\u043E\u043F\u0443\u0441\u043A", e.ad.status]]), row(btn2("\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0421\u041E\u041F", () => goDocument2(s.document_id, s.id)), ...a.enrollment_id ? [btn2("\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", () => go(enrollmentPage(a.enrollment_id), { enrollmentId: a.enrollment_id }))] : []));
      if (!sameRevision(a)) panel.append(msg("\u0420\u0435\u0434\u0430\u043A\u0446\u0438\u044F \u0421\u041E\u041F \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442. \u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u043F\u0435\u0440\u0435\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0438.", "warn"), btn2("\u041F\u0435\u0440\u0435\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("retraining")));
      if (a.approval_json) {
        const x = JSON.parse(a.approval_json);
        panel.append(msg("\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043E " + x.approved_on + " \xB7 \u041D\u0420: " + x.names.responsible + " \xB7 \u0440\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C: " + x.names.head + (x.note ? " \xB7 " + x.note : "")));
      }
      if (activePlan(a) && sameRevision(a) && !a.approval_json) {
        const responsible = person2("plan_responsible", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0437\u0430 \u0421\u041E\u041F (\u041D\u0420)"), head = person2("plan_head", "\u0420\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F"), approved = date3("approved_on"), comment = note("approval_note");
        panel.append(pane2("\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u043B\u0430\u043D\u0430", msg("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F, \u043D\u0435 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0434\u043F\u0438\u0441\u044C."), grid(responsible.element, head.element, f("\u0414\u0430\u0442\u0430", approved)), f("\u041F\u0440\u0438\u043C\u0435\u0447\u0430\u043D\u0438\u0435", comment), save2("\u0417\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435", "training_assignment", () => ({ command: "approve", responsible_id: responsible.value, head_id: head.value, approved_on: approved.value, note: comment.value }), a)));
      }
      if (activePlan(a)) {
        const due = date3("reschedule_due", a.due_on), why = reasonInput(), d = el2("details");
        d.append(el2("summary", "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u0440\u043E\u043A"), grid(f("\u041D\u043E\u0432\u044B\u0439 \u0441\u0440\u043E\u043A", due), f("\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", why)), msg("\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0441\u0440\u043E\u043A\u0430 \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0433\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F; \u043F\u0440\u0435\u0436\u043D\u0438\u0435 \u0444\u0430\u043A\u0442\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F."), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u043E\u0432\u044B\u0439 \u0441\u0440\u043E\u043A", "training_assignment", () => ({ command: "reschedule", due_on: due.value, reason: why.value }), a));
        panel.append(d, closeRecord("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", "training_assignment", a, "cancel"));
      }
      if (a.change_reason) panel.append(msg("\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435: " + a.change_reason));
      return panel;
    }
    function planMaterial(a) {
      const out = el2("div"), button = btn2("\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043B\u0430\u043D TWI \u0438 \u0448\u0430\u0433\u0438 \u0421\u041E\u041F", async () => {
        button.disabled = true;
        try {
          const r = currentStandard(db, a.sop_revision_id);
          const raw = JSON.parse(await readContent3(r.source));
          const t = linkedTwi(raw.constructor);
          out.replaceChildren(msg("\u0418\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F: " + revLabel(a.sop_revision_id) + " \xB7 " + t.status), tableOf2(["\u0420\u0430\u0437\u0434\u0435\u043B", "\u041F\u043E\u043B\u0435", "\u0421\u043E\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u0435"], t.fields.map((x) => [x.section, x.label, x.value || "\u2014"])), tableOf2(["\u2116", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435", "\u041A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B", "\u041F\u0440\u0438\u0447\u0438\u043D\u044B"], raw.constructor.steps.map((x, i) => [i + 1, x.action, (x.keyMoments || []).join("\n"), x.reason])));
        } catch (e) {
          out.replaceChildren(msg(e.message, "bad"));
          button.disabled = false;
        }
      });
      return pane2("\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", button, out);
    }
    function instruction(a) {
      const pr = progressFor(db, a), can = a.state !== "cancelled" && a.approval_json && sameRevision(a);
      const panel = pane2("\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", msg("\u0412\u0432\u043E\u0434\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C: " + (pr.intro ? "\u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430" : "\u0432 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435") + " \xB7 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438: " + pr.followup + "/5" + (pr.followupDue ? " \xB7 \u0441\u0440\u043E\u043A \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0438 " + pr.followupDue : ""), pr.followupDue && day > pr.followupDue && pr.followup < 5 ? "warn" : "muted"));
      const bar = el2("progress");
      bar.max = pr.stages.length;
      bar.value = pr.completed;
      bar.setAttribute("aria-label", "\u041F\u0440\u043E\u0433\u0440\u0435\u0441\u0441 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430");
      panel.append(bar, tableOf2(["\u042D\u0442\u0430\u043F", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", "\u041F\u043E\u043F\u044B\u0442\u043E\u043A"], pr.stages.map((s) => [s.label, pr.done.has(s.code) ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D" : s.code === pr.next?.code ? "\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439" : "\u041E\u0436\u0438\u0434\u0430\u0435\u0442", pr.facts.filter((x) => x.stage_code === s.code).length])));
      if (can) {
        const stage = select("session_stage", pr.stages.filter((x) => pr.done.has(x.code) || x.code === pr.next?.code).map((x) => [x.code, x.label + (pr.done.has(x.code) ? " \xB7 \u043F\u043E\u0432\u0442\u043E\u0440" : "")]), pr.next?.code || pr.stages[0].code, null);
        const when = fieldInput2("session_when", dateTime(), "datetime-local"), duration = num2("session_minutes", 15, 1, 1440), result = simple("session_result", { completed: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E", incomplete: "\u041D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E, \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C" }, "completed");
        const witness = person2("session_witness", "\u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0442\u043E\u0440 / \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C", "", { optional: true }), notes = note("session_notes", "", "\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435, \u0437\u0430\u0434\u0430\u043D\u0438\u0435, \u0443\u0441\u043B\u043E\u0432\u0438\u044F, \u043E\u0448\u0438\u0431\u043A\u0438 \u0438\u043B\u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442");
        const ack1 = check("mentor_ack", "\u0424\u0430\u043A\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u043C"), ack2 = check("trainee_ack", "\u0424\u0430\u043A\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u043C");
        panel.append(pane2("\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u0444\u0430\u043A\u0442", grid(f("\u042D\u0442\u0430\u043F / \u043F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u0435", stage), f("\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F", when), f("\u041C\u0438\u043D\u0443\u0442", duration), f("\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", result), witness.element), f("\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435 \u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", notes), ack1.element, ack2.element, msg("\u041E\u0442\u043C\u0435\u0442\u043A\u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0442 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u043A\u0442, \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u044E\u0442 \u043F\u043E\u0434\u043F\u0438\u0441\u0438 \u0432 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u0445."), save2("\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u044D\u0442\u0430\u043F", "training_session", () => ({ assignment_id: a.id, assignment_rev: a.rev, stage_code: stage.value, held_at: when.value, duration_minutes: Number(duration.value), result: result.value, notes: notes.value, witness_id: nullable(witness.value), mentor_ack: ack1.input.checked, trainee_ack: ack2.input.checked }))));
      } else panel.append(msg("\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u043E\u0432\u044B\u0445 \u044D\u0442\u0430\u043F\u043E\u0432 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u043F\u043E\u0441\u043B\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F.", "warn"));
      const facts = pr.facts.map((x) => [x.held_at, JSON.parse(x.steps_json).label, resultLabels[x.result] || x.result, x.duration_minutes, x.notes, x.witness_name || "\u2014"]);
      panel.append(pane2("\u0416\u0443\u0440\u043D\u0430\u043B \u0444\u0430\u043A\u0442\u043E\u0432", table(["\u0414\u0430\u0442\u0430 / \u0432\u0440\u0435\u043C\u044F", "\u042D\u0442\u0430\u043F", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", "\u041C\u0438\u043D\u0443\u0442", "\u0417\u0430\u043F\u0438\u0441\u044C", "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C"], facts), exportButton("\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436-" + a.id.slice(0, 8), ["\u0414\u0430\u0442\u0430 / \u0432\u0440\u0435\u043C\u044F", "\u042D\u0442\u0430\u043F", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", "\u041C\u0438\u043D\u0443\u0442", "\u0417\u0430\u043F\u0438\u0441\u044C", "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C"], facts)));
      return stack(planMaterial(a), panel);
    }
    function methodsPanel() {
      const methods = practicalMethods(db), out = pane2("\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043E\u0446\u0435\u043D\u043A\u0438", msg("\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u0439 XLSX \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0433\u043E \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430 \u043B\u0438\u0431\u043E \u043F\u0440\u0438\u0432\u0430\u0442\u043D\u044B\u0439 JSON \u0438\u0437 11 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432. \u0422\u0435\u043A\u0441\u0442 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u043E\u0433\u043E \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430 \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u043F\u0443\u0431\u043B\u0438\u0447\u043D\u0443\u044E \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0443. \u041F\u043E\u0440\u043E\u0433 \u0434\u043E\u043F\u0443\u0441\u043A\u0430 \u0437\u0434\u0435\u0441\u044C \u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u0430\u0432\u043B\u0438\u0432\u0430\u0435\u0442\u0441\u044F."), row(action("\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 JSON", () => pick2(".json", async (p) => {
        validatePracticalMethod(p);
        await write("checklist_version", p);
        return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
      }, 128e3)), action("\u0418\u043C\u043F\u043E\u0440\u0442 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u043E\u0433\u043E XLSX", () => {
        const input = el2("input");
        input.type = "file";
        input.accept = ".xlsx";
        input.onchange = () => {
          if (!input.files?.[0]) return;
          const file = input.files[0];
          run2(async () => {
            invariant(file.size <= 12 * 1024 * 1024, "\u0424\u0430\u0439\u043B \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
            const bytes = new Uint8Array(await file.arrayBuffer()), book = new ExcelJS.Workbook();
            await book.xlsx.load(bytes);
            const sheet = book.worksheets.find((s) => s.name.trim().toLocaleLowerCase("ru-RU") === "\u0447\u0435\u043A \u043B\u0438\u0441\u0442");
            invariant(sheet, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u0443\u044E \u0444\u043E\u0440\u043C\u0443 \u0441 \u043B\u0438\u0441\u0442\u043E\u043C \xAB\u0427\u0435\u043A \u043B\u0438\u0441\u0442\xBB \u0438\u043B\u0438 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 JSON");
            const criteria = [8, 9, 11, 12, 13, 14, 15, 16, 17, 18, 19].map((r, i) => ({ code: i + 1, section: r <= 9 ? "\u0420\u0430\u0437\u0434\u0435\u043B 1" : "\u0420\u0430\u0437\u0434\u0435\u043B 2", question: sheet.getCell("A" + r).text.trim() }));
            const p = validatePracticalMethod({ format: "lean-practical-checklist-v1", title: "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \xB7 " + file.name.slice(0, 150), source_sha256: await sha256(bytes), criteria });
            invariant(new Set(criteria.map((x) => x.question)).size === 11, "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u0442\u0440\u043E\u043A\u0438 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u044B");
            if (!confirm("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u0438\u0437 11 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432?\n\n" + criteria.map((x) => x.code + ". " + x.question).join("\n"))) return "\u0418\u043C\u043F\u043E\u0440\u0442 \u043E\u0442\u043C\u0435\u043D\u0451\u043D";
            await write("checklist_version", p);
            return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
          });
        };
        input.click();
      })));
      for (const m of methods) {
        const d = el2("details"), p = JSON.parse(m.methodology_json);
        d.append(el2("summary", "v" + m.version_no + " \xB7 " + p.title + " \xB7 " + (m.state === "active" ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u0418\u0441\u0442\u043E\u0440\u0438\u044F")), tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439"], practicalCriteria(db, m.id).map((q) => [q.position, q.section_code, q.question])));
        out.append(d);
      }
      return out;
    }
    function verificationForm(a, kind) {
      const who = person2("verify_" + kind + "_actor", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "", { filter: (x) => x.id !== a.trainee_id }), when = date3("verify_" + kind + "_date"), result = simple("verify_" + kind + "_result", { pass: "\u041F\u0440\u043E\u0439\u0434\u0435\u043D\u043E", fail: "\u041D\u0435 \u043F\u0440\u043E\u0439\u0434\u0435\u043D\u043E" }, "pass"), evidence = note("verify_" + kind + "_evidence"), feedback = note("verify_" + kind + "_feedback");
      const d = el2("details");
      d.append(el2("summary", kind === "safety" ? "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u041E\u0422" : "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u0442\u0435\u043E\u0440\u0438\u0438"), grid(who.element, f("\u0414\u0430\u0442\u0430", when), f("\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", result)), f("\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 / \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438", evidence), f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C", feedback), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 " + (kind === "safety" ? "\u041E\u0422" : "\u0442\u0435\u043E\u0440\u0438\u0438"), "training_verification", () => ({ assignment_id: a.id, assignment_rev: a.rev, kind, evaluator_id: who.value, evaluated_on: when.value, result: result.value, evidence: evidence.value, feedback: feedback.value })));
      return d;
    }
    function practicalForm(a) {
      const methods = practicalMethods(db).filter((x) => x.state === "active");
      if (!methods.length) return msg("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0432 \u0440\u0430\u0437\u0434\u0435\u043B\u0435 \xAB\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043E\u0446\u0435\u043D\u043A\u0438\xBB.", "warn");
      const m = methods[0], who = person2("practical_actor", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "", { filter: (x) => x.id !== a.trainee_id }), when = date3("practical_date"), conclusion = simple("practical_conclusion", conclusions, "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u2014"), feedback = note("practical_feedback");
      const controls = practicalCriteria(db, m.id).map((x) => ({ x, value: select("practical_value_" + x.position, [[0, "0 \u2014 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E"], [1, "1 \u2014 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E"]], "", "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E"), note: fieldInput2("practical_note_" + x.position) }));
      const result = msg("\u041E\u0446\u0435\u043D\u0435\u043D\u043E 0/11"), value = () => controls.map((q) => ({ criterion_id: q.x.id, value: q.value.value === "" ? null : Number(q.value.value), note: q.note.value }));
      function refresh2() {
        const x = practicalResult(value());
        result.textContent = "\u041E\u0446\u0435\u043D\u0435\u043D\u043E " + x.rated + "/11 \xB7 " + (x.fraction === null ? "\u0438\u0442\u043E\u0433 \u043D\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D" : x.yes + "/11 \xB7 " + (x.fraction * 100).toFixed(1) + "%");
      }
      controls.forEach((q) => q.value.onchange = refresh2);
      const d = el2("details");
      d.append(el2("summary", "\u041D\u043E\u0432\u0430\u044F \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430"), grid(who.element, f("\u0414\u0430\u0442\u0430", when), f("\u0417\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044E", conclusion)), msg("\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 v" + m.version_no + " \xB7 \u043F\u0440\u043E\u0446\u0435\u043D\u0442 \u0441\u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0441\u043B\u0435 \u0432\u0441\u0435\u0445 11 \u043E\u0442\u0432\u0435\u0442\u043E\u0432; \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0432\u044B\u0431\u0438\u0440\u0430\u0435\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E."), tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], controls.map((q) => [q.x.position, q.x.section_code, q.x.question, q.value, q.note])), result, f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u043C\u0443 / \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0443", feedback), save2("\u0417\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u043E\u0446\u0435\u043D\u043A\u0443", "assessment_session", () => ({ command: "practical", assignment_id: a.id, assignment_rev: a.rev, evaluator_id: who.value, assessed_on: when.value, method_id: m.id, responses: value(), conclusion: conclusion.value, feedback: feedback.value })));
      return d;
    }
    function qualificationForm(a, p) {
      const actor = person2("qualification_actor", "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C", "", { filter: (x) => x.id !== a.trainee_id }), when = date3("qualification_date"), state = simple("qualification_state", observationLabels, "rated"), level2 = levelPicker("qualification_level", a.scale_id), until = date3("qualification_until", ""), evidence = note("qualification_evidence"), feedback = note("qualification_feedback");
      state.onchange = () => {
        level2.disabled = state.value !== "rated";
        until.disabled = level2.disabled;
        if (level2.disabled) {
          level2.value = "";
          until.value = "";
        }
      };
      const d = el2("details");
      d.append(el2("summary", "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044E"), msg("\u041D\u0430\u0432\u044B\u043A: " + n("skill", a.skill_id) + " \xB7 \u0448\u043A\u0430\u043B\u0430 " + n("rating_scale", a.scale_id) + " \xB7 \u0446\u0435\u043B\u044C " + a.target_level + ". \u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0432\u044B\u0431\u0438\u0440\u0430\u0435\u0442\u0441\u044F \u043F\u043E \u0444\u0430\u043A\u0442\u0443, \u043D\u0435 \u0438\u0437 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u0430."), grid(actor.element, f("\u0414\u0430\u0442\u0430", when), f("\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435", state), f("\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C", level2), f("\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u0435\u043D \u0434\u043E (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E)", until)), f("\u0414\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u0438 \u043E\u0431\u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", evidence), f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C", feedback), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u044F", "assessment_session", () => ({ command: "qualification", assignment_id: a.id, assignment_rev: a.rev, evaluator_id: actor.value, assessed_on: when.value, practical_id: p.id, observation_state: state.value, level: state.value === "rated" && level2.value !== "" ? Number(level2.value) : null, valid_until: nullable(until.value), evidence: evidence.value, feedback: feedback.value })));
      return d;
    }
    function admissionForm(a) {
      const actor = person2("admission_actor", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0437\u0430 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435", "", { filter: (x) => x.id !== a.trainee_id }), when = date3("admission_date"), decision = simple("admission_decision", decisionLabels, "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u2014"), until = date3("admission_until", ""), evidence = note("admission_evidence"), feedback = note("admission_feedback");
      decision.onchange = () => {
        until.disabled = decision.value !== "granted";
        if (until.disabled) until.value = "";
      };
      const d = el2("details");
      d.append(el2("summary", "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435"), msg("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u0443\u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0435\u043D\u043D\u043E\u0433\u043E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430. \u041E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0432\u043D\u0435\u0448\u043D\u0438\u0435 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B, \u043D\u0430\u0440\u044F\u0434\u044B \u0438 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u0442."), grid(actor.element, f("\u0414\u0430\u0442\u0430 \u0440\u0435\u0448\u0435\u043D\u0438\u044F", when), f("\u0420\u0435\u0448\u0435\u043D\u0438\u0435", decision), f("\u0421\u0440\u043E\u043A (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D)", until)), f("\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 / \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430", evidence), f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C", feedback), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435", "admission_decision", () => ({ assignment_id: a.id, assignment_rev: a.rev, actor_id: actor.value, decided_on: when.value, valid_until: nullable(until.value), decision: decision.value, evidence: evidence.value, feedback: feedback.value })));
      return d;
    }
    function practice2(a) {
      const pr = progressFor(db, a), x = evidenceSummary(a), can = a.state !== "cancelled" && a.approval_json && sameRevision(a);
      const panel = pane2("\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430, \u0437\u043D\u0430\u043D\u0438\u044F \u0438 \u0434\u043E\u043F\u0443\u0441\u043A", tableOf2(["\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435"], [["\u0412\u0432\u043E\u0434\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", pr.intro ? "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430" : "\u041D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430"], ["\u041E\u0422", x.s ? resultLabels[x.s.result] : "\u041D\u0435\u0442 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430"], ["\u0422\u0435\u043E\u0440\u0438\u044F", x.t ? resultLabels[x.t.result] : "\u041D\u0435\u0442 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430"], ["\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430", x.p ? conclusions[x.p.conclusion] : "\u041D\u0435\u0442 \u043E\u0446\u0435\u043D\u043A\u0438"], ["\u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F", x.q ? "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043E" : "\u041D\u0435\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F"], ["\u0414\u043E\u043F\u0443\u0441\u043A", x.ad.status]]), msg("\u041F\u043E\u043B\u043E\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0438 \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u043D\u0435 \u0432\u044B\u0434\u0430\u044E\u0442 \u0434\u043E\u043F\u0443\u0441\u043A \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438."));
      if (can) {
        panel.append(verificationForm(a, "safety"), verificationForm(a, "theory"));
        if (pr.intro) panel.append(practicalForm(a));
        else panel.append(msg("\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u043F\u043E\u0441\u043B\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0432\u0432\u043E\u0434\u043D\u044B\u0445 \u043F\u0440\u043E\u0431.", "muted"));
        if (x.p) panel.append(qualificationForm(a, x.p));
        panel.append(admissionForm(a));
      }
      const verifications = rows(db, "SELECT * FROM training_verification WHERE assignment_id=? ORDER BY evaluated_on DESC,recorded_at DESC", [a.id]);
      panel.append(pane2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043E\u043A \u0437\u043D\u0430\u043D\u0438\u0439", table(["\u0414\u0430\u0442\u0430", "\u0412\u0438\u0434", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C"], verifications.map((v) => [v.evaluated_on, v.kind === "safety" ? "\u041E\u0422" : "\u0422\u0435\u043E\u0440\u0438\u044F", resultLabels[v.result], n("person", v.evaluator_id), v.evidence, v.feedback]))));
      const history = rows(db, "SELECT * FROM assessment_session WHERE assignment_id=? AND state='confirmed' ORDER BY assessed_at DESC,recorded_at DESC", [a.id]);
      const assessed = pane2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 \u0438 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438");
      for (const h of history) {
        const detail = el2("details");
        if (h.assessment_kind === "practical") {
          const values = JSON.parse(h.responses_json), result = practicalResult(values), criteria = practicalCriteria(db, h.method_id), lines = values.map((v, i) => [i + 1, criteria[i]?.section_code, criteria[i]?.question, v.value, v.note]);
          detail.append(el2("summary", h.assessed_at + " \xB7 \u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \xB7 " + result.yes + "/11 \xB7 " + (result.fraction * 100).toFixed(1) + "% \xB7 " + conclusions[h.conclusion]), msg("\u041E\u0446\u0435\u043D\u0449\u0438\u043A: " + n("person", h.evaluator_id) + " \xB7 " + h.feedback), tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], lines), exportButton("\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F-\u043E\u0446\u0435\u043D\u043A\u0430-" + h.id.slice(0, 8), ["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], [...lines, ["", "\u0418\u0442\u043E\u0433\u043E", result.yes + "/11", (result.fraction * 100).toFixed(1) + "%", conclusions[h.conclusion] + " \xB7 " + h.feedback]]));
        } else {
          const i = one(db, "SELECT * FROM assessment_item WHERE session_id=?", [h.id]);
          detail.append(el2("summary", h.assessed_at + " \xB7 \u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F \xB7 " + (i?.observation_state === "rated" ? "\u0443\u0440\u043E\u0432\u0435\u043D\u044C " + i.level : observationLabels[i?.observation_state] || "\u2014")), msg("\u0428\u043A\u0430\u043B\u0430: " + n("rating_scale", i?.scale_id) + " \xB7 \u0434\u043E " + (i?.valid_until || "\u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E") + " \xB7 " + n("person", h.evaluator_id)), msg(i?.evidence_note || ""), msg(h.feedback));
        }
        assessed.append(detail);
      }
      if (!history.length) assessed.append(msg("\u041E\u0446\u0435\u043D\u043E\u043A \u043F\u043E\u043A\u0430 \u043D\u0435\u0442."));
      panel.append(assessed);
      const ads = rows(db, "SELECT * FROM admission_decision WHERE assignment_id=? ORDER BY decided_on DESC,recorded_at DESC", [a.id]);
      const decisions = pane2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u0439 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435");
      for (const d of ads) {
        decisions.append(pane2(d.decided_on + " \xB7 " + decisionLabels[d.decision] + (d.revoked_at ? " \xB7 \u041E\u0442\u043E\u0437\u0432\u0430\u043D" : ""), msg("\u0420\u0435\u0448\u0435\u043D\u0438\u0435: " + n("person", d.actor_id) + " \xB7 \u0441\u0440\u043E\u043A: " + (d.valid_until || "\u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D")), msg(d.evidence), msg(d.feedback), ...d.revoked_at ? [msg("\u041F\u0440\u0438\u0447\u0438\u043D\u0430 \u043E\u0442\u0437\u044B\u0432\u0430: " + d.revoke_reason)] : d.decision === "granted" ? [closeRecord("\u041E\u0442\u043E\u0437\u0432\u0430\u0442\u044C \u0434\u043E\u043F\u0443\u0441\u043A", "admission_decision", d, "revoke")] : []));
      }
      if (!ads.length) decisions.append(msg("\u041D\u0435\u0442 \u0440\u0435\u0448\u0435\u043D\u0438\u0439."));
      panel.append(decisions);
      return panel;
    }
    function assignmentCard(a) {
      const root2 = pane2("\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \xB7 " + assignmentName(a), row(back(), btn2("\u041A \u043F\u043B\u0430\u043D\u0443 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", () => go("twi")), btn2("\u041A \u0436\u0443\u0440\u043D\u0430\u043B\u0443", () => go("journal")))), tabs = el2("div", void 0, "library-tabs");
      const selected = route.tab || (page2 === "instruction" ? "instruction" : page2 === "practical" ? "practice" : "overview"), content2 = el2("div");
      for (const [id, label, fn] of [["overview", "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", () => overview(a)], ["instruction", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436", () => instruction(a)], ["practice", "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \u0438 \u0434\u043E\u043F\u0443\u0441\u043A", () => practice2(a)]]) {
        const button = btn2(label, () => {
          route.tab = id;
          for (const x of tabs.children) x.classList.remove("selected");
          button.classList.add("selected");
          content2.replaceChildren(fn());
        }, "library-tab" + (selected === id ? " selected" : ""));
        tabs.append(button);
        if (selected === id) content2.append(fn());
      }
      root2.append(tabs, content2);
      return root2;
    }
    function registryPrograms() {
      const items = rows(db, "SELECT * FROM training_program ORDER BY code,version_no DESC").filter((p) => page2 === "internship" ? p.kind === "internship" : p.kind !== "internship"), enrollments = enrollmentList().filter((x) => items.some((p) => p.id === x.program_id));
      return stack(
        pane2(page2 === "internship" ? "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438" : "\u0428\u0430\u0431\u043B\u043E\u043D\u044B \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0438 \u0438 \u0432\u0432\u043E\u0434\u0430 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E", msg("\u0412\u0435\u0440\u0441\u0438\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u044B. \u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u0445\u0440\u0430\u043D\u0438\u0442 \u0441\u0432\u043E\u044E \u0432\u0435\u0440\u0441\u0438\u044E, \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044B\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B."), action("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", () => goLocal({ mode: "program" })), table(["\u041A\u043E\u0434", "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", "\u0412\u0438\u0434", "\u0412\u0435\u0440\u0441\u0438\u044F", "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F / \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], items.map((p) => [p.code, p.title, programKinds[p.kind], p.version_no, n("profession", p.profession_id) + " / " + n("position", p.position_id), statuses[p.state], btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ programId: p.id }), "primary")]))),
        pane2("\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", table(["\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", "\u0421\u0440\u043E\u043A", "\u0417\u0430\u0434\u0430\u043D\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], enrollments.map((x) => {
          const p = items.find((v) => v.id === x.program_id), t = enrollmentTasks(db, x);
          return [n("person", x.trainee_id), p.title + " \xB7 v" + p.version_no, n("person", x.mentor_id), x.due_on, t.filter((y) => y.done).length + "/" + t.length, statuses[x.state], btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ enrollmentId: x.id }), "primary")];
        })))
      );
    }
    function programForm() {
      const prev = route.copyId ? one(db, "SELECT * FROM training_program WHERE id=?", [route.copyId]) : null;
      const code = fieldInput2("program_code", prev?.code || ""), title = fieldInput2("program_title", prev?.title || ""), kind = select("program_kind", Object.entries(programKinds).filter(([k]) => page2 === "internship" ? k === "internship" : k !== "internship"), prev?.kind || (page2 === "internship" ? "internship" : "entry"), null);
      const profession = ref("profession", "program_profession", prev?.profession_id || "", "\u2014 \u041B\u044E\u0431\u0430\u044F \u2014"), position = ref("position", "program_position", prev?.position_id || "", "\u2014 \u041B\u044E\u0431\u0430\u044F \u2014"), author = person2("program_author", "\u0421\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u0435\u043B\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B"), tasks = el2("div", void 0, "stack"), controls = [];
      function taskLine(x = {}) {
        const part2 = simple("task_part", parts, x.part || "general"), name = fieldInput2("task_title", x.title || ""), hours = num2("task_hours", x.hours ?? 0, 0, 1e3, 0.25), offset = num2("task_day", x.day_offset ?? 0, 0, 3660), rev = revPicker("task_revision", x.sop_revision_id || "");
        const skill = ref("skill", "task_skill", x.skill_id || "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", (v) => v.operation_id === currentStandard(db, rev.value)?.operation_id), target = scaleFields("task_target", x.scale_id || "", x.target_level ?? null), line = el2("div", void 0, "lc4-task");
        const item = { part: part2, name, hours, offset, rev, skill, target, line };
        controls.push(item);
        function sync() {
          const on = !!rev.value;
          skill.disabled = !on;
          target.scale.disabled = !on;
          target.level.disabled = !on;
          if (!on) {
            skill.value = "";
            target.set("", null);
          }
        }
        rev.onchange = () => {
          replaceOptions(skill, ref("skill", "task_skill", "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", (v) => v.operation_id === currentStandard(db, rev.value)?.operation_id));
          sync();
        };
        line.append(row(el2("strong", "\u0417\u0430\u0434\u0430\u043D\u0438\u0435"), btn2("\u0423\u0434\u0430\u043B\u0438\u0442\u044C", () => {
          const i = controls.indexOf(item);
          if (i >= 0) controls.splice(i, 1);
          line.remove();
        })), grid(f("\u0427\u0430\u0441\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", part2), f("\u0417\u0430\u0434\u0430\u043D\u0438\u0435 / \u0444\u0443\u043D\u043A\u0446\u0438\u044F", name), f("\u0427\u0430\u0441\u044B", hours), f("\u0414\u0435\u043D\u044C \u043E\u0442 \u043D\u0430\u0447\u0430\u043B\u0430 (0 = \u043F\u0435\u0440\u0432\u044B\u0439)", offset)), f("\u0421\u041E\u041F (\u0435\u0441\u043B\u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438)", rev), f("\u041D\u0430\u0432\u044B\u043A", skill), target.element);
        tasks.append(line);
        sync();
      }
      if (prev) rows(db, "SELECT * FROM training_program_task WHERE program_id=? ORDER BY position", [prev.id]).forEach(taskLine);
      else if (page2 === "internship") Object.keys(parts).forEach((part2) => taskLine({ part: part2 }));
      else taskLine();
      return pane2(prev ? "\u041D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B" : "\u041D\u043E\u0432\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", row(back()), grid(f("\u041A\u043E\u0434", code), f("\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", title), f("\u0412\u0438\u0434", kind), f("\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", profession), f("\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", position), author.element), msg("\u0417\u0430\u0434\u0430\u043D\u0438\u044F \u0441 \u0421\u041E\u041F \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u044E\u0442\u0441\u044F \u0447\u0435\u0440\u0435\u0437 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F; \u043E\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u043E\u0442\u043C\u0435\u0447\u0430\u044E\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u043C \u0444\u0430\u043A\u0442\u043E\u043C. \u041F\u0440\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0438 \u0442\u043E\u0433\u043E \u0436\u0435 \u043A\u043E\u0434\u0430 \u0441\u043E\u0437\u0434\u0430\u0451\u0442\u0441\u044F \u043D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F."), tasks, btn2("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u0435", () => taskLine()), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0432\u0435\u0440\u0441\u0438\u044E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", "training_program", () => ({ code: code.value, kind: kind.value, title: title.value, profession_id: nullable(profession.value), position_id: nullable(position.value), created_by: author.value, tasks: controls.map((v) => ({ part: v.part.value, title: v.name.value, hours: Number(v.hours.value), day_offset: Number(v.offset.value), sop_revision_id: nullable(v.rev.value), skill_id: v.rev.value ? nullable(v.skill.value) : null, scale_id: v.rev.value ? nullable(v.target.scale.value) : null, target_level: v.rev.value && v.target.level.value !== "" ? Number(v.target.level.value) : null })) }), null, (id) => {
        route = { page: page2, programId: id };
      }));
    }
    function programCard(p) {
      const tasks = rows(db, "SELECT * FROM training_program_task WHERE program_id=? ORDER BY position", [p.id]), lines = tasks.map((x) => [x.position, parts[x.part], x.title, x.day_offset, x.hours, x.sop_revision_id ? revLabel(x.sop_revision_id) : "\u2014", x.target_level ?? "\u2014"]);
      const root2 = pane2(p.code + " \xB7 " + p.title + " \xB7 v" + p.version_no, row(back(), action("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E", () => goLocal({ mode: "program", copyId: p.id }))), msg(programKinds[p.kind] + " \xB7 " + statuses[p.state] + " \xB7 \u0447\u0430\u0441\u043E\u0432 " + tasks.reduce((s, x) => s + x.hours, 0)), tableOf2(["\u2116", "\u0427\u0430\u0441\u0442\u044C", "\u0417\u0430\u0434\u0430\u043D\u0438\u0435", "\u0414\u0435\u043D\u044C", "\u0427\u0430\u0441\u044B", "\u0421\u041E\u041F", "\u0426\u0435\u043B\u044C"], lines), exportButton("\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430-" + p.code, ["\u2116", "\u0427\u0430\u0441\u0442\u044C", "\u0417\u0430\u0434\u0430\u043D\u0438\u0435", "\u0414\u0435\u043D\u044C", "\u0427\u0430\u0441\u044B", "\u0421\u041E\u041F", "\u0426\u0435\u043B\u044C"], lines));
      if (p.state === "active") {
        const start = date3("enroll_start"), due = date3("enroll_due"), learner = person2("enroll_trainee", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "", { allowed: ["trainee"], at: () => start.value }), mentor = person2("enroll_mentor", "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", "", { allowed: ["mentor", "instructor"], at: () => start.value }), manager = person2("enroll_manager", "\u0420\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C"), reason = note("enroll_reason");
        const d = el2("details");
        d.append(el2("summary", "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0443\u044E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443"), grid(learner.element, mentor.element, manager.element, f("\u041D\u0430\u0447\u0430\u043B\u043E", start), f("\u0421\u0440\u043E\u043A \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F", due)), f("\u041F\u0440\u0438\u0447\u0438\u043D\u0430 / \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", reason), save2("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", "training_enrollment", () => ({ program_id: p.id, trainee_id: learner.value, mentor_id: mentor.value, manager_id: manager.value, start_on: start.value, due_on: due.value, reason: reason.value }), null, (id) => {
          route = { page: page2, enrollmentId: id };
        }));
        root2.append(d, closeRecord("\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0448\u0430\u0431\u043B\u043E\u043D\u0430", "training_program", p, "retire"));
      }
      return root2;
    }
    function plusDays2(d, days) {
      const v = /* @__PURE__ */ new Date(d + "T00:00:00Z");
      v.setUTCDate(v.getUTCDate() + days);
      return v.toISOString().slice(0, 10);
    }
    function enrollmentCard(x) {
      const p = one(db, "SELECT * FROM training_program WHERE id=?", [x.program_id]), tasks = enrollmentTasks(db, x), panel = pane2("\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \xB7 " + n("person", x.trainee_id), row(back(), btn2("\u0428\u0430\u0431\u043B\u043E\u043D \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", () => goLocal({ programId: p.id }))), msg(p.title + " \xB7 v" + p.version_no + " \xB7 " + statuses[x.state] + " \xB7 " + x.start_on + " \u2014 " + x.due_on), msg("\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A: " + n("person", x.mentor_id) + " \xB7 \u0440\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C: " + n("person", x.manager_id) + " \xB7 " + x.reason), tableOf2(["\u0427\u0430\u0441\u0442\u044C", "\u0417\u0430\u0434\u0430\u043D\u0438\u0435", "\u0421\u0440\u043E\u043A", "\u0427\u0430\u0441\u044B", "\u0424\u0430\u043A\u0442", ""], tasks.map((t2) => {
        const due = plusDays2(x.start_on, t2.day_offset), controls = row();
        if (t2.assignment) controls.append(btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", () => go("twi", { id: t2.assignment.id })));
        else if (x.state === "active" && t2.sop_revision_id) controls.append(action("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436", () => go("twi", { mode: "new", revisionId: t2.sop_revision_id, skillId: t2.skill_id, scaleId: t2.scale_id, targetLevel: t2.target_level, traineeId: x.trainee_id, supervisorId: x.mentor_id, enrollmentId: x.id, programTaskId: t2.id, startOn: x.start_on, dueOn: due, reason: "\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B: " + t2.title })));
        else if (x.state === "active") controls.append(action("\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", () => goLocal({ enrollmentId: x.id, taskId: t2.id })));
        return [parts[t2.part], t2.title, due, t2.hours, t2.done ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E" : t2.assignment ? stateLabel(t2.assignment) : t2.result ? resultLabels[t2.result.result] : "\u041D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E", controls];
      })));
      const t = tasks.find((q) => q.id === route.taskId);
      if (t && !t.sop_revision_id && x.state === "active") {
        const actor = person2("task_actor", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439"), when = date3("task_held"), minutes = num2("task_minutes", 0, 0, 1440), result = simple("task_result", { completed: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E", incomplete: "\u041D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E" }, "completed"), evidence = note("task_evidence");
        panel.append(pane2("\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \xB7 " + t.title, grid(actor.element, f("\u0414\u0430\u0442\u0430", when), f("\u041C\u0438\u043D\u0443\u0442", minutes), f("\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", result)), f("\u0424\u0430\u043A\u0442 \u0438 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", evidence), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0437\u0430\u0434\u0430\u043D\u0438\u044F", "training_task_result", () => ({ enrollment_id: x.id, task_id: t.id, actor_id: actor.value, held_on: when.value, result: result.value, minutes: Number(minutes.value), evidence: evidence.value, enrollment_rev: x.rev }), null, () => {
          route = { page: page2, enrollmentId: x.id };
        })));
      }
      if (x.state === "active") {
        const actor = person2("enroll_finish_actor", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0437\u0430 \u0438\u0442\u043E\u0433"), conclusion = simple("enroll_conclusion", conclusions, "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014"), feedback = note("enroll_feedback"), d = el2("details");
        d.append(el2("summary", "\u0418\u0442\u043E\u0433 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B"), grid(actor.element, f("\u0417\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435", conclusion)), f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C / \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", feedback), save2("\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", "training_enrollment", () => ({ command: "finish", actor_id: actor.value, conclusion: conclusion.value, feedback: feedback.value }), x, () => {
        }, !tasks.every((t2) => t2.done)), save2("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", "training_enrollment", () => ({ command: "cancel", actor_id: actor.value, conclusion: null, feedback: feedback.value }), x));
        panel.append(d);
      } else panel.append(msg("\u0417\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435: " + (conclusions[x.conclusion] || "\u2014") + " \xB7 " + (x.feedback || "")));
      return panel;
    }
    function certificatePage() {
      const items = rows(db, "SELECT * FROM mentor_credential ORDER BY issued_on DESC,id"), out = pane2("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B \u0438 \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0430", msg("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u044E\u0442\u0441\u044F \u0432\u044B\u0434\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B. \u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u043E \u043F\u0440\u043E\u0441\u043B\u0443\u0448\u0438\u0432\u0430\u043D\u0438\u0438 \u043D\u0435 \u0434\u0430\u0451\u0442 \u043F\u0440\u0430\u0432\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C. \u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F \u043F\u043E \u0431\u0430\u043B\u043B\u0430\u043C \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F."), action("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442", () => goLocal({ mode: "new" })), table(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0412\u0438\u0434", "\u0420\u043E\u043B\u044C", "\u041D\u043E\u043C\u0435\u0440", "\u0412\u044B\u0434\u0430\u043D", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u0434\u043E", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], items.map((x2) => [n("person", x2.person_id), x2.kind === "certificate" ? "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442" : "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E", credentialRoles[x2.role], x2.number, x2.issued_on, x2.valid_until || "\u041D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D", x2.revoked_at ? "\u041E\u0442\u043E\u0437\u0432\u0430\u043D" : x2.valid_until && x2.valid_until < day ? "\u0418\u0441\u0442\u0451\u043A" : "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D", btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: x2.id }), "primary")])));
      if (route.mode === "new") {
        const who = person2("credential_person", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A"), actor = person2("credential_actor", "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043B"), role = simple("credential_role", credentialRoles, "instructor"), kind = simple("credential_kind", { certificate: "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442", attendance: "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u043E \u043F\u0440\u043E\u0441\u043B\u0443\u0448\u0438\u0432\u0430\u043D\u0438\u0438" }, "certificate"), number = fieldInput2("credential_number"), issuer = fieldInput2("credential_issuer"), issued = date3("credential_issued"), valid = date3("credential_valid", ""), evidence = note("credential_evidence");
        return pane2("\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u043E \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0435", back(), grid(who.element, actor.element, f("\u0412\u0438\u0434", kind), f("\u0420\u043E\u043B\u044C", role), f("\u041D\u043E\u043C\u0435\u0440", number), f("\u041A\u0435\u043C \u0432\u044B\u0434\u0430\u043D", issuer), f("\u0412\u044B\u0434\u0430\u043D", issued), f("\u0421\u0440\u043E\u043A (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D)", valid)), f("\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B / \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0439 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442", evidence), save2("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442", "mentor_credential", () => ({ person_id: who.value, registered_by: actor.value, kind: kind.value, role: role.value, number: number.value, issuer: issuer.value, issued_on: issued.value, valid_until: nullable(valid.value), evidence: evidence.value }), null, (id) => {
          route = { page: page2, id };
        }));
      }
      const x = items.find((v) => v.id === route.id);
      if (x) return pane2(n("person", x.person_id) + " \xB7 " + x.number, back(), msg(credentialRoles[x.role] + " \xB7 " + x.issuer + " \xB7 " + x.issued_on + " \xB7 " + (x.revoked_at ? "\u041E\u0442\u043E\u0437\u0432\u0430\u043D" : "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D")), msg(x.evidence), ...!x.revoked_at ? [closeRecord("\u041E\u0442\u043E\u0437\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442", "mentor_credential", x, "revoke")] : []);
      return out;
    }
    function appointmentPage() {
      const items = rows(db, "SELECT * FROM mentor_appointment ORDER BY valid_from DESC,id");
      if (route.mode === "new") {
        const cert = select("appointment_certificate", rows(db, "SELECT * FROM mentor_credential WHERE kind='certificate' AND revoked_at IS NULL ORDER BY issued_on DESC").map((x2) => [x2.id, n("person", x2.person_id) + " \xB7 " + credentialRoles[x2.role] + " \xB7 " + x2.number])), actor = person2("appointment_actor", "\u0423\u0442\u0432\u0435\u0440\u0434\u0438\u0432\u0448\u0438\u0439 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"), number = fieldInput2("appointment_number"), order = date3("appointment_order_date"), start = date3("appointment_start"), end = date3("appointment_end", ""), ack = date3("appointment_ack"), evidence = note("appointment_evidence");
        return pane2("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043F\u0440\u0438\u043A\u0430\u0437\u0430", back(), f("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0438 \u0440\u043E\u043B\u044C", cert), grid(actor.element, f("\u041D\u043E\u043C\u0435\u0440 \u043F\u0440\u0438\u043A\u0430\u0437\u0430", number), f("\u0414\u0430\u0442\u0430 \u043F\u0440\u0438\u043A\u0430\u0437\u0430", order), f("\u041D\u0430\u0447\u0430\u043B\u043E \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0439", start), f("\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E)", end), f("\u0414\u0430\u0442\u0430 \u043E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u044F", ack)), f("\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 / \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043A\u0430\u0437\u0430", evidence), save2("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u0438\u043A\u0430\u0437", "mentor_appointment", () => {
          const c2 = one(db, "SELECT * FROM mentor_credential WHERE id=?", [cert.value]);
          invariant(c2, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442");
          return { person_id: c2.person_id, credential_id: c2.id, role: c2.role, order_number: number.value, order_on: order.value, approved_by: actor.value, valid_from: start.value, valid_to: nullable(end.value), acknowledged_on: ack.value, evidence: evidence.value };
        }, null, (id) => {
          route = { page: page2, id };
        }));
      }
      const x = items.find((v) => v.id === route.id);
      if (x) return pane2("\u041F\u0440\u0438\u043A\u0430\u0437 " + x.order_number, back(), msg(n("person", x.person_id) + " \xB7 " + credentialRoles[x.role] + " \xB7 " + x.valid_from + " \u2014 " + (x.valid_to || "\u0431\u0435\u0437 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F")), msg(x.evidence), ...!x.revoked_at ? [closeRecord("\u041F\u0440\u0435\u043A\u0440\u0430\u0442\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043F\u0440\u0438\u043A\u0430\u0437\u0430", "mentor_appointment", x, "revoke")] : [msg("\u041F\u0440\u0435\u043A\u0440\u0430\u0449\u0435\u043D\u043E: " + x.revoked_at)]);
      return pane2("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E \u043F\u0440\u0438\u043A\u0430\u0437\u0430\u043C", msg("\u0420\u043E\u043B\u0438 \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0435, \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u0438 \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u044B\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 \u2014 \u0440\u0430\u0437\u043D\u044B\u0435 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u044F. \u041F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0432 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435 \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430."), row(action("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u0438\u043A\u0430\u0437", () => goLocal({ mode: "new" })), btn2("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B", () => go("certification"))), table(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0420\u043E\u043B\u044C", "\u041F\u0440\u0438\u043A\u0430\u0437", "\u041D\u0430\u0447\u0430\u043B\u043E", "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", "\u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435", ""], items.map((x2) => [n("person", x2.person_id), credentialRoles[x2.role], x2.order_number, x2.valid_from, x2.valid_to || "\u2014", x2.acknowledged_on + (x2.revoked_at ? " \xB7 \u043F\u0440\u0435\u043A\u0440\u0430\u0449\u0451\u043D" : ""), btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: x2.id }), "primary")])));
    }
    function mentorPage() {
      const persons = directoryPeople(db, day).filter((p) => p.roles.some((x) => ["mentor", "instructor"].includes(x.kind))), auths = rows(db, "SELECT * FROM mentor_authorization WHERE credential_id IS NOT NULL ORDER BY valid_from DESC,id");
      if (route.mode === "auth") {
        let refresh2 = function() {
          replaceOptions(appointment, select("auth_appointment", rows(db, "SELECT * FROM mentor_appointment WHERE person_id=? AND revoked_at IS NULL ORDER BY valid_from DESC", [who.value]).map((x) => [x.id, x.order_number + " \xB7 " + credentialRoles[x.role] + " \xB7 " + x.valid_from])));
        };
        const who = person2("auth_person", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 / \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", route.personId || "", { allowed: ["mentor", "instructor"], onChange: refresh2 }), actor = person2("auth_actor", "\u0423\u0442\u0432\u0435\u0440\u0434\u0438\u0432\u0448\u0438\u0439 \u043F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C"), op = ref("operation", "auth_operation"), start = date3("auth_start"), end = date3("auth_end", ""), appointment = select("auth_appointment", []);
        refresh2();
        return pane2("\u041F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438", back(), grid(who.element, actor.element, f("\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", op), f("\u041F\u0440\u0438\u043A\u0430\u0437", appointment), f("\u041D\u0430\u0447\u0430\u043B\u043E", start), f("\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E)", end)), msg("\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0440\u043E\u043B\u0438, \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u0438 \u043F\u0440\u0438\u043A\u0430\u0437. \u0412\u0441\u0435 \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0442\u0441\u044F \u044F\u0434\u0440\u043E\u043C \u043D\u0430 \u0434\u0430\u0442\u0443 \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u044F."), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0435", "mentor_authorization", () => {
          const o = one(db, "SELECT * FROM mentor_appointment WHERE id=?", [appointment.value]);
          invariant(o, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0440\u0438\u043A\u0430\u0437 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
          return { person_id: who.value, operation_id: op.value, approved_by: actor.value, valid_from: start.value, valid_to: nullable(end.value), credential_id: o.credential_id, appointment_id: o.id };
        }, null, () => {
          route = { page: page2, personId: who.value };
        }));
      }
      const selected = persons.find((p) => p.id === route.personId);
      if (selected) {
        const rowsAuth = auths.filter((x) => x.person_id === selected.id), root2 = pane2("\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A \xB7 " + selected.display_name, back(), msg(selected.roles.map((x) => x.name).join(" \xB7 ")), row(action("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C", () => goLocal({ mode: "auth", personId: selected.id })), btn2("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B", () => go("certification")), btn2("\u041F\u0440\u0438\u043A\u0430\u0437\u044B", () => go("appointments"))), table(["\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", "\u041D\u0430\u0447\u0430\u043B\u043E", "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", ""], rowsAuth.map((a) => [n("operation", a.operation_id), a.valid_from, a.valid_to || "\u2014", authorizationValid(db, a.id, day) ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u041D\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442", a.revoked_at ? "\u041E\u0442\u043E\u0437\u0432\u0430\u043D" : closeRecord("\u041E\u0442\u043E\u0437\u0432\u0430\u0442\u044C", "mentor_authorization", a, "revoke")])), pane2("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438 \u0438\u0441\u0442\u043E\u0440\u0438\u044F", assignmentRows(asgns().filter((a) => a.mentor_id === selected.id || a.supervisor_id === selected.id))));
        return root2;
      }
      const search = searchInput("mentor_search"), out = el2("div");
      filterList(out, search, persons, (p) => p.display_name + " " + p.employee_code + " " + p.unit, (items) => table(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0440\u043E\u043B\u0438", "\u041F\u0440\u0430\u0432 \u043D\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438", "\u041E\u0442\u043A\u0440\u044B\u0442\u044B\u0445 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0439", ""], items.map((p) => [p.display_name, p.unit || "\u2014", p.roles.map((x) => x.name).join(", "), auths.filter((x) => x.person_id === p.id && authorizationValid(db, x.id, day)).length, asgns().filter((a) => a.mentor_id === p.id && activePlan(a)).length, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ personId: p.id }), "primary")])));
      return pane2("\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438 \u0438 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0435 \u0442\u0440\u0435\u043D\u0435\u0440\u044B", msg("\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u0440\u043E\u043B\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432, \u0437\u0430\u0442\u0435\u043C \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B, \u043F\u0440\u0438\u043A\u0430\u0437\u044B \u0438 \u043F\u0440\u0430\u0432\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C."), row(action("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C", () => goLocal({ mode: "auth" })), btn2("\u0420\u043E\u043B\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", () => go("business_role")), btn2("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0440\u043E\u043B\u0435\u0439", () => go("role_assignment")), btn2("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B", () => go("certification")), btn2("\u041F\u0440\u0438\u043A\u0430\u0437\u044B", () => go("appointments"))), search, out);
    }
    function requirementsPanel() {
      const profession = ref("profession", "requirement_profession"), skill = ref("skill", "requirement_skill"), target = scaleFields("requirement_target"), critical = simple("requirement_critical", { normal: "\u041E\u0431\u044B\u0447\u043D\u0430\u044F", important: "\u0412\u0430\u0436\u043D\u0430\u044F", critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" }, "normal"), start = date3("requirement_start"), end = date3("requirement_end", "");
      const existing = rows(db, "SELECT * FROM role_requirement ORDER BY valid_from DESC"), d = el2("details");
      d.append(el2("summary", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u043A \u043D\u0430\u0432\u044B\u043A\u0430\u043C \u043F\u043E \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F\u043C"), grid(f("\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", profession), f("\u041D\u0430\u0432\u044B\u043A", skill), f("\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u043E\u0441\u0442\u044C", critical), f("\u041D\u0430\u0447\u0430\u043B\u043E", start), f("\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 (\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)", end)), target.element, save2("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "role_requirement", () => ({ profession_id: profession.value, skill_id: skill.value, scale_id: target.scale.value, required_level: target.level.value === "" ? null : Number(target.level.value), criticality: critical.value, valid_from: start.value, valid_to: nullable(end.value) })), table(["\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", "\u041D\u0430\u0432\u044B\u043A", "\u0428\u043A\u0430\u043B\u0430", "\u0426\u0435\u043B\u044C", "\u041F\u0435\u0440\u0438\u043E\u0434", ""], existing.map((v) => {
        const end2 = date3("close_requirement");
        const closure = el2("details");
        closure.append(el2("summary", "\u0417\u0430\u043A\u0440\u044B\u0442\u044C"), f("\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u0434\u0435\u043D\u044C", end2), save2("\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "role_requirement", () => ({ command: "close", valid_to: end2.value }), v));
        return [n("profession", v.profession_id), n("skill", v.skill_id), n("rating_scale", v.scale_id), v.required_level, v.valid_from + " \u2014 " + (v.valid_to || "\u2014"), v.valid_to ? "\u0417\u0430\u043A\u0440\u044B\u0442\u043E" : closure];
      })));
      return d;
    }
    function coveragePanel(matrix) {
      const unit = ref("org_unit", "coverage_unit"), skill = ref("skill", "coverage_skill"), shift = select("coverage_shift", list(db, "work_shift").filter((x) => !x.archived).map((x) => [x.code, x.name]), "", "\u0412\u0441\u0435 \u0441\u043C\u0435\u043D\u044B"), target = scaleFields("coverage_target"), minimum = num2("coverage_min", 1, 0, 1e5), data = coverageData(db, day, matrix);
      const d = el2("details");
      d.append(el2("summary", "\u041F\u043E\u043A\u0440\u044B\u0442\u0438\u0435 \u043F\u043E \u0443\u0447\u0430\u0441\u0442\u043A\u0430\u043C \u0438 \u0441\u043C\u0435\u043D\u0430\u043C"), msg("\u041F\u043E\u043A\u0440\u044B\u0442\u0438\u0435 \u2014 \u0447\u0438\u0441\u043B\u043E \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u043E\u0432 \u0441 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u043C \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u044B\u043C \u0443\u0440\u043E\u0432\u043D\u0435\u043C \u0438, \u0434\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u043C \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u043C \u0434\u043E\u043F\u0443\u0441\u043A\u043E\u043C. \u041D\u0443\u043B\u0435\u0432\u043E\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435 \u043D\u0435 \u0434\u0430\u0451\u0442 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u0430."), grid(f("\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", unit), f("\u041D\u0430\u0432\u044B\u043A", skill), f("\u0421\u043C\u0435\u043D\u0430", shift), f("\u0422\u0440\u0435\u0431\u0443\u0435\u043C\u043E\u0435 \u0447\u0438\u0441\u043B\u043E", minimum)), target.element, action("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C", () => run2(async () => {
        const payload = { unit_id: unit.value, skill_id: skill.value, shift_code: shift.value, min_people: Number(minimum.value), scale_id: target.scale.value, required_level: target.level.value === "" ? null : Number(target.level.value) }, old = one(db, "SELECT * FROM coverage_requirement WHERE unit_id=? AND skill_id=? AND shift_code=?", [payload.unit_id, payload.skill_id, payload.shift_code]);
        await write("coverage_requirement", payload, old);
        return "\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430";
      })), table(["\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", "\u041D\u0430\u0432\u044B\u043A", "\u0421\u043C\u0435\u043D\u0430", "\u041D\u0443\u0436\u043D\u043E", "\u0415\u0441\u0442\u044C", "\u0414\u0435\u0444\u0438\u0446\u0438\u0442"], data.map((x) => [n("org_unit", x.unit_id), n("skill", x.skill_id), x.shift_code || "\u0412\u0441\u0435", x.min_people, x.actual, x.deficit])));
      return d;
    }
    function matrixPage() {
      const m = matrixData(db, day), q = searchInput("matrix_search"), unit = ref("org_unit", "matrix_unit", "", "\u0412\u0441\u0435 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F"), profession = ref("profession", "matrix_profession", "", "\u0412\u0441\u0435 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438"), shift = ref("work_shift", "matrix_shift", "", "\u0412\u0441\u0435 \u0441\u043C\u0435\u043D\u044B"), workplace = ref("workplace", "matrix_workplace", "", "\u0412\u0441\u0435 \u0440\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u0435\u0441\u0442\u0430"), category = ref("skill_category", "matrix_category", "", "\u0412\u0441\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438"), transpose = check("matrix_transpose", "\u041D\u0430\u0432\u044B\u043A\u0438 \u0441\u0442\u0440\u043E\u043A\u0430\u043C\u0438"), gaps = check("matrix_gaps", "\u0422\u043E\u043B\u044C\u043A\u043E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438 \u0441 \u0440\u0430\u0437\u0440\u044B\u0432\u0430\u043C\u0438"), out = el2("div");
      const operations = new Map(rows(db, "SELECT id,workplace_id FROM operation").map((o) => [o.id, o.workplace_id]));
      let personPage = 0, skillPage = 0;
      function cell(p, s, forExport = false) {
        const x = m.cells.get(p.id + ":" + s.id), fact = x.fact, actual = !fact ? "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E" : fact.observation_state === "rated" ? String(fact.level) : observationLabels[fact.observation_state], target = x.goal ? " / \u0446\u0435\u043B\u044C " + x.goal.required_level : "";
        const label = actual + target + (fact?.observation_state === "rated" && !x.valid ? " \xB7 \u0441\u0440\u043E\u043A \u0438\u0441\u0442\u0451\u043A" : "") + (!x.same && fact ? " \xB7 \u0434\u0440\u0443\u0433\u0430\u044F \u0448\u043A\u0430\u043B\u0430" : "") + (fact && !x.revisionCurrent ? " \xB7 \u043F\u0440\u0435\u0436\u043D\u044F\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F" : "") + (x.admission ? " \xB7 " + x.admission.status : "");
        if (forExport) return label;
        const b = btn2(label, () => goLocal({ personId: p.id, skillId: s.id }), "lc4-matrix-cell" + (x.gap ? " lc4-gap" : x.qualified ? " lc4-met" : ""));
        b.title = label;
        return b;
      }
      function subset() {
        let people = m.people.filter((p) => (!unit.value || p.unit_id === unit.value) && (!profession.value || p.profession_id === profession.value) && (!shift.value || p.shift_id === shift.value) && [p.display_name, p.employee_code].join(" ").toLocaleLowerCase("ru-RU").includes(q.value.trim().toLocaleLowerCase("ru-RU"))), skills = m.skills.filter((s) => (!category.value || s.category_id === category.value) && (!workplace.value || operations.get(s.operation_id) === workplace.value));
        if (gaps.input.checked) people = people.filter((p) => skills.some((s) => m.cells.get(p.id + ":" + s.id).gap));
        return { people, skills };
      }
      function draw() {
        const all = subset();
        if (!all.people.length || !all.skills.length) {
          out.replaceChildren(msg("\u041D\u0435\u0442 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0438\u043B\u0438 \u043D\u0430\u0432\u044B\u043A\u043E\u0432 \u043F\u043E \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u043C \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u043C. \u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430\u0445."));
          return;
        }
        personPage = Math.min(personPage, Math.floor((all.people.length - 1) / 40));
        skillPage = Math.min(skillPage, Math.floor((all.skills.length - 1) / 20));
        const people = all.people.slice(personPage * 40, personPage * 40 + 40), skills = all.skills.slice(skillPage * 20, skillPage * 20 + 20);
        const transposeOn = transpose.input.checked, heads = transposeOn ? ["\u041D\u0430\u0432\u044B\u043A", ...people.map((p) => p.display_name)] : ["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ...skills.map((s) => s.name)], data = transposeOn ? skills.map((s) => [s.name, ...people.map((p) => cell(p, s))]) : people.map((p) => [p.display_name, ...skills.map((s) => cell(p, s))]);
        const table2 = tableOf2(heads, data);
        table2.classList.add("lc4-matrix");
        const pager = row(msg("\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438 " + (personPage * 40 + 1) + "\u2013" + (personPage * 40 + people.length) + " \u0438\u0437 " + all.people.length), btn2("\u2039", () => {
          personPage--;
          draw();
        }, "", personPage === 0), btn2("\u203A", () => {
          personPage++;
          draw();
        }, "", personPage * 40 + people.length >= all.people.length), msg("\u041D\u0430\u0432\u044B\u043A\u0438 " + (skillPage * 20 + 1) + "\u2013" + (skillPage * 20 + skills.length) + " \u0438\u0437 " + all.skills.length), btn2("\u2039", () => {
          skillPage--;
          draw();
        }, "", skillPage === 0), btn2("\u203A", () => {
          skillPage++;
          draw();
        }, "", skillPage * 20 + skills.length >= all.skills.length));
        const download2 = btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0432\u0441\u044E \u0432\u044B\u0431\u043E\u0440\u043A\u0443 XLSX", () => run2(async () => {
          invariant(all.people.length * all.skills.length <= 2e5, "\u0423\u0442\u043E\u0447\u043D\u0438\u0442\u0435 \u0444\u0438\u043B\u044C\u0442\u0440\u044B \u0434\u043B\u044F \u044D\u043A\u0441\u043F\u043E\u0440\u0442\u0430");
          const headers = transposeOn ? ["\u041D\u0430\u0432\u044B\u043A", ...all.people.map((p) => p.display_name)] : ["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ...all.skills.map((s) => s.name)];
          await exportTable("\u041C\u0430\u0442\u0440\u0438\u0446\u0430-\u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", headers, transposeOn ? all.skills.map((s) => [s.name, ...all.people.map((p) => cell(p, s, true))]) : all.people.map((p) => [p.display_name, ...all.skills.map((s) => cell(p, s, true))]));
          return "\u041E\u0442\u0447\u0451\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
        }, { save: false }));
        out.replaceChildren(pager, table2, download2);
      }
      const reset = () => {
        personPage = 0;
        skillPage = 0;
        draw();
      };
      for (const control of [unit, profession, shift, workplace, category, transpose.input, gaps.input]) control.onchange = reset;
      q.oninput = reset;
      draw();
      if (route.personId && route.skillId) {
        const p = m.people.find((x) => x.id === route.personId), s = m.skills.find((x) => x.id === route.skillId);
        if (p && s) {
          const x = m.cells.get(p.id + ":" + s.id), history = rows(db, "SELECT i.*,a.assessed_at,a.evaluator_id,a.standard_revision_id,a.assignment_id FROM assessment_item i JOIN assessment_session a ON a.id=i.session_id WHERE a.person_id=? AND i.skill_id=? AND a.state='confirmed' ORDER BY a.assessed_at DESC,a.recorded_at DESC", [p.id, s.id]);
          return pane2(p.display_name + " \xB7 " + s.name, back(), msg(cell(p, s, true)), table(["\u0414\u0430\u0442\u0430", "\u0428\u043A\u0430\u043B\u0430", "\u0423\u0440\u043E\u0432\u0435\u043D\u044C / \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "\u0421\u041E\u041F", ""], history.map((h) => [h.assessed_at, n("rating_scale", h.scale_id), h.observation_state === "rated" ? h.level : observationLabels[h.observation_state], n("person", h.evaluator_id), revLabel(h.standard_revision_id), h.assignment_id ? btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { id: h.assignment_id, tab: "practice" })) : "\u2014"])), row(btn2("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { mode: "new", traineeId: p.id, skillId: s.id, scaleId: x.goal?.scale_id, targetLevel: x.goal?.required_level, revisionId: revs().find((r) => r.operation_id === s.operation_id)?.id, reason: "\u0420\u0430\u0437\u0432\u0438\u0442\u0438\u0435 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438" })), btn2("\u041F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", () => go("development", { mode: "new", personId: p.id }))));
        }
      }
      const scaleSetup = action("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0448\u043A\u0430\u043B\u0443 1\u20134", () => run2(async () => {
        invariant(!list(db, "rating_scale").some((x) => x.name === "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F (1\u20134)" && Number(x.version_no) === 1), "\u0428\u043A\u0430\u043B\u0430 \u0443\u0436\u0435 \u0441\u043E\u0437\u0434\u0430\u043D\u0430");
        ws2.edit("rating_scale", null, { name: "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F (1\u20134)", version_no: "1", levels: "1: \u041E\u0431\u0443\u0447\u0435\u043D\n2: \u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E\n3: \u0423\u0432\u0435\u0440\u0435\u043D\u043D\u043E \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\n4: \u041E\u0431\u0443\u0447\u0430\u0435\u0442 \u0434\u0440\u0443\u0433\u0438\u0445" });
        return "\u0428\u043A\u0430\u043B\u0430 1\u20134 \u0441\u043E\u0437\u0434\u0430\u043D\u0430. \u0423\u0440\u043E\u0432\u0435\u043D\u044C 4 \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u0442 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u0438\u043B\u0438 \u043F\u0440\u0438\u043A\u0430\u0437.";
      }), "", list(db, "rating_scale").some((x) => x.name === "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F (1\u20134)" && Number(x.version_no) === 1));
      return stack(pane2("\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", msg("\u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u0438 \u0446\u0435\u043B\u0435\u0432\u043E\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u044B \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E. \u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E, \u043D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E, \u0434\u0440\u0443\u0433\u0430\u044F \u0448\u043A\u0430\u043B\u0430, \u0441\u0440\u043E\u043A \u0438 \u0434\u043E\u043F\u0443\u0441\u043A \u043D\u0435 \u0441\u043C\u0435\u0448\u0438\u0432\u0430\u044E\u0442\u0441\u044F."), row(btn2("\u041D\u0430\u0432\u044B\u043A\u0438", () => go("skill")), btn2("\u0428\u043A\u0430\u043B\u044B", () => go("rating_scale")), scaleSetup), grid(f("\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", unit), f("\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", profession), f("\u0421\u043C\u0435\u043D\u0430", shift), f("\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E", workplace), f("\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F \u043D\u0430\u0432\u044B\u043A\u043E\u0432", category), f("\u041F\u043E\u0438\u0441\u043A \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430", q)), row(transpose.element, gaps.element), out), pane2("\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u0435", requirementsPanel(), coveragePanel(m)));
    }
    function journalPage() {
      const a = asgns(), facts = rows(db, "SELECT * FROM training_session WHERE stage_code IS NOT NULL ORDER BY held_at DESC,recorded_at DESC"), q = searchInput("journal_search"), out = el2("div"), heads = ["\u0414\u0430\u0442\u0430 / \u0432\u0440\u0435\u043C\u044F", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0421\u041E\u041F", "\u042D\u0442\u0430\u043F", "\u041C\u0438\u043D\u0443\u0442", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442"];
      const line = (x) => {
        const t = a.find((y) => y.id === x.assignment_id), names2 = JSON.parse(t?.recorded_names_json || "{}");
        return [x.held_at, names2.instructor || n("person", x.mentor_id), names2.trainee || n("person", t?.trainee_id), revLabel(t?.sop_revision_id), JSON.parse(x.steps_json).label, x.duration_minutes, resultLabels[x.result]];
      };
      filterList(out, q, facts, (x) => line(x).join(" "), (items) => table([...heads, ""], items.map((x) => [...line(x), btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => go("instruction", { id: x.assignment_id, tab: "instruction" }), "primary")])));
      return pane2("\u0416\u0443\u0440\u043D\u0430\u043B \u0437\u0430\u0434\u0430\u043D\u0438\u0439 \u0438 \u043F\u0440\u043E\u0432\u0435\u0434\u0451\u043D\u043D\u044B\u0445 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", msg("\u042D\u0442\u043E \u0444\u0430\u043A\u0442\u044B \u0438\u0437 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439, \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u0432\u0432\u043E\u0434 \u043D\u0435 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F. \u041F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u044F \u044F\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u044B\u043C\u0438 \u0437\u0430\u043F\u0438\u0441\u044F\u043C\u0438."), q, out, exportButton("\u0416\u0443\u0440\u043D\u0430\u043B-\u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", heads, facts.map(line)));
    }
    function retrainingPage() {
      const old = asgns().filter((a) => a.state !== "cancelled" && !sameRevision(a)), m = matrixData(db, day);
      const gaps = [];
      for (const p of m.people) for (const s of m.skills) {
        const x = m.cells.get(p.id + ":" + s.id);
        if (x.gap) gaps.push({ p, s, x });
      }
      return stack(
        pane2("\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0421\u041E\u041F \u2014 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0430\u043D\u0430\u043B\u0438\u0437 \u0432\u043B\u0438\u044F\u043D\u0438\u044F", msg("\u041F\u0440\u0435\u0436\u043D\u0438\u0435 \u0444\u0430\u043A\u0442\u044B, \u0443\u0440\u043E\u0432\u043D\u0438 \u0438 \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F. \u041D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0441\u043E\u0437\u0434\u0430\u0451\u0442\u0441\u044F \u043F\u043E \u044F\u0432\u043D\u043E\u043C\u0443 \u0440\u0435\u0448\u0435\u043D\u0438\u044E, \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0441\u0442\u0430\u0440\u044B\u0439 \u0434\u043E\u043F\u0443\u0441\u043A \u043D\u0435 \u0430\u043D\u043D\u0443\u043B\u0438\u0440\u0443\u0435\u0442\u0441\u044F."), table(["\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u041F\u0440\u0435\u0436\u043D\u0438\u0439 \u0421\u041E\u041F", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0430\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F", ""], old.map((a) => {
          const r = revs().find((x) => x.document_id === currentStandard(db, a.sop_revision_id)?.document_id);
          return [n("person", a.trainee_id), revLabel(a.sop_revision_id), stateLabel(a), r ? revLabel(r.id) : "\u041D\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u0421\u041E\u041F", row(btn2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F", () => go("twi", { id: a.id })), ...r ? [action("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043F\u0435\u0440\u0435\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { mode: "new", traineeId: a.trainee_id, revisionId: r.id, skillId: a.skill_id, scaleId: a.scale_id, targetLevel: a.target_level, reason: "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0438 \u0421\u041E\u041F: " + revLabel(a.sop_revision_id) }))] : [])];
        }))),
        pane2("\u0420\u0430\u0437\u0440\u044B\u0432\u044B \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", table(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u041D\u0430\u0432\u044B\u043A", "\u0426\u0435\u043B\u044C", "\u0424\u0430\u043A\u0442", ""], gaps.map(({ p, s, x }) => [p.display_name, s.name, x.goal.required_level, x.fact?.level ?? "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E", action("\u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u0435", () => go("development", { mode: "new", personId: p.id }))])))
      );
    }
    function developmentPage() {
      const items = rows(db, "SELECT * FROM development_plan ORDER BY due_on,id");
      if (route.mode === "new") {
        const who = person2("development_person", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", route.personId || ""), title = fieldInput2("development_title"), start = date3("development_start"), due = date3("development_due");
        return pane2("\u041D\u043E\u0432\u044B\u0439 \u043F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", back(), grid(who.element, f("\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 / \u0446\u0435\u043B\u044C", title), f("\u041D\u0430\u0447\u0430\u043B\u043E", start), f("\u0421\u0440\u043E\u043A", due)), save2("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", "development_plan", () => ({ person_id: who.value, title: title.value, start_on: start.value, due_on: due.value }), null, (id) => {
          route = { page: page2, id };
        }));
      }
      const plan = items.find((x) => x.id === route.id);
      if (plan) {
        const goals = rows(db, "SELECT * FROM development_goal WHERE plan_id=? ORDER BY due_on,id", [plan.id]), root2 = pane2(plan.title + " \xB7 " + n("person", plan.person_id), back(), msg(statuses[plan.state] + " \xB7 " + plan.start_on + " \u2014 " + plan.due_on), table(["\u0426\u0435\u043B\u044C", "\u041D\u0430\u0432\u044B\u043A", "\u0423\u0440\u043E\u0432\u0435\u043D\u044C", "\u0421\u0440\u043E\u043A", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", ""], goals.map((g) => {
          const t = JSON.parse(g.target_json);
          return [g.title, n("skill", g.skill_id), t.target_level ?? "\u2014", g.due_on, g.state === "open" ? "\u041E\u0442\u043A\u0440\u044B\u0442\u0430" : statuses[g.state] || g.state, g.state === "open" ? row(closeRecord("\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C", "development_goal", g, "finish"), closeRecord("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C", "development_goal", g, "cancel")) : "\u2014"];
        })));
        if (plan.state === "active") {
          const title = fieldInput2("goal_title"), skill = ref("skill", "goal_skill", "", "\u2014 \u0411\u0435\u0437 \u043D\u0430\u0432\u044B\u043A\u0430 \u2014"), target = scaleFields("goal_target"), due = date3("goal_due", plan.due_on);
          root2.append(pane2("\u041D\u043E\u0432\u0430\u044F \u0446\u0435\u043B\u044C", grid(f("\u0426\u0435\u043B\u044C", title), f("\u041D\u0430\u0432\u044B\u043A", skill), f("\u0421\u0440\u043E\u043A", due)), target.element, save2("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0446\u0435\u043B\u044C", "development_goal", () => ({ plan_id: plan.id, skill_id: nullable(skill.value), scale_id: skill.value ? nullable(target.scale.value) : null, target_level: skill.value && target.level.value !== "" ? Number(target.level.value) : null, title: title.value, due_on: due.value }))), closeRecord("\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u043F\u043B\u0430\u043D", "development_plan", plan, "finish"), closeRecord("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u043B\u0430\u043D", "development_plan", plan, "cancel"));
        }
        return root2;
      }
      return pane2("\u041F\u043B\u0430\u043D\u044B \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", action("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", () => goLocal({ mode: "new" })), table(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0426\u0435\u043B\u044C", "\u0421\u0440\u043E\u043A", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], items.map((x) => [n("person", x.person_id), x.title, x.due_on, statuses[x.state], btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: x.id }), "primary")])));
    }
    function myPlan() {
      const actor = person2("my_plan_person", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", route.personId || "", { onChange: (id2) => {
        route.personId = id2;
        render2();
      } }), id = actor.value, items = id ? asgns().filter((a) => [a.trainee_id, a.mentor_id, a.supervisor_id, a.assigned_by].includes(id)) : [], programs = id ? enrollmentList().filter((x) => [x.trainee_id, x.mentor_id, x.manager_id].includes(id)) : [];
      return stack(pane2("\u041C\u043E\u0439 \u043F\u043B\u0430\u043D", msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430. \u042D\u0442\u043E \u0444\u0438\u043B\u044C\u0442\u0440 \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439, \u043D\u0435 \u0432\u0445\u043E\u0434 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0443 \u0438 \u043D\u0435 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u043F\u0440\u0430\u0432 \u0434\u043E\u0441\u0442\u0443\u043F\u0430."), actor.element, id ? assignmentRows(items) : msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0434\u043B\u044F \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439.")), pane2("\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", table(["\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0421\u0440\u043E\u043A", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], programs.map((x) => [one(db, "SELECT title FROM training_program WHERE id=?", [x.program_id])?.title, n("person", x.trainee_id), x.due_on, statuses[x.state], btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => go(enrollmentPage(x.id), { enrollmentId: x.id }), "primary")]))));
    }
    let content;
    if (page2 === "twi" || page2 === "instruction" || page2 === "practical") {
      const a = route.id ? asgns().find((x) => x.id === route.id) : null;
      if (a) content = assignmentCard(a);
      else if (route.mode === "new" && page2 === "twi") content = assignmentForm();
      else if (page2 === "practical") content = stack(pane2("\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043E\u0446\u0435\u043D\u043A\u0438 \u0438 \u0434\u043E\u043F\u0443\u0441\u043A\u0438", msg("\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0434\u043B\u044F \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438, \u0443\u0440\u043E\u0432\u043D\u044F, \u041E\u0422, \u0442\u0435\u043E\u0440\u0438\u0438 \u0438 \u0440\u0435\u0448\u0435\u043D\u0438\u044F."), table(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0421\u041E\u041F", "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430", "\u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F", "\u0414\u043E\u043F\u0443\u0441\u043A", ""], asgns().map((a2) => {
        const x = evidenceSummary(a2);
        return [n("person", a2.trainee_id), revLabel(a2.sop_revision_id), x.p ? conclusions[x.p.conclusion] : "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E", x.q ? "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430" : "\u041D\u0435\u0442", x.ad.status, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: a2.id, tab: "practice" }), "primary")];
      }))), methodsPanel());
      else content = assignmentList();
    } else if (page2 === "programs" || page2 === "internship") {
      const n2 = route.enrollmentId && one(db, "SELECT * FROM training_enrollment WHERE id=?", [route.enrollmentId]), p = route.programId && one(db, "SELECT * FROM training_program WHERE id=?", [route.programId]);
      content = n2 ? enrollmentCard(n2) : p ? programCard(p) : route.mode === "program" ? programForm() : registryPrograms();
    } else if (page2 === "mentoring") content = mentorPage();
    else if (page2 === "certification") content = certificatePage();
    else if (page2 === "appointments") content = appointmentPage();
    else if (page2 === "skills") content = matrixPage();
    else if (page2 === "journal") content = journalPage();
    else if (page2 === "retraining") content = retrainingPage();
    else if (page2 === "development") content = developmentPage();
    else if (page2 === "my_plan") content = myPlan();
    if (content) {
      main.append(content);
      main.dataset.lc4Page = page2;
    }
  }

  // src/modules/library/frv-summary.js
  var positive = (v) => typeof v === "number" && Number.isFinite(v) && v > 0;
  var mean = (a) => a.length ? a.reduce((s, n) => s + n, 0) / a.length : null;
  var median = (a) => {
    const v = a.slice().sort((x, y) => x - y);
    return v.length % 2 ? v[v.length >> 1] : (v[v.length / 2 - 1] + v[v.length / 2]) / 2;
  };
  var clean = (x, max = 2e4) => typeof x === "string" ? x.trim().slice(0, max) : "";
  function frvSummary(raw) {
    const totals = { VA: 0, NVA_Necessary: 0, NVA_Waste: 0, WAIT: 0, BREAK: 0, OTHER: 0 }, cycles = [];
    let missing = 0;
    for (const [i, c] of raw.cycles.entries()) {
      let seconds = 0, complete = c.observations.length > 0, measured = 0;
      for (const o of c.observations) {
        if (!positive(o.durationSec) || !clean(o.actionRaw)) {
          missing++;
          complete = false;
          continue;
        }
        seconds += o.durationSec;
        measured++;
        totals[Object.hasOwn(totals, o.valueType) ? o.valueType : "OTHER"] += o.durationSec;
      }
      cycles.push({ index: i + 1, phase: ["baseline", "improved"].includes(c.phase) ? c.phase : "unassigned", seconds: measured ? seconds : null, complete });
    }
    const a = cycles.filter((c) => c.complete && c.phase === "baseline").map((c) => c.seconds), b = cycles.filter((c) => c.complete && c.phase === "improved").map((c) => c.seconds);
    const before = mean(a), after = mean(b), comparable = raw.comparisonApproved === true && before !== null && after !== null;
    return { totals, cycles, missing, baselineCount: a.length, improvedCount: b.length, before, after, comparable, delta: comparable ? before - after : null, percent: comparable && before > 0 ? (before - after) / before * 100 : null };
  }
  async function draftFromFrv(text4) {
    const raw = JSON.parse(text4);
    await inspectSource(text4, "frv");
    const candidate = raw.standard;
    invariant(candidate && !candidate.outdated && Array.isArray(candidate.steps) && candidate.steps.length > 0 && candidate.steps.length <= 12, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u044C\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0439 \u043F\u0440\u043E\u0435\u043A\u0442 \u0421\u041E\u041F \u0438\u0437 \u0437\u0430\u043C\u0435\u0440\u043E\u0432 \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435 \u0424\u0420\u0412 (\u043D\u0435 \u0431\u043E\u043B\u0435\u0435 12 \u0448\u0430\u0433\u043E\u0432)");
    const ids = /* @__PURE__ */ new Map();
    for (const [i, c] of raw.cycles.entries()) for (const o of c.observations) ids.set(o.id, { o, cycle: c.cycleNo || i + 1 });
    const used = /* @__PURE__ */ new Set(), steps = candidate.steps.map((s, i) => {
      invariant(clean(s.action) && positive(s.plannedTimeSec) && Array.isArray(s.sourceObservationIds) && s.sourceObservationIds.length, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435, \u043F\u0440\u043E\u0435\u043A\u0442\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u0438 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F \u0448\u0430\u0433\u0430 " + (i + 1));
      const found = s.sourceObservationIds.map((id) => {
        const x = ids.get(id);
        invariant(x && positive(x.o.durationSec) && clean(x.o.actionRaw) && x.o.standardCandidate === true && !used.has(id), "\u0428\u0430\u0433 " + (i + 1) + ": \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0437\u0430\u043C\u0435\u0440 \u0438\u043B\u0438 \u043E\u043D \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0435\u0442\u0441\u044F");
        used.add(id);
        return x;
      });
      const observed = median(found.map((x) => x.o.durationSec)), duration = Math.max(1, Math.round(s.plannedTimeSec)), km = [clean(s.keyMoment), s.safety ? "\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u044C: " + clean(s.safety) : ""].filter(Boolean);
      return { id: i + 1, action: clean(s.action), keyMoments: km.length ? km : [""], reason: clean(s.reason), durationSeconds: duration, hasPhoto: false, photoAnnotations: [], frv: { vdc: s.valueType === "VA", m2: s.valueType === "NVA_Necessary" ? duration : "", m1: s.valueType === "NVA_Waste" ? duration : "", move: s.distanceM ?? "", comment: clean(s.comment), autoFullStep: ["NVA_Necessary", "NVA_Waste"].includes(s.valueType) }, frvSource: { studyId: raw.study.studyId || "", libraryId: raw.study.libraryId || "", observationIds: s.sourceObservationIds.slice(), observationId: s.sourceObservationIds[0], cycleNos: found.map((x) => x.cycle), cycleNo: found[0].cycle, observedTimeSec: observed, projectTimeSec: s.plannedTimeSec } };
    });
    const payload = { schemaVersion: 2, document: { id: uuid(), status: "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A", number: "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A", version: 1 }, constructor: { schemaVersion: 4, meta: { branch: "", date: "", department: "", workplace: clean(raw.study.workplace), executor: clean(raw.study.operator), operation: clean(raw.study.operationId) || clean(raw.study.processDescription) || "\u041F\u0440\u043E\u0435\u043A\u0442 \u0421\u041E\u041F \u043F\u043E \u0424\u0420\u0412", sopNumber: "", safety: "", tools: "", material: "", approverPost: "", approverName: "" }, steps, description: clean(raw.study.processDescription), responsibles: [""], agreedList: [{ post: "", name: "" }], totalTimeSeconds: steps.reduce((s, x) => s + x.durationSeconds, 0), twi: { enabled: false } }, photoAssets: {} };
    const result = JSON.stringify({ ...payload, integrity: { algorithm: "SHA-256", sha256: await sha256(JSON.stringify(payload)) } }, null, 2);
    return { text: result, ...await inspectSource(result, "sop") };
  }

  // src/storage/local.js
  async function openCache() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open("lean-center-lc1", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("kv");
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  function load(cache2, key3) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readonly"), r = t.objectStore("kv").get(key3);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  function save(cache2, key3, value) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readwrite");
      t.objectStore("kv").put(value, key3);
      t.oncomplete = resolve;
      t.onabort = () => reject(t.error || new Error("\u0417\u0430\u043F\u0438\u0441\u044C \u043F\u0440\u0435\u0440\u0432\u0430\u043D\u0430"));
      t.onerror = () => reject(t.error);
    });
  }
  function saveWorkspace(cache2, expected, value) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readwrite"), s = t.objectStore("kv"), r = s.get("workspace");
      let reason;
      const next = expected + 1;
      r.onsuccess = () => {
        if ((r.result?.generation || 0) !== expected) {
          reason = new Error("\u0414\u0440\u0443\u0433\u0430\u044F \u0432\u043A\u043B\u0430\u0434\u043A\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430 \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E. \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443.");
          t.abort();
          return;
        }
        s.put({ generation: next, state: value }, "workspace");
      };
      t.oncomplete = () => resolve(next);
      t.onabort = () => reject(reason || t.error || new Error("\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430"));
      t.onerror = () => reject(t.error);
    });
  }

  // src/storage/network.js
  var textBytes = (s) => new TextEncoder().encode(s);
  async function chooseFolder() {
    invariant(window.showDirectoryPicker, "\u0412\u044B\u0431\u043E\u0440 \u043F\u0430\u043F\u043A\u0438 \u0437\u0430\u043F\u0440\u0435\u0449\u0451\u043D \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u043E\u043C. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0440\u0443\u0447\u043D\u043E\u0439 \u0438\u043C\u043F\u043E\u0440\u0442 \u0438 \u044D\u043A\u0441\u043F\u043E\u0440\u0442.");
    return window.showDirectoryPicker({ id: "lean-center-network", mode: "readwrite" });
  }
  async function permission(h, request = false) {
    if (!h) return false;
    let p = await h.queryPermission({ mode: "readwrite" });
    if (p !== "granted" && request) p = await h.requestPermission({ mode: "readwrite" });
    return p === "granted";
  }
  async function sub(h, name, create = false) {
    return h.getDirectoryHandle(name, { create });
  }
  async function readFile(dir, name, max = MAX_DB) {
    const f = await (await dir.getFileHandle(name)).getFile();
    invariant(f.size <= max, "\u0424\u0430\u0439\u043B \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043B\u0438\u043C\u0438\u0442: " + name);
    return new Uint8Array(await f.arrayBuffer());
  }
  async function writeNew(dir, name, data) {
    try {
      await dir.getFileHandle(name);
      throw new Error("\u0424\u0430\u0439\u043B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442: " + name);
    } catch (e) {
      if (e.name !== "NotFoundError") throw e;
    }
    const f = await dir.getFileHandle(name, { create: true }), w = await f.createWritable();
    try {
      await w.write(data);
      await w.close();
    } catch (e) {
      try {
        await w.abort();
      } catch {
      }
      throw e;
    }
    const expected = typeof data === "string" ? textBytes(data) : data;
    const back = await readFile(dir, name, Math.max(MAX_DB, expected.length));
    invariant(await sha256(back) === await sha256(expected), "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u043F\u0440\u043E\u0448\u043B\u0430 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C SHA-256: " + name);
  }
  async function testFolder(h) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043D\u0430 \u0437\u0430\u043F\u0438\u0441\u044C");
    const name = ".lean-test-" + uuid() + ".txt";
    await writeNew(h, name, "LEAN CENTER / TEST");
    await h.removeEntry(name);
    return true;
  }
  async function readContent(h, ref) {
    validateRef(ref);
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u043C \u0444\u0430\u0439\u043B\u0430\u043C");
    const d = await sub(h, "Documents"), bytes = await readFile(d, ref.sha256 + ".json", ref.size);
    return checkContent(ref, new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  }
  async function ensureContent(h, ref, read) {
    validateRef(ref);
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const d = await sub(h, "Documents", true), name = ref.sha256 + ".json";
    let exists = true;
    try {
      await d.getFileHandle(name);
    } catch (e) {
      if (e.name !== "NotFoundError") throw e;
      exists = false;
    }
    if (exists) {
      await readContent(h, ref);
      return;
    }
    invariant(typeof read === "function", "\u041D\u0435\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 " + ref.sha256);
    const text4 = await checkContent(ref, await read(ref));
    try {
      await writeNew(d, name, text4);
    } catch (e) {
      if (!String(e.message).startsWith("\u0424\u0430\u0439\u043B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442:")) throw e;
    }
    await readContent(h, ref);
  }
  async function sendPackage(h, p, read) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    for (const ref of refsForEvents(p.events)) await ensureContent(h, ref, read);
    const d = await sub(h, "Exchange", true);
    await writeNew(d, "change-" + p.id + ".leanpkg", canonical(p));
  }
  async function listPackages(h) {
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    let d;
    try {
      d = await sub(h, "Exchange");
    } catch (e) {
      if (e.name === "NotFoundError") return [];
      throw e;
    }
    const result = [];
    for await (const [name, entry] of d.entries()) {
      if (entry.kind !== "file" || !/^change-[0-9a-f-]+\.leanpkg$/i.test(name)) continue;
      try {
        const p = JSON.parse(new TextDecoder().decode(await readFile(d, name, MAX_PACKAGE)));
        invariant(name === "change-" + p.id + ".leanpkg", "\u0418\u043C\u044F \u043F\u0430\u043A\u0435\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 ID");
        result.push({ name, p });
      } catch (e) {
        result.push({ name, error: e.message });
      }
    }
    return result.sort((a, b) => (a.p?.created_at || "").localeCompare(b.p?.created_at || ""));
  }
  async function latestSnapshot(h, SQL2, databaseId = null) {
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    let d;
    try {
      d = await sub(h, "Database");
    } catch (e) {
      if (e.name === "NotFoundError") return null;
      throw e;
    }
    const manifests = [];
    for await (const [name, entry] of d.entries()) {
      if (entry.kind !== "file" || !/^publication-[0-9a-f-]+\.json$/i.test(name)) continue;
      const m = JSON.parse(new TextDecoder().decode(await readFile(d, name, 65536)));
      invariant(name === "publication-" + m.id + ".json", "\u0418\u043C\u044F \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
      if (!databaseId || m.database_id === databaseId) manifests.push(m);
    }
    if (!manifests.length) return null;
    invariant(new Set(manifests.map((m) => m.database_id)).size === 1, "\u0412 \u043F\u0430\u043F\u043A\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0431\u0430\u0437. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0439.");
    const ids = new Set(manifests.map((m) => m.id)), parents = new Set(manifests.map((m) => m.parent_id));
    const heads = manifests.filter((m) => !parents.has(m.id));
    invariant(heads.length === 1, "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u043F\u0430\u0440\u0430\u043B\u043B\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0430\u0437\u0431\u043E\u0440");
    const head = heads[0];
    const seen = /* @__PURE__ */ new Set();
    let node2 = head;
    while (node2) {
      invariant(!seen.has(node2.id), "\u0426\u0438\u043A\u043B \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
      seen.add(node2.id);
      node2 = node2.parent_id ? manifests.find((m) => m.id === node2.parent_id) : null;
    }
    invariant(seen.size === ids.size, "\u0420\u0430\u0437\u043E\u0440\u0432\u0430\u043D\u0430 \u0446\u0435\u043F\u043E\u0447\u043A\u0430 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
    const bytes = await readFile(d, "snapshot-" + head.id + ".sqlite");
    const db = await readSnapshot(SQL2, head, bytes);
    return { manifest: head, db, bytes };
  }
  async function publishSnapshot(h, SQL2, snapshot, read) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const current = await latestSnapshot(h, SQL2);
    try {
      invariant(!current ? snapshot.manifest.parent_id === null : current.manifest.database_id === snapshot.manifest.database_id && current.manifest.id === snapshot.manifest.parent_id, "\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u0431\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u044D\u0442\u043E \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0435\u0451.");
    } finally {
      current?.db.close();
    }
    const checked = await readSnapshot(SQL2, snapshot.manifest, snapshot.bytes);
    try {
      for (const ref of refsForDb(checked)) await ensureContent(h, ref, read);
    } finally {
      checked.close();
    }
    const d = await sub(h, "Database", true);
    await writeNew(d, "snapshot-" + snapshot.manifest.id + ".sqlite", snapshot.bytes);
    await writeNew(d, "publication-" + snapshot.manifest.id + ".json", canonical(snapshot.manifest));
    const verified = await latestSnapshot(h, SQL2, snapshot.manifest.database_id);
    try {
      invariant(verified?.manifest.id === snapshot.manifest.id, "\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430");
    } finally {
      verified?.db.close();
    }
  }
  async function saveBackup(h, obj2) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const d = await sub(h, "Backups", true);
    await writeNew(d, "backup-" + uuid() + ".leanbackup", canonical(obj2));
  }

  // src/modules/library/content.js
  var MAX_TRANSFER = 150 * 1024 * 1024;
  var key2 = (r) => "content:" + r.sha256;
  var ContentStore = class {
    constructor(getCache, getFolder) {
      this.getCache = getCache;
      this.getFolder = getFolder;
      this.memory = /* @__PURE__ */ new Map();
    }
    async put(ref, text4) {
      await checkContent(ref, text4);
      const cache2 = this.getCache();
      if (cache2) {
        const old = await load(cache2, key2(ref));
        if (old !== void 0) {
          await checkContent(ref, old);
          return old;
        }
        await save(cache2, key2(ref), text4);
        return text4;
      }
      const total = [...this.memory.values()].reduce((n, x) => n + x.length * 2, 0);
      invariant(this.memory.has(ref.sha256) || total + text4.length * 2 <= MAX_TRANSFER, "\u041B\u0438\u043C\u0438\u0442 \u043F\u0430\u043C\u044F\u0442\u0438 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432; \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u044D\u0448 \u0438\u043B\u0438 \u0441\u0435\u0442\u0435\u0432\u0443\u044E \u043F\u0430\u043F\u043A\u0443");
      this.memory.set(ref.sha256, text4);
      return text4;
    }
    async get(ref, { network = true } = {}) {
      validateRef(ref);
      const cache2 = this.getCache(), v = cache2 ? await load(cache2, key2(ref)) : this.memory.get(ref.sha256);
      if (v !== void 0) return checkContent(ref, v);
      const h = this.getFolder();
      invariant(network && h, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043D\u0435 \u0432 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u043C \u043A\u044D\u0448\u0435. \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043E\u0431\u0449\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u043F\u043E\u043B\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.");
      const text4 = await readContent(h, ref);
      return this.put(ref, text4);
    }
  };
  async function makeTransfer(kind, payload, refs, read) {
    refs = unionRefs(refs);
    if (!refs.length) return payload;
    let size = new TextEncoder().encode(canonical(payload)).length;
    const contents = [];
    for (const ref of refs) {
      const text4 = await checkContent(ref, await read(ref));
      size += new TextEncoder().encode(JSON.stringify(text4)).length + 256;
      invariant(size <= MAX_TRANSFER - 65536, "\u041F\u043E\u043B\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 150 \u041C\u0411; \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0441\u0435\u0442\u0435\u0432\u043E\u0435 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u0441 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u043C \u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435\u043C");
      contents.push({ ref, text: text4 });
    }
    return { format: "lean-content-bundle-v1", kind, payload, contents };
  }
  function unpackTransfer(value, kind) {
    if (value?.format !== "lean-content-bundle-v1") return { payload: value, contents: [] };
    invariant(value.kind === kind && Array.isArray(value.contents) && value.contents.length <= 1e4 && Object.hasOwn(value, "payload"), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432");
    return { payload: value.payload, contents: value.contents };
  }
  async function restoreContents(contents, refs, put) {
    refs = unionRefs(refs);
    const expected = new Map(refs.map((r) => [r.sha256, r]));
    invariant(contents.length === expected.size, "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C " + expected.size + ", \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E " + contents.length);
    const seen = /* @__PURE__ */ new Set();
    for (const item of contents) {
      invariant(item && typeof item === "object" && Object.keys(item).length === 2, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u044D\u043B\u0435\u043C\u0435\u043D\u0442 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442\u0430");
      const ref = validateRef(item.ref), match = expected.get(ref.sha256);
      invariant(match && canonical(match) === canonical(ref) && !seen.has(ref.sha256), "\u041B\u0438\u0448\u043D\u0438\u0439, \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u044B\u0439 \u0438\u043B\u0438 \u043D\u0435\u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u0439\u043B");
      seen.add(ref.sha256);
      await checkContent(ref, item.text);
    }
    for (const item of contents) await put(item.ref, item.text);
  }

  // src/modules/master-data/import-xlsx.js
  var MAX_ROWS = 1e3;
  var MAX_COLUMNS = 100;
  var MAX_XLSX = 20 * 1024 * 1024;
  var MAX_EXPANDED = 100 * 1024 * 1024;
  var normalized = (s) => foldKey(s).replace(/[^\p{L}\p{N}]+/gu, "");
  function fieldLabel(type, key3) {
    const f = definitions[type].fields[key3];
    if (f.ref) {
      if (f.ref === "person") return "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430";
      if (f.ref === "skill_category") return "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438";
      if (f.ref === "equipment") return "\u041A\u043E\u0434 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F";
      if (f.ref === "operation") return "\u041A\u043E\u0434 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 (\u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435/\u043A\u043E\u0434)";
      return "\u041A\u043E\u0434 " + { org_unit: key3 === "parent_id" ? "\u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F" : "\u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F", profession: "\u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438", position: "\u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438", work_shift: "\u0441\u043C\u0435\u043D\u044B", business_role: "\u0440\u043E\u043B\u0438", workplace: "\u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430" }[f.ref];
    }
    return f.label;
  }
  function importFields(type) {
    return Object.entries(definitions[type].fields).filter(([, f]) => !f.legacy);
  }
  function autoMap(type, headers) {
    const result = {};
    const used = /* @__PURE__ */ new Set();
    for (const [key3, f] of importFields(type)) {
      const aliases2 = [key3, fieldLabel(type, key3), f.label];
      if (key3 === "display_name") aliases2.push("\u0424\u0418\u041E", "\u0424\u0430\u043C\u0438\u043B\u0438\u044F \u0418\u043C\u044F \u041E\u0442\u0447\u0435\u0441\u0442\u0432\u043E", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A");
      if (key3 === "employee_code") aliases2.push("\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439", "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u2116", "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440");
      if (key3 === "name") aliases2.push("\u041D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435");
      const exact5 = headers.filter((h) => !used.has(h.col) && aliases2.some((a) => normalized(a) === normalized(h.name)));
      if (exact5.length === 1) {
        result[key3] = exact5[0].col;
        used.add(exact5[0].col);
      }
    }
    return result;
  }
  function checkXlsxContainer(buffer) {
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    invariant(bytes.length >= 22 && bytes.length <= MAX_XLSX, "XLSX \u0434\u043E 20 \u041C\u0411");
    const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let end = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
      if (v.getUint32(i, true) === 101010256 && i + 22 + v.getUint16(i + 20, true) === bytes.length) {
        end = i;
        break;
      }
    }
    invariant(end >= 0, "\u0424\u0430\u0439\u043B \u043D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043E\u0431\u044B\u0447\u043D\u044B\u043C XLSX (ZIP)");
    invariant(v.getUint16(end + 4, true) === 0 && v.getUint16(end + 6, true) === 0, "\u041C\u043D\u043E\u0433\u043E\u0442\u043E\u043C\u043D\u044B\u0439 ZIP \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F");
    const n = v.getUint16(end + 10, true), size = v.getUint32(end + 12, true), start = v.getUint32(end + 16, true);
    invariant(n === v.getUint16(end + 8, true) && n > 0 && n <= 2e3 && start + size === end, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u0430\u0442\u0430\u043B\u043E\u0433 XLSX");
    let p = start, total = 0;
    const names2 = /* @__PURE__ */ new Set();
    for (let i = 0; i < n; i++) {
      invariant(p + 46 <= end && v.getUint32(p, true) === 33639248, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u043A\u0430\u0442\u0430\u043B\u043E\u0433 XLSX");
      const flags = v.getUint16(p + 8, true), method = v.getUint16(p + 10, true), uncompressed = v.getUint32(p + 24, true), len = v.getUint16(p + 28, true), extra = v.getUint16(p + 30, true), comment = v.getUint16(p + 32, true);
      invariant(!(flags & 1) && [0, 8].includes(method) && p + 46 + len + extra + comment <= end, "\u041D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0439 ZIP");
      const name = new TextDecoder().decode(bytes.subarray(p + 46, p + 46 + len));
      invariant(!names2.has(name) && !name.split("/").includes(".."), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0438\u043B\u0438 \u043D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u043F\u0443\u0442\u044C \u0432 ZIP");
      names2.add(name);
      total += uncompressed;
      invariant(total <= MAX_EXPANDED, "\u0420\u0430\u0441\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0439 XLSX \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 100 \u041C\u0411");
      p += 46 + len + extra + comment;
    }
    invariant(p === end && names2.has("[Content_Types].xml") && names2.has("xl/workbook.xml"), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 XLSX");
    invariant(![...names2].some((n2) => /vbaProject\.bin|externalLinks\//i.test(n2)), "\u0424\u0430\u0439\u043B\u044B \u0441 \u043C\u0430\u043A\u0440\u043E\u0441\u0430\u043C\u0438 \u0438\u043B\u0438 \u0432\u043D\u0435\u0448\u043D\u0438\u043C\u0438 \u0441\u0432\u044F\u0437\u044F\u043C\u0438 \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044E\u0442\u0441\u044F");
  }
  async function loadWorkbook(ExcelJS2, buffer) {
    invariant(ExcelJS2?.Workbook, "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 ExcelJS \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430");
    checkXlsxContainer(buffer);
    const book = new ExcelJS2.Workbook();
    await book.xlsx.load(buffer);
    invariant(book.worksheets.length > 0 && book.worksheets.length <= 50, "\u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u043E\u0442 1 \u0434\u043E 50 \u043B\u0438\u0441\u0442\u043E\u0432");
    return book;
  }
  function sheetHeaders(sheet, row = 1) {
    invariant(Number.isInteger(row) && row >= 1 && row <= 20, "\u0421\u0442\u0440\u043E\u043A\u0430 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u043E\u0432: 1\u201320");
    invariant(sheet.columnCount <= MAX_COLUMNS, "\u041B\u0438\u0441\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0431\u043E\u043B\u0435\u0435 100 \u043A\u043E\u043B\u043E\u043D\u043E\u043A");
    const r = sheet.getRow(row), out = [];
    for (let col = 1; col <= sheet.columnCount; col++) {
      const name = r.getCell(col).text.trim();
      out.push({ col, name: name || "\u041A\u043E\u043B\u043E\u043D\u043A\u0430 " + col });
    }
    return out;
  }
  function sheetRows(sheet, headerRow, mapping) {
    invariant(sheet.rowCount - headerRow <= MAX_ROWS, "\u0412 \u043E\u0434\u043D\u043E\u043C \u0438\u043C\u043F\u043E\u0440\u0442\u0435 \u043D\u0435 \u0431\u043E\u043B\u0435\u0435 " + MAX_ROWS + " \u0441\u0442\u0440\u043E\u043A; \u0440\u0430\u0437\u0434\u0435\u043B\u0438\u0442\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u0443");
    const out = [];
    for (let n = headerRow + 1; n <= sheet.rowCount; n++) {
      const row = sheet.getRow(n), values = {};
      for (const [key3, col] of Object.entries(mapping)) if (col) values[key3] = row.getCell(col).value;
      if (Object.values(values).some((v) => v !== null && v !== void 0 && v !== "")) out.push({ row: n, values });
    }
    return out;
  }
  function cellText(v, f, key3) {
    if (v === null || v === void 0 || v === "") return null;
    if (v instanceof Date) {
      invariant(f.date && !isNaN(v.getTime()), "\u0414\u0430\u0442\u0430 \u0432 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u043E\u0439 \u043A\u043E\u043B\u043E\u043D\u043A\u0435");
      return v.toISOString().slice(0, 10);
    }
    if (typeof v === "object") {
      if (Array.isArray(v.richText)) v = v.richText.map((t) => t.text).join("");
      else throw Error("\u0424\u043E\u0440\u043C\u0443\u043B\u044B, \u043E\u0448\u0438\u0431\u043A\u0438 \u0438 \u0441\u0441\u044B\u043B\u043A\u0438 \u043D\u0435 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u044E\u0442\u0441\u044F; \u0432\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F");
    }
    if (typeof v === "number") {
      invariant(f.integer, "\u041A\u043E\u0434\u044B \u0438 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0442\u0435\u043A\u0441\u0442\u043E\u043C \u0432 Excel (\u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0432\u0435\u0434\u0443\u0449\u0438\u0435 \u043D\u0443\u043B\u0438)");
      v = String(v);
    }
    invariant(typeof v === "string", "\u041D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0439 \u0442\u0438\u043F \u044F\u0447\u0435\u0439\u043A\u0438");
    v = v.trim();
    if (!v) return null;
    if (key3 === "criticality") v = { "\u043E\u0431\u044B\u0447\u043D\u0430\u044F": "normal", "\u0432\u0430\u0436\u043D\u0430\u044F": "important", "\u043A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F": "critical" }[foldKey(v)] || v;
    if (f.date) {
      const m = v.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
      if (m) v = m[3] + "-" + m[2] + "-" + m[1];
    }
    return v;
  }
  function findRef(db, ref, value, unitId) {
    if (!value) return null;
    let matches = list(db, ref).filter((x) => !x.archived);
    if (["equipment", "operation", "workplace"].includes(ref)) {
      let code = value, unit = unitId;
      const split = value.indexOf("/");
      if (split >= 0) {
        const u = value.slice(0, split);
        const found = list(db, "org_unit").filter((x) => !x.archived && foldKey(x.code) === foldKey(u));
        invariant(found.length === 1, "\u041D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0439/\u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u043A\u043E\u0434 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F: " + u);
        unit = found[0].id;
        code = value.slice(split + 1);
      }
      matches = matches.filter((x) => (!unit || x.unit_id === unit) && foldKey(x.code) === foldKey(code));
    } else matches = matches.filter((x) => foldKey(ref === "person" ? x.employee_code : ref === "skill_category" ? x.name : x.code) === foldKey(value));
    invariant(matches.length === 1, "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430 \u0438\u043B\u0438 \u043D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u0430 \u0441\u0441\u044B\u043B\u043A\u0430: " + definitions[ref].label + " / " + value);
    return matches[0].id;
  }
  function workspaceToken(ws2) {
    return canonical({ database: meta(ws2.base, "database_id"), publication: meta(ws2.base, "publication_id"), count: one(ws2.base, "SELECT count(*) n FROM change_event").n, pending: ws2.pending.map((e) => e.id), dirty: ws2.dirty });
  }
  function previewValue(db, f, value) {
    if (value == null) return null;
    if (!f.ref) return value;
    const v = one(db, "SELECT * FROM " + f.ref + " WHERE id=?", [value]);
    if (!v) return value;
    return (v.employee_code || v.code ? (v.employee_code || v.code) + " \u2014 " : "") + (v.display_name || v.name || value);
  }
  var statusLabels = { create: "\u0421\u043E\u0437\u0434\u0430\u0442\u044C", update: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C", same: "\u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", error: "\u041E\u0448\u0438\u0431\u043A\u0430" };
  function planImport(ws2, type, source, { allowUpdates = false } = {}) {
    invariant(Object.hasOwn(definitions, type), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A");
    invariant(!ws2.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B");
    invariant(Array.isArray(source) && source.length > 0 && source.length <= MAX_ROWS, "\u041D\u0435\u0442 \u0441\u0442\u0440\u043E\u043A \u0438\u043B\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 1000");
    const d = definitions[type], db = openDb(ws2.SQL, bytesOf(ws2.working)), results = [], events = [], seen = /* @__PURE__ */ new Map();
    try {
      const parsed = source.map((item) => {
        try {
          const v = {};
          for (const [k, raw] of Object.entries(item.values)) {
            invariant(Object.hasOwn(d.fields, k) && !d.fields[k].legacy, "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u043A\u043E\u043B\u043E\u043D\u043A\u0430 " + k);
            v[k] = cellText(raw, d.fields[k], k);
          }
          return { row: item.row, v };
        } catch (e) {
          return { row: item.row, error: e.message };
        }
      });
      if (type === "org_unit") {
        const remaining = parsed.slice(), ordered = [], known = new Set(list(db, type).map((x) => foldKey(x.code)));
        while (remaining.length) {
          const i = remaining.findIndex((x2) => x2.error || !x2.v.parent_id || known.has(foldKey(x2.v.parent_id)) || !remaining.some((y) => y.v && foldKey(y.v.code) === foldKey(x2.v.parent_id)));
          if (i < 0) {
            for (const x2 of remaining) ordered.push({ ...x2, error: "\u0426\u0438\u043A\u043B \u0438\u043B\u0438 \u043D\u0435\u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u0430\u044F \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u044C \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0439" });
            break;
          }
          const [x] = remaining.splice(i, 1);
          ordered.push(x);
          if (x.v?.code) known.add(foldKey(x.v.code));
        }
        parsed.splice(0, parsed.length, ...ordered);
      }
      for (const item of parsed) {
        const result = { row: item.row, status: "error", message: "", changes: [] };
        results.push(result);
        if (item.error) {
          result.message = item.error;
          continue;
        }
        try {
          const p = {};
          for (const [k, f] of Object.entries(d.fields)) {
            if (!Object.hasOwn(item.v, k)) {
              p[k] = null;
              continue;
            }
            p[k] = f.ref ? findRef(db, f.ref, item.v[k], p.unit_id) : item.v[k];
          }
          const keys = type === "person" ? ["employee_code"] : type === "person_assignment" ? ["person_id", "valid_from"] : type === "role_assignment" ? ["person_id", "role_id", "valid_from"] : type === "skill_category" ? ["name"] : type === "skill" ? ["category_id", "name"] : type === "rating_scale" ? ["name", "version_no"] : ["equipment", "operation", "workplace"].includes(type) ? ["unit_id", "code"] : ["code"];
          invariant(keys.every((k) => p[k] != null), "\u041D\u0435 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D \u043A\u043B\u044E\u0447: " + keys.map((k) => fieldLabel(type, k)).join(", "));
          const key3 = identityKey(type, p);
          if (seen.has(key3)) {
            const previous = seen.get(key3);
            previous.status = "error";
            previous.message = "\u0414\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u043A\u043B\u044E\u0447\u0430 \u0432 \u0444\u0430\u0439\u043B\u0435 (\u0441\u0442\u0440\u043E\u043A\u0430 " + item.row + ")";
            throw Error("\u0414\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u043A\u043B\u044E\u0447\u0430 \u0432 \u0444\u0430\u0439\u043B\u0435 (\u0441\u0442\u0440\u043E\u043A\u0430 " + previous.row + ")");
          }
          seen.set(key3, result);
          const matches = list(db, type).filter((v) => identityKey(type, v) === key3);
          invariant(matches.length <= 1, "\u041D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 \u0431\u0430\u0437\u0435");
          const old = matches[0];
          invariant(!old?.archived, "\u041A\u043B\u044E\u0447 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0430\u0440\u0445\u0438\u0432\u043D\u043E\u0439 \u0437\u0430\u043F\u0438\u0441\u0438; \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u043E");
          const oldPayload = old ? recordPayload(type, old) : null;
          if (old) {
            for (const k of Object.keys(d.fields)) if (!Object.hasOwn(item.v, k)) p[k] = oldPayload[k];
          }
          if (type === "rating_scale" && p.levels) {
            p.levels = p.levels.split(/\r?\n/).filter((x) => x.trim()).map((x) => x.trim()).join("\n");
          }
          if (old && canonical(p) === canonical(oldPayload)) {
            result.status = "same";
            result.message = "\u0421\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043F\u0438\u0441\u044C\u044E \u0431\u0430\u0437\u044B";
            continue;
          }
          result.changes = Object.entries(p).filter(([k, v]) => !old || oldPayload[k] !== v).map(([k, v]) => ({ field: fieldLabel(type, k), before: previewValue(db, d.fields[k], oldPayload?.[k] ?? null), after: previewValue(db, d.fields[k], v) }));
          invariant(!old || allowUpdates, "\u041A\u043B\u044E\u0447 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442, \u0434\u0430\u043D\u043D\u044B\u0435 \u043E\u0442\u043B\u0438\u0447\u0430\u044E\u0442\u0441\u044F. \u0412\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438.");
          const e = { id: uuid(), entity_type: type, entity_id: old?.id || uuid(), operation: old ? "update" : "create", expected_revision: old?.rev || 0, payload: p, occurred_at: now() };
          tx(db, () => applyEvent(db, e));
          events.push(e);
          result.status = e.operation;
          result.message = old ? "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0439 \u0437\u0430\u043F\u0438\u0441\u0438" : "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430 \u043D\u043E\u0432\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C";
        } catch (e) {
          result.message = e.message;
        }
      }
      results.sort((a, b) => a.row - b.row);
      const counts = Object.fromEntries(Object.keys(statusLabels).map((k) => [k, results.filter((x) => x.status === k).length]));
      return { type, token: workspaceToken(ws2), results, counts, events: counts.error ? [] : events };
    } finally {
      db.close();
    }
  }
  function commitImport(ws2, plan) {
    invariant(plan && plan.counts.error === 0 && plan.events.length > 0, "\u041D\u0435\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 \u0434\u043B\u044F \u0438\u043C\u043F\u043E\u0440\u0442\u0430");
    invariant(plan.token === workspaceToken(ws2), "\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C; \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u0441\u043D\u043E\u0432\u0430");
    return ws2.applyBatch(plan.events);
  }
  async function makeTemplate(ExcelJS2, type) {
    const book = new ExcelJS2.Workbook(), sheet = book.addWorksheet(definitions[type].label.slice(0, 31));
    sheet.columns = importFields(type).map(([k, f]) => ({ header: fieldLabel(type, k), key: k, width: f.multiline ? 55 : f.ref ? 26 : 28, style: { numFmt: "@" } }));
    sheet.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
    sheet.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242E40" } };
    sheet.views = [{ state: "frozen", ySplit: 1 }];
    const guide = book.addWorksheet("\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F");
    guide.getColumn(1).width = 100;
    for (const t of ["\u0417\u0430\u043F\u043E\u043B\u043D\u044F\u0439\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0435\u0440\u0432\u044B\u0439 \u043B\u0438\u0441\u0442. \u041D\u0435 \u043C\u0435\u043D\u044F\u0439\u0442\u0435 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u0438 \u0431\u0435\u0437 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F.", "\u041A\u043E\u0434\u044B \u0438 \u0442\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0435 \u043D\u043E\u043C\u0435\u0440\u0430 \u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u043A\u0430\u043A \u0442\u0435\u043A\u0441\u0442, \u0434\u0430\u0442\u044B \u2014 YYYY-MM-DD \u0438\u043B\u0438 \u0434\u0430\u0442\u044B Excel.", "\u0421\u0441\u044B\u043B\u043A\u0438: \u043A\u043E\u0434\u044B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432. \u0414\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043C\u043E\u0436\u043D\u043E \u0443\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435/\u043A\u043E\u0434.", "\u0428\u043A\u0430\u043B\u0430: \u0443\u0440\u043E\u0432\u043D\u0438 \u0432 \u043E\u0434\u043D\u043E\u0439 \u044F\u0447\u0435\u0439\u043A\u0435, \u043A\u0430\u0436\u0434\u044B\u0439 \u0441 \u043D\u043E\u0432\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0438: 0: \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435.", "\u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043A\u043B\u044E\u0447\u0438 \u043D\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0431\u0435\u0437 \u044F\u0432\u043D\u043E\u0433\u043E \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F. \u0412\u0441\u0435 \u043E\u0448\u0438\u0431\u043A\u0438 \u0431\u043B\u043E\u043A\u0438\u0440\u0443\u044E\u0442 \u0438\u043C\u043F\u043E\u0440\u0442."]) guide.addRow([t]);
    return book.xlsx.writeBuffer();
  }

  // src/analytics/palette.js
  var labels = Object.freeze({
    actual: "\u0424\u0430\u043A\u0442",
    comparison: "\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435",
    compliant: "\u0421\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442",
    attention: "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044F",
    risk: "\u0420\u0438\u0441\u043A / \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435",
    critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435",
    plan: "\u041F\u043B\u0430\u043D",
    not_assessed: "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E",
    not_applicable: "\u041D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E"
  });
  var palettes = {
    light: {
      surface: "#FFFFFF",
      text: "#5B626E",
      grid: "#DADDDF",
      actual: "#242E40",
      comparison: "#2563EB",
      compliant: "#27965A",
      attention: "#A17600",
      risk: "#C46708",
      critical: "#E30613",
      plan: "#85878C",
      unavailable: "#BFC0C0",
      unavailableOutline: "#686B71",
      categorical: ["#242E40", "#2563EB", "#687B98", "#79649A", "#476F83", "#65749E"]
    },
    dark: {
      surface: "#232B39",
      text: "#BDC6D3",
      grid: "#424E60",
      actual: "#A9BCD4",
      comparison: "#74A8FF",
      compliant: "#69CA90",
      attention: "#F0CE57",
      risk: "#FFAB62",
      critical: "#FF777F",
      plan: "#A6ADB8",
      unavailable: "#626E80",
      unavailableOutline: "#C0CAD7",
      categorical: ["#A9BCD4", "#74A8FF", "#91A7C7", "#C3A6E0", "#80C3D4", "#A5B4E8"]
    }
  };
  for (const p of Object.values(palettes)) {
    Object.freeze(p.categorical);
    Object.freeze(p);
  }
  Object.freeze(palettes);
  function analyticsPalette(dark = false) {
    return palettes[dark ? "dark" : "light"];
  }
  function registryCountChart(categories, counts, dark = false) {
    if (!Array.isArray(categories) || !Array.isArray(counts) || categories.length !== counts.length || counts.some((n) => !Number.isSafeInteger(n) || n < 0)) throw new TypeError("Invalid registry counts");
    const p = analyticsPalette(dark);
    return {
      backgroundColor: "transparent",
      animation: false,
      color: p.categorical.slice(),
      textStyle: { fontFamily: "Proxima Nova, Proxima Nova Rg, Arial, sans-serif" },
      aria: { enabled: true, description: "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439: " + categories.map((n, i) => n + " \u2014 " + counts[i]).join("; ") },
      tooltip: { trigger: "axis" },
      grid: { left: 24, right: 36, bottom: 8, top: 8, containLabel: true },
      xAxis: { type: "value", minInterval: 1, axisLabel: { color: p.text }, splitLine: { lineStyle: { color: p.grid } } },
      yAxis: { type: "category", inverse: true, data: categories.slice(), axisLabel: { color: p.text, fontSize: 11, width: 144, overflow: "truncate" }, axisLine: { show: false }, axisTick: { show: false } },
      series: [{ name: "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438", type: "bar", barMaxWidth: 20, data: counts.slice(), label: { show: true, position: "right", color: p.text }, itemStyle: { color: p.actual, borderRadius: [0, 2, 2, 0] } }]
    };
  }

  // src/app.js
  var root = document.getElementById("app");
  var SQL;
  var ws;
  var cache;
  var folder;
  var generation = 0;
  var busy = false;
  var master = false;
  var page = "home";
  var theme = false;
  var status = "\u0413\u043E\u0442\u043E\u0432\u043E";
  var error = false;
  var chart = null;
  var edit = null;
  var query = "";
  var incoming = [];
  var importState = null;
  var historyPerson = null;
  var archiveFilter = "active";
  var libraryDraft = null;
  var editorSession = null;
  var libraryFilter = "all";
  var contentStore = new ContentStore(() => cache, () => folder);
  var readContent2 = (ref) => contentStore.get(ref);
  var sourceRefs = () => unionRefs(refsForDb(ws.base), refsForEvents(ws.pending));
  var planned = { sop: "\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u0421\u041E\u041F", sop_constructor: "\u041A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 \u0421\u041E\u041F", frv: "\u0424\u0420\u0412", twi_plans: "\u041F\u043B\u0430\u043D\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 TWI", sop_evaluation: "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F", my_plan: "\u041C\u043E\u0439 \u043F\u043B\u0430\u043D", twi: "\u041F\u043B\u0430\u043D \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", programs: "\u0412\u0432\u043E\u0434 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E", internship: "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438", instruction: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0438 TWI", retraining: "\u041F\u0435\u0440\u0435\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", journal: "\u0416\u0443\u0440\u043D\u0430\u043B \u0437\u0430\u0434\u0430\u043D\u0438\u0439", skills: "\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", practical: "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043E\u0446\u0435\u043D\u043A\u0438", development: "\u041F\u043B\u0430\u043D\u044B \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", mentoring: "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438 \u0438 \u0412\u0422", self_eval: "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430", certification: "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F", appointments: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F", audit: "\u0410\u0443\u0434\u0438\u0442\u044B 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F", calendar: "\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u044C", actions: "\u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u044F", analytics: "\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 \u0446\u0435\u043D\u0442\u0440\u0430", metrics: "\u0414\u0435\u0440\u0435\u0432\u043E \u043C\u0435\u0442\u0440\u0438\u043A", roi: "ROI-\u043C\u043E\u0434\u0435\u043B\u044C", ai: "\u0418\u0418-\u043F\u043E\u043C\u043E\u0449\u043D\u0438\u043A" };
  var labels2 = { home: "\u0414\u0430\u0448\u0431\u043E\u0440\u0434", ...Object.fromEntries(Object.entries(definitions).map(([k, v]) => [k, v.label])), ...planned, org_unit: "\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F", import_xlsx: "\u0418\u043C\u043F\u043E\u0440\u0442 \u0434\u0430\u043D\u043D\u044B\u0445", storage: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0438 \u043E\u0431\u043C\u0435\u043D" };
  var navGroups = [
    ["\u0415\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0442\u0430", ["home", "my_plan", "calendar", "actions"]],
    ["\u0421\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u0438\u0437\u0430\u0446\u0438\u044F \u0438 \u0443\u043B\u0443\u0447\u0448\u0435\u043D\u0438\u044F", ["sop", "sop_constructor", "frv", "sop_evaluation"]],
    ["\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", ["twi_plans", "twi", "programs", "internship", "instruction", "retraining", "journal"]],
    ["\u041B\u044E\u0434\u0438 \u0438 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438", ["person", "workplace", "skills", "practical", "development"]],
    ["\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438 \u0438 \u0412\u0422", ["mentoring", "self_eval", "certification", "appointments", "audit"]],
    ["\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430", ["analytics", "metrics", "roi"]],
    ["\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0446\u0435\u043D\u0442\u0440\u043E\u043C", ["org_unit", "import_xlsx", "storage"]],
    ["\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438", ["profession", "position", "work_shift", "equipment", "operation", "person_assignment", "business_role", "role_assignment", "skill_category", "skill", "rating_scale"]]
  ];
  var implemented = /* @__PURE__ */ new Set(["home", "sop", "sop_constructor", "frv", "twi_plans", "sop_evaluation", "storage", "import_xlsx", ...TRAINING_PAGES, ...Object.keys(definitions)]);
  var collapsedNav = /* @__PURE__ */ new Set(["\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438 \u0438 \u0412\u0422", "\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430", "\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438"]);
  var librarySelected = null;
  var libraryRevisionSelected = null;
  var evaluationSelected = null;
  var evaluationTab = "weighted";
  var evaluationSearch = "";
  function el(tag, text4, cls) {
    const n = document.createElement(tag);
    if (text4 !== void 0) n.textContent = text4;
    if (cls) n.className = cls;
    return n;
  }
  function add(parent, ...children) {
    parent.append(...children);
    return parent;
  }
  function btn(label, fn, cls = "", disabled = false) {
    const n = el("button", label, cls);
    n.type = "button";
    n.disabled = disabled || busy;
    n.addEventListener("click", fn);
    return n;
  }
  function pane(title, ...children) {
    return add(el("section", void 0, "panel"), el("h2", title), ...children);
  }
  function message(s, bad = false) {
    status = s;
    error = bad;
    const n = document.getElementById("status");
    if (n) {
      n.textContent = s;
      n.className = "status" + (bad ? " error" : "");
    }
  }
  function navigate(p) {
    if (busy) return;
    if (editorSession && !editorSession.host.hidden) hideEditor(editorSession);
    closePeopleDropdown();
    resetTrainingRoute();
    page = p;
    edit = null;
    query = "";
    historyPerson = null;
    archiveFilter = "active";
    libraryFilter = "all";
    librarySelected = null;
    libraryRevisionSelected = null;
    if (p === "sop_evaluation") {
      evaluationSelected = null;
      evaluationTab = "weighted";
      evaluationSearch = "";
    }
    render();
  }
  function goTraining(p, options = {}) {
    navigate(p);
    setTrainingRoute(p, options);
    render();
  }
  function openImport(type) {
    importState = { type, book: null, sheet: 0, header: 1, mapping: {}, allowUpdates: false, plan: null, file: "" };
    navigate("import_xlsx");
  }
  function openHistory(id) {
    navigate("person_assignment");
    historyPerson = id;
    archiveFilter = "all";
    render();
  }
  async function persist() {
    if (cache) generation = await saveWorkspace(cache, generation, ws.state());
  }
  function replace(newWs) {
    ws?.close();
    ws = newWs;
  }
  async function run(fn, { save: save2 = true } = {}) {
    if (busy) return;
    const prev = ws.state();
    busy = true;
    root.querySelectorAll("button").forEach((b) => b.disabled = true);
    message("\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F\u2026");
    try {
      const m = await fn();
      if (save2) await persist();
      message(m || "\u0413\u043E\u0442\u043E\u0432\u043E");
    } catch (e) {
      console.error(e);
      replace(new Workspace(SQL, openDb(SQL, prev.base), prev));
      message(e.message, true);
    } finally {
      busy = false;
      render();
    }
  }
  function download(name, body) {
    const url = URL.createObjectURL(new Blob([canonical(body)], { type: "application/json" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function pick(accept, fn, max = 150 * 1024 * 1024) {
    const i = el("input");
    i.type = "file";
    i.accept = accept;
    i.onchange = () => {
      const f = i.files?.[0];
      if (f) run(async () => {
        invariant(f.size <= max, "\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
        return await fn(JSON.parse(await f.text()));
      });
    };
    i.click();
  }
  var empty = () => !ws.pending.length && !ws.dirty && !meta(ws.base, "publication_id") && Object.keys(definitions).every((t) => list(ws.base, t).length === 0) && !one(ws.base, "SELECT id FROM document LIMIT 1") && !one(ws.base, "SELECT id FROM frv_study LIMIT 1");
  function refName(type, id) {
    if (!id) return "\u2014";
    const v = one(ws.working, "SELECT * FROM " + type + " WHERE id=?", [id]);
    return v?.display_name || v?.name || id;
  }
  function refOption(type, v) {
    return (v.employee_code || v.code ? (v.employee_code || v.code) + " \u2014 " : "") + (v.display_name || v.name || v.id) + (v.unit_id ? " \xB7 " + refName("org_unit", v.unit_id) : "") + (v.archived ? " (\u0430\u0440\u0445\u0438\u0432)" : "");
  }
  var today = () => {
    const d = /* @__PURE__ */ new Date();
    return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
  };
  function activeRecord(d, v) {
    return !v.archived && (!d.history || v.valid_from <= today() && (!v.valid_to || v.valid_to >= today()));
  }
  function showVal(k, f, v) {
    if (f.ref) return k === "shift_id" && !v[k] && v.shift_code ? v.shift_code + " (LC1)" : refName(f.ref, v[k]);
    if (k === "criticality") return { normal: "\u041E\u0431\u044B\u0447\u043D\u0430\u044F", important: "\u0412\u0430\u0436\u043D\u0430\u044F", critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" }[v[k]] || v[k];
    return v[k] ?? "\u2014";
  }
  var ICON_PATHS = {
    home: ["M3 10 12 3l9 7v10H3z", "M9 20v-6h6v6"],
    sop: ["M6 3h9l4 4v14H6z", "M14 3v5h5", "M9 12h7M9 16h7"],
    frv: ["M12 5a7 7 0 1 0 7 7 7 7 0 0 0-7-7z", "M12 8v4l3 2M9 2h6"],
    twi: ["M3 5h7l2 2 2-2h7v15h-7l-2 1-2-1H3z", "M12 7v14"],
    skills: ["M3 4h18v16H3z", "M3 9h18M3 14h18M9 4v16M15 4v16"],
    mentoring: ["M9 4a3 3 0 1 0 0 6 3 3 0 0 0 0-6z", "M3 20v-3c0-3 12-3 12 0v3", "M16 6h5M18.5 3.5v5"],
    audit: ["M5 4h14v17H5z", "M9 4V2h6v2", "m8 10 2 2 4-4", "M8 16h8"],
    calendar: ["M3 6h18v15H3z", "M7 3v6M17 3v6M3 10h18", "M7 14h3M14 14h3"],
    actions: ["M4 5h16v15H4z", "m7 11 3 3 6-6"],
    analytics: ["M4 3v17h17", "M8 16v-5M13 16V7M18 16V4"],
    ai: ["m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"],
    org_unit: ["M8 3h8v5H8z", "M12 8v5M4 13h16M4 13v3M20 13v3", "M2 16h5v5H2zM17 16h5v5h-5z"],
    person: ["M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z", "M4 21v-3c0-6 16-6 16 0v3"],
    profession: ["M3 7h18v13H3z", "M8 7V4h8v3M3 12h18M10 12v3h4v-3"],
    equipment: ["M3 21V9l6 4V8l6 5V4h5v17z", "M6 17h2M11 17h2M16 17h2"],
    operation: ["M4 3h16v5H4zM4 16h16v5H4z", "M12 8v8m-3-3 3 3 3-3"],
    person_assignment: ["M3 4h18v16H3z", "M7 8h4M7 12h4M7 16h4", "m14 13 2 2 4-5"],
    storage: ["M4 7c0-4 16-4 16 0v10c0 4-16 4-16 0z", "M4 7c0 4 16 4 16 0M4 12c0 4 16 4 16 0"]
  };
  function icon(key3, cls = "nav-icon") {
    if (key3 === "sop_constructor") key3 = "sop";
    if (key3 === "twi_plans") key3 = "twi";
    const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
    for (const [k, v] of Object.entries({ viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.65", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", class: cls })) svg.setAttribute(k, v);
    for (const d of ICON_PATHS[key3] || ICON_PATHS.home) {
      const p = document.createElementNS(ns, "path");
      p.setAttribute("d", d);
      svg.append(p);
    }
    return svg;
  }
  function navButton(k) {
    const n = btn("", () => navigate(k), "nav" + (page === k ? " active" : "") + (!implemented.has(k) ? " nav-planned" : ""));
    n.append(icon(k), el("span", labels2[k]));
    if (page === k) n.setAttribute("aria-current", "page");
    if (!implemented.has(k)) {
      n.title = "\u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u043D\u0430 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0435 \u044D\u0442\u0430\u043F\u044B";
      const dot = el("span", "", "planned-dot");
      dot.setAttribute("aria-hidden", "true");
      n.append(dot);
    }
    return n;
  }
  function sectionHeading(title, caption) {
    return add(el("div", void 0, "section-heading"), el("h2", title), el("span", caption, "muted"));
  }
  function home(main) {
    const todayIso = today(), overdue = one(ws.working, "SELECT count(*) n FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.state='effective' AND d.archived=0 AND r.review_due<?", [todayIso]).n;
    const without = one(ws.working, "SELECT count(*) n FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.state='draft' AND d.archived=0 AND (r.print_format IS NULL OR r.workplace_id IS NULL)").n;
    const needs = pane("\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044F", add(el("div", void 0, "attention-row"), el("strong", String(overdue), overdue ? "bad" : "muted"), el("span", "\u041F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0421\u041E\u041F"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
      navigate("sop");
      libraryFilter = "overdue";
      render();
    })), add(el("div", void 0, "attention-row"), el("strong", String(without), without ? "warn" : "muted"), el("span", "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438 \u0431\u0435\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0433\u043E \u043F\u0430\u0441\u043F\u043E\u0440\u0442\u0430"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
      navigate("sop");
      libraryFilter = "missing_passport";
      render();
    })));
    const overdueTraining = one(ws.working, "SELECT count(*) n FROM training_assignment WHERE source_sha256 IS NOT NULL AND state IN('planned','in_progress') AND due_on<?", [todayIso]).n;
    const revisedTraining = one(ws.working, "SELECT count(*) n FROM training_assignment a JOIN document_revision r ON r.id=a.sop_revision_id JOIN document d ON d.id=r.document_id WHERE a.source_sha256 IS NOT NULL AND a.state<>'cancelled' AND (r.state<>'effective' OR d.archived=1)").n;
    needs.append(add(el("div", void 0, "attention-row"), el("strong", String(overdueTraining), overdueTraining ? "warn" : "muted"), el("span", "\u041F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043D\u044B\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goTraining("twi", { filter: "overdue" }))), add(el("div", void 0, "attention-row"), el("strong", String(revisedTraining), revisedTraining ? "warn" : "muted"), el("span", "\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u043F\u0440\u0435\u0436\u043D\u0438\u043C \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F\u043C \u0421\u041E\u041F"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goTraining("retraining"))));
    main.append(needs);
    main.append(sectionHeading("\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F", "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"));
    const g = el("div", void 0, "kpi-grid");
    const counts = Object.fromEntries(Object.keys(definitions).map((k) => [k, list(ws.working, k).filter((x) => activeRecord(definitions[k], x)).length]));
    for (const k of ["org_unit", "person", "workplace", "equipment", "operation", "profession"]) {
      const d = definitions[k], n = btn("", () => navigate(k), "tile");
      n.setAttribute("aria-label", d.label + ": " + counts[k]);
      add(n, add(el("div", void 0, "tile-head"), el("span", d.label, "muted"), icon(k, "tile-icon")), el("b", String(counts[k])), el("span", "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u2192", "tile-link"));
      g.append(n);
    }
    main.append(g);
    main.append(add(el("div", void 0, "row registry-shortcuts"), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432 \u0438\u0437 Excel", () => openImport("person"), "primary"), btn("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", () => navigate("person_assignment")), btn("\u0428\u043A\u0430\u043B\u044B \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u043D\u0438\u044F", () => navigate("rating_scale"))));
    const c = el("div", void 0, "chart");
    c.style.height = Math.max(290, Object.keys(definitions).length * 29) + "px";
    main.append(pane("\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432", c));
    if (window.echarts) {
      chart = echarts.init(c, theme ? "dark" : null);
      chart.setOption(registryCountChart(Object.values(definitions).map((x) => x.label), Object.keys(definitions).map((k) => counts[k]), theme));
    }
    const links = el("div", void 0, "workspace-grid");
    for (const [k, n] of Object.entries(planned).filter(([k2]) => implemented.has(k2))) {
      const b = btn("", () => navigate(k), "workspace-link");
      b.append(icon(k), el("span", n));
      links.append(b);
    }
    main.append(pane("\u0420\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u043E\u0434\u0443\u043B\u0438", el("p", "\u0421\u041E\u041F, \u0424\u0420\u0412, TWI, \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438, \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0438 \u0430\u0443\u0434\u0438\u0442 \u2014 \u0440\u0430\u0432\u043D\u043E\u043F\u0440\u0430\u0432\u043D\u044B\u0435 \u043C\u043E\u0434\u0443\u043B\u0438 \u0446\u0435\u043D\u0442\u0440\u0430. \u0414\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0431\u0430\u0437\u0430, \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438, \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0421\u041E\u041F, \u0424\u0420\u0412, \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435, \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438 \u0438 \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438. \u0410\u0443\u0434\u0438\u0442 L1 \u0438 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u043D\u0430\u044F \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0430\u044E\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.", "muted"), links));
  }
  function form(type, v) {
    const d = definitions[type], f = el("form"), grid = el("div", void 0, "formgrid"), controls = {};
    for (const [k, x] of Object.entries(d.fields)) {
      let input;
      const initial = v?.[k] ?? (k === "criticality" ? "normal" : k === "kind" ? "\u0423\u0447\u0430\u0441\u0442\u043E\u043A" : k === "valid_from" ? today() : k === "version_no" ? "1" : "");
      if (x.legacy) {
        input = el("input");
        input.type = "hidden";
        input.name = k;
        input.value = initial;
        controls[k] = input;
        grid.append(input);
        if (initial) grid.append(add(el("div", void 0, "field"), el("span", x.label), el("p", initial, "muted")));
        continue;
      }
      if (x.ref || x.options) {
        input = el("select");
        const option = el("option", "\u2014");
        option.value = "";
        input.append(option);
        const opts = x.ref ? list(ws.working, x.ref).filter((y) => !y.archived || v?.[k] === y.id).map((y) => [y.id, refOption(x.ref, y)]) : x.options.map((y) => [y, y === "normal" ? "\u041E\u0431\u044B\u0447\u043D\u0430\u044F" : y === "important" ? "\u0412\u0430\u0436\u043D\u0430\u044F" : y === "critical" ? "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" : y]);
        for (const [value, label] of opts) {
          const o = el("option", label);
          o.value = value;
          input.append(o);
        }
      } else if (x.multiline) {
        input = el("textarea");
        input.rows = 5;
        input.maxLength = 5e3;
        input.placeholder = "0: \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u044F\n1: \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u044F";
      } else {
        input = el("input");
        input.type = x.date ? "date" : x.integer ? "number" : "text";
        input.maxLength = 500;
        if (x.integer) {
          input.min = "1";
          input.step = "1";
        }
      }
      input.name = k;
      input.required = !!x.required;
      input.value = initial;
      controls[k] = input;
      if (d.history && v?.id && k !== "valid_to") input.disabled = true;
      if (d.history && v?.valid_to && k === "valid_to") input.disabled = true;
      grid.append(add(el("label", void 0, "field"), el("span", x.label), input));
    }
    const submit = el("button", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C", "primary");
    submit.type = "submit";
    submit.disabled = busy;
    f.onsubmit = (e) => {
      e.preventDefault();
      const payload = Object.fromEntries(Object.entries(controls).map(([k, n]) => [k, n.value || null]));
      run(async () => {
        ws.edit(type, v?.id || null, payload);
        edit = null;
        return "\u0417\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
      });
    };
    if (d.history && v?.id) f.append(el("p", "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430: \u043C\u043E\u0436\u043D\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u0437\u0430\u043A\u0440\u044B\u0442\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0434\u0430\u0442\u043E\u0439 \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F. \u0414\u043B\u044F \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E\u0441\u043B\u0435 \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u044F.", "muted"));
    if (type === "rating_scale") f.append(el("p", "\u041F\u043E\u0441\u043B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0448\u043A\u0430\u043B\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430. \u0414\u043B\u044F \u043D\u043E\u0432\u043E\u0439 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E. \u0423\u0440\u043E\u0432\u043D\u0438 \u0437\u0430\u0434\u0430\u044E\u0442\u0441\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u043C; \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0438\u0435 \u043F\u043E\u0440\u043E\u0433\u0438 \u043D\u0435 \u043F\u0440\u0435\u0434\u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u044B.", "muted"));
    return add(f, grid, add(el("div", void 0, "row"), submit, btn("\u041E\u0442\u043C\u0435\u043D\u0430", () => {
      edit = null;
      render();
    })));
  }
  function orgTree(panel, items) {
    const box = el("div", void 0, "org-tree"), children = /* @__PURE__ */ new Map();
    for (const v of items) {
      const k = v.parent_id || "";
      if (!children.has(k)) children.set(k, []);
      children.get(k).push(v);
    }
    const seen = /* @__PURE__ */ new Set();
    function walk(id, depth) {
      for (const v of children.get(id) || []) {
        if (seen.has(v.id)) continue;
        seen.add(v.id);
        const line = add(el("div", void 0, "org-node"), el("span", v.code, "pill"), el("span", v.name), el("span", v.kind + (v.archived ? " \xB7 \u0410\u0440\u0445\u0438\u0432" : ""), "muted"));
        line.style.paddingLeft = Math.min(depth, 8) * 17 + "px";
        box.append(line);
        walk(v.id, depth + 1);
      }
    }
    walk("", 0);
    for (const v of items.filter((x) => !seen.has(x.id))) box.append(el("p", v.code + " \u2014 " + v.name + " (\u043D\u0435\u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u0439 \u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044C)", "warn"));
    if (items.length) panel.append(pane("\u0418\u0435\u0440\u0430\u0440\u0445\u0438\u044F \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F", box));
  }
  function registry(main, type) {
    const d = definitions[type], items = list(ws.working, type), search = el("input");
    search.type = "search";
    search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0443";
    search.value = query;
    const filter = el("select");
    for (const [value, label] of [["active", d.history ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435" : "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435"], ["all", "\u0412\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"], ["inactive", d.history ? "\u0418\u0441\u0442\u043E\u0440\u0438\u044F / \u0431\u0443\u0434\u0443\u0449\u0438\u0435" : "\u0410\u0440\u0445\u0438\u0432"]]) {
      const o = el("option", label);
      o.value = value;
      filter.append(o);
    }
    filter.value = archiveFilter;
    const panel = pane(d.label, add(el("div", void 0, "row"), search, filter, btn("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C", () => {
      edit = historyPerson ? { person_id: historyPerson } : {};
      render();
    }, "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 Excel", () => openImport(type))));
    main.append(panel);
    if (historyPerson) panel.append(add(el("div", void 0, "row"), el("span", "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430: " + refName("person", historyPerson), "pill"), btn("\u0412\u0441\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438", () => {
      historyPerson = null;
      render();
    })));
    if (edit !== null) panel.append(pane(edit.id ? "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435" : "\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C", form(type, edit)));
    const wrap = el("div", void 0, "tablewrap");
    panel.append(wrap);
    function draw() {
      wrap.replaceChildren();
      const data = items.filter((v) => (!historyPerson || v.person_id === historyPerson) && (archiveFilter === "all" || (archiveFilter === "active" ? activeRecord(d, v) : !activeRecord(d, v))) && Object.entries(d.fields).some(([k, f]) => String(showVal(k, f, v)).toLowerCase().includes(query.toLowerCase())));
      if (!data.length) {
        wrap.append(el("p", "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439", "empty"));
        return;
      }
      const fields = Object.entries(d.fields).filter(([, f]) => !f.legacy);
      const t = el("table"), head = el("tr");
      for (const [, f] of fields) head.append(el("th", f.label));
      head.append(el("th", "\u0412\u0435\u0440\u0441\u0438\u044F / \u0441\u0442\u0430\u0442\u0443\u0441"), el("th", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F"));
      t.append(add(el("thead"), head));
      const body = el("tbody");
      for (const v of data) {
        const tr = el("tr", void 0, !activeRecord(d, v) ? "archive" : "");
        for (const [k, f] of fields) tr.append(el("td", String(showVal(k, f, v)), f.multiline ? "multiline-cell" : ""));
        const state = v.archived ? "\u0410\u0440\u0445\u0438\u0432" : d.history ? v.valid_from > today() ? "\u0411\u0443\u0434\u0443\u0449\u0435\u0435" : v.valid_to && v.valid_to < today() ? "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E" : "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u0410\u043A\u0442\u0438\u0432\u043D\u043E";
        tr.append(el("td", state + " \xB7 v" + v.rev));
        const a = el("td");
        if (!v.archived) {
          if (!d.immutable && (!d.history || !v.valid_to)) a.append(btn(d.history ? "\u0417\u0430\u043A\u0440\u044B\u0442\u044C / \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C" : "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C", () => {
            edit = v;
            render();
          }, "", !!ws.conflicts.length));
          if (d.immutable) a.append(btn("\u041D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F", () => {
            edit = { name: v.name, version_no: String(Math.max(...items.filter((x) => x.name === v.name).map((x) => x.version_no)) + 1), levels: v.levels };
            render();
          }, "", !!ws.conflicts.length));
          if (!d.history) a.append(btn("\u0410\u0440\u0445\u0438\u0432", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C? \u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F.")) run(async () => {
              ws.edit(type, v.id, null, "archive");
              return "\u0417\u0430\u043F\u0438\u0441\u044C \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
            });
          }, "danger", !!ws.conflicts.length));
          if (type === "person") {
            a.append(btn("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F", () => openHistory(v.id)));
            a.append(btn("\u0420\u043E\u043B\u0438", () => {
              navigate("role_assignment");
              historyPerson = v.id;
              archiveFilter = "all";
              render();
            }));
          }
        }
        tr.append(a);
        body.append(tr);
      }
      t.append(body);
      wrap.append(t);
    }
    search.oninput = () => {
      query = search.value;
      draw();
    };
    filter.onchange = () => {
      archiveFilter = filter.value;
      draw();
    };
    draw();
    if (type === "org_unit") orgTree(panel, items);
  }
  function downloadBytes(name, bytes) {
    const url = URL.createObjectURL(new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function updateMapping(s) {
    s.plan = null;
    s.mapping = s.book ? autoMap(s.type, sheetHeaders(s.book.worksheets[s.sheet], s.header)) : {};
  }
  function importScreen(main) {
    const s = importState || (importState = { type: "person", book: null, sheet: 0, header: 1, mapping: {}, allowUpdates: false, plan: null, file: "" });
    const kind = el("select");
    kind.name = "import_type";
    for (const [key3, d] of Object.entries(definitions)) {
      const o = el("option", d.label);
      o.value = key3;
      kind.append(o);
    }
    kind.value = s.type;
    kind.onchange = () => {
      s.type = kind.value;
      try {
        updateMapping(s);
      } catch (e) {
        message(e.message, true);
        s.mapping = {};
      }
      render();
    };
    const load2 = el("input");
    load2.type = "file";
    load2.accept = ".xlsx";
    load2.name = "import_file";
    load2.onchange = () => {
      const f = load2.files?.[0];
      if (!f) return;
      run(async () => {
        invariant(/\.xlsx$/i.test(f.name) && f.size <= MAX_XLSX, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 XLSX \u0434\u043E 20 \u041C\u0411");
        const book = await loadWorkbook(window.ExcelJS, await f.arrayBuffer());
        s.book = book;
        s.file = f.name;
        s.sheet = 0;
        s.header = 1;
        updateMapping(s);
        return "Excel \u043E\u0442\u043A\u0440\u044B\u0442. \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u043A\u043E\u043B\u043E\u043D\u043E\u043A.";
      }, { save: false });
    };
    const setup = pane("1. \u0412\u044B\u0431\u043E\u0440 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u0438 \u0444\u0430\u0439\u043B\u0430", add(el("div", void 0, "formgrid"), add(el("label", void 0, "field"), el("span", "\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A"), kind), add(el("label", void 0, "field"), el("span", "Excel (.xlsx)"), load2)), add(el("div", void 0, "row"), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D XLSX", () => run(async () => {
      downloadBytes("LeanCenter-" + s.type + ".xlsx", await makeTemplate(window.ExcelJS, s.type));
      return "\u0428\u0430\u0431\u043B\u043E\u043D \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false })), btn("\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0438\u043C\u043F\u043E\u0440\u0442", () => openImport(s.type))), el("p", s.file ? "\u041E\u0442\u043A\u0440\u044B\u0442 \u0444\u0430\u0439\u043B: " + s.file : "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u0430\u0439\u043B. \u0414\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u0442\u0441\u044F \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0438\u043C\u043F\u043E\u0440\u0442\u0430.", "muted"));
    main.append(setup);
    if (!s.book) return;
    const select = el("select");
    select.name = "import_sheet";
    for (const [i, sheet] of s.book.worksheets.entries()) {
      const o = el("option", sheet.name);
      o.value = String(i);
      select.append(o);
    }
    select.value = String(s.sheet);
    select.onchange = () => {
      s.sheet = Number(select.value);
      try {
        updateMapping(s);
      } catch (e) {
        message(e.message, true);
        s.mapping = {};
      }
      render();
    };
    const hdr = el("input");
    hdr.type = "number";
    hdr.name = "header_row";
    hdr.min = 1;
    hdr.max = 20;
    hdr.value = s.header;
    hdr.onchange = () => {
      const v = Number(hdr.value);
      if (Number.isInteger(v) && v >= 1 && v <= 20) {
        s.header = v;
        try {
          updateMapping(s);
        } catch (e) {
          message(e.message, true);
          s.mapping = {};
        }
        render();
      }
    };
    const updates = el("input");
    updates.type = "checkbox";
    updates.name = "allow_updates";
    updates.checked = s.allowUpdates;
    updates.onchange = () => {
      s.allowUpdates = updates.checked;
      s.plan = null;
      render();
    };
    const mapPanel = pane("2. \u041B\u0438\u0441\u0442 \u0438 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u043A\u043E\u043B\u043E\u043D\u043E\u043A", add(el("div", void 0, "formgrid"), add(el("label", void 0, "field"), el("span", "\u041B\u0438\u0441\u0442"), select), add(el("label", void 0, "field"), el("span", "\u0421\u0442\u0440\u043E\u043A\u0430 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u043E\u0432 (1\u201320)"), hdr)), el("p", "\u041A\u043E\u0434\u044B \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0442\u0435\u043A\u0441\u0442\u043E\u043C \u0432 Excel. \u0421\u0441\u044B\u043B\u043A\u0438 \u2014 \u043F\u043E \u043A\u043E\u0434\u0430\u043C, \u043D\u0435 \u043F\u043E \u0424\u0418\u041E. \u0414\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435/\u043A\u043E\u0434. \u041D\u0435\u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044B\u0435 \u043A\u043E\u043B\u043E\u043D\u043A\u0438 \u043F\u0440\u0438 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442 \u043F\u0440\u0435\u0436\u043D\u0435\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435. \u041F\u0443\u0441\u0442\u0430\u044F \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u0430\u044F \u043A\u043E\u043B\u043E\u043D\u043A\u0430 \u043E\u0447\u0438\u0449\u0430\u0435\u0442 \u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043F\u043E\u043B\u0435.", "muted"));
    main.append(mapPanel);
    let headers;
    try {
      headers = sheetHeaders(s.book.worksheets[s.sheet], s.header);
    } catch (e) {
      mapPanel.append(el("p", e.message, "bad"));
      return;
    }
    const grid = el("div", void 0, "formgrid");
    for (const [key3, f] of importFields(s.type)) {
      const input = el("select");
      input.name = "map_" + key3;
      const blank = el("option", "\u2014 \u041D\u0435 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u2014");
      blank.value = "";
      input.append(blank);
      for (const h of headers) {
        const o = el("option", h.col + " \xB7 " + h.name);
        o.value = String(h.col);
        input.append(o);
      }
      input.value = String(s.mapping[key3] || "");
      input.onchange = () => {
        s.mapping[key3] = Number(input.value) || null;
        s.plan = null;
        render();
      };
      grid.append(add(el("label", void 0, "field"), el("span", fieldLabel(s.type, key3) + (f.required ? " *" : "")), input));
    }
    mapPanel.append(grid, add(el("label", void 0, "row"), updates, el("span", "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u044C \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0449\u0438\u0445 \u043A\u043B\u044E\u0447\u0435\u0439 (\u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430)")), btn("\u041F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430", () => run(async () => {
      const cols = Object.values(s.mapping).filter(Boolean);
      invariant(cols.length > 0 && new Set(cols).size === cols.length, "\u041D\u0430\u0437\u043D\u0430\u0447\u044C\u0442\u0435 \u043A\u0430\u0436\u0434\u043E\u0439 \u043A\u043E\u043B\u043E\u043D\u043A\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043E\u0434\u043D\u043E \u043F\u043E\u043B\u0435");
      s.plan = planImport(ws, s.type, sheetRows(s.book.worksheets[s.sheet], s.header, s.mapping), { allowUpdates: s.allowUpdates });
      return "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0433\u043E\u0442\u043E\u0432. \u0417\u0430\u043F\u0438\u0441\u044C \u0432 \u0431\u0430\u0437\u0443 \u0435\u0449\u0451 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430.";
    }, { save: false }), "primary"));
    if (!s.plan) return;
    const p = s.plan, c = p.counts;
    const report = pane("3. \u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438", add(el("div", void 0, "row"), el("span", "\u0421\u043E\u0437\u0434\u0430\u0442\u044C: " + c.create, "pill"), el("span", "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C: " + c.update, "pill"), el("span", "\u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439: " + c.same, "pill"), el("span", "\u041E\u0448\u0438\u0431\u043A\u0438: " + c.error, c.error ? "bad" : "pill")));
    const t = el("table"), head = el("tr");
    for (const h of ["\u0421\u0442\u0440\u043E\u043A\u0430 Excel", "\u0420\u0435\u0448\u0435\u043D\u0438\u0435", "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 / \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F"]) head.append(el("th", h));
    t.append(add(el("thead"), head));
    const body = el("tbody");
    for (const v of p.results) {
      const details = el("div");
      details.append(el("div", v.message, v.status === "error" ? "bad" : "muted"));
      for (const ch of v.changes) {
        details.append(el("div", ch.field + ": " + (ch.before ?? "\u2014") + " \u2192 " + (ch.after ?? "\u2014"), "preview-detail"));
      }
      body.append(add(el("tr"), el("td", String(v.row)), el("td", { create: "\u0421\u043E\u0437\u0434\u0430\u0442\u044C", update: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C", same: "\u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", error: "\u041E\u0448\u0438\u0431\u043A\u0430" }[v.status]), add(el("td"), details)));
    }
    t.append(body);
    report.append(add(el("div", void 0, "tablewrap"), t), el("p", c.error ? "\u0418\u043C\u043F\u043E\u0440\u0442 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D. \u0418\u0441\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0432\u0441\u0435 \u043E\u0448\u0438\u0431\u043A\u0438 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443." : "\u0411\u0443\u0434\u0443\u0442 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F, \u043E\u0434\u043D\u043E\u0439 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0435\u0439.", "muted"), btn("\u0418\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C " + p.events.length + " \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", () => {
      if (confirm("\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0432 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u0443\u044E \u0431\u0430\u0437\u0443?")) run(async () => {
        const n = commitImport(ws, p);
        s.plan = null;
        return "\u0418\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439: " + n;
      });
    }, "primary", !!c.error || !p.events.length || !!ws.conflicts.length));
    main.append(report);
  }
  var revisionLabels = { draft: "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A", review: "\u041D\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0438", approved: "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D", effective: "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442", superseded: "\u0417\u0430\u043C\u0435\u043D\u0451\u043D", withdrawn: "\u0412\u044B\u0432\u0435\u0434\u0435\u043D \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F", final: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E", archived: "\u0410\u0440\u0445\u0438\u0432" };
  function inputField(label, input) {
    return add(el("label", void 0, "field"), el("span", label), input);
  }
  function fieldInput(name, value = "", type = "text") {
    const n = el("input");
    n.name = name;
    n.type = type;
    n.value = value ?? "";
    return n;
  }
  function selectRef(type, name, id = null, optional2 = true) {
    const s = el("select");
    s.name = name;
    if (optional2) {
      const o = el("option", "\u2014 \u041D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u043E \u2014");
      o.value = "";
      s.append(o);
    }
    for (const v of list(ws.working, type).filter((x) => !x.archived || x.id === id)) {
      const o = el("option", refOption(type, v));
      o.value = v.id;
      s.append(o);
    }
    s.value = id || "";
    return s;
  }
  function personPickerField(name, label, id = null, { optional: optional2 = true, historicalName = "", allowed = null } = {}) {
    const wrap = el("div"), trigger = btn("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u25BE", () => openPeopleDropdown(trigger, { people: editorPeople, allowed, optional: optional2, selectedId: value, label, onChoose: (p) => {
      value = p?.id || "";
      selectedName = p?.display_name || "";
      update2();
    } }), "lc-directory-trigger");
    trigger.name = name;
    trigger.setAttribute("aria-label", "\u0412\u044B\u0431\u0440\u0430\u0442\u044C: " + label);
    trigger.setAttribute("aria-haspopup", "dialog");
    trigger.setAttribute("aria-expanded", "false");
    let value = id || "", selectedName = id ? one(ws.working, "SELECT display_name FROM person WHERE id=?", [id])?.display_name || historicalName : "";
    function update2() {
      trigger.textContent = (selectedName || "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430") + " \u25BE";
    }
    Object.defineProperties(wrap, { value: { get: () => value }, selectedName: { get: () => selectedName }, disabled: { get: () => trigger.disabled, set: (v) => {
      trigger.disabled = !!v;
    } } });
    wrap.append(trigger);
    update2();
    return wrap;
  }
  function personInputField(label, picker) {
    return add(el("div", void 0, "field"), el("span", label), picker);
  }
  function downloadRaw(name, text4) {
    const url = URL.createObjectURL(new Blob([text4], { type: "application/json;charset=utf-8" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function contentEvent(type, payload) {
    return { id: uuid(), entity_type: type, entity_id: uuid(), operation: "create", expected_revision: 0, payload, occurred_at: (/* @__PURE__ */ new Date()).toISOString() };
  }
  function tableOf(headers, data) {
    const t = el("table"), h = el("tr");
    headers.forEach((v) => h.append(el("th", v)));
    t.append(add(el("thead"), h));
    const body = el("tbody");
    for (const r of data) {
      const tr = el("tr");
      for (const v of r) tr.append(v instanceof Node ? add(el("td"), v) : el("td", String(v ?? "\u2014")));
      body.append(tr);
    }
    t.append(body);
    return add(el("div", void 0, "tablewrap detail-table"), t);
  }
  function evaluationForm(revision2, source) {
    const methods = sopMethods(ws.working).filter((m) => m.state === "active");
    if (!methods.length) return add(el("div"), el("p", "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F \u0432 \u0440\u0430\u0437\u0434\u0435\u043B\u0435 \xAB\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F\xBB.", "muted"), btn("\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u043A \u043E\u0446\u0435\u043D\u043A\u0435 \u0421\u041E\u041F", () => navigate("sop_evaluation")));
    const panel = el("div"), select = el("select");
    for (const m of methods) {
      const o = el("option", "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 v" + m.version_no);
      o.value = m.id;
      select.append(o);
    }
    const actor = personPickerField("eval_actor", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", null, { optional: false }), day = fieldInput("eval_date", today(), "date"), place = fieldInput("eval_place", revision2.workplace_name || ""), content = el("div");
    panel.append(add(el("div", void 0, "formgrid"), inputField("\u0412\u0435\u0440\u0441\u0438\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438", select), personInputField("\u041E\u0446\u0435\u043D\u0449\u0438\u043A", actor), inputField("\u0414\u0430\u0442\u0430", day), inputField("\u041C\u0435\u0441\u0442\u043E", place)), content);
    function draw() {
      content.replaceChildren();
      const criteria = sopCriteria(ws.working, select.value), values = criteria.map((c) => {
        const choice = el("select");
        choice.name = "criterion_" + c.position;
        for (const [v, n] of [["", "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E"], ["1", "1 \u2014 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E"], ["0", "0 \u2014 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E"]]) {
          const o = el("option", n);
          o.value = v;
          choice.append(o);
        }
        const note = fieldInput("note_" + c.position);
        note.maxLength = 2e3;
        return { c, choice, note };
      });
      const progress = el("p", "\u041E\u0446\u0435\u043D\u0435\u043D\u043E: 0 \u0438\u0437 20", "muted"), save2 = btn("\u0417\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043E\u0446\u0435\u043D\u043A\u0443", () => run(async () => {
        const payload = { revision_id: revision2.id, method_id: select.value, actor_id: actor.value, evaluated_on: day.value, place: place.value, source_sha256: source.sha256, responses: values.map((v) => ({ criterion_id: v.c.id, value: v.choice.value === "" ? null : Number(v.choice.value), note: v.note.value })) };
        await ws.applyContentEvents([contentEvent("sop_evaluation", payload)]);
        return "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
      }), "primary", true);
      function update2() {
        const result = evaluationResult(values.map((x) => ({ value: x.choice.value === "" ? null : Number(x.choice.value) })));
        progress.textContent = "\u041E\u0446\u0435\u043D\u0435\u043D\u043E: " + result.rated + " \u0438\u0437 20 \xB7 " + (result.fraction === null ? "\u0438\u0442\u043E\u0433 \u043F\u043E\u043A\u0430 \u043D\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D" : (result.fraction * 100).toFixed(0) + "%");
        save2.disabled = busy || result.rated !== 20 || !!ws.conflicts.length;
      }
      values.forEach((v) => v.choice.onchange = update2);
      content.append(tableOf(["\u2116", "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u043E\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], values.map((v) => [v.c.position, v.c.question, v.choice, v.note])), progress, el("p", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u2014 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u044B\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F / 20. \u041F\u043E\u0440\u043E\u0433 \u0437\u0430\u0447\u0451\u0442\u0430 \u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D; \u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0435 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442 \u0421\u041E\u041F \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438.", "muted"), save2);
    }
    select.onchange = () => {
      if (!confirm("\u0421\u043C\u0435\u043D\u0438\u0442\u044C \u0432\u0435\u0440\u0441\u0438\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438? \u041D\u0435\u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u044B\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u0431\u0443\u0434\u0443\u0442 \u043E\u0447\u0438\u0449\u0435\u043D\u044B.")) {
        select.value = select.dataset.previous;
        return;
      }
      select.dataset.previous = select.value;
      draw();
    };
    select.dataset.previous = select.value;
    draw();
    return panel;
  }
  async function evaluationXlsx(id) {
    const e = one(ws.working, "SELECT * FROM sop_evaluation WHERE id=?", [id]), v = one(ws.working, "SELECT * FROM document_revision WHERE id=?", [e.revision_id]), doc = one(ws.working, "SELECT * FROM document WHERE id=?", [v.document_id]);
    const responses = rows(ws.working, "SELECT c.position,c.question,r.value,r.note FROM sop_evaluation_response r JOIN checklist_criterion c ON c.id=r.criterion_id WHERE r.evaluation_id=? ORDER BY c.position", [id]);
    const method = one(ws.working, "SELECT version_no FROM checklist_version WHERE id=?", [e.method_id]);
    const w = new ExcelJS.Workbook(), s = w.addWorksheet("\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F", { pageSetup: { paperSize: 9, orientation: "landscape", fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
    s.columns = [{ width: 7 }, { width: 105 }, { width: 13 }, { width: 48 }];
    s.mergeCells("A1:D1");
    s.getCell("A1").value = "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F";
    s.getCell("A1").font = { bold: true, size: 16 };
    s.mergeCells("A2:D2");
    s.getCell("A2").value = doc.code + " \xB7 " + doc.title + " \xB7 \u0432\u0435\u0440\u0441\u0438\u044F " + v.version_no;
    s.mergeCells("A3:D3");
    s.getCell("A3").value = "\u041C\u0435\u0441\u0442\u043E: " + e.place + "    \u0414\u0430\u0442\u0430: " + e.evaluated_on + "    \u041E\u0446\u0435\u043D\u0449\u0438\u043A: " + e.actor_name + "    \u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 v" + method.version_no;
    s.mergeCells("A4:D4");
    s.getCell("A4").value = "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 SHA-256: " + e.source_sha256;
    s.addRow(["\u2116 \u043F/\u043F", "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u044B\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"]);
    s.getRow(5).font = { bold: true, color: { argb: "FFFFFFFF" } };
    s.getRow(5).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242E40" } };
    for (const x of responses) {
      const row2 = s.addRow([x.position, x.question, x.value, x.note]);
      row2.alignment = { vertical: "top", wrapText: true };
      row2.height = Math.max(28, 15 * Math.ceil(Math.max(x.question.length / 100, (x.note || "").length / 43)));
    }
    const result = evaluationResult(responses), row = s.addRow(["", "\u0418\u0422\u041E\u0413\u041E", { formula: "SUM(C6:C25)/20", result: result.fraction }, ""]);
    row.getCell(3).numFmt = "0%";
    s.pageSetup.printArea = "A1:D26";
    downloadBytes("\u041E\u0446\u0435\u043D\u043A\u0430-\u0421\u041E\u041F-" + doc.code + "-v" + v.version_no + ".xlsx", await w.xlsx.writeBuffer());
  }
  function evaluationHistory(revision2, source) {
    const data = rows(ws.working, "SELECT e.*,m.version_no AS method_version FROM sop_evaluation e JOIN checklist_version m ON m.id=e.method_id WHERE e.revision_id=? ORDER BY e.evaluated_on DESC,e.recorded_at DESC", [revision2.id]);
    const out = el("div");
    if (!data.length) out.append(el("p", "\u041E\u0446\u0435\u043D\u043E\u043A \u044D\u0442\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0435\u0449\u0451 \u043D\u0435\u0442.", "muted"));
    else out.append(tableOf(["\u0414\u0430\u0442\u0430", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", "\u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A", "\u041E\u0442\u0447\u0451\u0442"], data.map((e) => {
      const r = evaluationResult(rows(ws.working, "SELECT value FROM sop_evaluation_response WHERE evaluation_id=?", [e.id]));
      return [e.evaluated_on, e.actor_name, "v" + e.method_version, r.yes + "/20 \xB7 " + (r.fraction * 100).toFixed(0) + "%", e.source_sha256 === source.sha256 ? "\u0422\u0435\u043A\u0443\u0449\u0438\u0439" : "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0438\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A", btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C XLSX", () => run(async () => {
        await evaluationXlsx(e.id);
        return "\u041E\u0442\u0447\u0451\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
      }, { save: false }))];
    })));
    return out;
  }
  function goEvaluation(id) {
    navigate("sop_evaluation");
    evaluationSelected = id;
    render();
  }
  var stage43SourceLabels = { seed: "\u0421\u0442\u0430\u0440\u0442\u043E\u0432\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", auto: "\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438", manual: "\u0412\u0440\u0443\u0447\u043D\u0443\u044E", legacy: "\u0418\u0437 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0430" };
  var weightedLabel = (data) => {
    const x = weightedResult(data);
    return "\u0412\u0437\u0432\u0435\u0448\u0435\u043D\u043D\u044B\u0439 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: " + (x.fraction === null ? "\u2014" : (x.fraction * 100).toFixed(1) + "%") + " (" + x.points.toFixed(2) + " / " + x.weight.toFixed(2) + ")" + (x.seed ? " \xB7 \u0421\u0442\u0430\u0440\u0442\u043E\u0432\u044B\u0445 \u043E\u0446\u0435\u043D\u043E\u043A: " + x.seed + "; \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439" : "");
  };
  async function stage43Xlsx(doc, revision2, source, data, actorName) {
    const w = new ExcelJS.Workbook(), s = w.addWorksheet("\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 Stage43", { pageSetup: { paperSize: 9, orientation: "landscape", fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
    s.columns = [{ width: 7 }, { width: 84 }, { width: 12 }, { width: 10 }, { width: 12 }, { width: 48 }, { width: 23 }];
    s.mergeCells("A1:G1");
    s.getCell("A1").value = "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F \u2014 Stage43 (13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432)";
    s.getCell("A1").font = { bold: true, size: 15 };
    s.mergeCells("A2:G2");
    s.getCell("A2").value = doc.code + " \xB7 " + doc.title + " \xB7 \u0432\u0435\u0440\u0441\u0438\u044F " + revision2.version_no;
    s.mergeCells("A3:G3");
    s.getCell("A3").value = "SHA-256: " + source.sha256 + " \xB7 " + (actorName || "\u041E\u0446\u0435\u043D\u0449\u0438\u043A \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D");
    s.addRow(["\u2116", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u0412\u0435\u0441", "\u0411\u0430\u043B\u043B", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439", "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A"]);
    s.getRow(4).font = { bold: true, color: { argb: "FFFFFFFF" } };
    s.getRow(4).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242E40" } };
    data.forEach((x, i) => {
      const n = i + 5, row = s.addRow([x.id, x.req, x.score, x.weight, { formula: "C" + n + "*D" + n, result: x.score * x.weight }, x.comment, stage43SourceLabels[x.scoreSource]]);
      row.alignment = { vertical: "top", wrapText: true };
      row.height = Math.max(28, 15 * Math.ceil(Math.max(x.req.length / 75, x.comment.length / 43)));
    });
    const r = weightedResult(data), total = s.addRow(["", "\u0418\u0422\u041E\u0413\u041E", "", { formula: "SUM(D5:D17)", result: r.weight }, { formula: "SUM(E5:E17)", result: r.points }, "", ""]);
    total.font = { bold: true };
    const result = s.addRow(["", "\u0412\u0437\u0432\u0435\u0448\u0435\u043D\u043D\u044B\u0439 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", { formula: "E18/D18", result: r.fraction }, "", "", "", ""]);
    result.getCell(3).numFmt = "0.0%";
    s.mergeCells("A20:G20");
    s.getCell("A20").value = r.seed ? "\u0421\u0442\u0430\u0440\u0442\u043E\u0432\u044B\u0435 \u043E\u0446\u0435\u043D\u043A\u0438 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B: " + r.seed + "; \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439." : "\u041E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 Stage43; \u043D\u0435 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u0431\u0438\u043D\u0430\u0440\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430.";
    s.pageSetup.printArea = "A1:G20";
    downloadBytes("\u0427\u0435\u043A-\u043B\u0438\u0441\u0442-Stage43-" + doc.code + "-v" + revision2.version_no + ".xlsx", await w.xlsx.writeBuffer());
  }
  function stage43Panel(doc, revision2, source) {
    const panel = pane("\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0421\u041E\u041F \xB7 13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432", el("p", "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0433\u043E \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430\u2026", "muted"));
    void (async () => {
      try {
        let refresh2 = function() {
          const value = current();
          value.forEach((x, i) => {
            items[i].cell.textContent = (x.score * x.weight).toFixed(2);
            items[i].origin.textContent = stage43SourceLabels[x.scoreSource];
          });
          progress.textContent = weightedLabel(value);
        }, appendHistory = function() {
          const previous = records.filter((x) => x.source_sha256 !== source.sha256);
          for (const x of previous) {
            const data2 = JSON.parse(x.rows_json), d = el("details");
            d.append(el("summary", "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \xB7 \u043F\u0440\u0435\u0436\u043D\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \xB7 " + x.updated_at.slice(0, 10)), el("p", weightedLabel(data2) + " \xB7 " + (x.actor_name || "\u043E\u0446\u0435\u043D\u0449\u0438\u043A \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D"), "muted"), el("p", "SHA-256: " + x.source_sha256, "source-hash"), tableOf(["\u2116", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u0412\u0435\u0441", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], data2.map((y) => [y.id, y.req, y.score, y.weight, y.comment])));
            panel.append(d);
          }
        };
        const raw = JSON.parse(await readContent2(source)), original = stage43Checklist(raw.constructor);
        if (!panel.isConnected) return;
        panel.replaceChildren(el("h2", "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0421\u041E\u041F \xB7 13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432"), el("p", "\u041F\u0440\u0438\u0432\u044F\u0437\u0430\u043D \u043A \u0442\u043E\u0447\u043D\u043E\u043C\u0443 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0443 \u0432\u0435\u0440\u0441\u0438\u0438 " + revision2.version_no + ". \u0428\u043A\u0430\u043B\u0430 0 / 0,3 / 0,7 / 1 \u0438 \u0432\u0435\u0441\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B. \u041D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F 20-\u043F\u0443\u043D\u043A\u0442\u043D\u043E\u0439 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u043E\u0439 \u043E\u0446\u0435\u043D\u043A\u043E\u0439.", "muted"));
        const records = stage43Checks(ws.working, revision2.id), old = records.find((x) => x.source_sha256 === source.sha256);
        if (!original.length) {
          panel.append(el("p", "\u0412 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u043C JSON \u043D\u0435\u0442 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0421\u041E\u041F \u0438\u0437 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0441 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u043E\u043C.", "muted"));
          appendHistory();
          return;
        }
        const data = old ? JSON.parse(old.rows_json) : original, items = [], progress = el("p", weightedLabel(data), "muted"), actor = personPickerField("stage43_actor", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430", old?.actor_id || null, { historicalName: old?.actor_name || "" }), editable = !doc.archived && !ws.conflicts.length;
        panel.append(el("p", old ? "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u0430\u044F \u043F\u0440\u0430\u0432\u043A\u0430 \u0446\u0435\u043D\u0442\u0440\u0430 \xB7 " + old.updated_at.slice(0, 10) + " \xB7 " + (old.actor_name || "\u043E\u0446\u0435\u043D\u0449\u0438\u043A \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") : "\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D \u0438\u0437 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0435\u0449\u0451 \u043D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u043B\u0438\u0441\u044C \u0432 \u0446\u0435\u043D\u0442\u0440\u0435.", "muted"));
        const table = tableOf(["\u2116", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u0412\u0435\u0441", "\u0411\u0430\u043B\u043B", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439", "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A"], data.map((x) => {
          const select = el("select");
          select.name = "stage43_score_" + x.id;
          for (const v of [0, 0.3, 0.7, 1]) {
            const o = el("option", String(v).replace(".", ","));
            o.value = String(v);
            select.append(o);
          }
          select.value = String(x.score);
          select.disabled = !editable;
          const note = fieldInput("stage43_note_" + x.id, x.comment);
          note.maxLength = 2e3;
          note.disabled = !editable;
          const cell = el("span", (x.score * x.weight).toFixed(2)), origin = el("span", stage43SourceLabels[x.scoreSource], "muted"), item = { x, select, note, cell, origin, changed: false };
          items.push(item);
          select.onchange = () => {
            item.changed = true;
            refresh2();
          };
          note.oninput = refresh2;
          return [x.id, x.req, select, x.weight, cell, note, origin];
        }));
        const current = () => items.map(({ x, select, note, changed }) => ({ ...x, score: Number(select.value), comment: note.value, scoreSource: changed ? "manual" : x.scoreSource }));
        const save2 = btn("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0447\u0435\u043A-\u043B\u0438\u0441\u0442 \u0421\u041E\u041F", () => run(async () => {
          const payload = { revision_id: revision2.id, source, rows: current(), actor_id: actor.value || null };
          const e = old ? { ...contentEvent("sop_stage43_checklist", payload), entity_id: old.id, operation: "update", expected_revision: old.rev } : contentEvent("sop_stage43_checklist", payload);
          await ws.applyContentEvents([e], readContent2);
          evaluationSelected = revision2.id;
          evaluationTab = "weighted";
          page = "sop_evaluation";
          return "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u0421\u041E\u041F \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
        }), "primary", !editable);
        actor.disabled = !editable;
        panel.append(personInputField("\u041E\u0446\u0435\u043D\u0449\u0438\u043A (\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)", actor), table, progress, el("p", "\u041F\u0440\u0430\u0432\u043A\u0438 \u043E\u0446\u0435\u043D\u043A\u0438 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u044E\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0421\u041E\u041F, \u0435\u0433\u043E \u043F\u0430\u0441\u043F\u043E\u0440\u0442 \u0438\u043B\u0438 \u0441\u0442\u0430\u0442\u0443\u0441. \u0414\u043B\u044F \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u0435\u0447\u0430\u0442\u043D\u043E\u0433\u043E \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430 \u0441\u043A\u0430\u0447\u0430\u0439\u0442\u0435 \u043E\u0442\u0447\u0451\u0442 \u0437\u0434\u0435\u0441\u044C; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 XLSX Stage43 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u0442 \u043F\u0435\u0440\u0432\u043E\u043D\u0430\u0447\u0430\u043B\u044C\u043D\u0443\u044E \u043E\u0446\u0435\u043D\u043A\u0443.", "muted"), add(el("div", void 0, "row"), save2, btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0447\u0435\u043A-\u043B\u0438\u0441\u0442 XLSX", () => run(async () => {
          await stage43Xlsx(doc, revision2, source, current(), actor.selectedName);
          return "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 XLSX \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
        }, { save: false }))));
        appendHistory();
      } catch (e) {
        if (panel.isConnected) panel.replaceChildren(el("h2", "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0421\u041E\u041F"), el("p", e.message, "bad"));
      }
    })();
    return panel;
  }
  function evaluationDetail(doc, v, source, { registry: registry2 = false } = {}) {
    const root2 = el("div"), tabs = el("div", void 0, "library-tabs evaluation-tabs"), content = el("div", void 0, "evaluation-content"), panels = /* @__PURE__ */ new Map(), buttons = /* @__PURE__ */ new Map();
    function show2(kind) {
      if (registry2) evaluationTab = kind;
      if (!panels.has(kind)) {
        const body = kind === "weighted" ? stage43Panel(doc, v, source) : pane("\u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \xB7 20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432", evaluationHistory(v, source), ...!v.archived ? [evaluationForm(v, source)] : []);
        panels.set(kind, body);
        content.append(body);
      }
      for (const [k, body] of panels) body.hidden = k !== kind;
      for (const [k, b] of buttons) {
        b.classList.toggle("selected", k === kind);
        b.setAttribute("aria-pressed", String(k === kind));
      }
    }
    for (const [kind, name] of [["weighted", "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 (13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432)"], ["corporate", "\u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 (20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432)"]]) {
      const b = btn(name, () => show2(kind), "library-tab");
      buttons.set(kind, b);
      tabs.append(b);
    }
    root2.append(tabs, content);
    show2(registry2 ? evaluationTab : "weighted");
    return root2;
  }
  function evaluationRegistry() {
    const p = pane("\u0420\u0435\u0435\u0441\u0442\u0440 \u043E\u0446\u0435\u043D\u043E\u043A \u0421\u041E\u041F"), options = relatedRevisions(), v = options.find((x) => x.id === evaluationSelected);
    if (v) {
      const doc = { ...v, id: v.doc_id }, source = JSON.parse(v.payload_json).source;
      p.append(add(el("div", void 0, "row"), btn("\u041A \u0441\u043F\u0438\u0441\u043A\u0443 \u043E\u0446\u0435\u043D\u043E\u043A", () => {
        evaluationSelected = null;
        evaluationTab = "weighted";
        render();
      }), btn("\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0421\u041E\u041F", () => goDocument(doc.id, v.id))), el("h2", v.code + " \xB7 " + v.title + " \xB7 \u0432\u0435\u0440\u0441\u0438\u044F " + v.version_no), el("p", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F: " + refName("operation", v.operation_id) + " \xB7 " + (v.archived ? "\u0410\u0440\u0445\u0438\u0432" : revisionLabels[v.state] || v.state), "muted"), evaluationDetail(doc, v, source, { registry: true }));
      return p;
    }
    const search = fieldInput("evaluation_search", evaluationSearch, "search"), out = el("div");
    search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043A\u043E\u0434\u0443, \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E \u0438\u043B\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438";
    p.append(el("p", "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0443\u0436\u043D\u0443\u044E \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044E \u0421\u041E\u041F. \u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0438 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u0432\u0435\u0434\u0443\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.", "muted"), search, out);
    let generation2 = 0;
    function draw() {
      const epoch = ++generation2, q = search.value.trim().toLocaleLowerCase("ru-RU");
      evaluationSearch = search.value;
      const list2 = options.filter((x) => [x.code, x.title, refName("operation", x.operation_id)].some((s) => String(s || "").toLocaleLowerCase("ru-RU").includes(q))), entries = [];
      if (!list2.length) {
        out.replaceChildren(el("p", options.length ? "\u041D\u0435\u0442 \u0421\u041E\u041F \u043F\u043E \u0437\u0430\u0434\u0430\u043D\u043D\u043E\u043C\u0443 \u043F\u043E\u0438\u0441\u043A\u0443." : "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0421\u041E\u041F \u0432 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0435, \u0447\u0442\u043E\u0431\u044B \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u0442\u044C \u0435\u0433\u043E \u0432\u0435\u0440\u0441\u0438\u0438.", "muted"));
        return;
      }
      const t = tableOf(["\u0421\u041E\u041F", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", "\u0412\u0435\u0440\u0441\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441 \u0421\u041E\u041F", "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 (13)", "\u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 (20)", ""], list2.map((v2) => {
        const source = JSON.parse(v2.payload_json).source, cell = el("span", "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F\u2026", "muted");
        const latest2 = one(ws.working, "SELECT * FROM sop_evaluation WHERE revision_id=? AND source_sha256=? ORDER BY evaluated_on DESC,recorded_at DESC LIMIT 1", [v2.id, source.sha256]);
        const old = latest2 ? null : one(ws.working, "SELECT id FROM sop_evaluation WHERE revision_id=? LIMIT 1", [v2.id]);
        const result = latest2 ? evaluationResult(rows(ws.working, "SELECT value FROM sop_evaluation_response WHERE evaluation_id=?", [latest2.id])) : null;
        const corporate = latest2 ? result.yes + "/20 \xB7 " + (result.fraction * 100).toFixed(0) + "%" : old ? "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0435\u0436\u043D\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A" : "\u041D\u0435 \u043E\u0446\u0435\u043D\u0451\u043D";
        entries.push({ v: v2, source, cell });
        return [v2.code + " \xB7 " + v2.title, refName("operation", v2.operation_id), v2.version_no, v2.archived ? "\u0410\u0440\u0445\u0438\u0432" : revisionLabels[v2.state] || v2.state, cell, corporate, btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
          evaluationSelected = v2.id;
          evaluationTab = "weighted";
          render();
        }, "primary")];
      }));
      out.replaceChildren(t);
      void (async () => {
        for (const { v: v2, source, cell } of entries) {
          if (epoch !== generation2 || !out.isConnected) break;
          try {
            const saved = stage43Checks(ws.working, v2.id).find((x) => x.source_sha256 === source.sha256);
            const data = saved ? JSON.parse(saved.rows_json) : stage43Checklist(JSON.parse(await readContent2(source)).constructor);
            if (epoch !== generation2 || !cell.isConnected) break;
            if (!data.length) {
              cell.textContent = "\u041D\u0435\u0442 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430";
              continue;
            }
            const result = weightedResult(data);
            cell.textContent = (result.fraction * 100).toFixed(1) + "% \xB7 " + (result.seed ? "\u041F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u043E" : saved ? "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D" : "\u0418\u0437 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430");
          } catch (e) {
            cell.textContent = "\u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D";
            cell.className = "bad";
          }
        }
      })();
    }
    search.oninput = draw;
    draw();
    return p;
  }
  function sopEvaluationScreen(main) {
    const p = pane("\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F", el("p", "\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u043F\u0440\u0438\u0432\u0430\u0442\u043D\u044B\u0439 JSON \u0438\u0437 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F 4. \u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F \u2014 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0430 \u0438\u0437 20 \u043F\u0443\u043D\u043A\u0442\u043E\u0432, \u043D\u0435 \u0430\u0443\u0434\u0438\u0442 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 L1 \u0438 \u043D\u0435 13-\u043F\u0443\u043D\u043A\u0442\u043D\u044B\u0439 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442 Stage43.", "muted"));
    p.append(btn("\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 JSON", () => {
      const i = el("input");
      i.type = "file";
      i.accept = ".json";
      i.onchange = () => {
        if (!i.files?.[0]) return;
        run(async () => {
          invariant(i.files[0].size <= 128e3, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0444\u0430\u0439\u043B \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438");
          const m = validateChecklist(JSON.parse(await i.files[0].text()));
          if (!confirm(m.title + "\n20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432. \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438?")) return "\u0418\u043C\u043F\u043E\u0440\u0442 \u043E\u0442\u043C\u0435\u043D\u0451\u043D";
          await ws.applyContentEvents([contentEvent("checklist_version", m)]);
          return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0430, \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
        });
      };
      i.click();
    }, "primary", !!ws.conflicts.length));
    for (const m of sopMethods(ws.working)) {
      const data = JSON.parse(m.methodology_json), d = el("details");
      d.append(el("summary", "\u0412\u0435\u0440\u0441\u0438\u044F " + m.version_no + " \xB7 " + data.title + " \xB7 " + (m.state === "active" ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u0410\u0440\u0445\u0438\u0432")), el("p", "SHA-256 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430: " + data.source_sha256, "source-hash"), tableOf(["\u2116", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435"], sopCriteria(ws.working, m.id).map((q) => [q.position, q.question])));
      p.append(d);
    }
    const methods = el("details", void 0, "panel evaluation-methods");
    methods.append(el("summary", "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F"), p);
    main.append(evaluationRegistry(), methods);
  }
  function passportForm(c, revision2) {
    const form2 = el("form"), format = el("select");
    format.name = "print_format";
    for (const [v, n] of [["", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014"], ["portrait", "\u04103 \u043A\u043D\u0438\u0436\u043D\u044B\u0439 (9 \u0448\u0430\u0433\u043E\u0432)"], ["landscape", "\u04103 \u0430\u043B\u044C\u0431\u043E\u043C\u043D\u044B\u0439 (12 \u0448\u0430\u0433\u043E\u0432)"]]) {
      const o = el("option", n);
      o.value = v;
      format.append(o);
    }
    format.value = revision2.print_format || "";
    const changed = fieldInput("changed_on", revision2.changed_on || "", "date");
    changed.required = true;
    format.required = true;
    const save2 = el("button", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u0430\u0441\u043F\u043E\u0440\u0442", "primary");
    save2.type = "submit";
    save2.disabled = busy || !!ws.conflicts.length;
    form2.onsubmit = (e) => {
      e.preventDefault();
      run(async () => {
        await ws.applyContentEvents([libraryEvent(c, { command: "passport", revision_id: revision2.id, print_format: format.value, changed_on: changed.value })]);
        return "\u041F\u0430\u0441\u043F\u043E\u0440\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D: \u0441\u0440\u043E\u043A \u043F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440\u0430 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D \u043E\u0442 \u0434\u0430\u0442\u044B \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F.";
      });
    };
    form2.append(add(el("div", void 0, "formgrid"), inputField("\u0424\u043E\u0440\u043C\u0430\u0442 \u043F\u0435\u0447\u0430\u0442\u0438", format), inputField("\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0434\u0430\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", changed)), el("p", "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0438 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0431\u0435\u0440\u0443\u0442\u0441\u044F \u0438\u0437 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0430 \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0433\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043F\u0430\u0441\u043F\u043E\u0440\u0442\u0430.", "muted"), save2);
    return form2;
  }
  function sourcePassport(data) {
    const panel = el("div"), open = btn("\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u043F\u0430\u0441\u043F\u043E\u0440\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0430", async () => {
      open.disabled = true;
      try {
        const p = JSON.parse(await readContent2(data.source)), s = p.constructor, m = s.meta || {};
        panel.replaceChildren(tableOf(["\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442", "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435"], [["\u0424\u0438\u043B\u0438\u0430\u043B", m.branch], ["\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", m.department], ["\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E", m.workplace], ["\u0418\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u0438", m.executor], ["\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", m.operation], ["\u041D\u043E\u043C\u0435\u0440", m.sopNumber], ["\u0414\u0430\u0442\u0430", m.date], ["\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u044C / \u0421\u0418\u0417", m.safety], ["\u0418\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B", m.tools], ["\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B", m.material], ["\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u0433\u0440\u0443\u043F\u043F\u0430", (s.responsibles || []).join("; ")], ["\u0421\u043E\u0433\u043B\u0430\u0441\u0443\u044E\u0449\u0438\u0435", (s.agreedList || []).map((x) => [x.post, x.name].filter(Boolean).join(" ")).join("; ")], ["\u0423\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0439", [m.approverPost, m.approverName].filter(Boolean).join(" ")]]));
      } catch (e) {
        panel.append(el("p", e.message, "bad"));
        open.disabled = false;
      }
    });
    panel.append(open);
    return panel;
  }
  function materialsPanel(data) {
    const panel = el("div"), button = btn("\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0444\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438 \u0448\u0430\u0433\u043E\u0432", async () => {
      button.disabled = true;
      try {
        const p = JSON.parse(await readContent2(data.source));
        const grid = el("div", void 0, "material-grid");
        for (const [i, s] of p.constructor.steps.entries()) {
          const a = p.photoAssets[String(s.id)];
          if (!a) continue;
          const img = el("img");
          img.alt = "\u0412\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u0448\u0430\u0433\u0430 " + (i + 1);
          img.loading = "lazy";
          img.src = a.rendered || a.original;
          grid.append(add(el("figure"), img, el("figcaption", i + 1 + ". " + s.action)));
        }
        panel.replaceChildren(grid, el("p", "\u0412 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u043C JSON \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044B \u0438 \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0430.", "muted"));
      } catch (e) {
        panel.append(el("p", e.message, "bad"));
        button.disabled = false;
      }
    });
    panel.append(button);
    return panel;
  }
  function constructorScreen(main) {
    main.append(pane("\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0421\u041E\u041F", el("p", "\u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u044B\u0439 \u0421\u041E\u041F \u0438\u043B\u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0438\u0437 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430. \u0418\u043C\u043F\u043E\u0440\u0442 Excel \u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0432 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0435.", "muted"), btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0421\u041E\u041F", () => launchEditor(libraryContext("sop")), "primary", !!ws.conflicts.length), btn("\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u0421\u041E\u041F", () => navigate("sop"))));
    if (editorSession && editorSession.host.hidden) main.append(el("p", "\u041E\u0442\u043A\u0440\u044B\u0442\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0447\u0435\u0440\u0435\u0437 \u043A\u043D\u043E\u043F\u043A\u0443 \u043D\u0430 \u0432\u0435\u0440\u0445\u043D\u0435\u0439 \u043F\u0430\u043D\u0435\u043B\u0438.", "muted"));
  }
  function editableRevision(doc, rev) {
    return !doc.archived && (rev.state === "draft" || ["effective", "superseded", "withdrawn"].includes(rev.state) && !one(ws.working, "SELECT id FROM document_revision WHERE document_id=? AND state IN ('draft','review','approved')", [doc.id]));
  }
  function relatedRevisions() {
    return rows(ws.working, "SELECT r.*,d.id doc_id,d.code,d.title,d.archived,d.operation_id FROM document_revision r JOIN document d ON d.id=r.document_id WHERE d.kind='sop' ORDER BY d.code,r.version_no DESC");
  }
  function frvOriginPanel(revision2) {
    const origin = frvOriginSnapshot(ws.working, revision2.id), panel = el("div");
    if (!origin) return panel;
    const out = el("div"), open = btn("\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0437\u0430\u043C\u0435\u0440\u044B \u0424\u0420\u0412", async () => {
      open.disabled = true;
      try {
        const raw = JSON.parse(await readContent2(origin.source)), s = frvSummary(raw);
        out.replaceChildren(
          el("p", "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0435 \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435: " + (raw.study.studyId || origin.title) + " \xB7 " + (raw.study.operationId || "") + " \xB7 " + (origin.current ? "\u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A" : "\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0430 \u043C\u043E\u043C\u0435\u043D\u0442 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0438 \u0432 \u0421\u041E\u041F"), "muted"),
          tableOf(["\u0426\u0438\u043A\u043B", "\u0413\u0440\u0443\u043F\u043F\u0430", "\u0418\u0437\u043C\u0435\u0440\u0435\u043D\u043E, \u0441\u0435\u043A", "\u041F\u043E\u043B\u043D\u043E\u0442\u0430"], s.cycles.map((c) => [c.index, c.phase, c.seconds, c.complete ? "\u041F\u043E\u043B\u043D\u044B\u0439" : "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0439"])),
          el("p", "\u0421\u0442\u0440\u043E\u043A \u0431\u0435\u0437 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F / \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F: " + s.missing, "muted")
        );
      } catch (e) {
        out.replaceChildren(el("p", e.message, "bad"));
        open.disabled = false;
      }
    });
    panel.append(el("p", "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u0421\u041E\u041F: " + origin.title + " \xB7 " + (origin.current ? "\u0422\u0435\u043A\u0443\u0449\u0438\u0435 \u0437\u0430\u043C\u0435\u0440\u044B" : "\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0437\u0430\u043C\u0435\u0440\u044B; \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u043B\u043E\u0441\u044C \u043F\u043E\u0441\u043B\u0435 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u0421\u041E\u041F"), "muted"), el("p", "SHA-256 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0437\u0430\u043C\u0435\u0440\u043E\u0432: " + origin.source.sha256, "source-hash"), add(el("div", void 0, "row"), open, btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0437\u0430\u043C\u0435\u0440\u044B JSON", () => run(async () => {
      downloadRaw("FRV-\u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A-" + origin.source.sha256.slice(0, 12) + ".json", await readContent2(origin.source));
      return "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0437\u0430\u043C\u0435\u0440\u044B \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u044B";
    }, { save: false })), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0442\u0435\u043A\u0443\u0449\u0435\u0435 \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0424\u0420\u0412", () => goResearch(origin.study_id))), out);
    return panel;
  }
  function relatedPanel(doc, rev, kind) {
    const data = JSON.parse(rev.payload_json), c = libraryContext("sop", doc.id, rev.id), out = el("div"), open = btn(kind === "frv" ? "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F" : "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043B\u0430\u043D \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 TWI", async () => {
      open.disabled = true;
      try {
        const raw = JSON.parse(await readContent2(data.source)), source = raw.constructor;
        if (kind === "frv") {
          const x = linkedFrv(source), t = x.totals, n = (v) => v === null ? "\u2014" : Number(v.toFixed(2)).toLocaleString("ru-RU");
          out.replaceChildren(
            el("p", "\u0420\u0430\u0441\u0447\u0451\u0442 \u043F\u043E \u0448\u0430\u0433\u0430\u043C \u0421\u041E\u041F, \u0432\u0435\u0440\u0441\u0438\u044F " + rev.version_no + ". \u042D\u0442\u043E \u043D\u0435 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0437\u0430\u043C\u0435\u0440\u044B.", "muted"),
            tableOf(["\u0412\u0440\u0435\u043C\u044F, \u0441\u0435\u043A", "\u0412\u0414\u0426, \u0441\u0435\u043A", "\u041C1, \u0441\u0435\u043A", "\u041C2, \u0441\u0435\u043A", "\u041D\u0435 \u0440\u0430\u0441\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u043E, \u0441\u0435\u043A", "\u041F\u0435\u0440\u0435\u043C\u0435\u0449\u0435\u043D\u0438\u0435, \u043C"], [[n(t.seconds), n(t.vdc), n(t.m1), n(t.m2), n(t.unclassified), n(t.distance)]]),
            ...x.invalid ? [el("p", "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0445 \u0441\u0442\u0440\u043E\u043A: " + x.invalid + ". \u0418\u0445 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043D\u0435 \u0432\u043A\u043B\u044E\u0447\u0435\u043D\u044B \u0432 \u0441\u0443\u043C\u043C\u0443.", "bad")] : [],
            tableOf(["\u2116", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435", "\u041D\u0430\u0447\u0430\u043B\u043E, \u0441\u0435\u043A", "\u0412\u0440\u0435\u043C\u044F, \u0441\u0435\u043A", "\u0412\u0414\u0426", "\u041C1", "\u041C2", "\u041D\u0435 \u0440\u0430\u0441\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u043E", "\u041F\u0435\u0440\u0435\u043C\u0435\u0449\u0435\u043D\u0438\u0435, \u043C", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], x.rows.map((q) => [q.position, q.action, n(q.start), n(q.seconds), n(q.vdc), n(q.m1), n(q.m2), n(q.unclassified), n(q.distance), q.valid ? q.comment : "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F: " + q.comment])),
            el("p", "\u041D\u0430\u0431\u043B\u044E\u0434\u0430\u043B\u0438: " + (x.meta.observers || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"), "muted")
          );
          out.append(frvOriginPanel(rev));
        } else {
          const x = linkedTwi(source);
          out.replaceChildren(el("p", "\u0421\u0442\u0430\u0442\u0443\u0441: " + x.status + " \xB7 " + x.filled + " \u0438\u0437 15 \u043F\u043E\u043B\u0435\u0439. \u041F\u043B\u0430\u043D \u0441\u0432\u044F\u0437\u0430\u043D \u0441 \u0432\u0435\u0440\u0441\u0438\u0435\u0439 " + rev.version_no + " \u0438 \u043D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\u043C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F.", x.outdated ? "warn" : "muted"));
          if (x.exists) out.append(el("p", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440: " + (x.trainer || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") + " \xB7 \u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439: " + (x.trainee || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D"), "muted"), tableOf(["\u0420\u0430\u0437\u0434\u0435\u043B", "\u041F\u043E\u043B\u0435", "\u0421\u043E\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u0435"], x.fields.map((q) => [{ prepare: "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430", present: "\u041F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0440\u0430\u0431\u043E\u0442\u044B", tryOut: "\u041F\u0440\u043E\u0431\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435", followUp: "\u0421\u043E\u043F\u0440\u043E\u0432\u043E\u0436\u0434\u0435\u043D\u0438\u0435" }[q.section], q.label, q.value || "\u2014"])));
          else out.append(el("p", "\u041F\u043B\u0430\u043D \u0435\u0449\u0451 \u043D\u0435 \u0441\u043E\u0437\u0434\u0430\u043D. \u0421\u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0439\u0442\u0435 \u0435\u0433\u043E \u0438\u0437 \u0448\u0430\u0433\u043E\u0432 \u0421\u041E\u041F \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435.", "muted"));
        }
      } catch (e) {
        out.replaceChildren(el("p", e.message, "bad"));
        open.disabled = false;
      }
    });
    const buttons = add(el("div", void 0, "row"), open, btn("\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0421\u041E\u041F", () => goDocument(doc.id, rev.id)));
    if (kind === "twi" && rev.state === "effective" && !doc.archived) buttons.append(btn("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => goTraining("twi", { mode: "new", revisionId: rev.id }), "primary", !!ws.conflicts.length));
    if (editableRevision(doc, rev)) buttons.append(btn(rev.state === "draft" ? kind === "frv" ? "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F" : "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u043B\u0430\u043D TWI" : "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044E \u0421\u041E\u041F", () => openRelated(c, kind), "primary", !!ws.conflicts.length));
    return add(el("div"), buttons, out);
  }
  function linkedRegistry(main, kind) {
    const filter = fieldInput("linked_search", "", "search");
    filter.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043A\u043E\u0434\u0443, \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E, \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438";
    const out = el("div"), info = el("p", kind === "frv" ? "\u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F \u2014 \u0440\u0430\u0441\u0447\u0451\u0442 \u043F\u043E \u0448\u0430\u0433\u0430\u043C, \u043D\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0439." : "\u041F\u043B\u0430\u043D\u044B \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u044B \u043A \u0442\u043E\u0447\u043D\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0421\u041E\u041F. \u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u043F\u043B\u0430\u043D \u043C\u043E\u0436\u043D\u043E \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438\u0437 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430.", "muted");
    main.append(pane(kind === "frv" ? "\u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F" : "\u0420\u0435\u0435\u0441\u0442\u0440 \u043F\u043B\u0430\u043D\u043E\u0432 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 TWI", info, filter, out));
    let drawGeneration = 0;
    function draw() {
      const epoch = ++drawGeneration, q = filter.value.trim().toLowerCase(), data = relatedRevisions().filter((v) => [v.code, v.title, refName("operation", v.operation_id)].some((x) => String(x || "").toLowerCase().includes(q)));
      if (!data.length) {
        out.replaceChildren(el("p", "\u041D\u0435\u0442 \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0445 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0439 \u0421\u041E\u041F.", "muted"));
        return;
      }
      const body = el("div"), entries = [];
      const t = tableOf(["\u0421\u041E\u041F", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", "\u0412\u0435\u0440\u0441\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441 \u0421\u041E\u041F", kind === "frv" ? "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A" : "\u041F\u043B\u0430\u043D", ""], data.map((v) => {
        const cell = el("span", kind === "frv" ? "\u0428\u0430\u0433\u0438 \u0421\u041E\u041F" : "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F\u2026", "muted");
        entries.push({ v, cell });
        return [v.code + " \xB7 " + v.title, refName("operation", v.operation_id), v.version_no, v.archived ? "\u0410\u0440\u0445\u0438\u0432" : revisionLabels[v.state] || v.state, cell, btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
          body.replaceChildren(pane(v.code + " \xB7 " + v.title + " \xB7 v" + v.version_no, relatedPanel({ ...v, id: v.doc_id }, v, kind)));
        }, "primary")];
      }));
      out.replaceChildren(t, body);
      if (kind === "twi") void (async () => {
        for (const { v, cell } of entries) {
          if (epoch !== drawGeneration || !out.isConnected) break;
          try {
            const raw = JSON.parse(await readContent2(JSON.parse(v.payload_json).source));
            cell.textContent = linkedTwi(raw.constructor).status;
          } catch (e) {
            cell.textContent = "\u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D";
            cell.className = "bad";
          }
        }
      })();
    }
    filter.oninput = draw;
    draw();
  }
  function twiPlansScreen(main) {
    linkedRegistry(main, "twi");
  }
  function frvAnalysisPanel(v, data) {
    const panel = el("div"), button = btn("\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F \u0438 \u0430\u043D\u0430\u043B\u0438\u0437", async () => {
      button.disabled = true;
      try {
        const raw = JSON.parse(await readContent2(data.source)), s = frvSummary(raw), n = (x) => x === null ? "\u2014" : Number(x.toFixed(2)).toLocaleString("ru-RU");
        panel.replaceChildren(tableOf(["\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F", "\u0421\u0435\u043A\u0443\u043D\u0434\u044B", "\u041C\u0438\u043D\u0443\u0442\u044B"], Object.entries(s.totals).map(([k, x]) => [{ VA: "\u0412\u0414\u0426", NVA_Necessary: "\u041C2", NVA_Waste: "\u041C1", WAIT: "\u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435", BREAK: "\u041F\u0435\u0440\u0435\u0440\u044B\u0432", OTHER: "\u041D\u0435 \u043A\u043B\u0430\u0441\u0441\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043E" }[k], n(x), n(x / 60)])), tableOf(["\u0413\u0440\u0443\u043F\u043F\u0430", "\u041F\u043E\u043B\u043D\u044B\u0445 \u0446\u0438\u043A\u043B\u043E\u0432", "\u0421\u0440\u0435\u0434\u043D\u0435\u0435, \u0441\u0435\u043A"], [["\u0414\u043E", s.baselineCount, n(s.before)], ["\u041F\u043E\u0441\u043B\u0435", s.improvedCount, n(s.after)]]), el("p", "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0445 \u0441\u0442\u0440\u043E\u043A: " + s.missing + " \xB7 " + (s.comparable ? "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435: \u0440\u0430\u0437\u043D\u0438\u0446\u0430 " + n(s.delta) + " \u0441\u0435\u043A (" + n(s.percent) + "%)" : "\u042D\u0444\u0444\u0435\u043A\u0442 \u043D\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D: \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u0438\u043C\u043E\u0441\u0442\u044C \u0438 \u043F\u043E\u043B\u043D\u044B\u0435 \u0446\u0438\u043A\u043B\u044B \u0434\u043E/\u043F\u043E\u0441\u043B\u0435."), "muted"), tableOf(["\u0426\u0438\u043A\u043B", "\u0413\u0440\u0443\u043F\u043F\u0430", "\u0418\u0437\u043C\u0435\u0440\u0435\u043D\u043E, \u0441\u0435\u043A", "\u041F\u043E\u043B\u043D\u043E\u0442\u0430"], s.cycles.map((x) => [x.index, x.phase, n(x.seconds), x.complete ? "\u041F\u043E\u043B\u043D\u044B\u0439" : "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0439"])));
      } catch (e) {
        panel.append(el("p", e.message, "bad"));
        button.disabled = false;
      }
    });
    const transfer = btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442 \u0421\u041E\u041F \u0438\u0437 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0433\u043E \u0424\u0420\u0412", async () => {
      if (busy) return;
      transfer.disabled = true;
      try {
        invariant(!libraryDraft, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440");
        const d = await draftFromFrv(await readContent2(data.source));
        launchEditor({ ...libraryContext("sop"), operation_id: v.operation_id, seedText: d.text, origin: { study_id: v.id, source_sha256: data.source.sha256 } });
      } catch (e) {
        message(e.message, true);
      } finally {
        transfer.disabled = false;
      }
    }, "primary", !!ws.conflicts.length);
    return add(el("div"), panel, add(el("div", void 0, "row"), button, ...v.state !== "archived" ? [transfer] : []));
  }
  function libraryContext(kind, id = null, revisionId = null) {
    const row = id ? one(ws.working, "SELECT * FROM " + (kind === "sop" ? "document" : "frv_study") + " WHERE id=?", [id]) : null;
    const revision2 = kind === "sop" && revisionId ? one(ws.working, "SELECT * FROM document_revision WHERE id=? AND document_id=?", [revisionId, id]) : null;
    invariant(!id || row, "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430");
    invariant(!revisionId || revision2, "\u0412\u0435\u0440\u0441\u0438\u044F \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430");
    return { kind, id, revisionId, expected: row?.rev || 0, database: meta(ws.base, "database_id"), title: row?.title || "", code: row?.code || "", operation_id: row?.operation_id || null, observed_at: row?.observed_at || "", command: !id ? "create" : kind === "frv" ? "save" : revision2?.state === "draft" ? "save" : "revise", source: revision2 ? JSON.parse(revision2.payload_json).source : kind === "frv" && row ? JSON.parse(row.context_json).source : null };
  }
  function editorPeople() {
    return directoryPeople(ws.working, today());
  }
  function assertContext(c) {
    invariant(c.database === meta(ws.base, "database_id"), "\u041E\u0442\u043A\u0440\u044B\u0442\u0430 \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u043C\u043E\u0436\u043D\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.");
    if (c.id) {
      const row = one(ws.working, "SELECT * FROM " + (c.kind === "sop" ? "document" : "frv_study") + " WHERE id=?", [c.id]);
      invariant(row && row.rev === c.expected, "\u0417\u0430\u043F\u0438\u0441\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430 \u043F\u043E\u0441\u043B\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F. \u041D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u0439\u0442\u0435 \u0435\u0451; \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 JSON \u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E.");
    }
  }
  function libraryEvent(c, payload, operation2 = c.id ? "update" : "create") {
    assertContext(c);
    return { id: uuid(), entity_type: c.kind === "sop" ? "document" : "frv_study", entity_id: c.id || uuid(), operation: operation2, expected_revision: c.expected, payload, occurred_at: (/* @__PURE__ */ new Date()).toISOString() };
  }
  async function chooseLibraryFile(kind, ctx = libraryContext(kind)) {
    if (libraryDraft) {
      message("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.", true);
      return;
    }
    const i = el("input");
    i.type = "file";
    i.accept = ".json,application/json";
    i.onchange = () => {
      const file = i.files?.[0];
      if (file) run(async () => {
        invariant(file.size <= MAX_CONTENT, "JSON \u0434\u043E 30 \u041C\u0411");
        const text4 = await file.text(), inspected = await inspectSource(text4, kind);
        assertContext(ctx);
        libraryDraft = { ctx, text: text4, ...inspected, editor: false };
        page = kind === "sop" ? "sop" : "frv";
        return "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D. \u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0441\u0432\u044F\u0437\u0438 \u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0430\u043F\u0438\u0441\u044C.";
      }, { save: false });
    };
    i.click();
  }
  function editorStatus(s, text4, bad = false) {
    if (editorSession !== s) return;
    s.note.textContent = text4;
    s.note.classList.toggle("bad", bad);
  }
  function editorRoute(c) {
    return c.kind === "frv" || c.editorTab === "frv" ? "frv" : c.editorTab === "twi" ? "twi_plans" : "sop_constructor";
  }
  function showEditor(s) {
    if (editorSession !== s) return;
    page = editorRoute(s.ctx);
    s.host.hidden = false;
    document.body.classList.add("editor-active");
    render();
    s.close.focus();
    if (s.loaded) s.frame.contentWindow.postMessage({ protocol: "lean-editor-v1", session: s.session, type: "directory", people: editorPeople(), theme: theme ? "dark" : "light" }, "*");
  }
  function hideEditor(s) {
    if (editorSession !== s) return;
    s.host.hidden = true;
    document.body.classList.remove("editor-active");
    root.querySelector("main")?.removeAttribute("inert");
  }
  function goDocument(id, revisionId = null) {
    navigate("sop");
    librarySelected = id;
    libraryRevisionSelected = revisionId;
    render();
  }
  function goResearch(id) {
    navigate("frv");
    librarySelected = id;
    render();
  }
  function openRelated(c, tab) {
    launchEditor({ ...c, editorTab: tab });
  }
  function disposeEditor(s, confirmed = false) {
    if (editorSession !== s) return false;
    if (!confirmed && !window.confirm("\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430? \u041D\u0435\u043F\u0435\u0440\u0435\u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043C\u043E\u0433\u0443\u0442 \u0431\u044B\u0442\u044C \u043F\u043E\u0442\u0435\u0440\u044F\u043D\u044B. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043A\u0430\u0447\u0430\u0439\u0442\u0435 JSON \u0438\u043B\u0438 \u043F\u0435\u0440\u0435\u0434\u0430\u0439\u0442\u0435 \u0432 Lean Center.")) return false;
    clearTimeout(s.timeout);
    hideEditor(s);
    s.host.remove();
    editorSession = null;
    return true;
  }
  function launchEditor(ctx) {
    if (libraryDraft) {
      message("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.", true);
      return;
    }
    if (editorSession) {
      const old = editorSession.ctx;
      if (old.kind === ctx.kind && old.id === ctx.id && old.revisionId === ctx.revisionId && old.editorTab === ctx.editorTab && !ctx.seedText) {
        showEditor(editorSession);
        message("\u0412\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435 \u043A \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0439 \u0440\u0430\u0431\u043E\u0447\u0435\u0439 \u043A\u043E\u043F\u0438\u0438 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430.");
        return;
      }
      if (!disposeEditor(editorSession)) return;
    }
    try {
      assertContext(ctx);
      const template = window.LC_EDITOR_HTML, marker = "window.LC_EDITOR_CONTEXT=null;/* LC_EMBED_CONTEXT */";
      invariant(typeof template === "string" && template.split(marker).length === 2, "\u0424\u0430\u0439\u043B \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D. \u0420\u0430\u0441\u043F\u0430\u043A\u0443\u0439\u0442\u0435 \u0432\u0435\u0441\u044C ZIP: index.html \u0438 \u043F\u0430\u043F\u043A\u0430 versions \u0434\u043E\u043B\u0436\u043D\u044B \u043D\u0430\u0445\u043E\u0434\u0438\u0442\u044C\u0441\u044F \u0440\u044F\u0434\u043E\u043C.");
      const session = uuid(), host = el("section", void 0, "editor-host"), bar = el("div", void 0, "editor-host-bar"), frame = el("iframe"), note = el("span", "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430\u2026", "editor-host-note");
      host.id = "lc-editor-host";
      host.setAttribute("aria-label", "\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430");
      host.setAttribute("role", "region");
      frame.id = "lc-editor-frame";
      frame.title = ctx.kind === "frv" ? "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0424\u0420\u0412" : ctx.editorTab === "twi" ? "\u041F\u043B\u0430\u043D \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 TWI" : ctx.editorTab === "frv" ? "\u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F" : "\u041A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 \u0421\u041E\u041F";
      const s = { session, host, frame, note, ctx, loading: false, loaded: false, timeout: null, close: null };
      const back = btn("\u041A \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0435", () => {
        hideEditor(s);
        navigate(s.ctx.kind === "frv" ? "frv" : "sop");
      });
      const close = btn("\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440", () => {
        if (disposeEditor(s)) {
          message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0437\u0430\u043A\u0440\u044B\u0442. \u0411\u0430\u0437\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430.");
          navigate(s.ctx.kind === "frv" ? "frv" : "sop");
        }
      });
      s.close = close;
      bar.append(el("strong", frame.title), note, back, close);
      host.append(bar, frame);
      editorSession = s;
      document.body.append(host);
      showEditor(s);
      s.timeout = setTimeout(() => {
        if (!s.loaded) {
          editorStatus(s, "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0443. \u0417\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0435\u0433\u043E \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0444\u0430\u0439\u043B\u043E\u0432 \u0438 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0430.", true);
          message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B \u0433\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C. \u0414\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u044B.", true);
        }
      }, 3e4);
      frame.srcdoc = template.replace(marker, () => "window.LC_EDITOR_CONTEXT=" + JSON.stringify({ session, kind: ctx.kind, tab: ctx.editorTab || null }) + ";/* LC_EMBED_CONTEXT */");
      message("\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430. \u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0433\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u0438.");
    } catch (e) {
      if (editorSession) disposeEditor(editorSession, true);
      message(e.message, true);
    }
  }
  window.addEventListener("message", async (e) => {
    const s = editorSession, m = e.data;
    if (!s || e.source !== s.frame.contentWindow || m?.protocol !== "lean-editor-v1" || m.session !== s.session) return;
    const reply = (message2) => {
      if (editorSession === s) s.frame.contentWindow?.postMessage({ protocol: "lean-editor-v1", session: s.session, type: "result", message: message2 }, "*");
    };
    if (m.type === "ready" && !s.loading && !s.loaded) {
      s.loading = true;
      try {
        assertContext(s.ctx);
        const text4 = s.ctx.seedText ?? (s.ctx.source ? await readContent2(s.ctx.source) : null);
        if (editorSession !== s) return;
        const op = s.ctx.operation_id ? one(ws.working, "SELECT * FROM operation WHERE id=?", [s.ctx.operation_id]) : null;
        s.frame.contentWindow.postMessage({ protocol: "lean-editor-v1", session: s.session, type: "load", text: text4, defaults: { operation: op?.name || "", unit: op ? refName("org_unit", op.unit_id) : "", people: editorPeople(), theme: theme ? "dark" : "light" } }, "*");
        editorStatus(s, "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u0439 \u043A\u043E\u043F\u0438\u0438\u2026");
      } catch (err) {
        clearTimeout(s.timeout);
        reply(err.message);
        editorStatus(s, err.message, true);
        message(err.message, true);
      } finally {
        s.loading = false;
      }
    } else if (m.type === "loaded") {
      clearTimeout(s.timeout);
      s.loaded = true;
      editorStatus(s, "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0433\u043E\u0442\u043E\u0432");
      message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0433\u043E\u0442\u043E\u0432. \u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u0432 \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0443 \u2014 \u043F\u043E\u0441\u043B\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F.");
    } else if (m.type === "source") {
      if (!s.loaded) {
        reply("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0435\u0449\u0451 \u043D\u0435 \u0433\u043E\u0442\u043E\u0432.");
        return;
      }
      if (busy) {
        reply("\u0426\u0435\u043D\u0442\u0440 \u0437\u0430\u043D\u044F\u0442. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0443 \u0438\u043B\u0438 \u0441\u043A\u0430\u0447\u0430\u0439\u0442\u0435 JSON.");
        return;
      }
      if (m.kind !== s.ctx.kind || typeof m.text !== "string" || m.text.length > MAX_CONTENT) {
        reply("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B");
        return;
      }
      if (libraryDraft) {
        reply("\u0412 \u0446\u0435\u043D\u0442\u0440\u0435 \u0443\u0436\u0435 \u0435\u0441\u0442\u044C \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B. \u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0435\u0433\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.");
        return;
      }
      await run(async () => {
        assertContext(s.ctx);
        const inspected = await inspectSource(m.text, s.ctx.kind);
        invariant(editorSession === s, "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0437\u0430\u043A\u0440\u044B\u0442");
        libraryDraft = { ctx: s.ctx, text: m.text, ...inspected, editor: true, origin: s.ctx.origin || null };
        page = s.ctx.kind === "sop" ? "sop" : "frv";
        return "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043B\u0435\u043D \u043A \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044E. \u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0430\u043F\u0438\u0441\u044C.";
      }, { save: false });
      if (error) {
        reply(status);
        showEditor(s);
      } else {
        reply("\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043B\u0435\u043D \u043A \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044E \u0432 Lean Center.");
        hideEditor(s);
        render();
      }
    } else if (m.type === "error") {
      clearTimeout(s.timeout);
      editorStatus(s, "\u041E\u0448\u0438\u0431\u043A\u0430: " + String(m.message || "\u043E\u0448\u0438\u0431\u043A\u0430"), true);
      message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440: " + String(m.message || "\u043E\u0448\u0438\u0431\u043A\u0430"), true);
    }
  });
  window.addEventListener("beforeunload", (e) => {
    if (editorSession || libraryDraft) {
      e.preventDefault();
      e.returnValue = "";
    }
  });
  function sourceSummary(d) {
    const p = d.projection;
    return d.source.kind === "sop" ? "\u0428\u0430\u0433\u043E\u0432: " + p.steps.length + " \xB7 \u0424\u043E\u0442\u043E: " + p.photos + " \xB7 TWI: " + (p.twi ? "\u0435\u0441\u0442\u044C" : "\u043D\u0435\u0442") : "\u0426\u0438\u043A\u043B\u043E\u0432: " + p.cycles + " \xB7 \u041F\u043E\u043B\u043D\u044B\u0445: " + p.complete + " \xB7 \u0418\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0439: " + p.measurements.length + " \xB7 \u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F/\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F: " + p.unmeasured;
  }
  function libraryPreview(main, kind) {
    if (!libraryDraft || libraryDraft.ctx.kind !== kind) return;
    const d = libraryDraft, c = d.ctx, p = d.projection, form2 = el("form");
    const code = fieldInput("library_code", c.code || (p.number && p.number !== "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A" ? p.number : ""));
    code.required = kind === "sop" && !c.id;
    const title = fieldInput("library_title", c.title || p.title);
    title.required = true;
    title.maxLength = 500;
    const op = selectRef("operation", "library_operation", c.operation_id);
    const observed = fieldInput("library_observed", c.observed_at, "date");
    observed.required = kind === "frv";
    const grid = el("div", void 0, "formgrid");
    if (kind === "sop") {
      if (c.id) grid.append(el("p", "\u041A\u043E\u0434 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430: " + c.code, "muted"));
      else grid.append(inputField("\u041A\u043E\u0434 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0432 Lean Center", code));
    }
    grid.append(inputField("\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", title), inputField("\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F (\u0434\u043B\u044F \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u0430)", op));
    if (kind === "frv") grid.append(inputField("\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0434\u0430\u0442\u0430 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F", observed));
    const confirm2 = el("button", c.command === "create" ? "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u043E\u0432\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A" : c.command === "revise" ? "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E" : "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430", "primary");
    confirm2.type = "submit";
    confirm2.disabled = busy || !!ws.conflicts.length;
    form2.onsubmit = (e) => {
      e.preventDefault();
      run(async () => {
        assertContext(c);
        const payload = { command: c.command, title: title.value.trim(), operation_id: op.value || null, source: d.source, projection: p };
        if (kind === "sop") {
          if (c.command === "create") payload.code = code.value.trim();
          else payload.revision_id = c.command === "save" ? c.revisionId : null;
        } else payload.observed_at = observed.value;
        await contentStore.put(d.source, d.text);
        const ev = libraryEvent(c, payload);
        const events = [ev];
        if (d.origin) {
          invariant(c.command === "create", "\u041F\u0440\u043E\u0435\u043A\u0442 \u0438\u0437 \u0424\u0420\u0412 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043D\u043E\u0432\u044B\u043C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u043C");
          events.push({ id: uuid(), entity_type: "document", entity_id: ev.entity_id, operation: "update", expected_revision: 1, payload: { command: "origin", revision_id: ev.id, ...d.origin }, occurred_at: (/* @__PURE__ */ new Date()).toISOString() });
        }
        await ws.applyContentEvents(events, readContent2);
        await persist();
        libraryDraft = null;
        librarySelected = ev.entity_id;
        if (kind === "sop") libraryRevisionSelected = c.command === "save" ? c.revisionId : ev.id;
        if (d.editor && editorSession) disposeEditor(editorSession, true);
        return "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043E\u0431\u0449\u0435\u0439 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
      }, { save: false });
    };
    main.append(pane("\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B", el("p", sourceSummary(d)), el("p", "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0442\u0430\u0442\u0443\u0441 Stage43: " + (p.legacy_status || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") + " \xB7 \u041D\u043E\u043C\u0435\u0440: " + (p.number || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") + " \xB7 " + Math.ceil(d.source.size / 1024) + " \u041A\u0411", "muted"), el("p", "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0442\u0430\u0442\u0443\u0441 \u043D\u0435 \u0441\u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044F \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435\u043C \u0432 Lean Center. \u0421\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u0438 \u0444\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E \u043F\u043E SHA-256.", "muted"), add(form2, grid, add(el("div", void 0, "row"), confirm2, btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON", () => downloadRaw("Stage43-" + kind + ".json", d.text)), btn("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440", () => {
      if (window.confirm("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0438\u043C\u043F\u043E\u0440\u0442? \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u0441\u044F.")) {
        libraryDraft = null;
        render();
      }
    })))));
  }
  function libraryAction(c, command, label) {
    const panel = el("div", void 0, "library-action"), actor = selectRef("person", "decision_actor", null), note = fieldInput("decision_note");
    note.maxLength = 2e3;
    const ok = btn(label, () => run(async () => {
      const payload = c.kind === "sop" ? { command, revision_id: c.revisionId, actor_id: actor.value || null, note: note.value } : { command, actor_id: actor.value || null, note: note.value };
      await ws.applyContentEvents([libraryEvent(c, payload)], readContent2);
      return "\u0421\u0442\u0430\u0442\u0443\u0441 \u0438\u0437\u043C\u0435\u043D\u0451\u043D. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
    }), "primary", !!ws.conflicts.length);
    panel.append(inputField("\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", actor), inputField("\u041F\u0440\u0438\u043C\u0435\u0447\u0430\u043D\u0438\u0435 / \u043F\u0440\u0438\u0447\u0438\u043D\u0430", note), ok);
    return panel;
  }
  function rawButton(source, name) {
    return btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C JSON", () => run(async () => {
      downloadRaw(name, await readContent2(source));
      return "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false }));
  }
  function sourceDetails(data) {
    const details = el("details"), summary = el("summary", "\u0421\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E\u0431 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0435"), p = data.projection;
    details.append(summary, el("p", sourceSummary(data), "muted"), el("p", "SHA-256: " + data.source.sha256, "source-hash"), el("p", "Stage43: " + (p.legacy_id || "\u0431\u0435\u0437 ID") + " / " + (p.legacy_version || "\u2014") + " / " + (p.legacy_status || "\u2014"), "muted"));
    return details;
  }
  function libraryHeader(main, kind) {
    const search = fieldInput("library_search", query, "search");
    search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E, \u043A\u043E\u0434\u0443, \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438";
    const filter = el("select");
    filter.name = "library_filter";
    for (const [v, n] of [["all", "\u0412\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"], ["active", "\u0411\u0435\u0437 \u0430\u0440\u0445\u0438\u0432\u0430"], ["archive", "\u0410\u0440\u0445\u0438\u0432"], ...kind === "sop" ? [["overdue", "\u041F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D \u043F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440"], ["missing_passport", "\u041D\u0435\u0442 \u043F\u0430\u0441\u043F\u043E\u0440\u0442\u0430"]] : []]) {
      const o = el("option", n);
      o.value = v;
      filter.append(o);
    }
    filter.value = libraryFilter;
    const controls = add(el("div", void 0, "row"), btn(kind === "sop" ? "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0421\u041E\u041F \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435" : "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0424\u0420\u0412", () => launchEditor(libraryContext(kind)), "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 JSON Stage43", () => chooseLibraryFile(kind), "", !!ws.conflicts.length), search, filter);
    const p = pane(kind === "sop" ? "\u041E\u0431\u0449\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0421\u041E\u041F" : "\u041E\u0431\u0449\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0424\u0420\u0412", el("p", "\u0421\u043E\u0437\u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430\u0445. \u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0438, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B \u0438 \u0432\u0435\u0440\u0441\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u0432 \u043E\u0431\u0449\u0435\u0439 \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0435. \u041F\u0435\u0447\u0430\u0442\u043D\u044B\u0435 \u0444\u043E\u0440\u043C\u044B \u0438 \u0444\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B. \u0418\u0418 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u043F\u0440\u043E\u043A\u0441\u0438 Yandex Cloud \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E \u043A\u043E\u043C\u0430\u043D\u0434\u0435; \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0431\u0435\u0437 \u0441\u0435\u0442\u0438.", "muted"), controls);
    main.append(p);
    libraryPreview(main, kind);
    const out = el("div", void 0, "stack");
    main.append(out);
    return { search, filter, out };
  }
  function libraryScreen(main, kind) {
    const { search, filter, out } = libraryHeader(main, kind);
    function draw() {
      out.replaceChildren();
      const items = rows(ws.working, kind === "sop" ? "SELECT * FROM document ORDER BY code" : "SELECT * FROM frv_study ORDER BY observed_at DESC,title");
      const filtered = items.filter((v) => {
        const a = kind === "sop" ? !!v.archived : v.state === "archived";
        let visible = libraryFilter === "all" || libraryFilter === "active" && !a || libraryFilter === "archive" && a;
        if (kind === "sop" && !a && libraryFilter === "overdue") visible = !!one(ws.working, "SELECT id FROM document_revision WHERE document_id=? AND state='effective' AND review_due<?", [v.id, today()]);
        if (kind === "sop" && !a && libraryFilter === "missing_passport") visible = !!one(ws.working, "SELECT id FROM document_revision WHERE document_id=? AND state='draft' AND (print_format IS NULL OR workplace_id IS NULL)", [v.id]);
        return visible && [v.title, v.code, refName("operation", v.operation_id)].some((x) => String(x || "").toLowerCase().includes(query.toLowerCase()));
      });
      if (!filtered.length) {
        out.append(pane("\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439", el("p", "\u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435 \u0438\u043B\u0438 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C\u044B\u0439 JSON Stage43.", "muted")));
        return;
      }
      if (!filtered.some((x) => x.id === librarySelected)) {
        librarySelected = null;
        libraryRevisionSelected = null;
      }
      if (!librarySelected) {
        out.append(pane(kind === "sop" ? "\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432" : "\u0416\u0443\u0440\u043D\u0430\u043B \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0439", tableOf(["\u041A\u043E\u0434 / \u0434\u0430\u0442\u0430", "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], filtered.map((v) => {
          const rev = kind === "sop" ? one(ws.working, "SELECT * FROM document_revision WHERE document_id=? ORDER BY CASE WHEN state='effective' THEN 0 ELSE 1 END,version_no DESC LIMIT 1", [v.id]) : null;
          return [v.code || v.observed_at, v.title, refName("operation", v.operation_id), v.archived ? "\u0410\u0440\u0445\u0438\u0432" : revisionLabels[rev?.state || v.state] || "\u2014", btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
            librarySelected = v.id;
            libraryRevisionSelected = null;
            draw();
          }, "primary")];
        }))));
        return;
      }
      out.append(add(el("div", void 0, "row"), btn("\u041A \u0441\u043F\u0438\u0441\u043A\u0443", () => {
        librarySelected = null;
        libraryRevisionSelected = null;
        draw();
      })));
      for (const v of filtered.filter((x) => x.id === librarySelected)) {
        const p = pane((kind === "sop" ? v.code + " \xB7 " : "") + v.title, el("p", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F: " + refName("operation", v.operation_id) + " \xB7 \u0420\u0435\u0432\u0438\u0437\u0438\u044F \u0437\u0430\u043F\u0438\u0441\u0438: " + v.rev, "muted"));
        if (kind === "sop") {
          const versions = rows(ws.working, "SELECT * FROM document_revision WHERE document_id=? ORDER BY version_no DESC", [v.id]);
          if (libraryRevisionSelected && !versions.some((x) => x.id === libraryRevisionSelected)) libraryRevisionSelected = null;
          if (libraryRevisionSelected) p.append(btn("\u0412\u0441\u0435 \u0432\u0435\u0440\u0441\u0438\u0438 \u0421\u041E\u041F", () => {
            libraryRevisionSelected = null;
            draw();
          }), el("p", "\u041E\u0442\u043A\u0440\u044B\u0442\u0430 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F \u043F\u043E \u0441\u0432\u044F\u0437\u0438 \u0438\u0437 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0440\u0430\u0437\u0434\u0435\u043B\u0430.", "muted"));
          for (const revision2 of versions.filter((x) => !libraryRevisionSelected || x.id === libraryRevisionSelected)) {
            const data = JSON.parse(revision2.payload_json), c = libraryContext(kind, v.id, revision2.id), section = el("div", void 0, "library-version");
            section.dataset.revisionId = revision2.id;
            const header = add(el("div", void 0, "row"), el("strong", "\u0412\u0435\u0440\u0441\u0438\u044F " + revision2.version_no), el("span", revisionLabels[revision2.state] || revision2.state, "pill"), el("span", revision2.created_at.slice(0, 10), "muted"));
            section.append(header, el("p", sourceSummary(data), "muted"), el("p", "\u041F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440: " + (revision2.review_due || "\u0434\u0430\u0442\u0430 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u0430") + " \xB7 " + (revision2.print_format === "portrait" ? "\u04103 \u043A\u043D\u0438\u0436\u043D\u044B\u0439" : revision2.print_format === "landscape" ? "\u04103 \u0430\u043B\u044C\u0431\u043E\u043C\u043D\u044B\u0439" : "\u0444\u043E\u0440\u043C\u0430\u0442 \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D") + " \xB7 \u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E: " + (revision2.workplace_name || "\u043D\u0435 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u043E"), revision2.review_due && revision2.review_due < today() && revision2.state === "effective" ? "bad" : "muted"), sourceDetails(data));
            const tabs = el("div", void 0, "library-tabs"), body = el("div", void 0, "library-tab-body");
            const steps = () => tableOf(["\u2116", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435", "\u0421\u0435\u043A", "\u041A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B", "\u041F\u043E\u0447\u0435\u043C\u0443 \u0432\u0430\u0436\u043D\u043E"], data.projection.steps.map((s, i) => [i + 1, s.action, s.seconds, s.key_points.join("\n"), s.reason]));
            const passport = () => add(el("div"), el("p", "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E: " + (revision2.workplace_name || "\u2014") + " \xB7 \u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435: " + (revision2.equipment_name || "\u2014") + " \xB7 \u0414\u0430\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F: " + (revision2.changed_on || "\u2014")), sourcePassport(data), ...!v.archived && revision2.state === "draft" ? [passportForm(c, revision2)] : []);
            const assessments = () => add(el("div"), btn("\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u0432 \u0440\u0435\u0435\u0441\u0442\u0440 \u043E\u0446\u0435\u043D\u043E\u043A \u0421\u041E\u041F", () => goEvaluation(revision2.id)), evaluationDetail(v, revision2, data.source));
            const materials = () => materialsPanel(data);
            const history = () => add(el("div"), tableOf(["\u0412\u0435\u0440\u0441\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441", "\u0421\u043E\u0437\u0434\u0430\u043D\u0430", "\u041F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440"], versions.map((x) => [x.version_no, revisionLabels[x.state] || x.state, x.created_at.slice(0, 10), x.review_due])), frvOriginPanel(revision2));
            const stages = el("div", void 0, "lifecycle");
            for (const [k, n] of [["draft", "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A"], ["review", "\u041D\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0438"], ["approved", "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D"], ["effective", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442"]]) stages.append(el("span", n, "life-stage" + (revision2.state === k ? " current" : "")));
            section.append(stages);
            for (const [name, make] of [["\u0428\u0430\u0433\u0438 \u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B", steps], ["\u041F\u0430\u0441\u043F\u043E\u0440\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430", passport], ["\u0412\u0435\u0440\u0441\u0438\u0438", history], ["\u0424\u0420\u0412", () => relatedPanel(v, revision2, "frv")], ["\u041F\u043B\u0430\u043D TWI", () => relatedPanel(v, revision2, "twi")], ["\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F", assessments], ["\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B", materials]]) {
              const tab = btn(name, () => {
                for (const t of tabs.children) t.classList.remove("selected");
                tab.classList.add("selected");
                body.replaceChildren(make());
              }, "library-tab");
              tabs.append(tab);
            }
            tabs.firstChild.classList.add("selected");
            body.append(steps());
            section.append(tabs, body);
            const buttons = add(el("div", void 0, "row"), rawButton(data.source, "SOP-" + v.code + "-v" + revision2.version_no + ".json"));
            const open = versions.some((x) => ["draft", "review", "approved"].includes(x.state));
            if (!v.archived && (revision2.state === "draft" || !open && ["effective", "withdrawn", "superseded"].includes(revision2.state))) {
              buttons.append(btn(revision2.state === "draft" ? "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440" : "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0432\u0435\u0440\u0441\u0438\u044E \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435", () => launchEditor(c), "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 JSON", () => chooseLibraryFile(kind, c), "", !!ws.conflicts.length));
            }
            section.append(buttons);
            const actions = revision2.state === "draft" ? [["submit", "\u041D\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435"]] : revision2.state === "review" ? [["approve", "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u0442\u044C"], ["return", "\u0412\u0435\u0440\u043D\u0443\u0442\u044C \u0432 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A"]] : revision2.state === "approved" ? [["effect", "\u0412\u0432\u0435\u0441\u0442\u0438 \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435"]] : revision2.state === "effective" ? [["withdraw", "\u0412\u044B\u0432\u0435\u0441\u0442\u0438 \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F"]] : [];
            if (!v.archived) for (const [cmd, label] of actions) {
              const det = el("details");
              det.append(el("summary", label), libraryAction(c, cmd, label));
              section.append(det);
            }
            const decisions = rows(ws.working, "SELECT * FROM document_approval WHERE revision_id=? ORDER BY decided_at", [revision2.id]);
            for (const a of decisions) section.append(el("p", (a.decision === "approved" ? "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043B: " : "\u0412\u0435\u0440\u043D\u0443\u043B: ") + refName("person", a.actor_id) + " \xB7 " + a.decided_at.slice(0, 10) + (a.note ? " \xB7 " + a.note : ""), "muted"));
            p.append(section);
          }
          if (!v.archived && versions.length && versions.every((x) => ["superseded", "withdrawn"].includes(x.state))) p.append(btn("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0421\u041E\u041F", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0431\u0435\u0437 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u043E\u0440\u0438\u0438?")) run(async () => {
              await ws.applyContentEvents([libraryEvent(libraryContext(kind, v.id), null, "archive")], readContent2);
              return "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0432 \u0430\u0440\u0445\u0438\u0432\u0435";
            });
          }, "danger", !!ws.conflicts.length));
        } else {
          const data = JSON.parse(v.context_json), c = libraryContext(kind, v.id);
          p.append(el("p", revisionLabels[v.state] + " \xB7 \u0414\u0430\u0442\u0430 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F: " + v.observed_at), el("p", sourceSummary(data), "muted"), sourceDetails(data), frvAnalysisPanel(v, data));
          for (const link2 of rows(ws.working, "SELECT d.id,d.code,d.title,r.id revision_id,r.version_no,o.source_sha256 FROM sop_frv_origin o JOIN document_revision r ON r.id=o.revision_id JOIN document d ON d.id=r.document_id WHERE o.study_id=?", [v.id])) p.append(add(el("div", void 0, "row"), el("span", link2.code + " \xB7 v" + link2.version_no + " \xB7 " + (link2.source_sha256 === data.source.sha256 ? "\u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A" : "\u0420\u0430\u043D\u0435\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u0437\u0430\u043C\u0435\u0440\u044B"), "muted"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0421\u041E\u041F", () => goDocument(link2.id, link2.revision_id))));
          const buttons = add(el("div", void 0, "row"), rawButton(data.source, "FRV-" + v.id + ".json"));
          if (v.state === "draft") {
            buttons.append(btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440", () => launchEditor(c), "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 JSON", () => chooseLibraryFile(kind, c), "", !!ws.conflicts.length));
            const det = el("details");
            det.append(el("summary", "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435"), libraryAction(c, "finalize", "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435"));
            p.append(det);
          }
          if (v.state !== "archived") buttons.append(btn("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0431\u0435\u0437 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0439?")) run(async () => {
              await ws.applyContentEvents([libraryEvent(c, null, "archive")], readContent2);
              return "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 \u0430\u0440\u0445\u0438\u0432\u0435";
            });
          }, "danger", !!ws.conflicts.length));
          p.append(buttons);
        }
        out.append(p);
      }
    }
    search.oninput = () => {
      query = search.value;
      draw();
    };
    filter.onchange = () => {
      libraryFilter = filter.value;
      draw();
    };
    draw();
    if (kind === "frv") linkedRegistry(main, "frv");
  }
  async function backupTransfer() {
    return makeTransfer("backup", await backup(ws), sourceRefs(), readContent2);
  }
  async function restoreBackupTransfer(value) {
    const { payload, contents } = unpackTransfer(value, "backup");
    const db = openDb(SQL, decode(payload.base));
    let refs;
    try {
      refs = unionRefs(refsForDb(db), refsForEvents(payload.pending));
    } finally {
      db.close();
    }
    await restoreContents(contents, refs, (r, t) => contentStore.put(r, t));
    return restore(SQL, payload, readContent2);
  }
  async function acceptManualTransfer(value) {
    const { payload, contents } = unpackTransfer(value, "package");
    await restoreContents(contents, refsForEvents(payload.events), (r, t) => contentStore.put(r, t));
    return ws.accept(payload, readContent2);
  }
  async function snapshotTransfer(s) {
    return makeTransfer("snapshot", { manifest: s.manifest, base: encode(s.bytes) }, refsForDb(ws.base), readContent2);
  }
  async function openSnapshotTransfer(value) {
    const { payload, contents } = unpackTransfer(value, "snapshot"), db = await readSnapshot(SQL, payload.manifest, decode(payload.base));
    try {
      await restoreContents(contents, refsForDb(db), (r, t) => contentStore.put(r, t));
    } catch (e) {
      db.close();
      throw e;
    }
    await useSnapshot(db);
  }
  async function useSnapshot(db) {
    if (meta(db, "database_id") === meta(ws.base, "database_id")) {
      ws.replaceBase(db);
      return;
    }
    if (!empty()) {
      db.close();
      throw new Error("\u042D\u0442\u043E \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u0435\u0451 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.");
    }
    replace(new Workspace(SQL, db));
  }
  async function refresh() {
    invariant(folder, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
    invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F");
    const s = await latestSnapshot(folder, SQL);
    invariant(s, "\u0412 \u043F\u0430\u043F\u043A\u0435 \u043D\u0435\u0442 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0431\u0430\u0437\u044B");
    await useSnapshot(s.db);
    return ws.conflicts.length ? "\u041E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u043E; \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439" : "\u0417\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0431\u0430\u0437\u0430";
  }
  async function publish() {
    invariant(master, "\u0412\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
    invariant(folder, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
    invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F");
    const snapshot = await prepareSnapshot(ws);
    await publishSnapshot(folder, SQL, snapshot, readContent2);
    const db = await readSnapshot(SQL, snapshot.manifest, snapshot.bytes);
    replace(new Workspace(SQL, db, { device: ws.device }));
    return "\u0411\u0430\u0437\u0430 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430 \u043F\u043E SHA-256";
  }
  function storage(main) {
    const mode = el("input");
    mode.type = "checkbox";
    mode.checked = master;
    mode.onchange = () => {
      master = mode.checked;
      render();
    };
    const summary = pane("\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F", el("p", "ID \u0431\u0430\u0437\u044B: " + meta(ws.base, "database_id"), "muted"), el("p", "\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F: " + (meta(ws.base, "publication_id") || "\u0435\u0449\u0451 \u043D\u0435\u0442"), "muted"), el("p", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F: " + ws.pending.length + " \xB7 \u041F\u0440\u0438\u043D\u044F\u0442\u043E, \u043D\u043E \u043D\u0435 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043E: " + (ws.dirty ? "\u0434\u0430" : "\u043D\u0435\u0442")), add(el("label", void 0, "row"), mode, el("span", "\u0420\u0435\u0436\u0438\u043C \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F (\u0442\u043E\u043B\u044C\u043A\u043E \u0443\u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0435\u043D\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A)")), el("p", "\u0420\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F \u2014 \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0430\u0442\u0435\u043B\u044C, \u043D\u0435 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u044F. \u041F\u0440\u0430\u0432\u0430 \u043F\u0430\u043F\u043A\u0438 \u043D\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u044E\u0442\u0441\u044F \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F.", "muted"));
    main.append(summary);
    const controls = add(el("div", void 0, "row"), btn("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u0435\u0442\u0435\u0432\u0443\u044E \u043F\u0430\u043F\u043A\u0443", () => run(async () => {
      folder = await chooseFolder();
      if (cache) await save(cache, "folder", folder);
      return "\u0412\u044B\u0431\u0440\u0430\u043D\u0430 \u043F\u0430\u043F\u043A\u0430: " + folder.name;
    }, { save: false }), "primary"), btn("\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0434\u043E\u0441\u0442\u0443\u043F", () => run(async () => {
      invariant(folder, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
      await testFolder(folder);
      return "\u0427\u0442\u0435\u043D\u0438\u0435, \u0437\u0430\u043F\u0438\u0441\u044C \u0438 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u0442\u0435\u0441\u0442\u043E\u0432\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B";
    }, { save: false }), "", !folder), btn("\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0438\u0437 \u043F\u0430\u043F\u043A\u0438", () => run(refresh), "", !folder), btn("\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", () => run(async () => {
      invariant(folder, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
      await sendPackage(folder, await ws.package(), readContent2);
      return "\u041F\u0430\u043A\u0435\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0431\u0430\u0437\u043E\u0439";
    }, { save: false }), "", !folder || !ws.pending.length || !!ws.conflicts.length));
    main.append(pane("\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u043F\u0430\u043F\u043A\u0430", el("p", folder ? "\u041F\u0430\u043F\u043A\u0430: " + folder.name : "\u041D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u0430", "muted"), controls));
    const masterPanel = pane("\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u0438 \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", el("p", "\u0418\u0437\u0434\u0430\u0442\u0435\u043B\u044C \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438 \u043F\u0443\u0431\u043B\u0438\u043A\u0443\u0435\u0442 \u043D\u043E\u0432\u0443\u044E \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E. \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0444\u0430\u0439\u043B\u044B \u043D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u044E\u0442\u0441\u044F.", "muted"), add(el("div", void 0, "row"), btn("\u041F\u0440\u0438\u043D\u044F\u0442\u044C \u0441\u0432\u043E\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", () => run(async () => {
      const n = await ws.acceptOwn(readContent2);
      return "\u041F\u0440\u0438\u043D\u044F\u0442\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439: " + n;
    }), "", !master || !ws.pending.length || !!ws.conflicts.length), btn("\u0421\u043F\u0438\u0441\u043E\u043A \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0445", () => run(async () => {
      invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430");
      incoming = await listPackages(folder);
      return "\u041D\u0430\u0439\u0434\u0435\u043D\u043E \u043F\u0430\u043A\u0435\u0442\u043E\u0432: " + incoming.length;
    }, { save: false }), "", !folder || !master), btn("\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u0431\u0430\u0437\u0443", () => run(publish), "primary", !folder || !master || !!ws.pending.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u043F\u0430\u043A\u0435\u0442\u0430 \u0432\u0440\u0443\u0447\u043D\u0443\u044E", () => pick(".leanpkg,.json", async (p) => {
      invariant(master, "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
      const result = await acceptManualTransfer(p);
      return result.duplicate ? "\u041F\u0430\u043A\u0435\u0442 \u0443\u0436\u0435 \u043F\u0440\u0438\u043D\u044F\u0442" : "\u041F\u0440\u0438\u043D\u044F\u0442\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439: " + result.count;
    }, MAX_TRANSFER), "", !master)));
    for (const item of incoming) {
      const p = item.p, known = p && one(ws.base, "SELECT id FROM exchange_package WHERE id=?", [p.id]);
      masterPanel.append(add(el("div", void 0, "row"), el("span", item.name + " \xB7 " + (item.error || (known ? "\u043F\u0440\u0438\u043D\u044F\u0442" : p.events?.length + " \u0441\u043E\u0431\u044B\u0442\u0438\u0439")), "muted"), btn("\u041F\u0440\u0438\u043D\u044F\u0442\u044C", () => run(async () => {
        const x = await ws.accept(p, readContent2);
        return x.duplicate ? "\u0423\u0436\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u043E" : "\u041F\u0440\u0438\u043D\u044F\u0442\u043E: " + x.count;
      }), "", !!known || !master || !p || !!ws.pending.length)));
    }
    main.append(masterPanel);
    main.append(pane("\u041F\u0435\u0440\u0435\u043D\u043E\u0441 \u0438 \u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435", add(el("div", void 0, "row"), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043F\u0430\u043A\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", () => run(async () => {
      const p = await ws.package();
      download("change-" + p.id + ".leanpkg", await makeTransfer("package", p, refsForEvents(p.events), readContent2));
      return "\u041F\u0430\u043A\u0435\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false }), "", !ws.pending.length || !!ws.conflicts.length), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E", () => run(async () => {
      download("lean-" + uuid() + ".leanbackup", await backupTransfer());
      return "\u041A\u043E\u043F\u0438\u044F \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
    }, { save: false })), btn("\u041A\u043E\u043F\u0438\u044F \u043D\u0430 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u0434\u0438\u0441\u043A", () => run(async () => {
      await saveBackup(folder, await backupTransfer());
      return "\u041A\u043E\u043F\u0438\u044F \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430";
    }, { save: false }), "", !folder), btn("\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u043A\u043E\u043F\u0438\u044E", () => pick(".leanbackup,.json", async (obj2) => {
      const next = await restoreBackupTransfer(obj2);
      if (!empty() && !confirm("\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E? \u0423\u0431\u0435\u0434\u0438\u0442\u0435\u0441\u044C, \u0447\u0442\u043E \u0441\u043A\u0430\u0447\u0430\u043B\u0438 \u0435\u0451 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) {
        next.close();
        return "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
      }
      replace(next);
      return "\u041A\u043E\u043F\u0438\u044F \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 ID \u0431\u0430\u0437\u044B";
    })), btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A \u0434\u043B\u044F \u0440\u0443\u0447\u043D\u043E\u0433\u043E \u043E\u0431\u043C\u0435\u043D\u0430", () => run(async () => {
      invariant(master, "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
      const s = await prepareSnapshot(ws);
      download("snapshot-" + s.manifest.id + ".leansnapshot", await snapshotTransfer(s));
      replace(new Workspace(SQL, await readSnapshot(SQL, s.manifest, s.bytes), { device: ws.device }));
      return "\u0421\u043D\u0438\u043C\u043E\u043A \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0441\u043A\u0430\u0447\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u0439\u043B; \u0440\u0443\u0447\u043D\u0430\u044F \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430";
    }), "", !master || !!ws.pending.length || !!folder), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A", () => pick(".leansnapshot,.json", async (obj2) => {
      await openSnapshotTransfer(obj2);
      return "\u0421\u043D\u0438\u043C\u043E\u043A \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D \u0438 \u043E\u0442\u043A\u0440\u044B\u0442";
    })))));
    if (ws.conflicts.length) {
      const p = pane("\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", el("p", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E. \u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0438\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u044B; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u0430\u043D\u044B.", "bad"));
      for (const c of ws.conflicts) {
        p.append(el("p", c.error, "bad"));
        const v = one(ws.working, "SELECT * FROM " + c.event.entity_type + " WHERE id=?", [c.event.entity_id]);
        p.append(el("pre", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435: " + JSON.stringify(c.event.payload, null, 2) + "\n\u0422\u0435\u043A\u0443\u0449\u0435\u0435: " + JSON.stringify(v, null, 2), "muted"));
      }
      p.append(add(el("div", void 0, "row"), btn("\u041E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", () => {
        if (confirm("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0435\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435? \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
          ws.resolveConflict("discard");
          return "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0435\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435 \u043E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
        });
      }, "danger"), btn("\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0441\u0432\u043E\u0451 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435", () => {
        if (confirm("\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0432\u0430\u0448\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E\u0432\u0435\u0440\u0445 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0440\u0435\u0432\u0438\u0437\u0438\u0438? \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
          ws.resolveConflict("reapply");
          return "\u0421\u043E\u0437\u0434\u0430\u043D\u043E \u043D\u043E\u0432\u043E\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435; \u043E\u043D\u043E \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438";
        });
      }, "", Object.hasOwn(DOMAIN_TYPES, ws.conflicts[0].event.entity_type))));
      main.append(p);
    }
    main.append(pane("\u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u044F", el("p", "\u0422\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0443\u0441\u0442\u043E\u0439 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0439 \u0431\u0430\u0437\u0435. \u041D\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u043A\u0430\u043A \u0440\u0430\u0431\u043E\u0447\u0443\u044E.", "muted"), btn("\u041D\u043E\u0432\u0430\u044F \u043F\u0443\u0441\u0442\u0430\u044F \u0431\u0430\u0437\u0430", () => {
      if (confirm("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0443\u0441\u0442\u0443\u044E \u0431\u0430\u0437\u0443 \u0432\u043C\u0435\u0441\u0442\u043E \u0442\u0435\u043A\u0443\u0449\u0435\u0439? \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
        replace(new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration)));
        folder = null;
        incoming = [];
        master = false;
        importState = null;
        libraryDraft = null;
        if (cache) await save(cache, "folder", null);
        return "\u041D\u043E\u0432\u0430\u044F \u043F\u0443\u0441\u0442\u0430\u044F \u0431\u0430\u0437\u0430 \u0441\u043E\u0437\u0434\u0430\u043D\u0430";
      });
    }, "danger"), btn("\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0434\u0435\u043C\u043E-\u0434\u0430\u043D\u043D\u044B\u043C\u0438", () => run(async () => {
      invariant(empty(), "\u0414\u0435\u043C\u043E \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0443\u0441\u0442\u043E\u0439 \u0431\u0430\u0437\u0435");
      const u = ws.edit("org_unit", null, { code: "DEMO", name: "\u0423\u0447\u0435\u0431\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", kind: "\u041F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", parent_id: null });
      const v = ws.edit("org_unit", null, { code: "DEMO-M", name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0443\u0447\u0430\u0441\u0442\u043E\u043A", kind: "\u0423\u0447\u0430\u0441\u0442\u043E\u043A", parent_id: u });
      const p = ws.edit("profession", null, { code: "DEMO-MECH", name: "\u041C\u0435\u0445\u0430\u043D\u0438\u043A" });
      const a = ws.edit("person", null, { employee_code: "DEMO-001", display_name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A 01" });
      const e = ws.edit("equipment", null, { unit_id: v, code: "DEMO-E", name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0441\u0442\u0435\u043D\u0434" });
      ws.edit("operation", null, { unit_id: v, equipment_id: e, code: "DEMO-O", name: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u0442\u0435\u043D\u0434\u0430", criticality: "normal" });
      ws.edit("person_assignment", null, { person_id: a, unit_id: v, profession_id: p, shift_code: "1", valid_from: "2026-11-25", valid_to: null });
      return "\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u044B \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438";
    }), "", !empty())));
  }
  function render() {
    chart?.dispose();
    chart = null;
    document.documentElement.classList.toggle("dark", theme);
    const header = el("header", void 0, "corp-header");
    const brand = add(el("div", void 0, "brand-lockup"), el("div", void 0, "brand-mark"), add(el("div"), el("div", "LEAN CENTER", "brand"), el("div", "\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u043D\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u043C \u043C\u0435\u0441\u0442\u0435 \xB7 TWI", "brand-sub")));
    const metaPanel = add(el("div", void 0, "header-meta"), el("span", window.LC_BUILD.version || "lc3.7", "version"), btn(theme ? "\u0421\u0432\u0435\u0442\u043B\u0430\u044F \u0442\u0435\u043C\u0430" : "\u0422\u0451\u043C\u043D\u0430\u044F \u0442\u0435\u043C\u0430", () => {
      theme = !theme;
      render();
    }), btn("\u0425\u0440\u0430\u043D\u0435\u043D\u0438\u0435", () => navigate("storage")));
    if (editorSession && editorSession.host.hidden && !libraryDraft) metaPanel.append(btn("\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440", () => showEditor(editorSession), "primary"));
    header.append(brand, metaPanel);
    const side = el("aside", void 0, "sidebar");
    side.setAttribute("aria-label", "\u041D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F");
    const group = (name, keys) => {
      side.append(el("div", name, "navgroup"));
      for (const k of keys) side.append(navButton(k));
    };
    for (const [name, keys] of navGroups) {
      const d = el("details", void 0, "nav-section");
      d.open = !collapsedNav.has(name) || keys.includes(page);
      d.append(el("summary", name, "navgroup"));
      for (const k of keys) d.append(navButton(k));
      d.addEventListener("toggle", () => {
        if (d.open) collapsedNav.delete(name);
        else collapsedNav.add(name);
      });
      side.append(d);
    }
    side.append(el("p", "\u25CF  \u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0440\u0430\u0437\u0434\u0435\u043B\u044B", "nav-hint"));
    const main = el("main", void 0, "main");
    const section = navGroups.find(([, keys]) => keys.includes(page))?.[0] || "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E";
    const top = add(el("div", void 0, "top"), add(el("div"), el("div", section, "eyebrow"), el("h1", labels2[page]), el("div", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \xB7 " + ws.pending.length + " \u043E\u0436\u0438\u0434\u0430\u044E\u0449\u0438\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", "muted")), el("span", folder ? "\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u043F\u0430\u043F\u043A\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u0430" : "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F", "pill"));
    main.append(top);
    const stat = el("div", status, "status" + (error ? " error" : ""));
    stat.id = "status";
    stat.setAttribute("role", "status");
    main.append(stat);
    if (!cache) main.append(el("p", "IndexedDB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0430\u043C\u044F\u0442\u0438 \u2014 \u0441\u043A\u0430\u0447\u0438\u0432\u0430\u0439\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0434\u043E \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u044F.", "bad"));
    if (ws.conflicts.length) main.append(el("p", "\u0415\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \xAB\u0411\u0430\u0437\u0430 \u0438 \u043E\u0431\u043C\u0435\u043D\xBB.", "bad"));
    if (ws.dirty) main.append(el("p", "\u041F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0435\u0449\u0451 \u043D\u0435 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u044B.", "warn"));
    root.replaceChildren(add(el("div", void 0, "shell"), header, side, main));
    main.inert = !!editorSession && !editorSession.host.hidden;
    if (editorSession?.loaded) editorSession.frame.contentWindow.postMessage({ protocol: "lean-editor-v1", session: editorSession.session, type: "theme", theme: theme ? "dark" : "light" }, "*");
    if (page === "home") home(main);
    else if (page === "storage") storage(main);
    else if (page === "import_xlsx") importScreen(main);
    else if (page === "sop_constructor") constructorScreen(main);
    else if (page === "twi_plans") twiPlansScreen(main);
    else if (page === "sop" || page === "frv") libraryScreen(main, page);
    else if (page === "sop_evaluation") sopEvaluationScreen(main);
    else if (Object.hasOwn(definitions, page)) registry(main, page);
    else if (TRAINING_PAGES.includes(page)) trainingScreen(main, page, { ws, el, add, btn, pane, tableOf, inputField, fieldInput, refName, refOption, today, run, render, go: goTraining, goDocument, readContent: readContent2, pick, downloadBytes });
    else main.append(pane(labels2[page], el("p", "\u041C\u043E\u0434\u0443\u043B\u044C \u0437\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D \u043D\u0430 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0435 \u044D\u0442\u0430\u043F\u044B. \u0412 \u044D\u0442\u043E\u0439 \u0441\u0431\u043E\u0440\u043A\u0435 \u0433\u043E\u0442\u043E\u0432\u0438\u0442\u0441\u044F \u0435\u0434\u0438\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \u0438 \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u0430.", "muted")));
    main.append(el("p", "LC3.7 \xB7 \u0430\u0432\u0442\u043E\u043D\u043E\u043C\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F \xB7 \u043E\u0431\u0449\u0438\u0439 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u043E\u0431\u043C\u0435\u043D", "foot"));
  }
  window.addEventListener("resize", () => chart?.resize());
  async function init() {
    configureMigrations(LC_BUILD.migration3, LC_BUILD.migration4, LC_BUILD.migration5, LC_BUILD.migration6, LC_BUILD.migration7);
    SQL = await window.initSqlJs({ wasmBinary: decode(window.LC_BUILD.wasm) });
    try {
      cache = await openCache();
      const s = await load(cache, "workspace");
      generation = s?.generation || 0;
      folder = await load(cache, "folder");
      ws = s ? new Workspace(SQL, openDb(SQL, s.state.base), s.state) : new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration));
      if (!s) await persist();
      if (folder && await permission(folder, false)) {
        const prev = ws.state();
        try {
          const remote = await latestSnapshot(folder, SQL);
          if (remote) {
            await useSnapshot(remote.db);
            await persist();
            message(ws.conflicts.length ? "\u0411\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430, \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B" : "\u0411\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430 \u0438\u0437 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u043F\u0430\u043F\u043A\u0438");
          }
        } catch (e) {
          replace(new Workspace(SQL, openDb(SQL, prev.base), prev));
          message("\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u0431\u0430\u0437\u0430 \u043D\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430: " + e.message, true);
        }
      }
    } catch (e) {
      if (!cache) {
        ws = new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration));
        message("IndexedDB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D, \u0440\u0443\u0447\u043D\u043E\u0439 \u0440\u0435\u0436\u0438\u043C: " + e.message, true);
      } else if (ws) {
        message("\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043D\u0435 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u0430: " + e.message, true);
        cache = null;
      } else throw e;
    }
    render();
  }
  init().catch((e) => {
    console.error(e);
    root.replaceChildren(el("h1", "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C Lean Center"), el("p", e.message), el("p", "\u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0443\u0434\u0430\u043B\u0435\u043D\u044B. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0431\u0440\u0430\u0443\u0437\u0435\u0440 \u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E."));
  });
})();
