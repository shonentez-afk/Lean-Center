(() => {
  // src/core/db.js
  var SCHEMA_VERSION = 5;
  var migration3 = null;
  var migration4 = null;
  var migration5 = null;
  function configureMigrations(sql, next, last) {
    invariant(typeof sql === "string" && sql.includes("PRAGMA user_version=3") && typeof next === "string" && next.includes("PRAGMA user_version=4") && typeof last === "string" && last.includes("PRAGMA user_version=5"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0439 LC2/LC3");
    migration3 = sql;
    migration4 = next;
    migration5 = last;
  }
  var MAX_DB = 100 * 1024 * 1024;
  var MAX_PACKAGE = 5 * 1024 * 1024;
  var uuid = () => crypto.randomUUID();
  var now = () => (/* @__PURE__ */ new Date()).toISOString();
  var isId = (x) => typeof x === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x);
  var invariant = (ok, msg) => {
    if (!ok) throw new Error(msg);
  };
  var canonical = (x) => x === null || typeof x !== "object" ? JSON.stringify(x) : Array.isArray(x) ? "[" + x.map(canonical).join(",") + "]" : "{" + Object.keys(x).sort().map((k) => JSON.stringify(k) + ":" + canonical(x[k])).join(",") + "}";
  async function sha256(data) {
    const b = typeof data === "string" ? new TextEncoder().encode(data) : data;
    return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", b)), (x) => x.toString(16).padStart(2, "0")).join("");
  }
  function encode(bytes) {
    let s = "";
    for (let i = 0; i < bytes.length; i += 16384) s += String.fromCharCode(...bytes.subarray(i, i + 16384));
    return btoa(s);
  }
  function decode(s) {
    invariant(typeof s === "string" && s.length <= MAX_DB * 1.4, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0444\u0430\u0439\u043B \u0431\u0430\u0437\u044B");
    return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  }
  function rows(db, sql, args = []) {
    const st = db.prepare(sql);
    try {
      st.bind(args);
      const result = [];
      while (st.step()) result.push(st.getAsObject());
      return result;
    } finally {
      st.free();
    }
  }
  var one = (db, sql, args = []) => rows(db, sql, args)[0] || null;
  var meta = (db, key2) => one(db, "SELECT value FROM meta WHERE key=?", [key2])?.value || null;
  var setMeta = (db, key2, value) => db.run("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", [key2, value]);
  function tx(db, fn) {
    db.run("BEGIN IMMEDIATE");
    try {
      const value = fn();
      db.run("COMMIT");
      return value;
    } catch (e) {
      db.run("ROLLBACK");
      throw e;
    }
  }
  function bytesOf(db) {
    const bytes = db.export();
    db.run("PRAGMA foreign_keys=ON");
    return bytes;
  }
  function verifyDb(db, version = SCHEMA_VERSION) {
    invariant(one(db, "PRAGMA integrity_check")?.integrity_check === "ok", "\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u0430 \u0446\u0435\u043B\u043E\u0441\u0442\u043D\u043E\u0441\u0442\u044C SQLite");
    invariant(rows(db, "PRAGMA foreign_key_check").length === 0, "\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u044B \u0441\u0432\u044F\u0437\u0438 \u0431\u0430\u0437\u044B");
    invariant(Number(meta(db, "schema_version")) === version && one(db, "PRAGMA user_version").user_version === version, "\u0412\u0435\u0440\u0441\u0438\u044F \u0431\u0430\u0437\u044B \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F");
    invariant(isId(meta(db, "database_id")), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 ID \u0431\u0430\u0437\u044B");
    const p = meta(db, "publication_id");
    invariant(!p || one(db, "SELECT id FROM publication WHERE id=?", [p]), "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438");
  }
  function upgradeDb(db) {
    const version = Number(meta(db, "schema_version"));
    invariant([2, 3, 4, SCHEMA_VERSION].includes(version), "\u0412\u0435\u0440\u0441\u0438\u044F \u0431\u0430\u0437\u044B \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F: " + version);
    verifyDb(db, version);
    if (version === 2) {
      invariant(migration3, "\u041C\u0438\u0433\u0440\u0430\u0446\u0438\u044F LC2 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0430");
      invariant(!one(db, "SELECT person_id FROM person_role LIMIT 1"), "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u0440\u043E\u043B\u0438 legacy v1/v2. \u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u044F\u0432\u043D\u043E\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u0435\u0440\u0435\u0434 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0435\u0439; \u0438\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430.");
      db.run(migration3);
      verifyDb(db, 3);
    }
    if (version < 4) {
      invariant(migration4, "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 LC3");
      invariant(!one(db, "SELECT id FROM document LIMIT 1") && !one(db, "SELECT id FROM frv_study LIMIT 1"), "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u0440\u0430\u043D\u0435\u0435 \u043D\u0435 \u0438\u043D\u0442\u0435\u0433\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/\u0424\u0420\u0412; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u044F");
      db.run(migration4);
      verifyDb(db, 4);
    }
    if (version < 5) {
      db.run(migration5);
      verifyDb(db);
    }
    return db;
  }
  function openDb(SQL2, bytes, { upgrade = true } = {}) {
    invariant(bytes instanceof Uint8Array && bytes.length > 100 && bytes.length <= MAX_DB, "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u0440\u0430\u0437\u043C\u0435\u0440 \u0431\u0430\u0437\u044B");
    const d = new SQL2.Database(bytes);
    try {
      d.run("PRAGMA foreign_keys=ON");
      if (upgrade) upgradeDb(d);
      else verifyDb(d, Number(meta(d, "schema_version")));
      return d;
    } catch (e) {
      d.close();
      throw e;
    }
  }
  function createDb(SQL2, schema, migration, id = uuid()) {
    const d = new SQL2.Database();
    try {
      d.run(schema);
      d.run(migration);
      setMeta(d, "database_id", id);
      return upgradeDb(d);
    } catch (e) {
      d.close();
      throw e;
    }
  }
  var definitions = {
    org_unit: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, kind: { label: "\u0422\u0438\u043F", options: ["\u041F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", "\u0426\u0435\u0445", "\u0423\u0447\u0430\u0441\u0442\u043E\u043A", "\u0421\u043B\u0443\u0436\u0431\u0430", "\u0413\u0440\u0443\u043F\u043F\u0430"], required: true }, parent_id: { label: "\u0420\u043E\u0434\u0438\u0442\u0435\u043B\u044C", ref: "org_unit" } } },
    person: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438", fields: { employee_code: { label: "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440", required: true }, display_name: { label: "\u0424\u0418\u041E / \u0438\u043C\u044F", required: true } } },
    profession: { label: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    equipment: { label: "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    workplace: { label: "\u0420\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u0435\u0441\u0442\u0430", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    operation: { label: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u0438", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, equipment_id: { label: "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", ref: "equipment" }, workplace_id: { label: "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E", ref: "workplace" }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, criticality: { label: "\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u043E\u0441\u0442\u044C", options: ["normal", "important", "critical"], required: true } } },
    position: { label: "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    work_shift: { label: "\u0421\u043C\u0435\u043D\u044B", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    business_role: { label: "\u0420\u043E\u043B\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    person_assignment: { label: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", history: true, fields: { person_id: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ref: "person", required: true }, unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, profession_id: { label: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", ref: "profession" }, position_id: { label: "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", ref: "position" }, shift_id: { label: "\u0421\u043C\u0435\u043D\u0430", ref: "work_shift" }, shift_code: { label: "\u041A\u043E\u0434 \u0441\u043C\u0435\u043D\u044B LC1", legacy: true }, valid_from: { label: "\u041D\u0430\u0447\u0430\u043B\u043E", date: true, required: true }, valid_to: { label: "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", date: true } } },
    role_assignment: { label: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0440\u043E\u043B\u0435\u0439", history: true, fields: { person_id: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ref: "person", required: true }, role_id: { label: "\u0420\u043E\u043B\u044C", ref: "business_role", required: true }, valid_from: { label: "\u041D\u0430\u0447\u0430\u043B\u043E", date: true, required: true }, valid_to: { label: "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", date: true } } },
    skill_category: { label: "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043D\u0430\u0432\u044B\u043A\u043E\u0432", fields: { name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    skill: { label: "\u041D\u0430\u0432\u044B\u043A\u0438", fields: { category_id: { label: "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F", ref: "skill_category", required: true }, operation_id: { label: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", ref: "operation" }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    rating_scale: { label: "\u0428\u043A\u0430\u043B\u044B \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u043D\u0438\u044F", immutable: true, fields: { name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, version_no: { label: "\u0412\u0435\u0440\u0441\u0438\u044F", required: true, integer: true }, levels: { label: "\u0423\u0440\u043E\u0432\u043D\u0438 (\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435)", required: true, multiline: true, virtual: true } } }
  };
  var legacyTypes = /* @__PURE__ */ new Set(["org_unit", "person", "profession", "equipment", "operation", "person_assignment"]);
  var foldKey = (x) => String(x ?? "").normalize("NFKC").trim().toLocaleLowerCase("ru-RU");
  function parseLevels(text2) {
    invariant(typeof text2 === "string" && text2.length <= 5e3, "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u0435\u0439");
    const lines = text2.split(/\r?\n/).filter((x) => x.trim());
    invariant(lines.length >= 2 && lines.length <= 20, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0442 2 \u0434\u043E 20 \u0443\u0440\u043E\u0432\u043D\u0435\u0439");
    const levels = lines.map((line) => {
      const m = line.match(/^\s*(-?\d+)\s*:\s*(\S.*)$/);
      invariant(m, "\u041A\u0430\u0436\u0434\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C: \u0447\u0438\u0441\u043B\u043E: \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435");
      const value = Number(m[1]), label = m[2].trim();
      invariant(Number.isSafeInteger(value) && value >= 0 && value <= 1e3 && label.length <= 200, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C");
      return { value, label };
    });
    invariant(new Set(levels.map((x) => x.value)).size === levels.length, "\u041F\u043E\u0432\u0442\u043E\u0440 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0443\u0440\u043E\u0432\u043D\u044F");
    return levels.sort((a, b) => a.value - b.value);
  }
  function recordPayload(type, record) {
    const d = definitions[type];
    return Object.fromEntries(Object.entries(d.fields).map(([k, f]) => [k, record[k] == null ? null : String(record[k])]));
  }
  function list(db, type) {
    invariant(Object.hasOwn(definitions, type), "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A");
    const result = rows(db, "SELECT * FROM " + type + " ORDER BY " + (type === "person" ? "display_name" : definitions[type].history ? "valid_from DESC" : type === "rating_scale" ? "name,version_no" : "name"));
    if (type === "rating_scale") for (const v of result) v.levels = rows(db, "SELECT value,label FROM rating_level WHERE scale_id=? ORDER BY value", [v.id]).map((x) => x.value + ": " + x.label).join("\n");
    return result;
  }
  function identityKey(type, v) {
    if (type === "person") return foldKey(v.employee_code);
    if (type === "person_assignment") return [v.person_id, v.valid_from].join("|");
    if (type === "role_assignment") return [v.person_id, v.role_id, v.valid_from].join("|");
    if (type === "skill_category") return foldKey(v.name);
    if (type === "skill") return [v.category_id, foldKey(v.name)].join("|");
    if (type === "rating_scale") return [foldKey(v.name), Number(v.version_no)].join("|");
    if (["equipment", "operation", "workplace"].includes(type)) return [v.unit_id, foldKey(v.code)].join("|");
    return foldKey(v.code);
  }
  function normalize(db, type, p, id, old) {
    const def = definitions[type];
    invariant(def && p && typeof p === "object" && !Array.isArray(p), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u0438\u043F \u0437\u0430\u043F\u0438\u0441\u0438");
    const legacy = type === "person_assignment" && !Object.hasOwn(p, "position_id") && !Object.hasOwn(p, "shift_id");
    if (legacy) p = { ...p, position_id: old?.position_id ?? null, shift_id: old?.shift_id ?? null };
    if (type === "operation" && !Object.hasOwn(p, "workplace_id")) p = { ...p, workplace_id: old?.workplace_id ?? null };
    invariant(Object.keys(p).length === Object.keys(def.fields).length && Object.keys(p).every((k) => Object.hasOwn(def.fields, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u0437\u0430\u043F\u0438\u0441\u0438");
    const v = {};
    for (const [k, f] of Object.entries(def.fields)) {
      let x = p[k];
      invariant(x === null || typeof x === "string", "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: " + f.label);
      x = typeof x === "string" ? x.trim() : null;
      if (!x) x = null;
      invariant(!f.required || x !== null, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435: " + f.label);
      if (x !== null) {
        invariant(x.length <= (f.multiline ? 5e3 : 500), "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0434\u043B\u0438\u043D\u043D\u043E\u0435 \u043F\u043E\u043B\u0435");
        if (f.integer) invariant(/^\d+$/.test(x) && Number.isSafeInteger(Number(x)) && Number(x) > 0 && Number(x) <= 1e5, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0432\u0435\u0440\u0441\u0438\u0438");
        if (f.options) invariant(f.options.includes(x), "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: " + f.label);
        if (f.date) invariant(/^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0434\u0430\u0442\u0430");
        if (f.ref) {
          invariant(isId(x), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440");
          const ref = one(db, "SELECT * FROM " + f.ref + " WHERE id=?", [x]);
          invariant(ref && (!ref.archived || old?.[k] === x), "\u0421\u0441\u044B\u043B\u043A\u0430 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430: " + f.label);
        }
      }
      v[k] = x;
    }
    if (type === "org_unit") {
      let x = v.parent_id;
      const seen = /* @__PURE__ */ new Set([id]);
      while (x) {
        invariant(!seen.has(x), "\u0426\u0438\u043A\u043B \u0432 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0435");
        seen.add(x);
        x = one(db, "SELECT parent_id FROM org_unit WHERE id=?", [x])?.parent_id;
      }
    }
    if (type === "operation" && v.equipment_id) invariant(one(db, "SELECT unit_id FROM equipment WHERE id=?", [v.equipment_id])?.unit_id === v.unit_id, "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F");
    if (type === "operation" && v.workplace_id) invariant(one(db, "SELECT unit_id FROM workplace WHERE id=?", [v.workplace_id])?.unit_id === v.unit_id, "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F");
    if (type === "operation" && old && (v.workplace_id !== old.workplace_id || v.unit_id !== old.unit_id || v.equipment_id !== old.equipment_id)) invariant(!one(db, "SELECT r.id FROM document_revision r JOIN document d ON d.id=r.document_id WHERE d.operation_id=? AND r.state IN ('review','approved','effective','superseded','withdrawn') LIMIT 1", [id]), "\u041D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0441 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u044B\u043C\u0438 \u0421\u041E\u041F; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E");
    if (type === "workplace" && old && v.unit_id !== old.unit_id) invariant(!one(db, "SELECT id FROM operation WHERE workplace_id=? LIMIT 1", [id]), "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0441\u0432\u044F\u0437\u0430\u043D\u043E \u0441 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C\u0438");
    if (type === "equipment" && old && v.unit_id !== old.unit_id) invariant(!one(db, "SELECT id FROM operation WHERE equipment_id=? LIMIT 1", [id]), "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0442\u0438 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0441 \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u043C\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C\u0438");
    if (type === "person_assignment") {
      invariant(!v.valid_to || v.valid_to >= v.valid_from, "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 \u0440\u0430\u043D\u044C\u0448\u0435 \u043D\u0430\u0447\u0430\u043B\u0430");
      invariant(!v.shift_id || !v.shift_code, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043C\u0435\u043D\u0443 \u0438\u0437 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u043B\u0438\u0431\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043A\u043E\u0434, \u043D\u0435 \u043E\u0431\u0430");
      if (old) {
        for (const k of ["person_id", "unit_id", "profession_id", "position_id", "shift_id", "shift_code", "valid_from"]) invariant(old[k] === v[k], "\u0418\u0441\u0442\u043E\u0440\u0438\u044E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435");
        invariant(!old.valid_to || old.valid_to === v.valid_to, "\u0417\u0430\u043A\u0440\u044B\u0442\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u043E");
      }
      invariant(!one(db, "SELECT id FROM person_assignment WHERE person_id=? AND id<>? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? LIMIT 1", [v.person_id, id, v.valid_to || "9999-12-31", v.valid_from]), "\u041F\u0435\u0440\u0435\u0441\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
    }
    if (type === "role_assignment") {
      invariant(!v.valid_to || v.valid_to >= v.valid_from, "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 \u0440\u0430\u043D\u044C\u0448\u0435 \u043D\u0430\u0447\u0430\u043B\u0430");
      if (old) {
        for (const k of ["person_id", "role_id", "valid_from"]) invariant(old[k] === v[k], "\u0418\u0441\u0442\u043E\u0440\u0438\u044E \u0440\u043E\u043B\u0438 \u043D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435");
        invariant(!old.valid_to || old.valid_to === v.valid_to, "\u0417\u0430\u043A\u0440\u044B\u0442\u0430\u044F \u0440\u043E\u043B\u044C \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
      }
      invariant(!one(db, "SELECT id FROM role_assignment WHERE person_id=? AND role_id=? AND id<>? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? LIMIT 1", [v.person_id, v.role_id, id, v.valid_to || "9999-12-31", v.valid_from]), "\u041F\u0435\u0440\u0435\u0441\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043E\u0434\u043D\u043E\u0439 \u0440\u043E\u043B\u0438");
    }
    if (type === "rating_scale") {
      invariant(!old, "\u0428\u043A\u0430\u043B\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E");
      parseLevels(v.levels);
    }
    const key2 = identityKey(type, v);
    if (!old || identityKey(type, old) !== key2) invariant(!list(db, type).some((x) => x.id !== id && identityKey(type, x) === key2), "\u0414\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u043A\u043B\u044E\u0447\u0430 / UNIQUE");
    return v;
  }
  function validateEvent(e) {
    invariant(e && Object.keys(e).every((k) => ["id", "entity_type", "entity_id", "operation", "expected_revision", "payload", "occurred_at"].includes(k)) && isId(e.id) && isId(e.entity_id) && (Object.hasOwn(definitions, e.entity_type) || Object.hasOwn(DOMAIN_TYPES, e.entity_type)) && ["create", "update", "archive"].includes(e.operation) && Number.isSafeInteger(e.expected_revision) && e.expected_revision >= 0 && typeof e.occurred_at === "string" && !isNaN(Date.parse(e.occurred_at)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435");
  }
  function applyEvent(db, e, packageId = null) {
    validateEvent(e);
    const prev = one(db, "SELECT * FROM change_event WHERE id=?", [e.id]);
    if (prev) {
      invariant(prev.entity_type === e.entity_type && prev.entity_id === e.entity_id && prev.operation === e.operation && prev.expected_revision === e.expected_revision && prev.occurred_at === e.occurred_at && canonical(JSON.parse(prev.payload_json)) === canonical(e.payload), "\u041F\u043E\u0432\u0442\u043E\u0440 ID \u0441 \u0434\u0440\u0443\u0433\u0438\u043C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u044B\u043C");
      return false;
    }
    const t = e.entity_type, old = one(db, "SELECT * FROM " + t + " WHERE id=?", [e.entity_id]);
    invariant((old?.rev || 0) === e.expected_revision, "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0432\u0435\u0440\u0441\u0438\u0438: " + (definitions[t]?.label || DOMAIN_TYPES[t]) + " / " + e.entity_id + " (\u043E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C " + e.expected_revision + ", \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F " + (old?.rev || 0) + ")");
    if (Object.hasOwn(DOMAIN_TYPES, t)) applyDomainEvent(db, e, old);
    else if (e.operation === "create" || e.operation === "update") {
      invariant(e.operation === "create" ? !old : !!old && !old.archived, "\u041D\u0435\u043B\u044C\u0437\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u044D\u0442\u0443 \u0437\u0430\u043F\u0438\u0441\u044C");
      const p = normalize(db, t, e.payload, e.entity_id, old);
      const keys = Object.keys(p).filter((k) => !definitions[t].fields[k].virtual);
      const values = keys.map((k) => p[k]);
      if (!old) {
        db.run("INSERT INTO " + t + "(id," + keys.join(",") + ",rev) VALUES(" + Array(keys.length + 2).fill("?").join(",") + ")", [e.entity_id, ...values, 1]);
        if (t === "rating_scale") for (const l of parseLevels(p.levels)) db.run("INSERT INTO rating_level(scale_id,value,label) VALUES(?,?,?)", [e.entity_id, l.value, l.label]);
      } else db.run("UPDATE " + t + " SET " + keys.map((k) => k + "=?").join(",") + ",rev=rev+1 WHERE id=?", [...values, e.entity_id]);
    } else {
      invariant(old && !old.archived && !definitions[t].history && e.payload === null, "\u041D\u0435\u043B\u044C\u0437\u044F \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C");
      const date2 = e.occurred_at.slice(0, 10);
      const active2 = " AND (valid_to IS NULL OR valid_to>=?)";
      const deps = {
        org_unit: [["org_unit", "parent_id", false], ["equipment", "unit_id", false], ["workplace", "unit_id", false], ["operation", "unit_id", false], ["person_assignment", "unit_id", true]],
        person: [["person_assignment", "person_id", true], ["role_assignment", "person_id", true]],
        profession: [["person_assignment", "profession_id", true]],
        position: [["person_assignment", "position_id", true]],
        work_shift: [["person_assignment", "shift_id", true]],
        business_role: [["role_assignment", "role_id", true]],
        equipment: [["operation", "equipment_id", false]],
        workplace: [["operation", "workplace_id", false]],
        operation: [["skill", "operation_id", false]],
        skill_category: [["skill", "category_id", false]]
      };
      if (t === "operation") invariant(!one(db, "SELECT id FROM document WHERE operation_id=? AND archived=0 LIMIT 1", [e.entity_id]) && !one(db, "SELECT id FROM frv_study WHERE operation_id=? AND state<>'archived' LIMIT 1", [e.entity_id]), "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441\u0432\u044F\u0437\u0430\u043D\u0430 \u0441 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u043C\u0438 \u0438\u043B\u0438 \u0424\u0420\u0412");
      for (const [table, column, history] of deps[t] || []) invariant(!one(db, "SELECT id FROM " + table + " WHERE " + column + "=?" + (history ? active2 : " AND archived=0") + " LIMIT 1", history ? [e.entity_id, date2] : [e.entity_id]), "\u0417\u0430\u043F\u0438\u0441\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0441\u0432\u044F\u0437\u044F\u0445; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u0443\u0439\u0442\u0435 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438");
      db.run("UPDATE " + t + " SET archived=1,rev=rev+1 WHERE id=?", [e.entity_id]);
    }
    db.run("INSERT INTO change_event(id,package_id,entity_type,entity_id,operation,expected_revision,payload_json,occurred_at) VALUES(?,?,?,?,?,?,?,?)", [e.id, packageId, t, e.entity_id, e.operation, e.expected_revision, canonical(e.payload), e.occurred_at]);
    return true;
  }
  async function makePackage(db, events, device) {
    invariant(events.length > 0 && events.length <= 2e3, "\u041D\u0435\u0442 \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u0438\u043B\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u043F\u0430\u043A\u0435\u0442\u0430");
    const body = { format: "lean-change-v1", id: uuid(), database_id: meta(db, "database_id"), base_publication_id: meta(db, "publication_id"), schema_version: SCHEMA_VERSION, device_id: device, created_at: now(), events: structuredClone(events) };
    const hash = await sha256(canonical(body));
    invariant(new TextEncoder().encode(canonical(body)).length < MAX_PACKAGE, "\u041F\u0430\u043A\u0435\u0442 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 5 \u041C\u0411");
    return { ...body, hash };
  }
  async function checkPackage(p) {
    invariant(p && typeof p === "object" && Object.keys(p).length === 9 && p.format === "lean-change-v1" && isId(p.id) && isId(p.database_id) && isId(p.device_id) && (p.base_publication_id === null || isId(p.base_publication_id)) && [2, 3, 4, SCHEMA_VERSION].includes(p.schema_version) && typeof p.created_at === "string" && !isNaN(Date.parse(p.created_at)) && Array.isArray(p.events) && p.events.length > 0 && p.events.length <= 2e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043F\u0430\u043A\u0435\u0442");
    const { hash, ...body } = p;
    invariant(new TextEncoder().encode(canonical(body)).length < MAX_PACKAGE, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u043F\u0430\u043A\u0435\u0442");
    invariant(await sha256(canonical(body)) === hash, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 \u043F\u0430\u043A\u0435\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
    p.events.forEach((e) => {
      validateEvent(e);
      if (p.schema_version < 4) invariant(!Object.hasOwn(DOMAIN_TYPES, e.entity_type), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC3");
      if (p.schema_version < 5) invariant(!["workplace", "checklist_version", "sop_evaluation"].includes(e.entity_type) && !(e.entity_type === "operation" && e.payload && Object.hasOwn(e.payload, "workplace_id")) && !(e.entity_type === "document" && ["passport", "origin"].includes(e.payload?.command)), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC3.1");
      if (p.schema_version === 2) invariant(legacyTypes.has(e.entity_type) && (e.entity_type !== "person_assignment" || e.payload === null || !Object.hasOwn(e.payload, "position_id") && !Object.hasOwn(e.payload, "shift_id")), "\u041F\u0430\u043A\u0435\u0442 v2 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u043F\u043E\u043B\u044F LC2");
    });
    invariant(new Set(p.events.map((e) => e.id)).size === p.events.length, "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u0432 \u043F\u0430\u043A\u0435\u0442\u0435");
  }
  async function mergePackage(db, p, readContent3) {
    await checkPackage(p);
    invariant(p.database_id === meta(db, "database_id"), "\u041F\u0430\u043A\u0435\u0442 \u0434\u0440\u0443\u0433\u043E\u0439 \u0431\u0430\u0437\u044B");
    const known = one(db, "SELECT * FROM exchange_package WHERE id=?", [p.id]);
    if (known) {
      invariant(known.manifest_sha256 === p.hash, "\u041F\u043E\u0432\u0442\u043E\u0440 ID \u043F\u0430\u043A\u0435\u0442\u0430 \u0441 \u0438\u043D\u044B\u043C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u044B\u043C");
      return { duplicate: true, count: 0 };
    }
    invariant(!p.base_publication_id || one(db, "SELECT id FROM publication WHERE id=?", [p.base_publication_id]), "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F");
    await verifyDomainEvents(p.events, readContent3);
    return tx(db, () => {
      db.run("INSERT INTO exchange_package(id,base_publication_id,schema_version,database_id,device_id,created_at,state,manifest_sha256) VALUES(?,?,?,?,?,?,?,?)", [p.id, p.base_publication_id, p.schema_version, p.database_id, p.device_id, p.created_at, "applied", p.hash]);
      let count = 0;
      for (const e of p.events) if (applyEvent(db, e, p.id)) count++;
      return { duplicate: false, count };
    });
  }
  var Workspace = class {
    constructor(SQL2, base, { pending = [], device = uuid(), dirty = false } = {}) {
      this.SQL = SQL2;
      this.base = base;
      this.pending = structuredClone(pending);
      this.device = device;
      this.dirty = dirty;
      this.rebuild();
    }
    rebuild() {
      this.working?.close();
      this.working = openDb(this.SQL, bytesOf(this.base));
      this.conflicts = [];
      const remaining = [];
      for (const e of this.pending) {
        if (this.conflicts.length) {
          remaining.push(e);
          continue;
        }
        try {
          tx(this.working, () => applyEvent(this.working, e));
          if (!one(this.base, "SELECT id FROM change_event WHERE id=?", [e.id])) remaining.push(e);
        } catch (err) {
          remaining.push(e);
          this.conflicts.push({ event: e, error: err.message });
        }
      }
      this.pending = remaining;
    }
    edit(type, id, payload, operation2) {
      invariant(Object.hasOwn(definitions, type), "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0441\u0435\u0440\u0432\u0438\u0441 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430");
      invariant(!this.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439");
      invariant(this.pending.length < 2e3, "\u0414\u043E\u0441\u0442\u0438\u0433\u043D\u0443\u0442 \u043B\u0438\u043C\u0438\u0442 \u043E\u0447\u0435\u0440\u0435\u0434\u0438. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0439\u0442\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F.");
      const old = id ? one(this.working, "SELECT * FROM " + (Object.hasOwn(definitions, type) ? type : "invalid") + " WHERE id=?", [id]) : null;
      const e = { id: uuid(), entity_type: type, entity_id: id || uuid(), operation: operation2 || (old ? "update" : "create"), expected_revision: old?.rev || 0, payload, occurred_at: now() };
      tx(this.working, () => applyEvent(this.working, e));
      this.pending.push(e);
      return e.entity_id;
    }
    // Whole import is committed locally in one SQLite transaction, with checked revisions.
    applyBatch(events) {
      invariant(events.every((e) => Object.hasOwn(definitions, e.entity_type)), "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432");
      return this._applyBatch(events);
    }
    async applyContentEvents(events, readContent3) {
      await verifyDomainEvents(events, readContent3);
      return this._applyBatch(events);
    }
    _applyBatch(events) {
      invariant(!this.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B");
      invariant(Array.isArray(events) && events.length > 0 && this.pending.length + events.length <= 2e3, "\u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u043E\u0447\u0435\u0440\u0435\u0434\u0438 (2000)");
      invariant(new TextEncoder().encode(canonical([...this.pending, ...events])).length < MAX_PACKAGE - 4096, "\u041E\u0447\u0435\u0440\u0435\u0434\u044C \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043B\u0438\u043C\u0438\u0442 \u043F\u0430\u043A\u0435\u0442\u0430");
      tx(this.working, () => {
        for (const e of events) {
          invariant(applyEvent(this.working, e), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u0438\u043C\u043F\u043E\u0440\u0442\u0430");
        }
      });
      this.pending.push(...structuredClone(events));
      return events.length;
    }
    async package() {
      return makePackage(this.base, this.pending, this.device);
    }
    async accept(p, readContent3) {
      invariant(!this.pending.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0440\u0438\u043C\u0438\u0442\u0435 \u0438\u043B\u0438 \u044D\u043A\u0441\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u0438 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
      const r = await mergePackage(this.base, p, readContent3);
      if (!r.duplicate) this.dirty = true;
      this.rebuild();
      return r;
    }
    async acceptOwn(readContent3) {
      invariant(!this.conflicts.length, "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0442");
      if (!this.pending.length) return 0;
      const p = await this.package();
      const r = await mergePackage(this.base, p, readContent3);
      this.dirty = true;
      this.rebuild();
      return r.count;
    }
    discardPending() {
      this.pending = [];
      this.rebuild();
    }
    resolveConflict(choice) {
      invariant(this.conflicts.length === 1 && ["discard", "reapply"].includes(choice), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0430\u0435\u043C\u043E\u0433\u043E \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0430");
      const e = this.conflicts[0].event, i = this.pending.findIndex((x) => x.id === e.id);
      invariant(i >= 0, "\u0421\u043E\u0431\u044B\u0442\u0438\u0435 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442");
      if (choice === "discard") {
        this.pending.splice(i, 1);
        this.rebuild();
        return;
      }
      invariant(!Object.hasOwn(DOMAIN_TYPES, e.entity_type), "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430: \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u0432\u0440\u0443\u0447\u043D\u0443\u044E");
      const old = one(this.working, "SELECT * FROM " + e.entity_type + " WHERE id=?", [e.entity_id]);
      const next = { ...e, id: uuid(), expected_revision: old?.rev || 0, occurred_at: now() };
      invariant(e.operation === "create" ? !old : !!old && !old.archived, "\u0417\u0430\u043F\u0438\u0441\u044C \u0443\u0434\u0430\u043B\u0435\u043D\u0430, \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0438\u043B\u0438 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442; \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0440\u0443\u0447\u043D\u043E\u0435 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435");
      tx(this.working, () => applyEvent(this.working, next));
      this.pending.splice(i, 1, next);
      this.rebuild();
    }
    replaceBase(db) {
      try {
        invariant(meta(db, "database_id") === meta(this.base, "database_id"), "\u0414\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430");
        const current = meta(this.base, "publication_id");
        let p = meta(db, "publication_id"), found = !current;
        const seen = /* @__PURE__ */ new Set();
        while (p) {
          invariant(!seen.has(p), "\u0426\u0438\u043A\u043B \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
          seen.add(p);
          if (p === current) found = true;
          const row = one(db, "SELECT parent_id FROM publication WHERE id=?", [p]);
          invariant(row, "\u0420\u0430\u0437\u043E\u0440\u0432\u0430\u043D\u0430 \u0446\u0435\u043F\u043E\u0447\u043A\u0430 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
          p = row.parent_id;
        }
        invariant(found, "\u0421\u043D\u0438\u043C\u043E\u043A \u0443\u0441\u0442\u0430\u0440\u0435\u043B \u0438\u043B\u0438 \u0438\u043C\u0435\u0435\u0442 \u0434\u0440\u0443\u0433\u0443\u044E \u0432\u0435\u0442\u043A\u0443");
        if (this.dirty) {
          for (const e of rows(this.base, "SELECT * FROM change_event")) invariant(canonical(one(db, "SELECT * FROM change_event WHERE id=?", [e.id])) === canonical(e), "\u0415\u0441\u0442\u044C \u043D\u0435\u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
          for (const e of rows(this.base, "SELECT * FROM exchange_package")) invariant(canonical(one(db, "SELECT * FROM exchange_package WHERE id=?", [e.id])) === canonical(e), "\u0415\u0441\u0442\u044C \u043D\u0435\u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u0430\u043A\u0435\u0442\u044B");
        }
        const prev = this.base;
        this.base = db;
        this.dirty = false;
        this.rebuild();
        prev.close();
      } catch (e) {
        if (this.base !== db) db.close();
        throw e;
      }
    }
    state() {
      return { base: bytesOf(this.base), pending: structuredClone(this.pending), device: this.device, dirty: this.dirty };
    }
    close() {
      this.working.close();
      this.base.close();
    }
  };
  async function prepareSnapshot(ws2) {
    invariant(!ws2.pending.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0440\u0438\u043C\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
    const db = openDb(ws2.SQL, bytesOf(ws2.base));
    try {
      const descriptor = { format: "lean-snapshot-v1", id: uuid(), database_id: meta(db, "database_id"), parent_id: meta(db, "publication_id"), schema_version: SCHEMA_VERSION, created_at: now() };
      const descriptor_hash = await sha256(canonical(descriptor));
      db.run("INSERT INTO publication(id,parent_id,created_at,schema_version,manifest_sha256) VALUES(?,?,?,?,?)", [descriptor.id, descriptor.parent_id, descriptor.created_at, SCHEMA_VERSION, descriptor_hash]);
      setMeta(db, "publication_id", descriptor.id);
      verifyDb(db);
      const bytes = bytesOf(db);
      return { bytes, manifest: { ...descriptor, descriptor_hash, snapshot_sha256: await sha256(bytes), size: bytes.length } };
    } finally {
      db.close();
    }
  }
  async function readSnapshot(SQL2, manifest, bytes) {
    invariant(manifest && manifest.format === "lean-snapshot-v1" && isId(manifest.id) && isId(manifest.database_id) && (manifest.parent_id === null || isId(manifest.parent_id)) && [2, 3, 4, SCHEMA_VERSION].includes(manifest.schema_version) && manifest.size === bytes.length && bytes.length <= MAX_DB, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442");
    const { descriptor_hash, snapshot_sha256, size, ...descriptor } = manifest;
    invariant(await sha256(canonical(descriptor)) === descriptor_hash && await sha256(bytes) === snapshot_sha256, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D \u0441\u043D\u0438\u043C\u043E\u043A");
    const db = openDb(SQL2, bytes, { upgrade: false });
    try {
      const p = one(db, "SELECT * FROM publication WHERE id=?", [manifest.id]);
      invariant(Number(meta(db, "schema_version")) === manifest.schema_version && p?.schema_version === manifest.schema_version && meta(db, "database_id") === manifest.database_id && meta(db, "publication_id") === manifest.id && p?.manifest_sha256 === descriptor_hash && p.parent_id === manifest.parent_id, "\u0421\u043D\u0438\u043C\u043E\u043A \u0438 \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442");
      return upgradeDb(db);
    } catch (e) {
      db.close();
      throw e;
    }
  }
  async function backup(ws2) {
    const s = ws2.state();
    const body = { format: "lean-backup-v1", base: encode(s.base), pending: s.pending, device: s.device, dirty: s.dirty };
    return { ...body, hash: await sha256(canonical(body)) };
  }
  async function restore(SQL2, obj2, readContent3) {
    const { hash, ...body } = obj2;
    invariant(body.format === "lean-backup-v1" && Array.isArray(body.pending) && body.pending.length <= 2e3 && isId(body.device) && typeof body.dirty === "boolean" && await sha256(canonical(body)) === hash, "\u0420\u0435\u0437\u0435\u0440\u0432\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0435\u043D\u0430");
    body.pending.forEach(validateEvent);
    await verifyDomainEvents(body.pending, readContent3);
    return new Workspace(SQL2, openDb(SQL2, decode(body.base)), body);
  }

  // src/modules/library/sop-review.js
  var text = (x, n = 500) => typeof x === "string" && x.trim() && x.length <= n;
  var sha = (x) => typeof x === "string" && /^[0-9a-f]{64}$/.test(x);
  var exact = (p, ks) => invariant(p && typeof p === "object" && !Array.isArray(p) && Object.keys(p).length === ks.length && ks.every((k) => Object.hasOwn(p, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F");
  var SOP_CHECKLIST_CODE = "SOP_APP4";
  function validDate(x) {
    return typeof x === "string" && /^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x;
  }
  function reviewDue(changed) {
    invariant(validDate(changed), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0421\u041E\u041F");
    const [y, m, d] = changed.split("-").map(Number);
    const day = Math.min(d, new Date(Date.UTC(y + 1, m, 0)).getUTCDate());
    return String(y + 1).padStart(4, "0") + "-" + String(m).padStart(2, "0") + "-" + String(day).padStart(2, "0");
  }
  function validateChecklist(p) {
    exact(p, ["format", "title", "source_sha256", "criteria"]);
    invariant(p.format === "lean-sop-checklist-v1" && text(p.title, 200) && sha(p.source_sha256) && Array.isArray(p.criteria) && p.criteria.length === 20, "\u041D\u0443\u0436\u043D\u0430 \u0444\u043E\u0440\u043C\u0430 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F \u0438\u0437 20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    p.criteria.forEach((q, i) => {
      exact(q, ["code", "question"]);
      invariant(q.code === i + 1 && text(q.question, 2500), "\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u044F \u0438\u043B\u0438 \u0442\u0435\u043A\u0441\u0442 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u044F " + (i + 1));
    });
    return p;
  }
  function sopMethods(db) {
    return rows(db, "SELECT v.*,c.name FROM checklist_version v JOIN checklist c ON c.id=v.checklist_id WHERE c.code=? ORDER BY version_no DESC", [SOP_CHECKLIST_CODE]);
  }
  function sopCriteria(db, id) {
    return rows(db, "SELECT * FROM checklist_criterion WHERE version_id=? ORDER BY position", [id]);
  }
  function applySopMethod(db, e, old) {
    invariant(e.operation === "create" && !old, "\u0412\u0435\u0440\u0441\u0438\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
    const p = validateChecklist(e.payload);
    const methods = sopMethods(db);
    invariant(!methods.some((m) => {
      const d = JSON.parse(m.methodology_json);
      return canonical(d.criteria) === canonical(p.criteria) && d.source_sha256 === p.source_sha256;
    }), "\u0422\u0430\u043A\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0443\u0436\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430");
    let c = one(db, "SELECT * FROM checklist WHERE code=?", [SOP_CHECKLIST_CODE]);
    if (!c) {
      db.run("INSERT INTO checklist(id,code,name) VALUES(?,?,?)", [e.id, SOP_CHECKLIST_CODE, "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F"]);
      c = { id: e.id };
    }
    const n = methods.length ? methods[0].version_no + 1 : 1;
    db.run("INSERT INTO checklist_version(id,checklist_id,version_no,state,methodology_json,rev) VALUES(?,?,?,'draft',?,1)", [e.entity_id, c.id, n, canonical(p)]);
    for (const q of p.criteria) db.run("INSERT INTO checklist_criterion(id,version_id,code,section_code,position,question) VALUES(?,?,?,?,?,?)", [e.entity_id + ":" + q.code, e.entity_id, String(q.code), "SOP", q.code, q.question]);
    db.run("UPDATE checklist_version SET state='active' WHERE id=?", [e.entity_id]);
  }
  function applySopEvaluation(db, e, old) {
    invariant(e.operation === "create" && !old, "\u0417\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E");
    const p = e.payload;
    exact(p, ["revision_id", "method_id", "actor_id", "evaluated_on", "place", "source_sha256", "responses"]);
    invariant(isId(p.revision_id) && isId(p.method_id) && isId(p.actor_id) && validDate(p.evaluated_on) && text(p.place, 500) && sha(p.source_sha256), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0434\u0430\u0442\u0443, \u043C\u0435\u0441\u0442\u043E, \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u0435\u043C\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u0438 \u043E\u0446\u0435\u043D\u0449\u0438\u043A\u0430");
    const rev = one(db, "SELECT * FROM document_revision WHERE id=?", [p.revision_id]);
    invariant(rev && JSON.parse(rev.payload_json).source.sha256 === p.source_sha256, "\u0412\u0435\u0440\u0441\u0438\u044F \u0421\u041E\u041F \u0438\u043B\u0438 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C");
    const person = one(db, "SELECT display_name FROM person WHERE id=? AND archived=0", [p.actor_id]);
    invariant(person, "\u041E\u0446\u0435\u043D\u0449\u0438\u043A \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442");
    invariant(sopMethods(db).some((m) => m.id === p.method_id && m.state === "active"), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F");
    const criteria = sopCriteria(db, p.method_id);
    invariant(criteria.length === 20 && Array.isArray(p.responses) && p.responses.length === 20, "\u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043E\u0442\u0432\u0435\u0442\u0438\u0442\u044C \u043D\u0430 \u0432\u0441\u0435 20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    p.responses.forEach((q, i) => {
      exact(q, ["criterion_id", "value", "note"]);
      invariant(q.criterion_id === criteria[i].id && (q.value === 0 || q.value === 1) && typeof q.note === "string" && q.note.length <= 2e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 " + (i + 1));
    });
    db.run("INSERT INTO sop_evaluation(id,revision_id,method_id,actor_id,evaluated_on,place,actor_name,source_sha256,recorded_at,rev) VALUES(?,?,?,?,?,?,?,?,?,1)", [e.entity_id, p.revision_id, p.method_id, p.actor_id, p.evaluated_on, p.place.trim(), person.display_name, p.source_sha256, e.occurred_at]);
    for (const q of p.responses) db.run("INSERT INTO sop_evaluation_response(evaluation_id,method_id,criterion_id,value,note) VALUES(?,?,?,?,?)", [e.entity_id, p.method_id, q.criterion_id, q.value, q.note]);
  }

  // src/modules/library/domain.js
  var DOMAIN_TYPES = Object.freeze({ document: "\u0411\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0421\u041E\u041F", frv_study: "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u0424\u0420\u0412", checklist_version: "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F", sop_evaluation: "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F" });
  var MAX_CONTENT = 30 * 1024 * 1024;
  var MIME = { sop: "application/vnd.lean.stage43.sop+json", frv: "application/vnd.lean.stage43.frv+json" };
  var encoder = new TextEncoder();
  var obj = (x) => x && typeof x === "object" && !Array.isArray(x);
  var string = (x, max = 2e4) => typeof x === "string" && x.length <= max;
  var nonempty = (x, max = 500) => string(x, max) && x.trim().length > 0;
  var date = (x) => string(x, 10) && /^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x;
  var digest = (x) => typeof x === "string" && /^[0-9a-f]{64}$/.test(x);
  var types = /* @__PURE__ */ new Set(["VA", "NVA_Necessary", "NVA_Waste", "WAIT", "BREAK", "OTHER"]);
  var exact2 = (p, keys) => invariant(obj(p) && Object.keys(p).length === keys.length && keys.every((k) => Object.hasOwn(p, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u0441\u043E\u0431\u044B\u0442\u0438\u044F LC3");
  var num = (x) => typeof x === "number" && Number.isFinite(x) && x >= 0;
  var safeImage = (x) => string(x, MAX_CONTENT) && /^data:image\/(?:jpeg|png|webp|gif);base64,[A-Za-z0-9+/]+={0,2}$/i.test(x);
  function validateRef(ref) {
    exact2(ref, ["sha256", "size", "kind"]);
    invariant(digest(ref.sha256) && Number.isSafeInteger(ref.size) && ref.size > 0 && ref.size <= MAX_CONTENT && Object.hasOwn(MIME, ref.kind), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0441\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B");
    return ref;
  }
  async function checkContent(ref, text2) {
    validateRef(ref);
    invariant(typeof text2 === "string" && text2.length <= MAX_CONTENT, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0432\u0435\u043B\u0438\u043A");
    const bytes = encoder.encode(text2);
    invariant(bytes.length === ref.size && await sha256(bytes) === ref.sha256, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D: " + ref.sha256);
    return text2;
  }
  async function inspectSource(text2, kind) {
    invariant(Object.hasOwn(MIME, kind) && typeof text2 === "string" && text2.length <= MAX_CONTENT, "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u0438\u043F \u0438\u043B\u0438 \u0440\u0430\u0437\u043C\u0435\u0440 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430");
    const bytes = encoder.encode(text2);
    invariant(bytes.length > 0 && bytes.length <= MAX_CONTENT, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u043D\u0435 \u0434\u043E\u043B\u0436\u0435\u043D \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0442\u044C 30 \u041C\u0411");
    const p = JSON.parse(text2);
    invariant(obj(p), "\u041E\u0436\u0438\u0434\u0430\u043B\u0441\u044F JSON Stage43");
    let projection;
    if (kind === "sop") {
      invariant(p.schemaVersion === 2 && obj(p.document) && Object.hasOwn(p, "constructor") && obj(p.constructor) && Array.isArray(p.constructor.steps) && obj(p.photoAssets) && p.integrity?.algorithm === "SHA-256" && digest(p.integrity.sha256), "\u041E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u0421\u041E\u041F Stage43 \u0441 SHA-256");
      const base = { schemaVersion: p.schemaVersion, document: p.document, constructor: p.constructor, photoAssets: p.photoAssets };
      invariant(await sha256(JSON.stringify(base)) === p.integrity.sha256, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C\u043E\u0433\u043E \u0421\u041E\u041F \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
      const s = p.constructor, d = p.document, seen = /* @__PURE__ */ new Set();
      invariant(obj(s.meta) && s.steps.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0448\u0430\u0433\u0438 \u0421\u041E\u041F");
      const steps = s.steps.map((st) => {
        invariant(obj(st) && Number.isSafeInteger(st.id) && st.id > 0 && !seen.has(st.id) && string(st.action) && Array.isArray(st.keyMoments) && st.keyMoments.length <= 3 && st.keyMoments.every((x) => string(x)) && string(st.reason) && num(st.durationSeconds) && typeof st.hasPhoto === "boolean", "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0448\u0430\u0433 \u0421\u041E\u041F");
        seen.add(st.id);
        if (st.hasPhoto) {
          const a = p.photoAssets[String(st.id)];
          invariant(obj(a) && safeImage(a.original) && (!a.rendered || safeImage(a.rendered)), "\u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u043D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u043E\u0435 \u0444\u043E\u0442\u043E \u0448\u0430\u0433\u0430 " + st.id);
        }
        return { source_id: String(st.id), action: st.action, key_points: st.keyMoments, reason: st.reason, seconds: st.durationSeconds, photo: st.hasPhoto };
      });
      invariant(Object.keys(p.photoAssets).every((k) => steps.some((st) => st.source_id === k && st.photo)), "\u0415\u0441\u0442\u044C \u0444\u043E\u0442\u043E \u0431\u0435\u0437 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u0448\u0430\u0433\u0430");
      projection = { title: String(s.meta.operation || "").slice(0, 500), number: String(d.number || s.meta.sopNumber || "").slice(0, 200), legacy_id: String(d.id || "").slice(0, 200), legacy_version: String(d.version ?? "").slice(0, 50), legacy_status: String(d.status || "").slice(0, 80), photos: steps.filter((x) => x.photo).length, twi: !!s.twi?.enabled, steps };
    } else {
      invariant(["FRV-1.2", "FRV-1.3"].includes(p.schemaVersion) && obj(p.study) && Array.isArray(p.cycles) && p.cycles.length <= 1e3, "\u041E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C \u043A\u043E\u043F\u0438\u044F \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u0424\u0420\u0412 FRV-1.2/1.3");
      const seen = /* @__PURE__ */ new Set(), measurements = [];
      let complete = 0, unmeasured = 0, count = 0;
      for (const [i, c] of p.cycles.entries()) {
        invariant(obj(c) && Array.isArray(c.observations) && c.observations.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0446\u0438\u043A\u043B \u0424\u0420\u0412");
        let full = c.observations.length > 0;
        const phase = ["baseline", "improved", "unassigned"].includes(c.phase) ? c.phase : "unassigned";
        for (const o of c.observations) {
          count++;
          invariant(count <= 5e3 && obj(o) && nonempty(o.id, 200) && !seen.has(o.id) && string(o.actionRaw) && (!o.valueType || types.has(o.valueType)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435 \u0424\u0420\u0412");
          seen.add(o.id);
          const v = o.durationSec;
          invariant(v == null || num(v), "\u0412\u0440\u0435\u043C\u044F \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u0447\u0438\u0441\u043B\u043E\u043C \u0441\u0435\u043A\u0443\u043D\u0434 \u0438\u043B\u0438 null");
          if (v == null || !o.actionRaw.trim()) {
            unmeasured++;
            full = false;
            continue;
          }
          if (v === 0) full = false;
          measurements.push({ source_id: o.id, cycle: i + 1, phase, action: o.actionRaw, category: o.valueType || "OTHER", seconds: v });
        }
        if (full) complete++;
      }
      projection = { title: String(p.study.operationId || p.study.processDescription || p.study.studyId || "").slice(0, 500), number: String(p.study.studyId || "").slice(0, 200), legacy_id: String(p.study.libraryId || "").slice(0, 200), legacy_version: String(p.study.version || "").slice(0, 50), legacy_status: String(p.study.status || "").slice(0, 80), cycles: p.cycles.length, complete, unmeasured, measurements };
    }
    invariant(encoder.encode(canonical(projection)).length <= 2 * 1024 * 1024, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u0430\u044F \u043F\u0440\u043E\u0435\u043A\u0446\u0438\u044F \u0434\u043B\u044F \u043E\u0434\u043D\u043E\u0433\u043E \u043F\u0430\u043A\u0435\u0442\u0430; \u0440\u0430\u0437\u0434\u0435\u043B\u0438\u0442\u0435 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A");
    return { source: { sha256: await sha256(bytes), size: bytes.length, kind }, projection };
  }
  function refsForEvents(events) {
    const out = /* @__PURE__ */ new Map();
    for (const e of events || []) if (Object.hasOwn(DOMAIN_TYPES, e.entity_type) && e.payload?.source) {
      const r = validateRef(e.payload.source);
      out.set(r.sha256, r);
    }
    return [...out.values()];
  }
  function refsForDb(db) {
    return rows(db, "SELECT sha256,byte_size,mime FROM attachment WHERE mime IN (?,?) ORDER BY sha256", [MIME.sop, MIME.frv]).map((x) => validateRef({ sha256: x.sha256, size: x.byte_size, kind: x.mime === MIME.sop ? "sop" : "frv" }));
  }
  function unionRefs(...groups) {
    const m = /* @__PURE__ */ new Map();
    for (const refs of groups) for (const ref of refs) {
      validateRef(ref);
      const old = m.get(ref.sha256);
      invariant(!old || canonical(old) === canonical(ref), "\u041D\u0435\u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430");
      m.set(ref.sha256, ref);
    }
    return [...m.values()];
  }
  async function verifyDomainEvents(events, readContent3) {
    const checked = /* @__PURE__ */ new Map();
    for (const e of events || []) {
      if (!Object.hasOwn(DOMAIN_TYPES, e.entity_type) || !e.payload?.source) continue;
      const ref = validateRef(e.payload.source);
      invariant(typeof readContent3 === "function", "\u041F\u0430\u043A\u0435\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043F\u043E\u043B\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432");
      let result = checked.get(ref.sha256);
      if (!result) {
        const text2 = await checkContent(ref, await readContent3(ref));
        result = await inspectSource(text2, ref.kind);
        checked.set(ref.sha256, result);
      }
      invariant(canonical(result.source) === canonical(ref) && canonical(result.projection) === canonical(e.payload.projection), "\u041F\u0440\u043E\u0435\u043A\u0446\u0438\u044F \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u043C \u0444\u0430\u0439\u043B\u043E\u043C");
    }
  }
  function register(db, ref) {
    validateRef(ref);
    const old = one(db, "SELECT * FROM attachment WHERE sha256=?", [ref.sha256]);
    if (old) {
      invariant(old.mime === MIME[ref.kind] && old.byte_size === ref.size, "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E");
      return;
    }
    db.run("INSERT INTO attachment(sha256,mime,byte_size,original_name) VALUES(?,?,?,?)", [ref.sha256, MIME[ref.kind], ref.size, ref.sha256 + ".json"]);
  }
  function link(db, ref, type, id) {
    register(db, ref);
    db.run("DELETE FROM attachment_link WHERE entity_type=? AND entity_id=? AND purpose='stage43-source'", [type, id]);
    db.run("INSERT INTO attachment_link(id,sha256,entity_type,entity_id,purpose) VALUES(?,?,?,?,?)", [id + ":source", ref.sha256, type, id, "stage43-source"]);
  }
  function active(db, table, id) {
    invariant(isId(id) && one(db, "SELECT id FROM " + table + " WHERE id=? AND archived=0", [id]), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u0437\u0430\u043F\u0438\u0441\u044C: " + table);
  }
  function operation(db, id) {
    if (id !== null) active(db, "operation", id);
  }
  function sourcePayload(p, kind) {
    validateRef(p.source);
    invariant(p.source.kind === kind && obj(p.projection) && nonempty(p.title) && string(p.projection.title, 500), "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435");
    return canonical({ source: p.source, projection: p.projection });
  }
  function docSteps(db, rid, p) {
    invariant(Array.isArray(p.projection.steps) && p.projection.steps.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0448\u0430\u0433\u0438");
    db.run("DELETE FROM document_step WHERE revision_id=?", [rid]);
    for (const [i, s] of p.projection.steps.entries()) {
      invariant(string(s.action) && Array.isArray(s.key_points) && s.key_points.every((x) => string(x)) && string(s.reason) && num(s.seconds), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0448\u0430\u0433");
      db.run("INSERT INTO document_step(id,revision_id,position,action_text,key_points_json,reason_text,duration_seconds) VALUES(?,?,?,?,?,?,?)", [rid + ":" + (i + 1), rid, i + 1, s.action, canonical(s.key_points), s.reason, s.seconds]);
    }
  }
  function revision(db, id, docId) {
    const r = one(db, "SELECT * FROM document_revision WHERE id=? AND document_id=?", [id, docId]);
    invariant(r, "\u0412\u0435\u0440\u0441\u0438\u044F \u043D\u0435 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0443");
    return r;
  }
  function openRevision(db, id) {
    return one(db, "SELECT id FROM document_revision WHERE document_id=? AND state IN ('draft','review','approved')", [id]);
  }
  function newRevision(db, e, p, version) {
    const payload = sourcePayload(p, "sop");
    register(db, p.source);
    db.run("INSERT INTO document_revision(id,document_id,version_no,state,payload_json,created_at) VALUES(?,?,?,'draft',?,?)", [e.id, e.entity_id, version, payload, e.occurred_at]);
    docSteps(db, e.id, p);
    link(db, p.source, "document_revision", e.id);
  }
  function applyDomainEvent(db, e, old) {
    const p = e.payload, id = e.entity_id;
    if (e.entity_type === "checklist_version") return applySopMethod(db, e, old);
    if (e.entity_type === "sop_evaluation") return applySopEvaluation(db, e, old);
    if (e.entity_type === "document") {
      if (e.operation === "create") {
        exact2(p, ["command", "code", "title", "operation_id", "source", "projection"]);
        invariant(!old && p.command === "create" && nonempty(p.code, 200) && nonempty(p.title), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043D\u043E\u0432\u044B\u0439 \u0421\u041E\u041F");
        operation(db, p.operation_id);
        invariant(!rows(db, "SELECT code FROM document").some((x) => foldKey(x.code) === foldKey(p.code)), "\u041D\u043E\u043C\u0435\u0440 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442");
        db.run("INSERT INTO document(id,code,kind,operation_id,title,rev) VALUES(?,?,'sop',?,?,1)", [id, p.code.trim(), p.operation_id, p.title.trim()]);
        newRevision(db, e, p, 1);
        return;
      }
      invariant(old && !old.archived && old.kind === "sop", "\u0421\u041E\u041F \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D");
      if (e.operation === "archive") {
        invariant(p === null && !one(db, "SELECT id FROM document_revision WHERE document_id=? AND state NOT IN ('superseded','withdrawn')", [id]), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0432\u0435\u0434\u0438\u0442\u0435 \u0432\u0435\u0440\u0441\u0438\u0438 \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F");
        db.run("UPDATE document SET archived=1,rev=rev+1 WHERE id=?", [id]);
        return;
      }
      invariant(e.operation === "update" && obj(p), "\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441 \u0421\u041E\u041F");
      if (p.command === "passport") {
        exact2(p, ["command", "revision_id", "print_format", "changed_on"]);
        const v2 = revision(db, p.revision_id, id);
        invariant(v2.state === "draft", "\u041F\u0430\u0441\u043F\u043E\u0440\u0442 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0443 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430");
        invariant(["portrait", "landscape"].includes(p.print_format) && validDate(p.changed_on) && p.changed_on <= e.occurred_at.slice(0, 10), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u043E\u0440\u043C\u0430\u0442 \u0438 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
        const steps = rows(db, "SELECT * FROM document_step WHERE revision_id=?", [v2.id]);
        invariant(steps.length <= (p.print_format === "portrait" ? 9 : 12), "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0448\u0430\u0433\u043E\u0432 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u04103");
        const op = old.operation_id ? one(db, "SELECT * FROM operation WHERE id=? AND archived=0", [old.operation_id]) : null;
        const w = op?.workplace_id ? one(db, "SELECT * FROM workplace WHERE id=? AND archived=0", [op.workplace_id]) : null;
        const equipment = op?.equipment_id ? one(db, "SELECT * FROM equipment WHERE id=?", [op.equipment_id]) : null;
        db.run("UPDATE document_revision SET print_format=?,changed_on=?,review_due=?,workplace_id=?,workplace_name=?,equipment_name=? WHERE id=?", [p.print_format, p.changed_on, reviewDue(p.changed_on), w?.id || null, w?.name || null, equipment?.name || null, v2.id]);
        db.run("UPDATE document SET rev=rev+1 WHERE id=?", [id]);
        return;
      }
      if (p.command === "origin") {
        exact2(p, ["command", "revision_id", "study_id", "source_sha256"]);
        const v2 = revision(db, p.revision_id, id);
        invariant(v2.state === "draft", "\u0421\u0432\u044F\u0437\u044C \u0424\u0420\u0412 \u0437\u0430\u0434\u0430\u0451\u0442\u0441\u044F \u0443 \u043D\u043E\u0432\u043E\u0433\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430");
        const f = one(db, "SELECT * FROM frv_study WHERE id=?", [p.study_id]);
        invariant(f && f.state !== "archived" && f.operation_id === old.operation_id && JSON.parse(f.context_json).source.sha256 === p.source_sha256, "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C \u0438\u043B\u0438 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
        invariant(!one(db, "SELECT revision_id FROM sop_frv_origin WHERE revision_id=?", [v2.id]), "\u0421\u0432\u044F\u0437\u044C \u0441 \u0424\u0420\u0412 \u0443\u0436\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430");
        db.run("INSERT INTO sop_frv_origin VALUES(?,?,?,?)", [v2.id, f.id, p.source_sha256, e.occurred_at]);
        db.run("UPDATE document SET rev=rev+1 WHERE id=?", [id]);
        return;
      }
      if (p.command === "save" || p.command === "revise") {
        exact2(p, ["command", "revision_id", "title", "operation_id", "source", "projection"]);
        operation(db, p.operation_id);
        const payload = sourcePayload(p, "sop");
        if (p.command === "save") {
          const v2 = revision(db, p.revision_id, id);
          invariant(v2.state === "draft", "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A");
          db.run("UPDATE document_revision SET payload_json=?,print_format=NULL,changed_on=NULL,review_due=NULL,workplace_id=NULL,workplace_name=NULL,equipment_name=NULL WHERE id=?", [payload, v2.id]);
          docSteps(db, v2.id, p);
          link(db, p.source, "document_revision", v2.id);
        } else {
          invariant(p.revision_id === null && !openRevision(db, id), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E");
          const version = one(db, "SELECT max(version_no) n FROM document_revision WHERE document_id=?", [id]).n + 1;
          newRevision(db, e, p, version);
        }
        invariant(old.operation_id === p.operation_id || !one(db, "SELECT id FROM document_revision WHERE document_id=? AND state IN ('approved','effective','superseded','withdrawn')", [id]), "\u0421\u0432\u044F\u0437\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u043E\u0432\u0430\u0432\u0448\u0435\u0433\u043E \u0421\u041E\u041F \u0441 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0435\u0439 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
        db.run("UPDATE document SET title=?,operation_id=?,rev=rev+1 WHERE id=?", [p.title.trim(), p.operation_id, id]);
        return;
      }
      exact2(p, ["command", "revision_id", "actor_id", "note"]);
      const v = revision(db, p.revision_id, id);
      invariant(string(p.note, 2e3), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u043F\u0440\u0438\u043C\u0435\u0447\u0430\u043D\u0438\u0435");
      active(db, "person", p.actor_id);
      const transitions = { submit: ["draft", "review"], return: ["review", "draft"], approve: ["review", "approved"], effect: ["approved", "effective"], withdraw: ["effective", "withdrawn"] };
      const tr = Object.hasOwn(transitions, p.command) && transitions[p.command];
      invariant(tr && v.state === tr[0], "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u043F\u0435\u0440\u0435\u0445\u043E\u0434 \u0441\u0442\u0430\u0442\u0443\u0441\u0430");
      if (["submit", "approve", "effect"].includes(p.command)) {
        active(db, "operation", old.operation_id);
        const steps = rows(db, "SELECT action_text FROM document_step WHERE revision_id=?", [v.id]);
        invariant(steps.length && steps.every((s) => s.action_text.trim()), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0432\u0441\u0435\u0445 \u0448\u0430\u0433\u043E\u0432");
        if (v.print_format) {
          invariant(steps.length <= (v.print_format === "portrait" ? 9 : 12), "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0448\u0430\u0433\u043E\u0432 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u0444\u043E\u0440\u043C\u0430\u0442 \u04103");
          invariant(v.workplace_id && one(db, "SELECT workplace_id FROM operation WHERE id=?", [old.operation_id])?.workplace_id === v.workplace_id, "\u041F\u0430\u0441\u043F\u043E\u0440\u0442: \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
        }
      }
      if (p.command === "return" || p.command === "withdraw") invariant(p.note.trim(), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043F\u0440\u0438\u0447\u0438\u043D\u0443");
      if (p.command === "effect") {
        db.run("UPDATE document_revision SET state='superseded' WHERE document_id=? AND state='effective'", [id]);
        db.run("UPDATE document_revision SET state='effective',effective_at=? WHERE id=?", [e.occurred_at, v.id]);
      } else db.run("UPDATE document_revision SET state=? WHERE id=?", [tr[1], v.id]);
      if (p.command === "approve" || p.command === "return") db.run("INSERT INTO document_approval(id,revision_id,actor_id,decision,decided_at,note) VALUES(?,?,?,?,?,?)", [e.id, v.id, p.actor_id, p.command === "approve" ? "approved" : "returned", e.occurred_at, p.note]);
      db.run("UPDATE document SET rev=rev+1 WHERE id=?", [id]);
      return;
    }
    invariant(e.entity_type === "frv_study", "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435");
    if (e.operation === "archive") {
      invariant(old && old.state !== "archived" && p === null, "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E");
      db.run("UPDATE frv_study SET state='archived',rev=rev+1 WHERE id=?", [id]);
      return;
    }
    if (e.operation === "update" && p?.command === "finalize") {
      exact2(p, ["command", "actor_id", "note"]);
      active(db, "person", p.actor_id);
      invariant(old?.state === "draft" && string(p.note, 2e3), "\u0424\u0438\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430");
      active(db, "operation", old.operation_id);
      invariant(JSON.parse(old.context_json).projection.complete > 0, "\u041D\u0435\u0442 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u043D\u043E\u0433\u043E \u0446\u0438\u043A\u043B\u0430");
      db.run("UPDATE frv_study SET state='final',rev=rev+1 WHERE id=?", [id]);
      return;
    }
    exact2(p, ["command", "title", "operation_id", "observed_at", "source", "projection"]);
    invariant(date(p.observed_at), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F");
    operation(db, p.operation_id);
    const context = sourcePayload(p, "frv");
    invariant(e.operation === "create" ? !old && p.command === "create" : old?.state === "draft" && p.command === "save", "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0424\u0420\u0412");
    if (!old) db.run("INSERT INTO frv_study(id,operation_id,title,observed_at,state,context_json,rev) VALUES(?,?,?,?,'draft',?,1)", [id, p.operation_id, p.title.trim(), p.observed_at, context]);
    else db.run("UPDATE frv_study SET operation_id=?,title=?,observed_at=?,context_json=?,rev=rev+1 WHERE id=?", [p.operation_id, p.title.trim(), p.observed_at, context, id]);
    db.run("DELETE FROM frv_measurement WHERE study_id=?", [id]);
    invariant(Array.isArray(p.projection.measurements) && p.projection.measurements.length <= 5e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F");
    for (const [i, m] of p.projection.measurements.entries()) {
      invariant(nonempty(m.action, 2e4) && types.has(m.category) && num(m.seconds), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0435");
      db.run("INSERT INTO frv_measurement(id,study_id,position,activity,category,duration_seconds,raw_json) VALUES(?,?,?,?,?,?,?)", [id + ":" + (i + 1), id, i + 1, m.action, m.category, m.seconds, canonical(m)]);
    }
    link(db, p.source, "frv_study", id);
  }

  // src/storage/local.js
  async function openCache() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open("lean-center-lc1", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("kv");
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  function load(cache2, key2) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readonly"), r = t.objectStore("kv").get(key2);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  function save(cache2, key2, value) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readwrite");
      t.objectStore("kv").put(value, key2);
      t.oncomplete = resolve;
      t.onabort = () => reject(t.error || new Error("\u0417\u0430\u043F\u0438\u0441\u044C \u043F\u0440\u0435\u0440\u0432\u0430\u043D\u0430"));
      t.onerror = () => reject(t.error);
    });
  }
  function saveWorkspace(cache2, expected, value) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readwrite"), s = t.objectStore("kv"), r = s.get("workspace");
      let reason;
      const next = expected + 1;
      r.onsuccess = () => {
        if ((r.result?.generation || 0) !== expected) {
          reason = new Error("\u0414\u0440\u0443\u0433\u0430\u044F \u0432\u043A\u043B\u0430\u0434\u043A\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430 \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E. \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443.");
          t.abort();
          return;
        }
        s.put({ generation: next, state: value }, "workspace");
      };
      t.oncomplete = () => resolve(next);
      t.onabort = () => reject(reason || t.error || new Error("\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430"));
      t.onerror = () => reject(t.error);
    });
  }

  // src/storage/network.js
  var textBytes = (s) => new TextEncoder().encode(s);
  async function chooseFolder() {
    invariant(window.showDirectoryPicker, "\u0412\u044B\u0431\u043E\u0440 \u043F\u0430\u043F\u043A\u0438 \u0437\u0430\u043F\u0440\u0435\u0449\u0451\u043D \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u043E\u043C. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0440\u0443\u0447\u043D\u043E\u0439 \u0438\u043C\u043F\u043E\u0440\u0442 \u0438 \u044D\u043A\u0441\u043F\u043E\u0440\u0442.");
    return window.showDirectoryPicker({ id: "lean-center-network", mode: "readwrite" });
  }
  async function permission(h, request = false) {
    if (!h) return false;
    let p = await h.queryPermission({ mode: "readwrite" });
    if (p !== "granted" && request) p = await h.requestPermission({ mode: "readwrite" });
    return p === "granted";
  }
  async function sub(h, name, create = false) {
    return h.getDirectoryHandle(name, { create });
  }
  async function readFile(dir, name, max = MAX_DB) {
    const f = await (await dir.getFileHandle(name)).getFile();
    invariant(f.size <= max, "\u0424\u0430\u0439\u043B \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043B\u0438\u043C\u0438\u0442: " + name);
    return new Uint8Array(await f.arrayBuffer());
  }
  async function writeNew(dir, name, data) {
    try {
      await dir.getFileHandle(name);
      throw new Error("\u0424\u0430\u0439\u043B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442: " + name);
    } catch (e) {
      if (e.name !== "NotFoundError") throw e;
    }
    const f = await dir.getFileHandle(name, { create: true }), w = await f.createWritable();
    try {
      await w.write(data);
      await w.close();
    } catch (e) {
      try {
        await w.abort();
      } catch {
      }
      throw e;
    }
    const expected = typeof data === "string" ? textBytes(data) : data;
    const back = await readFile(dir, name, Math.max(MAX_DB, expected.length));
    invariant(await sha256(back) === await sha256(expected), "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u043F\u0440\u043E\u0448\u043B\u0430 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C SHA-256: " + name);
  }
  async function testFolder(h) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043D\u0430 \u0437\u0430\u043F\u0438\u0441\u044C");
    const name = ".lean-test-" + uuid() + ".txt";
    await writeNew(h, name, "LEAN CENTER / TEST");
    await h.removeEntry(name);
    return true;
  }
  async function readContent(h, ref) {
    validateRef(ref);
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u043C \u0444\u0430\u0439\u043B\u0430\u043C");
    const d = await sub(h, "Documents"), bytes = await readFile(d, ref.sha256 + ".json", ref.size);
    return checkContent(ref, new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  }
  async function ensureContent(h, ref, read) {
    validateRef(ref);
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const d = await sub(h, "Documents", true), name = ref.sha256 + ".json";
    let exists = true;
    try {
      await d.getFileHandle(name);
    } catch (e) {
      if (e.name !== "NotFoundError") throw e;
      exists = false;
    }
    if (exists) {
      await readContent(h, ref);
      return;
    }
    invariant(typeof read === "function", "\u041D\u0435\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 " + ref.sha256);
    const text2 = await checkContent(ref, await read(ref));
    try {
      await writeNew(d, name, text2);
    } catch (e) {
      if (!String(e.message).startsWith("\u0424\u0430\u0439\u043B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442:")) throw e;
    }
    await readContent(h, ref);
  }
  async function sendPackage(h, p, read) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    for (const ref of refsForEvents(p.events)) await ensureContent(h, ref, read);
    const d = await sub(h, "Exchange", true);
    await writeNew(d, "change-" + p.id + ".leanpkg", canonical(p));
  }
  async function listPackages(h) {
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    let d;
    try {
      d = await sub(h, "Exchange");
    } catch (e) {
      if (e.name === "NotFoundError") return [];
      throw e;
    }
    const result = [];
    for await (const [name, entry] of d.entries()) {
      if (entry.kind !== "file" || !/^change-[0-9a-f-]+\.leanpkg$/i.test(name)) continue;
      try {
        const p = JSON.parse(new TextDecoder().decode(await readFile(d, name, MAX_PACKAGE)));
        invariant(name === "change-" + p.id + ".leanpkg", "\u0418\u043C\u044F \u043F\u0430\u043A\u0435\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 ID");
        result.push({ name, p });
      } catch (e) {
        result.push({ name, error: e.message });
      }
    }
    return result.sort((a, b) => (a.p?.created_at || "").localeCompare(b.p?.created_at || ""));
  }
  async function latestSnapshot(h, SQL2, databaseId = null) {
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    let d;
    try {
      d = await sub(h, "Database");
    } catch (e) {
      if (e.name === "NotFoundError") return null;
      throw e;
    }
    const manifests = [];
    for await (const [name, entry] of d.entries()) {
      if (entry.kind !== "file" || !/^publication-[0-9a-f-]+\.json$/i.test(name)) continue;
      const m = JSON.parse(new TextDecoder().decode(await readFile(d, name, 65536)));
      invariant(name === "publication-" + m.id + ".json", "\u0418\u043C\u044F \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
      if (!databaseId || m.database_id === databaseId) manifests.push(m);
    }
    if (!manifests.length) return null;
    invariant(new Set(manifests.map((m) => m.database_id)).size === 1, "\u0412 \u043F\u0430\u043F\u043A\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0431\u0430\u0437. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0439.");
    const ids = new Set(manifests.map((m) => m.id)), parents = new Set(manifests.map((m) => m.parent_id));
    const heads = manifests.filter((m) => !parents.has(m.id));
    invariant(heads.length === 1, "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u043F\u0430\u0440\u0430\u043B\u043B\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0430\u0437\u0431\u043E\u0440");
    const head = heads[0];
    const seen = /* @__PURE__ */ new Set();
    let node = head;
    while (node) {
      invariant(!seen.has(node.id), "\u0426\u0438\u043A\u043B \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
      seen.add(node.id);
      node = node.parent_id ? manifests.find((m) => m.id === node.parent_id) : null;
    }
    invariant(seen.size === ids.size, "\u0420\u0430\u0437\u043E\u0440\u0432\u0430\u043D\u0430 \u0446\u0435\u043F\u043E\u0447\u043A\u0430 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
    const bytes = await readFile(d, "snapshot-" + head.id + ".sqlite");
    const db = await readSnapshot(SQL2, head, bytes);
    return { manifest: head, db, bytes };
  }
  async function publishSnapshot(h, SQL2, snapshot, read) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const current = await latestSnapshot(h, SQL2);
    try {
      invariant(!current ? snapshot.manifest.parent_id === null : current.manifest.database_id === snapshot.manifest.database_id && current.manifest.id === snapshot.manifest.parent_id, "\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u0431\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u044D\u0442\u043E \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0435\u0451.");
    } finally {
      current?.db.close();
    }
    const checked = await readSnapshot(SQL2, snapshot.manifest, snapshot.bytes);
    try {
      for (const ref of refsForDb(checked)) await ensureContent(h, ref, read);
    } finally {
      checked.close();
    }
    const d = await sub(h, "Database", true);
    await writeNew(d, "snapshot-" + snapshot.manifest.id + ".sqlite", snapshot.bytes);
    await writeNew(d, "publication-" + snapshot.manifest.id + ".json", canonical(snapshot.manifest));
    const verified = await latestSnapshot(h, SQL2, snapshot.manifest.database_id);
    try {
      invariant(verified?.manifest.id === snapshot.manifest.id, "\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430");
    } finally {
      verified?.db.close();
    }
  }
  async function saveBackup(h, obj2) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const d = await sub(h, "Backups", true);
    await writeNew(d, "backup-" + uuid() + ".leanbackup", canonical(obj2));
  }

  // src/modules/library/content.js
  var MAX_TRANSFER = 150 * 1024 * 1024;
  var key = (r) => "content:" + r.sha256;
  var ContentStore = class {
    constructor(getCache, getFolder) {
      this.getCache = getCache;
      this.getFolder = getFolder;
      this.memory = /* @__PURE__ */ new Map();
    }
    async put(ref, text2) {
      await checkContent(ref, text2);
      const cache2 = this.getCache();
      if (cache2) {
        const old = await load(cache2, key(ref));
        if (old !== void 0) {
          await checkContent(ref, old);
          return old;
        }
        await save(cache2, key(ref), text2);
        return text2;
      }
      const total = [...this.memory.values()].reduce((n, x) => n + x.length * 2, 0);
      invariant(this.memory.has(ref.sha256) || total + text2.length * 2 <= MAX_TRANSFER, "\u041B\u0438\u043C\u0438\u0442 \u043F\u0430\u043C\u044F\u0442\u0438 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432; \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u044D\u0448 \u0438\u043B\u0438 \u0441\u0435\u0442\u0435\u0432\u0443\u044E \u043F\u0430\u043F\u043A\u0443");
      this.memory.set(ref.sha256, text2);
      return text2;
    }
    async get(ref, { network = true } = {}) {
      validateRef(ref);
      const cache2 = this.getCache(), v = cache2 ? await load(cache2, key(ref)) : this.memory.get(ref.sha256);
      if (v !== void 0) return checkContent(ref, v);
      const h = this.getFolder();
      invariant(network && h, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043D\u0435 \u0432 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u043C \u043A\u044D\u0448\u0435. \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043E\u0431\u0449\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u043F\u043E\u043B\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.");
      const text2 = await readContent(h, ref);
      return this.put(ref, text2);
    }
  };
  async function makeTransfer(kind, payload, refs, read) {
    refs = unionRefs(refs);
    if (!refs.length) return payload;
    let size = new TextEncoder().encode(canonical(payload)).length;
    const contents = [];
    for (const ref of refs) {
      const text2 = await checkContent(ref, await read(ref));
      size += new TextEncoder().encode(JSON.stringify(text2)).length + 256;
      invariant(size <= MAX_TRANSFER - 65536, "\u041F\u043E\u043B\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 150 \u041C\u0411; \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0441\u0435\u0442\u0435\u0432\u043E\u0435 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u0441 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u043C \u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435\u043C");
      contents.push({ ref, text: text2 });
    }
    return { format: "lean-content-bundle-v1", kind, payload, contents };
  }
  function unpackTransfer(value, kind) {
    if (value?.format !== "lean-content-bundle-v1") return { payload: value, contents: [] };
    invariant(value.kind === kind && Array.isArray(value.contents) && value.contents.length <= 1e4 && Object.hasOwn(value, "payload"), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432");
    return { payload: value.payload, contents: value.contents };
  }
  async function restoreContents(contents, refs, put) {
    refs = unionRefs(refs);
    const expected = new Map(refs.map((r) => [r.sha256, r]));
    invariant(contents.length === expected.size, "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C " + expected.size + ", \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E " + contents.length);
    const seen = /* @__PURE__ */ new Set();
    for (const item of contents) {
      invariant(item && typeof item === "object" && Object.keys(item).length === 2, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u044D\u043B\u0435\u043C\u0435\u043D\u0442 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442\u0430");
      const ref = validateRef(item.ref), match = expected.get(ref.sha256);
      invariant(match && canonical(match) === canonical(ref) && !seen.has(ref.sha256), "\u041B\u0438\u0448\u043D\u0438\u0439, \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u044B\u0439 \u0438\u043B\u0438 \u043D\u0435\u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u0439\u043B");
      seen.add(ref.sha256);
      await checkContent(ref, item.text);
    }
    for (const item of contents) await put(item.ref, item.text);
  }

  // src/modules/master-data/import-xlsx.js
  var MAX_ROWS = 1e3;
  var MAX_COLUMNS = 100;
  var MAX_XLSX = 20 * 1024 * 1024;
  var MAX_EXPANDED = 100 * 1024 * 1024;
  var normalized = (s) => foldKey(s).replace(/[^\p{L}\p{N}]+/gu, "");
  function fieldLabel(type, key2) {
    const f = definitions[type].fields[key2];
    if (f.ref) {
      if (f.ref === "person") return "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430";
      if (f.ref === "skill_category") return "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438";
      if (f.ref === "equipment") return "\u041A\u043E\u0434 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F";
      if (f.ref === "operation") return "\u041A\u043E\u0434 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 (\u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435/\u043A\u043E\u0434)";
      return "\u041A\u043E\u0434 " + { org_unit: key2 === "parent_id" ? "\u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F" : "\u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F", profession: "\u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438", position: "\u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438", work_shift: "\u0441\u043C\u0435\u043D\u044B", business_role: "\u0440\u043E\u043B\u0438", workplace: "\u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430" }[f.ref];
    }
    return f.label;
  }
  function importFields(type) {
    return Object.entries(definitions[type].fields).filter(([, f]) => !f.legacy);
  }
  function autoMap(type, headers) {
    const result = {};
    const used = /* @__PURE__ */ new Set();
    for (const [key2, f] of importFields(type)) {
      const aliases = [key2, fieldLabel(type, key2), f.label];
      if (key2 === "display_name") aliases.push("\u0424\u0418\u041E", "\u0424\u0430\u043C\u0438\u043B\u0438\u044F \u0418\u043C\u044F \u041E\u0442\u0447\u0435\u0441\u0442\u0432\u043E", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A");
      if (key2 === "employee_code") aliases.push("\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439", "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u2116", "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440");
      if (key2 === "name") aliases.push("\u041D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435");
      const exact3 = headers.filter((h) => !used.has(h.col) && aliases.some((a) => normalized(a) === normalized(h.name)));
      if (exact3.length === 1) {
        result[key2] = exact3[0].col;
        used.add(exact3[0].col);
      }
    }
    return result;
  }
  function checkXlsxContainer(buffer) {
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    invariant(bytes.length >= 22 && bytes.length <= MAX_XLSX, "XLSX \u0434\u043E 20 \u041C\u0411");
    const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let end = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
      if (v.getUint32(i, true) === 101010256 && i + 22 + v.getUint16(i + 20, true) === bytes.length) {
        end = i;
        break;
      }
    }
    invariant(end >= 0, "\u0424\u0430\u0439\u043B \u043D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043E\u0431\u044B\u0447\u043D\u044B\u043C XLSX (ZIP)");
    invariant(v.getUint16(end + 4, true) === 0 && v.getUint16(end + 6, true) === 0, "\u041C\u043D\u043E\u0433\u043E\u0442\u043E\u043C\u043D\u044B\u0439 ZIP \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F");
    const n = v.getUint16(end + 10, true), size = v.getUint32(end + 12, true), start = v.getUint32(end + 16, true);
    invariant(n === v.getUint16(end + 8, true) && n > 0 && n <= 2e3 && start + size === end, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u0430\u0442\u0430\u043B\u043E\u0433 XLSX");
    let p = start, total = 0;
    const names = /* @__PURE__ */ new Set();
    for (let i = 0; i < n; i++) {
      invariant(p + 46 <= end && v.getUint32(p, true) === 33639248, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u043A\u0430\u0442\u0430\u043B\u043E\u0433 XLSX");
      const flags = v.getUint16(p + 8, true), method = v.getUint16(p + 10, true), uncompressed = v.getUint32(p + 24, true), len = v.getUint16(p + 28, true), extra = v.getUint16(p + 30, true), comment = v.getUint16(p + 32, true);
      invariant(!(flags & 1) && [0, 8].includes(method) && p + 46 + len + extra + comment <= end, "\u041D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0439 ZIP");
      const name = new TextDecoder().decode(bytes.subarray(p + 46, p + 46 + len));
      invariant(!names.has(name) && !name.split("/").includes(".."), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0438\u043B\u0438 \u043D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u043F\u0443\u0442\u044C \u0432 ZIP");
      names.add(name);
      total += uncompressed;
      invariant(total <= MAX_EXPANDED, "\u0420\u0430\u0441\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0439 XLSX \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 100 \u041C\u0411");
      p += 46 + len + extra + comment;
    }
    invariant(p === end && names.has("[Content_Types].xml") && names.has("xl/workbook.xml"), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 XLSX");
    invariant(![...names].some((n2) => /vbaProject\.bin|externalLinks\//i.test(n2)), "\u0424\u0430\u0439\u043B\u044B \u0441 \u043C\u0430\u043A\u0440\u043E\u0441\u0430\u043C\u0438 \u0438\u043B\u0438 \u0432\u043D\u0435\u0448\u043D\u0438\u043C\u0438 \u0441\u0432\u044F\u0437\u044F\u043C\u0438 \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044E\u0442\u0441\u044F");
  }
  async function loadWorkbook(ExcelJS, buffer) {
    invariant(ExcelJS?.Workbook, "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 ExcelJS \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430");
    checkXlsxContainer(buffer);
    const book = new ExcelJS.Workbook();
    await book.xlsx.load(buffer);
    invariant(book.worksheets.length > 0 && book.worksheets.length <= 50, "\u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u043E\u0442 1 \u0434\u043E 50 \u043B\u0438\u0441\u0442\u043E\u0432");
    return book;
  }
  function sheetHeaders(sheet, row = 1) {
    invariant(Number.isInteger(row) && row >= 1 && row <= 20, "\u0421\u0442\u0440\u043E\u043A\u0430 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u043E\u0432: 1\u201320");
    invariant(sheet.columnCount <= MAX_COLUMNS, "\u041B\u0438\u0441\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0431\u043E\u043B\u0435\u0435 100 \u043A\u043E\u043B\u043E\u043D\u043E\u043A");
    const r = sheet.getRow(row), out = [];
    for (let col = 1; col <= sheet.columnCount; col++) {
      const name = r.getCell(col).text.trim();
      out.push({ col, name: name || "\u041A\u043E\u043B\u043E\u043D\u043A\u0430 " + col });
    }
    return out;
  }
  function sheetRows(sheet, headerRow, mapping) {
    invariant(sheet.rowCount - headerRow <= MAX_ROWS, "\u0412 \u043E\u0434\u043D\u043E\u043C \u0438\u043C\u043F\u043E\u0440\u0442\u0435 \u043D\u0435 \u0431\u043E\u043B\u0435\u0435 " + MAX_ROWS + " \u0441\u0442\u0440\u043E\u043A; \u0440\u0430\u0437\u0434\u0435\u043B\u0438\u0442\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u0443");
    const out = [];
    for (let n = headerRow + 1; n <= sheet.rowCount; n++) {
      const row = sheet.getRow(n), values = {};
      for (const [key2, col] of Object.entries(mapping)) if (col) values[key2] = row.getCell(col).value;
      if (Object.values(values).some((v) => v !== null && v !== void 0 && v !== "")) out.push({ row: n, values });
    }
    return out;
  }
  function cellText(v, f, key2) {
    if (v === null || v === void 0 || v === "") return null;
    if (v instanceof Date) {
      invariant(f.date && !isNaN(v.getTime()), "\u0414\u0430\u0442\u0430 \u0432 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u043E\u0439 \u043A\u043E\u043B\u043E\u043D\u043A\u0435");
      return v.toISOString().slice(0, 10);
    }
    if (typeof v === "object") {
      if (Array.isArray(v.richText)) v = v.richText.map((t) => t.text).join("");
      else throw Error("\u0424\u043E\u0440\u043C\u0443\u043B\u044B, \u043E\u0448\u0438\u0431\u043A\u0438 \u0438 \u0441\u0441\u044B\u043B\u043A\u0438 \u043D\u0435 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u044E\u0442\u0441\u044F; \u0432\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F");
    }
    if (typeof v === "number") {
      invariant(f.integer, "\u041A\u043E\u0434\u044B \u0438 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0442\u0435\u043A\u0441\u0442\u043E\u043C \u0432 Excel (\u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0432\u0435\u0434\u0443\u0449\u0438\u0435 \u043D\u0443\u043B\u0438)");
      v = String(v);
    }
    invariant(typeof v === "string", "\u041D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0439 \u0442\u0438\u043F \u044F\u0447\u0435\u0439\u043A\u0438");
    v = v.trim();
    if (!v) return null;
    if (key2 === "criticality") v = { "\u043E\u0431\u044B\u0447\u043D\u0430\u044F": "normal", "\u0432\u0430\u0436\u043D\u0430\u044F": "important", "\u043A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F": "critical" }[foldKey(v)] || v;
    if (f.date) {
      const m = v.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
      if (m) v = m[3] + "-" + m[2] + "-" + m[1];
    }
    return v;
  }
  function findRef(db, ref, value, unitId) {
    if (!value) return null;
    let matches = list(db, ref).filter((x) => !x.archived);
    if (["equipment", "operation", "workplace"].includes(ref)) {
      let code = value, unit = unitId;
      const split = value.indexOf("/");
      if (split >= 0) {
        const u = value.slice(0, split);
        const found = list(db, "org_unit").filter((x) => !x.archived && foldKey(x.code) === foldKey(u));
        invariant(found.length === 1, "\u041D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0439/\u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u043A\u043E\u0434 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F: " + u);
        unit = found[0].id;
        code = value.slice(split + 1);
      }
      matches = matches.filter((x) => (!unit || x.unit_id === unit) && foldKey(x.code) === foldKey(code));
    } else matches = matches.filter((x) => foldKey(ref === "person" ? x.employee_code : ref === "skill_category" ? x.name : x.code) === foldKey(value));
    invariant(matches.length === 1, "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430 \u0438\u043B\u0438 \u043D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u0430 \u0441\u0441\u044B\u043B\u043A\u0430: " + definitions[ref].label + " / " + value);
    return matches[0].id;
  }
  function workspaceToken(ws2) {
    return canonical({ database: meta(ws2.base, "database_id"), publication: meta(ws2.base, "publication_id"), count: one(ws2.base, "SELECT count(*) n FROM change_event").n, pending: ws2.pending.map((e) => e.id), dirty: ws2.dirty });
  }
  function previewValue(db, f, value) {
    if (value == null) return null;
    if (!f.ref) return value;
    const v = one(db, "SELECT * FROM " + f.ref + " WHERE id=?", [value]);
    if (!v) return value;
    return (v.employee_code || v.code ? (v.employee_code || v.code) + " \u2014 " : "") + (v.display_name || v.name || value);
  }
  var statusLabels = { create: "\u0421\u043E\u0437\u0434\u0430\u0442\u044C", update: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C", same: "\u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", error: "\u041E\u0448\u0438\u0431\u043A\u0430" };
  function planImport(ws2, type, source, { allowUpdates = false } = {}) {
    invariant(Object.hasOwn(definitions, type), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A");
    invariant(!ws2.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B");
    invariant(Array.isArray(source) && source.length > 0 && source.length <= MAX_ROWS, "\u041D\u0435\u0442 \u0441\u0442\u0440\u043E\u043A \u0438\u043B\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 1000");
    const d = definitions[type], db = openDb(ws2.SQL, bytesOf(ws2.working)), results = [], events = [], seen = /* @__PURE__ */ new Map();
    try {
      const parsed = source.map((item) => {
        try {
          const v = {};
          for (const [k, raw] of Object.entries(item.values)) {
            invariant(Object.hasOwn(d.fields, k) && !d.fields[k].legacy, "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u043A\u043E\u043B\u043E\u043D\u043A\u0430 " + k);
            v[k] = cellText(raw, d.fields[k], k);
          }
          return { row: item.row, v };
        } catch (e) {
          return { row: item.row, error: e.message };
        }
      });
      if (type === "org_unit") {
        const remaining = parsed.slice(), ordered = [], known = new Set(list(db, type).map((x) => foldKey(x.code)));
        while (remaining.length) {
          const i = remaining.findIndex((x2) => x2.error || !x2.v.parent_id || known.has(foldKey(x2.v.parent_id)) || !remaining.some((y) => y.v && foldKey(y.v.code) === foldKey(x2.v.parent_id)));
          if (i < 0) {
            for (const x2 of remaining) ordered.push({ ...x2, error: "\u0426\u0438\u043A\u043B \u0438\u043B\u0438 \u043D\u0435\u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u0430\u044F \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u044C \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0439" });
            break;
          }
          const [x] = remaining.splice(i, 1);
          ordered.push(x);
          if (x.v?.code) known.add(foldKey(x.v.code));
        }
        parsed.splice(0, parsed.length, ...ordered);
      }
      for (const item of parsed) {
        const result = { row: item.row, status: "error", message: "", changes: [] };
        results.push(result);
        if (item.error) {
          result.message = item.error;
          continue;
        }
        try {
          const p = {};
          for (const [k, f] of Object.entries(d.fields)) {
            if (!Object.hasOwn(item.v, k)) {
              p[k] = null;
              continue;
            }
            p[k] = f.ref ? findRef(db, f.ref, item.v[k], p.unit_id) : item.v[k];
          }
          const keys = type === "person" ? ["employee_code"] : type === "person_assignment" ? ["person_id", "valid_from"] : type === "role_assignment" ? ["person_id", "role_id", "valid_from"] : type === "skill_category" ? ["name"] : type === "skill" ? ["category_id", "name"] : type === "rating_scale" ? ["name", "version_no"] : ["equipment", "operation", "workplace"].includes(type) ? ["unit_id", "code"] : ["code"];
          invariant(keys.every((k) => p[k] != null), "\u041D\u0435 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D \u043A\u043B\u044E\u0447: " + keys.map((k) => fieldLabel(type, k)).join(", "));
          const key2 = identityKey(type, p);
          if (seen.has(key2)) {
            const previous = seen.get(key2);
            previous.status = "error";
            previous.message = "\u0414\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u043A\u043B\u044E\u0447\u0430 \u0432 \u0444\u0430\u0439\u043B\u0435 (\u0441\u0442\u0440\u043E\u043A\u0430 " + item.row + ")";
            throw Error("\u0414\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u043A\u043B\u044E\u0447\u0430 \u0432 \u0444\u0430\u0439\u043B\u0435 (\u0441\u0442\u0440\u043E\u043A\u0430 " + previous.row + ")");
          }
          seen.set(key2, result);
          const matches = list(db, type).filter((v) => identityKey(type, v) === key2);
          invariant(matches.length <= 1, "\u041D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 \u0431\u0430\u0437\u0435");
          const old = matches[0];
          invariant(!old?.archived, "\u041A\u043B\u044E\u0447 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0430\u0440\u0445\u0438\u0432\u043D\u043E\u0439 \u0437\u0430\u043F\u0438\u0441\u0438; \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u043E");
          const oldPayload = old ? recordPayload(type, old) : null;
          if (old) {
            for (const k of Object.keys(d.fields)) if (!Object.hasOwn(item.v, k)) p[k] = oldPayload[k];
          }
          if (type === "rating_scale" && p.levels) {
            p.levels = p.levels.split(/\r?\n/).filter((x) => x.trim()).map((x) => x.trim()).join("\n");
          }
          if (old && canonical(p) === canonical(oldPayload)) {
            result.status = "same";
            result.message = "\u0421\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043F\u0438\u0441\u044C\u044E \u0431\u0430\u0437\u044B";
            continue;
          }
          result.changes = Object.entries(p).filter(([k, v]) => !old || oldPayload[k] !== v).map(([k, v]) => ({ field: fieldLabel(type, k), before: previewValue(db, d.fields[k], oldPayload?.[k] ?? null), after: previewValue(db, d.fields[k], v) }));
          invariant(!old || allowUpdates, "\u041A\u043B\u044E\u0447 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442, \u0434\u0430\u043D\u043D\u044B\u0435 \u043E\u0442\u043B\u0438\u0447\u0430\u044E\u0442\u0441\u044F. \u0412\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438.");
          const e = { id: uuid(), entity_type: type, entity_id: old?.id || uuid(), operation: old ? "update" : "create", expected_revision: old?.rev || 0, payload: p, occurred_at: now() };
          tx(db, () => applyEvent(db, e));
          events.push(e);
          result.status = e.operation;
          result.message = old ? "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0439 \u0437\u0430\u043F\u0438\u0441\u0438" : "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430 \u043D\u043E\u0432\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C";
        } catch (e) {
          result.message = e.message;
        }
      }
      results.sort((a, b) => a.row - b.row);
      const counts = Object.fromEntries(Object.keys(statusLabels).map((k) => [k, results.filter((x) => x.status === k).length]));
      return { type, token: workspaceToken(ws2), results, counts, events: counts.error ? [] : events };
    } finally {
      db.close();
    }
  }
  function commitImport(ws2, plan) {
    invariant(plan && plan.counts.error === 0 && plan.events.length > 0, "\u041D\u0435\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 \u0434\u043B\u044F \u0438\u043C\u043F\u043E\u0440\u0442\u0430");
    invariant(plan.token === workspaceToken(ws2), "\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C; \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u0441\u043D\u043E\u0432\u0430");
    return ws2.applyBatch(plan.events);
  }
  async function makeTemplate(ExcelJS, type) {
    const book = new ExcelJS.Workbook(), sheet = book.addWorksheet(definitions[type].label.slice(0, 31));
    sheet.columns = importFields(type).map(([k, f]) => ({ header: fieldLabel(type, k), key: k, width: f.multiline ? 55 : f.ref ? 26 : 28, style: { numFmt: "@" } }));
    sheet.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
    sheet.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242E40" } };
    sheet.views = [{ state: "frozen", ySplit: 1 }];
    const guide = book.addWorksheet("\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F");
    guide.getColumn(1).width = 100;
    for (const t of ["\u0417\u0430\u043F\u043E\u043B\u043D\u044F\u0439\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0435\u0440\u0432\u044B\u0439 \u043B\u0438\u0441\u0442. \u041D\u0435 \u043C\u0435\u043D\u044F\u0439\u0442\u0435 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u0438 \u0431\u0435\u0437 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F.", "\u041A\u043E\u0434\u044B \u0438 \u0442\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0435 \u043D\u043E\u043C\u0435\u0440\u0430 \u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u043A\u0430\u043A \u0442\u0435\u043A\u0441\u0442, \u0434\u0430\u0442\u044B \u2014 YYYY-MM-DD \u0438\u043B\u0438 \u0434\u0430\u0442\u044B Excel.", "\u0421\u0441\u044B\u043B\u043A\u0438: \u043A\u043E\u0434\u044B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432. \u0414\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043C\u043E\u0436\u043D\u043E \u0443\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435/\u043A\u043E\u0434.", "\u0428\u043A\u0430\u043B\u0430: \u0443\u0440\u043E\u0432\u043D\u0438 \u0432 \u043E\u0434\u043D\u043E\u0439 \u044F\u0447\u0435\u0439\u043A\u0435, \u043A\u0430\u0436\u0434\u044B\u0439 \u0441 \u043D\u043E\u0432\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0438: 0: \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435.", "\u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043A\u043B\u044E\u0447\u0438 \u043D\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0431\u0435\u0437 \u044F\u0432\u043D\u043E\u0433\u043E \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F. \u0412\u0441\u0435 \u043E\u0448\u0438\u0431\u043A\u0438 \u0431\u043B\u043E\u043A\u0438\u0440\u0443\u044E\u0442 \u0438\u043C\u043F\u043E\u0440\u0442."]) guide.addRow([t]);
    return book.xlsx.writeBuffer();
  }

  // src/analytics/palette.js
  var labels = Object.freeze({
    actual: "\u0424\u0430\u043A\u0442",
    comparison: "\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435",
    compliant: "\u0421\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442",
    attention: "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044F",
    risk: "\u0420\u0438\u0441\u043A / \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435",
    critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435",
    plan: "\u041F\u043B\u0430\u043D",
    not_assessed: "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E",
    not_applicable: "\u041D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E"
  });
  var palettes = {
    light: {
      surface: "#FFFFFF",
      text: "#5B626E",
      grid: "#DADDDF",
      actual: "#242E40",
      comparison: "#2563EB",
      compliant: "#27965A",
      attention: "#A17600",
      risk: "#C46708",
      critical: "#E30613",
      plan: "#85878C",
      unavailable: "#BFC0C0",
      unavailableOutline: "#686B71",
      categorical: ["#242E40", "#2563EB", "#687B98", "#79649A", "#476F83", "#65749E"]
    },
    dark: {
      surface: "#232B39",
      text: "#BDC6D3",
      grid: "#424E60",
      actual: "#A9BCD4",
      comparison: "#74A8FF",
      compliant: "#69CA90",
      attention: "#F0CE57",
      risk: "#FFAB62",
      critical: "#FF777F",
      plan: "#A6ADB8",
      unavailable: "#626E80",
      unavailableOutline: "#C0CAD7",
      categorical: ["#A9BCD4", "#74A8FF", "#91A7C7", "#C3A6E0", "#80C3D4", "#A5B4E8"]
    }
  };
  for (const p of Object.values(palettes)) {
    Object.freeze(p.categorical);
    Object.freeze(p);
  }
  Object.freeze(palettes);
  function analyticsPalette(dark = false) {
    return palettes[dark ? "dark" : "light"];
  }
  function registryCountChart(categories, counts, dark = false) {
    if (!Array.isArray(categories) || !Array.isArray(counts) || categories.length !== counts.length || counts.some((n) => !Number.isSafeInteger(n) || n < 0)) throw new TypeError("Invalid registry counts");
    const p = analyticsPalette(dark);
    return {
      backgroundColor: "transparent",
      animation: false,
      color: p.categorical.slice(),
      textStyle: { fontFamily: "Proxima Nova, Proxima Nova Rg, Arial, sans-serif" },
      aria: { enabled: true, description: "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439: " + categories.map((n, i) => n + " \u2014 " + counts[i]).join("; ") },
      tooltip: { trigger: "axis" },
      grid: { left: 24, right: 36, bottom: 8, top: 8, containLabel: true },
      xAxis: { type: "value", minInterval: 1, axisLabel: { color: p.text }, splitLine: { lineStyle: { color: p.grid } } },
      yAxis: { type: "category", inverse: true, data: categories.slice(), axisLabel: { color: p.text, fontSize: 11, width: 144, overflow: "truncate" }, axisLine: { show: false }, axisTick: { show: false } },
      series: [{ name: "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438", type: "bar", barMaxWidth: 20, data: counts.slice(), label: { show: true, position: "right", color: p.text }, itemStyle: { color: p.actual, borderRadius: [0, 2, 2, 0] } }]
    };
  }

  // src/app.js
  var root = document.getElementById("app");
  var SQL;
  var ws;
  var cache;
  var folder;
  var generation = 0;
  var busy = false;
  var master = false;
  var page = "home";
  var theme = false;
  var status = "\u0413\u043E\u0442\u043E\u0432\u043E";
  var error = false;
  var chart = null;
  var edit = null;
  var query = "";
  var incoming = [];
  var importState = null;
  var historyPerson = null;
  var archiveFilter = "active";
  var libraryDraft = null;
  var editorSession = null;
  var libraryFilter = "all";
  var contentStore = new ContentStore(() => cache, () => folder);
  var readContent2 = (ref) => contentStore.get(ref);
  var sourceRefs = () => unionRefs(refsForDb(ws.base), refsForEvents(ws.pending));
  var planned = { sop: "\u0421\u041E\u041F \u0438 \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430", frv: "\u0424\u0420\u0412", twi: "TWI \u0438 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", skills: "\u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438", mentoring: "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u0447\u0435\u0441\u0442\u0432\u043E", audit: "\u0410\u0443\u0434\u0438\u0442 \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F", calendar: "\u041F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435", actions: "\u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u044F", analytics: "\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430", ai: "\u0418\u0418-\u043F\u043E\u043C\u043E\u0449\u043D\u0438\u043A" };
  var labels2 = { home: "\u041E\u0431\u0437\u043E\u0440 \u0446\u0435\u043D\u0442\u0440\u0430", ...Object.fromEntries(Object.entries(definitions).map(([k, v]) => [k, v.label])), ...planned, import_xlsx: "\u0418\u043C\u043F\u043E\u0440\u0442 Excel", storage: "\u0411\u0430\u0437\u0430 \u0438 \u043E\u0431\u043C\u0435\u043D" };
  function el(tag, text2, cls) {
    const n = document.createElement(tag);
    if (text2 !== void 0) n.textContent = text2;
    if (cls) n.className = cls;
    return n;
  }
  function add(parent, ...children) {
    parent.append(...children);
    return parent;
  }
  function btn(label, fn, cls = "", disabled = false) {
    const n = el("button", label, cls);
    n.type = "button";
    n.disabled = disabled || busy;
    n.addEventListener("click", fn);
    return n;
  }
  function pane(title, ...children) {
    return add(el("section", void 0, "panel"), el("h2", title), ...children);
  }
  function message(s, bad = false) {
    status = s;
    error = bad;
    const n = document.getElementById("status");
    if (n) {
      n.textContent = s;
      n.className = "status" + (bad ? " error" : "");
    }
  }
  function navigate(p) {
    page = p;
    edit = null;
    query = "";
    historyPerson = null;
    archiveFilter = "active";
    libraryFilter = "all";
    render();
  }
  function openImport(type) {
    importState = { type, book: null, sheet: 0, header: 1, mapping: {}, allowUpdates: false, plan: null, file: "" };
    navigate("import_xlsx");
  }
  function openHistory(id) {
    navigate("person_assignment");
    historyPerson = id;
    archiveFilter = "all";
    render();
  }
  async function persist() {
    if (cache) generation = await saveWorkspace(cache, generation, ws.state());
  }
  function replace(newWs) {
    ws?.close();
    ws = newWs;
  }
  async function run(fn, { save: save2 = true } = {}) {
    if (busy) return;
    const prev = ws.state();
    busy = true;
    document.querySelectorAll("button").forEach((b) => b.disabled = true);
    message("\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F\u2026");
    try {
      const m = await fn();
      if (save2) await persist();
      message(m || "\u0413\u043E\u0442\u043E\u0432\u043E");
    } catch (e) {
      console.error(e);
      replace(new Workspace(SQL, openDb(SQL, prev.base), prev));
      message(e.message, true);
    } finally {
      busy = false;
      render();
    }
  }
  function download(name, body) {
    const url = URL.createObjectURL(new Blob([canonical(body)], { type: "application/json" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function pick(accept, fn, max = 150 * 1024 * 1024) {
    const i = el("input");
    i.type = "file";
    i.accept = accept;
    i.onchange = () => {
      const f = i.files?.[0];
      if (f) run(async () => {
        invariant(f.size <= max, "\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
        return await fn(JSON.parse(await f.text()));
      });
    };
    i.click();
  }
  var empty = () => !ws.pending.length && !ws.dirty && !meta(ws.base, "publication_id") && Object.keys(definitions).every((t) => list(ws.base, t).length === 0) && !one(ws.base, "SELECT id FROM document LIMIT 1") && !one(ws.base, "SELECT id FROM frv_study LIMIT 1");
  function refName(type, id) {
    if (!id) return "\u2014";
    const v = one(ws.working, "SELECT * FROM " + type + " WHERE id=?", [id]);
    return v?.display_name || v?.name || id;
  }
  function refOption(type, v) {
    return (v.employee_code || v.code ? (v.employee_code || v.code) + " \u2014 " : "") + (v.display_name || v.name || v.id) + (v.unit_id ? " \xB7 " + refName("org_unit", v.unit_id) : "") + (v.archived ? " (\u0430\u0440\u0445\u0438\u0432)" : "");
  }
  var today = () => {
    const d = /* @__PURE__ */ new Date();
    return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
  };
  function activeRecord(d, v) {
    return !v.archived && (!d.history || v.valid_from <= today() && (!v.valid_to || v.valid_to >= today()));
  }
  function showVal(k, f, v) {
    if (f.ref) return k === "shift_id" && !v[k] && v.shift_code ? v.shift_code + " (LC1)" : refName(f.ref, v[k]);
    if (k === "criticality") return { normal: "\u041E\u0431\u044B\u0447\u043D\u0430\u044F", important: "\u0412\u0430\u0436\u043D\u0430\u044F", critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" }[v[k]] || v[k];
    return v[k] ?? "\u2014";
  }
  var ICON_PATHS = {
    home: ["M3 10 12 3l9 7v10H3z", "M9 20v-6h6v6"],
    sop: ["M6 3h9l4 4v14H6z", "M14 3v5h5", "M9 12h7M9 16h7"],
    frv: ["M12 5a7 7 0 1 0 7 7 7 7 0 0 0-7-7z", "M12 8v4l3 2M9 2h6"],
    twi: ["M3 5h7l2 2 2-2h7v15h-7l-2 1-2-1H3z", "M12 7v14"],
    skills: ["M3 4h18v16H3z", "M3 9h18M3 14h18M9 4v16M15 4v16"],
    mentoring: ["M9 4a3 3 0 1 0 0 6 3 3 0 0 0 0-6z", "M3 20v-3c0-3 12-3 12 0v3", "M16 6h5M18.5 3.5v5"],
    audit: ["M5 4h14v17H5z", "M9 4V2h6v2", "m8 10 2 2 4-4", "M8 16h8"],
    calendar: ["M3 6h18v15H3z", "M7 3v6M17 3v6M3 10h18", "M7 14h3M14 14h3"],
    actions: ["M4 5h16v15H4z", "m7 11 3 3 6-6"],
    analytics: ["M4 3v17h17", "M8 16v-5M13 16V7M18 16V4"],
    ai: ["m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"],
    org_unit: ["M8 3h8v5H8z", "M12 8v5M4 13h16M4 13v3M20 13v3", "M2 16h5v5H2zM17 16h5v5h-5z"],
    person: ["M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z", "M4 21v-3c0-6 16-6 16 0v3"],
    profession: ["M3 7h18v13H3z", "M8 7V4h8v3M3 12h18M10 12v3h4v-3"],
    equipment: ["M3 21V9l6 4V8l6 5V4h5v17z", "M6 17h2M11 17h2M16 17h2"],
    operation: ["M4 3h16v5H4zM4 16h16v5H4z", "M12 8v8m-3-3 3 3 3-3"],
    person_assignment: ["M3 4h18v16H3z", "M7 8h4M7 12h4M7 16h4", "m14 13 2 2 4-5"],
    storage: ["M4 7c0-4 16-4 16 0v10c0 4-16 4-16 0z", "M4 7c0 4 16 4 16 0M4 12c0 4 16 4 16 0"]
  };
  function icon(key2, cls = "nav-icon") {
    const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
    for (const [k, v] of Object.entries({ viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.65", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", class: cls })) svg.setAttribute(k, v);
    for (const d of ICON_PATHS[key2] || ICON_PATHS.home) {
      const p = document.createElementNS(ns, "path");
      p.setAttribute("d", d);
      svg.append(p);
    }
    return svg;
  }
  function navButton(k) {
    const n = btn("", () => navigate(k), "nav" + (page === k ? " active" : ""));
    n.append(icon(k), el("span", labels2[k]));
    if (page === k) n.setAttribute("aria-current", "page");
    return n;
  }
  function sectionHeading(title, caption) {
    return add(el("div", void 0, "section-heading"), el("h2", title), el("span", caption, "muted"));
  }
  function home(main) {
    main.append(sectionHeading("\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F", "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"));
    const g = el("div", void 0, "kpi-grid");
    const counts = Object.fromEntries(Object.keys(definitions).map((k) => [k, list(ws.working, k).filter((x) => activeRecord(definitions[k], x)).length]));
    for (const k of ["org_unit", "person", "profession", "position", "equipment", "operation"]) {
      const d = definitions[k], n = btn("", () => navigate(k), "tile");
      n.setAttribute("aria-label", d.label + ": " + counts[k]);
      add(n, add(el("div", void 0, "tile-head"), el("span", d.label, "muted"), icon(k, "tile-icon")), el("b", String(counts[k])), el("span", "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u2192", "tile-link"));
      g.append(n);
    }
    main.append(g);
    main.append(add(el("div", void 0, "row registry-shortcuts"), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432 \u0438\u0437 Excel", () => openImport("person"), "primary"), btn("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", () => navigate("person_assignment")), btn("\u0428\u043A\u0430\u043B\u044B \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u043D\u0438\u044F", () => navigate("rating_scale"))));
    const c = el("div", void 0, "chart");
    c.style.height = Math.max(290, Object.keys(definitions).length * 29) + "px";
    main.append(pane("\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432", c));
    if (window.echarts) {
      chart = echarts.init(c, theme ? "dark" : null);
      chart.setOption(registryCountChart(Object.values(definitions).map((x) => x.label), Object.keys(definitions).map((k) => counts[k]), theme));
    }
    const links = el("div", void 0, "workspace-grid");
    for (const [k, n] of Object.entries(planned)) {
      const b = btn("", () => navigate(k), "workspace-link");
      b.append(icon(k), el("span", n));
      links.append(b);
    }
    main.append(pane("\u0420\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u043E\u0434\u0443\u043B\u0438", el("p", "\u0421\u041E\u041F, \u0424\u0420\u0412, TWI, \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438, \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0438 \u0430\u0443\u0434\u0438\u0442 \u2014 \u0440\u0430\u0432\u043D\u043E\u043F\u0440\u0430\u0432\u043D\u044B\u0435 \u043C\u043E\u0434\u0443\u043B\u0438 \u0446\u0435\u043D\u0442\u0440\u0430. \u0414\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0431\u0430\u0437\u0430, \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438, \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0421\u041E\u041F \u0438 \u0424\u0420\u0412. \u041E\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u043C\u043E\u0434\u0443\u043B\u0438 \u0431\u0443\u0434\u0443\u0442 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0430\u0442\u044C\u0441\u044F \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E.", "muted"), links));
  }
  function form(type, v) {
    const d = definitions[type], f = el("form"), grid = el("div", void 0, "formgrid"), controls = {};
    for (const [k, x] of Object.entries(d.fields)) {
      let input;
      const initial = v?.[k] ?? (k === "criticality" ? "normal" : k === "kind" ? "\u0423\u0447\u0430\u0441\u0442\u043E\u043A" : k === "valid_from" ? today() : k === "version_no" ? "1" : "");
      if (x.legacy) {
        input = el("input");
        input.type = "hidden";
        input.name = k;
        input.value = initial;
        controls[k] = input;
        grid.append(input);
        if (initial) grid.append(add(el("div", void 0, "field"), el("span", x.label), el("p", initial, "muted")));
        continue;
      }
      if (x.ref || x.options) {
        input = el("select");
        const option = el("option", "\u2014");
        option.value = "";
        input.append(option);
        const opts = x.ref ? list(ws.working, x.ref).filter((y) => !y.archived || v?.[k] === y.id).map((y) => [y.id, refOption(x.ref, y)]) : x.options.map((y) => [y, y === "normal" ? "\u041E\u0431\u044B\u0447\u043D\u0430\u044F" : y === "important" ? "\u0412\u0430\u0436\u043D\u0430\u044F" : y === "critical" ? "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" : y]);
        for (const [value, label] of opts) {
          const o = el("option", label);
          o.value = value;
          input.append(o);
        }
      } else if (x.multiline) {
        input = el("textarea");
        input.rows = 5;
        input.maxLength = 5e3;
        input.placeholder = "0: \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u044F\n1: \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u044F";
      } else {
        input = el("input");
        input.type = x.date ? "date" : x.integer ? "number" : "text";
        input.maxLength = 500;
        if (x.integer) {
          input.min = "1";
          input.step = "1";
        }
      }
      input.name = k;
      input.required = !!x.required;
      input.value = initial;
      controls[k] = input;
      if (d.history && v?.id && k !== "valid_to") input.disabled = true;
      if (d.history && v?.valid_to && k === "valid_to") input.disabled = true;
      grid.append(add(el("label", void 0, "field"), el("span", x.label), input));
    }
    const submit = el("button", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C", "primary");
    submit.type = "submit";
    submit.disabled = busy;
    f.onsubmit = (e) => {
      e.preventDefault();
      const payload = Object.fromEntries(Object.entries(controls).map(([k, n]) => [k, n.value || null]));
      run(async () => {
        ws.edit(type, v?.id || null, payload);
        edit = null;
        return "\u0417\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
      });
    };
    if (d.history && v?.id) f.append(el("p", "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430: \u043C\u043E\u0436\u043D\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u0437\u0430\u043A\u0440\u044B\u0442\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0434\u0430\u0442\u043E\u0439 \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F. \u0414\u043B\u044F \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E\u0441\u043B\u0435 \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u044F.", "muted"));
    if (type === "rating_scale") f.append(el("p", "\u041F\u043E\u0441\u043B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0448\u043A\u0430\u043B\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430. \u0414\u043B\u044F \u043D\u043E\u0432\u043E\u0439 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E. \u0423\u0440\u043E\u0432\u043D\u0438 \u0437\u0430\u0434\u0430\u044E\u0442\u0441\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u043C; \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0438\u0435 \u043F\u043E\u0440\u043E\u0433\u0438 \u043D\u0435 \u043F\u0440\u0435\u0434\u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u044B.", "muted"));
    return add(f, grid, add(el("div", void 0, "row"), submit, btn("\u041E\u0442\u043C\u0435\u043D\u0430", () => {
      edit = null;
      render();
    })));
  }
  function orgTree(panel, items) {
    const box = el("div", void 0, "org-tree"), children = /* @__PURE__ */ new Map();
    for (const v of items) {
      const k = v.parent_id || "";
      if (!children.has(k)) children.set(k, []);
      children.get(k).push(v);
    }
    const seen = /* @__PURE__ */ new Set();
    function walk(id, depth) {
      for (const v of children.get(id) || []) {
        if (seen.has(v.id)) continue;
        seen.add(v.id);
        const line = add(el("div", void 0, "org-node"), el("span", v.code, "pill"), el("span", v.name), el("span", v.kind + (v.archived ? " \xB7 \u0410\u0440\u0445\u0438\u0432" : ""), "muted"));
        line.style.paddingLeft = Math.min(depth, 8) * 17 + "px";
        box.append(line);
        walk(v.id, depth + 1);
      }
    }
    walk("", 0);
    for (const v of items.filter((x) => !seen.has(x.id))) box.append(el("p", v.code + " \u2014 " + v.name + " (\u043D\u0435\u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u0439 \u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044C)", "warn"));
    if (items.length) panel.append(pane("\u0418\u0435\u0440\u0430\u0440\u0445\u0438\u044F \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F", box));
  }
  function registry(main, type) {
    const d = definitions[type], items = list(ws.working, type), search = el("input");
    search.type = "search";
    search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0443";
    search.value = query;
    const filter = el("select");
    for (const [value, label] of [["active", d.history ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435" : "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435"], ["all", "\u0412\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"], ["inactive", d.history ? "\u0418\u0441\u0442\u043E\u0440\u0438\u044F / \u0431\u0443\u0434\u0443\u0449\u0438\u0435" : "\u0410\u0440\u0445\u0438\u0432"]]) {
      const o = el("option", label);
      o.value = value;
      filter.append(o);
    }
    filter.value = archiveFilter;
    const panel = pane(d.label, add(el("div", void 0, "row"), search, filter, btn("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C", () => {
      edit = historyPerson ? { person_id: historyPerson } : {};
      render();
    }, "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 Excel", () => openImport(type))));
    main.append(panel);
    if (historyPerson) panel.append(add(el("div", void 0, "row"), el("span", "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430: " + refName("person", historyPerson), "pill"), btn("\u0412\u0441\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438", () => {
      historyPerson = null;
      render();
    })));
    if (edit !== null) panel.append(pane(edit.id ? "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435" : "\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C", form(type, edit)));
    const wrap = el("div", void 0, "tablewrap");
    panel.append(wrap);
    function draw() {
      wrap.replaceChildren();
      const data = items.filter((v) => (!historyPerson || v.person_id === historyPerson) && (archiveFilter === "all" || (archiveFilter === "active" ? activeRecord(d, v) : !activeRecord(d, v))) && Object.entries(d.fields).some(([k, f]) => String(showVal(k, f, v)).toLowerCase().includes(query.toLowerCase())));
      if (!data.length) {
        wrap.append(el("p", "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439", "empty"));
        return;
      }
      const fields = Object.entries(d.fields).filter(([, f]) => !f.legacy);
      const t = el("table"), head = el("tr");
      for (const [, f] of fields) head.append(el("th", f.label));
      head.append(el("th", "\u0412\u0435\u0440\u0441\u0438\u044F / \u0441\u0442\u0430\u0442\u0443\u0441"), el("th", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F"));
      t.append(add(el("thead"), head));
      const body = el("tbody");
      for (const v of data) {
        const tr = el("tr", void 0, !activeRecord(d, v) ? "archive" : "");
        for (const [k, f] of fields) tr.append(el("td", String(showVal(k, f, v)), f.multiline ? "multiline-cell" : ""));
        const state = v.archived ? "\u0410\u0440\u0445\u0438\u0432" : d.history ? v.valid_from > today() ? "\u0411\u0443\u0434\u0443\u0449\u0435\u0435" : v.valid_to && v.valid_to < today() ? "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E" : "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u0410\u043A\u0442\u0438\u0432\u043D\u043E";
        tr.append(el("td", state + " \xB7 v" + v.rev));
        const a = el("td");
        if (!v.archived) {
          if (!d.immutable && (!d.history || !v.valid_to)) a.append(btn(d.history ? "\u0417\u0430\u043A\u0440\u044B\u0442\u044C / \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C" : "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C", () => {
            edit = v;
            render();
          }, "", !!ws.conflicts.length));
          if (d.immutable) a.append(btn("\u041D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F", () => {
            edit = { name: v.name, version_no: String(Math.max(...items.filter((x) => x.name === v.name).map((x) => x.version_no)) + 1), levels: v.levels };
            render();
          }, "", !!ws.conflicts.length));
          if (!d.history) a.append(btn("\u0410\u0440\u0445\u0438\u0432", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C? \u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F.")) run(async () => {
              ws.edit(type, v.id, null, "archive");
              return "\u0417\u0430\u043F\u0438\u0441\u044C \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
            });
          }, "danger", !!ws.conflicts.length));
          if (type === "person") {
            a.append(btn("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F", () => openHistory(v.id)));
            a.append(btn("\u0420\u043E\u043B\u0438", () => {
              navigate("role_assignment");
              historyPerson = v.id;
              archiveFilter = "all";
              render();
            }));
          }
        }
        tr.append(a);
        body.append(tr);
      }
      t.append(body);
      wrap.append(t);
    }
    search.oninput = () => {
      query = search.value;
      draw();
    };
    filter.onchange = () => {
      archiveFilter = filter.value;
      draw();
    };
    draw();
    if (type === "org_unit") orgTree(panel, items);
  }
  function downloadBytes(name, bytes) {
    const url = URL.createObjectURL(new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function updateMapping(s) {
    s.plan = null;
    s.mapping = s.book ? autoMap(s.type, sheetHeaders(s.book.worksheets[s.sheet], s.header)) : {};
  }
  function importScreen(main) {
    const s = importState || (importState = { type: "person", book: null, sheet: 0, header: 1, mapping: {}, allowUpdates: false, plan: null, file: "" });
    const kind = el("select");
    kind.name = "import_type";
    for (const [key2, d] of Object.entries(definitions)) {
      const o = el("option", d.label);
      o.value = key2;
      kind.append(o);
    }
    kind.value = s.type;
    kind.onchange = () => {
      s.type = kind.value;
      try {
        updateMapping(s);
      } catch (e) {
        message(e.message, true);
        s.mapping = {};
      }
      render();
    };
    const load2 = el("input");
    load2.type = "file";
    load2.accept = ".xlsx";
    load2.name = "import_file";
    load2.onchange = () => {
      const f = load2.files?.[0];
      if (!f) return;
      run(async () => {
        invariant(/\.xlsx$/i.test(f.name) && f.size <= MAX_XLSX, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 XLSX \u0434\u043E 20 \u041C\u0411");
        const book = await loadWorkbook(window.ExcelJS, await f.arrayBuffer());
        s.book = book;
        s.file = f.name;
        s.sheet = 0;
        s.header = 1;
        updateMapping(s);
        return "Excel \u043E\u0442\u043A\u0440\u044B\u0442. \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u043A\u043E\u043B\u043E\u043D\u043E\u043A.";
      }, { save: false });
    };
    const setup = pane("1. \u0412\u044B\u0431\u043E\u0440 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u0438 \u0444\u0430\u0439\u043B\u0430", add(el("div", void 0, "formgrid"), add(el("label", void 0, "field"), el("span", "\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A"), kind), add(el("label", void 0, "field"), el("span", "Excel (.xlsx)"), load2)), add(el("div", void 0, "row"), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D XLSX", () => run(async () => {
      downloadBytes("LeanCenter-" + s.type + ".xlsx", await makeTemplate(window.ExcelJS, s.type));
      return "\u0428\u0430\u0431\u043B\u043E\u043D \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false })), btn("\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0438\u043C\u043F\u043E\u0440\u0442", () => openImport(s.type))), el("p", s.file ? "\u041E\u0442\u043A\u0440\u044B\u0442 \u0444\u0430\u0439\u043B: " + s.file : "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u0430\u0439\u043B. \u0414\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u0442\u0441\u044F \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0438\u043C\u043F\u043E\u0440\u0442\u0430.", "muted"));
    main.append(setup);
    if (!s.book) return;
    const select = el("select");
    select.name = "import_sheet";
    for (const [i, sheet] of s.book.worksheets.entries()) {
      const o = el("option", sheet.name);
      o.value = String(i);
      select.append(o);
    }
    select.value = String(s.sheet);
    select.onchange = () => {
      s.sheet = Number(select.value);
      try {
        updateMapping(s);
      } catch (e) {
        message(e.message, true);
        s.mapping = {};
      }
      render();
    };
    const hdr = el("input");
    hdr.type = "number";
    hdr.name = "header_row";
    hdr.min = 1;
    hdr.max = 20;
    hdr.value = s.header;
    hdr.onchange = () => {
      const v = Number(hdr.value);
      if (Number.isInteger(v) && v >= 1 && v <= 20) {
        s.header = v;
        try {
          updateMapping(s);
        } catch (e) {
          message(e.message, true);
          s.mapping = {};
        }
        render();
      }
    };
    const updates = el("input");
    updates.type = "checkbox";
    updates.name = "allow_updates";
    updates.checked = s.allowUpdates;
    updates.onchange = () => {
      s.allowUpdates = updates.checked;
      s.plan = null;
      render();
    };
    const mapPanel = pane("2. \u041B\u0438\u0441\u0442 \u0438 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u043A\u043E\u043B\u043E\u043D\u043E\u043A", add(el("div", void 0, "formgrid"), add(el("label", void 0, "field"), el("span", "\u041B\u0438\u0441\u0442"), select), add(el("label", void 0, "field"), el("span", "\u0421\u0442\u0440\u043E\u043A\u0430 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u043E\u0432 (1\u201320)"), hdr)), el("p", "\u041A\u043E\u0434\u044B \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0442\u0435\u043A\u0441\u0442\u043E\u043C \u0432 Excel. \u0421\u0441\u044B\u043B\u043A\u0438 \u2014 \u043F\u043E \u043A\u043E\u0434\u0430\u043C, \u043D\u0435 \u043F\u043E \u0424\u0418\u041E. \u0414\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435/\u043A\u043E\u0434. \u041D\u0435\u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044B\u0435 \u043A\u043E\u043B\u043E\u043D\u043A\u0438 \u043F\u0440\u0438 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442 \u043F\u0440\u0435\u0436\u043D\u0435\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435. \u041F\u0443\u0441\u0442\u0430\u044F \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u0430\u044F \u043A\u043E\u043B\u043E\u043D\u043A\u0430 \u043E\u0447\u0438\u0449\u0430\u0435\u0442 \u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043F\u043E\u043B\u0435.", "muted"));
    main.append(mapPanel);
    let headers;
    try {
      headers = sheetHeaders(s.book.worksheets[s.sheet], s.header);
    } catch (e) {
      mapPanel.append(el("p", e.message, "bad"));
      return;
    }
    const grid = el("div", void 0, "formgrid");
    for (const [key2, f] of importFields(s.type)) {
      const input = el("select");
      input.name = "map_" + key2;
      const blank = el("option", "\u2014 \u041D\u0435 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u2014");
      blank.value = "";
      input.append(blank);
      for (const h of headers) {
        const o = el("option", h.col + " \xB7 " + h.name);
        o.value = String(h.col);
        input.append(o);
      }
      input.value = String(s.mapping[key2] || "");
      input.onchange = () => {
        s.mapping[key2] = Number(input.value) || null;
        s.plan = null;
        render();
      };
      grid.append(add(el("label", void 0, "field"), el("span", fieldLabel(s.type, key2) + (f.required ? " *" : "")), input));
    }
    mapPanel.append(grid, add(el("label", void 0, "row"), updates, el("span", "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u044C \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0449\u0438\u0445 \u043A\u043B\u044E\u0447\u0435\u0439 (\u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430)")), btn("\u041F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430", () => run(async () => {
      const cols = Object.values(s.mapping).filter(Boolean);
      invariant(cols.length > 0 && new Set(cols).size === cols.length, "\u041D\u0430\u0437\u043D\u0430\u0447\u044C\u0442\u0435 \u043A\u0430\u0436\u0434\u043E\u0439 \u043A\u043E\u043B\u043E\u043D\u043A\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043E\u0434\u043D\u043E \u043F\u043E\u043B\u0435");
      s.plan = planImport(ws, s.type, sheetRows(s.book.worksheets[s.sheet], s.header, s.mapping), { allowUpdates: s.allowUpdates });
      return "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0433\u043E\u0442\u043E\u0432. \u0417\u0430\u043F\u0438\u0441\u044C \u0432 \u0431\u0430\u0437\u0443 \u0435\u0449\u0451 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430.";
    }, { save: false }), "primary"));
    if (!s.plan) return;
    const p = s.plan, c = p.counts;
    const report = pane("3. \u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438", add(el("div", void 0, "row"), el("span", "\u0421\u043E\u0437\u0434\u0430\u0442\u044C: " + c.create, "pill"), el("span", "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C: " + c.update, "pill"), el("span", "\u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439: " + c.same, "pill"), el("span", "\u041E\u0448\u0438\u0431\u043A\u0438: " + c.error, c.error ? "bad" : "pill")));
    const t = el("table"), head = el("tr");
    for (const h of ["\u0421\u0442\u0440\u043E\u043A\u0430 Excel", "\u0420\u0435\u0448\u0435\u043D\u0438\u0435", "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 / \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F"]) head.append(el("th", h));
    t.append(add(el("thead"), head));
    const body = el("tbody");
    for (const v of p.results) {
      const details = el("div");
      details.append(el("div", v.message, v.status === "error" ? "bad" : "muted"));
      for (const ch of v.changes) {
        details.append(el("div", ch.field + ": " + (ch.before ?? "\u2014") + " \u2192 " + (ch.after ?? "\u2014"), "preview-detail"));
      }
      body.append(add(el("tr"), el("td", String(v.row)), el("td", { create: "\u0421\u043E\u0437\u0434\u0430\u0442\u044C", update: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C", same: "\u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", error: "\u041E\u0448\u0438\u0431\u043A\u0430" }[v.status]), add(el("td"), details)));
    }
    t.append(body);
    report.append(add(el("div", void 0, "tablewrap"), t), el("p", c.error ? "\u0418\u043C\u043F\u043E\u0440\u0442 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D. \u0418\u0441\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0432\u0441\u0435 \u043E\u0448\u0438\u0431\u043A\u0438 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443." : "\u0411\u0443\u0434\u0443\u0442 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F, \u043E\u0434\u043D\u043E\u0439 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0435\u0439.", "muted"), btn("\u0418\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C " + p.events.length + " \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", () => {
      if (confirm("\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0432 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u0443\u044E \u0431\u0430\u0437\u0443?")) run(async () => {
        const n = commitImport(ws, p);
        s.plan = null;
        return "\u0418\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439: " + n;
      });
    }, "primary", !!c.error || !p.events.length || !!ws.conflicts.length));
    main.append(report);
  }
  var revisionLabels = { draft: "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A", review: "\u041D\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0438", approved: "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D", effective: "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442", superseded: "\u0417\u0430\u043C\u0435\u043D\u0451\u043D", withdrawn: "\u0412\u044B\u0432\u0435\u0434\u0435\u043D \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F", final: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E", archived: "\u0410\u0440\u0445\u0438\u0432" };
  function inputField(label, input) {
    return add(el("label", void 0, "field"), el("span", label), input);
  }
  function fieldInput(name, value = "", type = "text") {
    const n = el("input");
    n.name = name;
    n.type = type;
    n.value = value ?? "";
    return n;
  }
  function selectRef(type, name, id = null, optional = true) {
    const s = el("select");
    s.name = name;
    if (optional) {
      const o = el("option", "\u2014 \u041D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u043E \u2014");
      o.value = "";
      s.append(o);
    }
    for (const v of list(ws.working, type).filter((x) => !x.archived || x.id === id)) {
      const o = el("option", refOption(type, v));
      o.value = v.id;
      s.append(o);
    }
    s.value = id || "";
    return s;
  }
  function downloadRaw(name, text2) {
    const url = URL.createObjectURL(new Blob([text2], { type: "application/json;charset=utf-8" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function libraryContext(kind, id = null, revisionId = null) {
    const row = id ? one(ws.working, "SELECT * FROM " + (kind === "sop" ? "document" : "frv_study") + " WHERE id=?", [id]) : null;
    const revision2 = kind === "sop" && revisionId ? one(ws.working, "SELECT * FROM document_revision WHERE id=? AND document_id=?", [revisionId, id]) : null;
    invariant(!id || row, "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430");
    invariant(!revisionId || revision2, "\u0412\u0435\u0440\u0441\u0438\u044F \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430");
    return { kind, id, revisionId, expected: row?.rev || 0, database: meta(ws.base, "database_id"), title: row?.title || "", code: row?.code || "", operation_id: row?.operation_id || null, observed_at: row?.observed_at || "", command: !id ? "create" : kind === "frv" ? "save" : revision2?.state === "draft" ? "save" : "revise", source: revision2 ? JSON.parse(revision2.payload_json).source : kind === "frv" && row ? JSON.parse(row.context_json).source : null };
  }
  function assertContext(c) {
    invariant(c.database === meta(ws.base, "database_id"), "\u041E\u0442\u043A\u0440\u044B\u0442\u0430 \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u043C\u043E\u0436\u043D\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.");
    if (c.id) {
      const row = one(ws.working, "SELECT * FROM " + (c.kind === "sop" ? "document" : "frv_study") + " WHERE id=?", [c.id]);
      invariant(row && row.rev === c.expected, "\u0417\u0430\u043F\u0438\u0441\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430 \u043F\u043E\u0441\u043B\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F. \u041D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u0439\u0442\u0435 \u0435\u0451; \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 JSON \u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E.");
    }
  }
  function libraryEvent(c, payload, operation2 = c.id ? "update" : "create") {
    assertContext(c);
    return { id: uuid(), entity_type: c.kind === "sop" ? "document" : "frv_study", entity_id: c.id || uuid(), operation: operation2, expected_revision: c.expected, payload, occurred_at: (/* @__PURE__ */ new Date()).toISOString() };
  }
  async function chooseLibraryFile(kind, ctx = libraryContext(kind)) {
    if (libraryDraft) {
      message("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.", true);
      return;
    }
    const i = el("input");
    i.type = "file";
    i.accept = ".json,application/json";
    i.onchange = () => {
      const file = i.files?.[0];
      if (file) run(async () => {
        invariant(file.size <= MAX_CONTENT, "JSON \u0434\u043E 30 \u041C\u0411");
        const text2 = await file.text(), inspected = await inspectSource(text2, kind);
        assertContext(ctx);
        libraryDraft = { ctx, text: text2, ...inspected, editor: false };
        page = kind === "sop" ? "sop" : "frv";
        return "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D. \u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0441\u0432\u044F\u0437\u0438 \u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0430\u043F\u0438\u0441\u044C.";
      }, { save: false });
    };
    i.click();
  }
  function launchEditor(ctx) {
    if (libraryDraft) {
      message("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.", true);
      return;
    }
    if (editorSession && !editorSession.popup.closed) {
      editorSession.popup.focus();
      message("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u044B\u0439 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0438\u043B\u0438 \u0441\u043A\u0430\u0447\u0430\u0439\u0442\u0435 \u0435\u0433\u043E JSON.", true);
      return;
    }
    assertContext(ctx);
    const session = uuid(), url = "versions/" + LC_BUILD.version + "/editor/Stage43.html?lcSession=" + session + "&lcKind=" + ctx.kind;
    const popup = window.open(url, "lean-editor-" + session, "popup,width=1400,height=900");
    if (!popup) {
      message("\u0411\u0440\u0430\u0443\u0437\u0435\u0440 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043B \u043E\u043A\u043D\u043E \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430. \u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0432\u0441\u043F\u043B\u044B\u0432\u0430\u044E\u0449\u0438\u0435 \u043E\u043A\u043D\u0430.", true);
      return;
    }
    editorSession = { session, popup, ctx, loading: false };
    message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 Stage43 \u043E\u0442\u043A\u0440\u044B\u0442; \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u0432 \u043E\u0431\u0449\u0443\u044E \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0443 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F \u043F\u043E\u0441\u043B\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F.");
  }
  window.addEventListener("message", async (e) => {
    const s = editorSession, m = e.data;
    if (!s || e.source !== s.popup || m?.protocol !== "lean-editor-v1" || m.session !== s.session) return;
    const reply = (message2) => s.popup.postMessage({ protocol: "lean-editor-v1", session: s.session, type: "result", message: message2 }, "*");
    if (m.type === "ready" && !s.loading) {
      s.loading = true;
      try {
        assertContext(s.ctx);
        const text2 = s.ctx.source ? await readContent2(s.ctx.source) : null;
        const op = s.ctx.operation_id ? one(ws.working, "SELECT * FROM operation WHERE id=?", [s.ctx.operation_id]) : null;
        s.popup.postMessage({ protocol: "lean-editor-v1", session: s.session, type: "load", text: text2, defaults: { operation: op?.name || "", unit: op ? refName("org_unit", op.unit_id) : "" } }, "*");
      } catch (err) {
        reply(err.message);
        message(err.message, true);
      } finally {
        s.loading = false;
      }
    } else if (m.type === "source") {
      if (busy) {
        reply("\u0426\u0435\u043D\u0442\u0440 \u0437\u0430\u043D\u044F\u0442. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0443 \u0438\u043B\u0438 \u0441\u043A\u0430\u0447\u0430\u0439\u0442\u0435 JSON.");
        return;
      }
      if (m.kind !== s.ctx.kind || typeof m.text !== "string" || m.text.length > MAX_CONTENT) {
        reply("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B");
        return;
      }
      if (libraryDraft) {
        reply("\u0412 \u0446\u0435\u043D\u0442\u0440\u0435 \u0443\u0436\u0435 \u0435\u0441\u0442\u044C \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B. \u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0435\u0433\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.");
        return;
      }
      await run(async () => {
        assertContext(s.ctx);
        const inspected = await inspectSource(m.text, s.ctx.kind);
        libraryDraft = { ctx: s.ctx, text: m.text, ...inspected, editor: true };
        page = s.ctx.kind === "sop" ? "sop" : "frv";
        return "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u043F\u0435\u0440\u0435\u0434\u0430\u043B \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B. \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u0432 \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0443.";
      }, { save: false });
      if (error) reply(status);
      else reply("\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0433\u043E\u0442\u043E\u0432. \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u0432 \u043E\u0441\u043D\u043E\u0432\u043D\u043E\u043C \u043E\u043A\u043D\u0435.");
    } else if (m.type === "error") message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440: " + String(m.message || "\u043E\u0448\u0438\u0431\u043A\u0430"), true);
  });
  function sourceSummary(d) {
    const p = d.projection;
    return d.source.kind === "sop" ? "\u0428\u0430\u0433\u043E\u0432: " + p.steps.length + " \xB7 \u0424\u043E\u0442\u043E: " + p.photos + " \xB7 TWI: " + (p.twi ? "\u0435\u0441\u0442\u044C" : "\u043D\u0435\u0442") : "\u0426\u0438\u043A\u043B\u043E\u0432: " + p.cycles + " \xB7 \u041F\u043E\u043B\u043D\u044B\u0445: " + p.complete + " \xB7 \u0418\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0439: " + p.measurements.length + " \xB7 \u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F/\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F: " + p.unmeasured;
  }
  function libraryPreview(main, kind) {
    if (!libraryDraft || libraryDraft.ctx.kind !== kind) return;
    const d = libraryDraft, c = d.ctx, p = d.projection, form2 = el("form");
    const code = fieldInput("library_code", c.code || (p.number && p.number !== "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A" ? p.number : ""));
    code.required = kind === "sop" && !c.id;
    const title = fieldInput("library_title", c.title || p.title);
    title.required = true;
    title.maxLength = 500;
    const op = selectRef("operation", "library_operation", c.operation_id);
    const observed = fieldInput("library_observed", c.observed_at, "date");
    observed.required = kind === "frv";
    const grid = el("div", void 0, "formgrid");
    if (kind === "sop") {
      if (c.id) grid.append(el("p", "\u041A\u043E\u0434 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430: " + c.code, "muted"));
      else grid.append(inputField("\u041A\u043E\u0434 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0432 Lean Center", code));
    }
    grid.append(inputField("\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", title), inputField("\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F (\u0434\u043B\u044F \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u0430)", op));
    if (kind === "frv") grid.append(inputField("\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0434\u0430\u0442\u0430 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F", observed));
    const confirm2 = el("button", c.command === "create" ? "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u043E\u0432\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A" : c.command === "revise" ? "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E" : "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430", "primary");
    confirm2.type = "submit";
    confirm2.disabled = busy || !!ws.conflicts.length;
    form2.onsubmit = (e) => {
      e.preventDefault();
      run(async () => {
        assertContext(c);
        const payload = { command: c.command, title: title.value.trim(), operation_id: op.value || null, source: d.source, projection: p };
        if (kind === "sop") {
          if (c.command === "create") payload.code = code.value.trim();
          else payload.revision_id = c.command === "save" ? c.revisionId : null;
        } else payload.observed_at = observed.value;
        await contentStore.put(d.source, d.text);
        const ev = libraryEvent(c, payload);
        await ws.applyContentEvents([ev], readContent2);
        await persist();
        libraryDraft = null;
        if (d.editor && editorSession && !editorSession.popup.closed) {
          editorSession.popup.postMessage({ protocol: "lean-editor-v1", session: editorSession.session, type: "result", message: "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D \u0432 Lean Center. \u0421\u043A\u0430\u0447\u0430\u0439\u0442\u0435 JSON \u043F\u0440\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u0438. \u0414\u043B\u044F \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0439 \u043F\u0440\u0430\u0432\u043A\u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0438\u0437 \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0438." }, "*");
        }
        return "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043E\u0431\u0449\u0435\u0439 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
      }, { save: false });
    };
    main.append(pane("\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B", el("p", sourceSummary(d)), el("p", "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0442\u0430\u0442\u0443\u0441 Stage43: " + (p.legacy_status || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") + " \xB7 \u041D\u043E\u043C\u0435\u0440: " + (p.number || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") + " \xB7 " + Math.ceil(d.source.size / 1024) + " \u041A\u0411", "muted"), el("p", "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0442\u0430\u0442\u0443\u0441 \u043D\u0435 \u0441\u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044F \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435\u043C \u0432 Lean Center. \u0421\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u0438 \u0444\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E \u043F\u043E SHA-256.", "muted"), add(form2, grid, add(el("div", void 0, "row"), confirm2, btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON", () => downloadRaw("Stage43-" + kind + ".json", d.text)), btn("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440", () => {
      if (window.confirm("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0438\u043C\u043F\u043E\u0440\u0442? \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u0441\u044F.")) {
        libraryDraft = null;
        render();
      }
    })))));
  }
  function libraryAction(c, command, label) {
    const panel = el("div", void 0, "library-action"), actor = selectRef("person", "decision_actor", null), note = fieldInput("decision_note");
    note.maxLength = 2e3;
    const ok = btn(label, () => run(async () => {
      const payload = c.kind === "sop" ? { command, revision_id: c.revisionId, actor_id: actor.value || null, note: note.value } : { command, actor_id: actor.value || null, note: note.value };
      await ws.applyContentEvents([libraryEvent(c, payload)], readContent2);
      return "\u0421\u0442\u0430\u0442\u0443\u0441 \u0438\u0437\u043C\u0435\u043D\u0451\u043D. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
    }), "primary", !!ws.conflicts.length);
    panel.append(inputField("\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", actor), inputField("\u041F\u0440\u0438\u043C\u0435\u0447\u0430\u043D\u0438\u0435 / \u043F\u0440\u0438\u0447\u0438\u043D\u0430", note), ok);
    return panel;
  }
  function rawButton(source, name) {
    return btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C JSON", () => run(async () => {
      downloadRaw(name, await readContent2(source));
      return "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false }));
  }
  function sourceDetails(data) {
    const details = el("details"), summary = el("summary", "\u0421\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E\u0431 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0435"), p = data.projection;
    details.append(summary, el("p", sourceSummary(data), "muted"), el("p", "SHA-256: " + data.source.sha256, "source-hash"), el("p", "Stage43: " + (p.legacy_id || "\u0431\u0435\u0437 ID") + " / " + (p.legacy_version || "\u2014") + " / " + (p.legacy_status || "\u2014"), "muted"));
    return details;
  }
  function libraryHeader(main, kind) {
    const search = fieldInput("library_search", query, "search");
    search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E, \u043A\u043E\u0434\u0443, \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438";
    const filter = el("select");
    filter.name = "library_filter";
    for (const [v, n] of [["all", "\u0412\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"], ["active", "\u0411\u0435\u0437 \u0430\u0440\u0445\u0438\u0432\u0430"], ["archive", "\u0410\u0440\u0445\u0438\u0432"]]) {
      const o = el("option", n);
      o.value = v;
      filter.append(o);
    }
    filter.value = libraryFilter;
    const controls = add(el("div", void 0, "row"), btn(kind === "sop" ? "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0421\u041E\u041F \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435" : "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435", () => launchEditor(libraryContext(kind)), "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 JSON Stage43", () => chooseLibraryFile(kind), "", !!ws.conflicts.length), search, filter);
    const p = pane(kind === "sop" ? "\u041E\u0431\u0449\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0421\u041E\u041F" : "\u041E\u0431\u0449\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0424\u0420\u0412", el("p", "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 Stage43 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u043C \u0440\u0430\u0431\u043E\u0447\u0438\u043C \u043E\u043A\u043D\u043E\u043C. \u041F\u0435\u0447\u0430\u0442\u044C, \u0444\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438, TWI \u0438 \u043F\u0440\u0435\u0436\u043D\u0438\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u044B XLSX \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B \u0432 \u0435\u0433\u043E \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u043C \u043C\u0435\u0445\u0430\u043D\u0438\u0437\u043C\u0435. \u0418\u0418 \u0432 \u0438\u043D\u0442\u0435\u0433\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u043C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435 \u043F\u043E\u043A\u0430 \u043E\u0442\u043A\u043B\u044E\u0447\u0451\u043D; \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435 \u0438 \u043E\u0431\u0449\u0430\u044F \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u044E\u0442\u0441\u044F \u0432 Lean Center.", "muted"), controls);
    main.append(p);
    libraryPreview(main, kind);
    const out = el("div", void 0, "stack");
    main.append(out);
    return { search, filter, out };
  }
  function libraryScreen(main, kind) {
    const { search, filter, out } = libraryHeader(main, kind);
    function draw() {
      out.replaceChildren();
      const items = rows(ws.working, kind === "sop" ? "SELECT * FROM document ORDER BY code" : "SELECT * FROM frv_study ORDER BY observed_at DESC,title");
      const filtered = items.filter((v) => {
        const a = kind === "sop" ? !!v.archived : v.state === "archived";
        return (libraryFilter === "all" || (libraryFilter === "active" ? !a : a)) && [v.title, v.code, refName("operation", v.operation_id)].some((x) => String(x || "").toLowerCase().includes(query.toLowerCase()));
      });
      if (!filtered.length) {
        out.append(pane("\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439", el("p", "\u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435 \u0438\u043B\u0438 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C\u044B\u0439 JSON Stage43.", "muted")));
        return;
      }
      for (const v of filtered) {
        const p = pane((kind === "sop" ? v.code + " \xB7 " : "") + v.title, el("p", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F: " + refName("operation", v.operation_id) + " \xB7 \u0420\u0435\u0432\u0438\u0437\u0438\u044F \u0437\u0430\u043F\u0438\u0441\u0438: " + v.rev, "muted"));
        if (kind === "sop") {
          const versions = rows(ws.working, "SELECT * FROM document_revision WHERE document_id=? ORDER BY version_no DESC", [v.id]);
          for (const revision2 of versions) {
            const data = JSON.parse(revision2.payload_json), c = libraryContext(kind, v.id, revision2.id), section = el("div", void 0, "library-version");
            const header = add(el("div", void 0, "row"), el("strong", "\u0412\u0435\u0440\u0441\u0438\u044F " + revision2.version_no), el("span", revisionLabels[revision2.state] || revision2.state, "pill"), el("span", revision2.created_at.slice(0, 10), "muted"));
            section.append(header, el("p", sourceSummary(data), "muted"), sourceDetails(data));
            const buttons = add(el("div", void 0, "row"), rawButton(data.source, "SOP-" + v.code + "-v" + revision2.version_no + ".json"));
            const open = versions.some((x) => ["draft", "review", "approved"].includes(x.state));
            if (!v.archived && (revision2.state === "draft" || !open && ["effective", "withdrawn", "superseded"].includes(revision2.state))) {
              buttons.append(btn(revision2.state === "draft" ? "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440" : "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0432\u0435\u0440\u0441\u0438\u044E \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435", () => launchEditor(c), "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 JSON", () => chooseLibraryFile(kind, c), "", !!ws.conflicts.length));
            }
            section.append(buttons);
            const actions = revision2.state === "draft" ? [["submit", "\u041D\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435"]] : revision2.state === "review" ? [["approve", "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u0442\u044C"], ["return", "\u0412\u0435\u0440\u043D\u0443\u0442\u044C \u0432 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A"]] : revision2.state === "approved" ? [["effect", "\u0412\u0432\u0435\u0441\u0442\u0438 \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435"]] : revision2.state === "effective" ? [["withdraw", "\u0412\u044B\u0432\u0435\u0441\u0442\u0438 \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F"]] : [];
            if (!v.archived) for (const [cmd, label] of actions) {
              const det = el("details");
              det.append(el("summary", label), libraryAction(c, cmd, label));
              section.append(det);
            }
            const decisions = rows(ws.working, "SELECT * FROM document_approval WHERE revision_id=? ORDER BY decided_at", [revision2.id]);
            for (const a of decisions) section.append(el("p", (a.decision === "approved" ? "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043B: " : "\u0412\u0435\u0440\u043D\u0443\u043B: ") + refName("person", a.actor_id) + " \xB7 " + a.decided_at.slice(0, 10) + (a.note ? " \xB7 " + a.note : ""), "muted"));
            p.append(section);
          }
          if (!v.archived && versions.length && versions.every((x) => ["superseded", "withdrawn"].includes(x.state))) p.append(btn("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0421\u041E\u041F", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0431\u0435\u0437 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u043E\u0440\u0438\u0438?")) run(async () => {
              await ws.applyContentEvents([libraryEvent(libraryContext(kind, v.id), null, "archive")], readContent2);
              return "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0432 \u0430\u0440\u0445\u0438\u0432\u0435";
            });
          }, "danger", !!ws.conflicts.length));
        } else {
          const data = JSON.parse(v.context_json), c = libraryContext(kind, v.id);
          p.append(el("p", revisionLabels[v.state] + " \xB7 \u0414\u0430\u0442\u0430 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F: " + v.observed_at), el("p", sourceSummary(data), "muted"), sourceDetails(data));
          const buttons = add(el("div", void 0, "row"), rawButton(data.source, "FRV-" + v.id + ".json"));
          if (v.state === "draft") {
            buttons.append(btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440", () => launchEditor(c), "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 JSON", () => chooseLibraryFile(kind, c), "", !!ws.conflicts.length));
            const det = el("details");
            det.append(el("summary", "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435"), libraryAction(c, "finalize", "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435"));
            p.append(det);
          }
          if (v.state !== "archived") buttons.append(btn("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0431\u0435\u0437 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0439?")) run(async () => {
              await ws.applyContentEvents([libraryEvent(c, null, "archive")], readContent2);
              return "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 \u0430\u0440\u0445\u0438\u0432\u0435";
            });
          }, "danger", !!ws.conflicts.length));
          p.append(buttons);
        }
        out.append(p);
      }
    }
    search.oninput = () => {
      query = search.value;
      draw();
    };
    filter.onchange = () => {
      libraryFilter = filter.value;
      draw();
    };
    draw();
  }
  async function backupTransfer() {
    return makeTransfer("backup", await backup(ws), sourceRefs(), readContent2);
  }
  async function restoreBackupTransfer(value) {
    const { payload, contents } = unpackTransfer(value, "backup");
    const db = openDb(SQL, decode(payload.base));
    let refs;
    try {
      refs = unionRefs(refsForDb(db), refsForEvents(payload.pending));
    } finally {
      db.close();
    }
    await restoreContents(contents, refs, (r, t) => contentStore.put(r, t));
    return restore(SQL, payload, readContent2);
  }
  async function acceptManualTransfer(value) {
    const { payload, contents } = unpackTransfer(value, "package");
    await restoreContents(contents, refsForEvents(payload.events), (r, t) => contentStore.put(r, t));
    return ws.accept(payload, readContent2);
  }
  async function snapshotTransfer(s) {
    return makeTransfer("snapshot", { manifest: s.manifest, base: encode(s.bytes) }, refsForDb(ws.base), readContent2);
  }
  async function openSnapshotTransfer(value) {
    const { payload, contents } = unpackTransfer(value, "snapshot"), db = await readSnapshot(SQL, payload.manifest, decode(payload.base));
    try {
      await restoreContents(contents, refsForDb(db), (r, t) => contentStore.put(r, t));
    } catch (e) {
      db.close();
      throw e;
    }
    await useSnapshot(db);
  }
  async function useSnapshot(db) {
    if (meta(db, "database_id") === meta(ws.base, "database_id")) {
      ws.replaceBase(db);
      return;
    }
    if (!empty()) {
      db.close();
      throw new Error("\u042D\u0442\u043E \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u0435\u0451 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.");
    }
    replace(new Workspace(SQL, db));
  }
  async function refresh() {
    invariant(folder, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
    invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F");
    const s = await latestSnapshot(folder, SQL);
    invariant(s, "\u0412 \u043F\u0430\u043F\u043A\u0435 \u043D\u0435\u0442 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0431\u0430\u0437\u044B");
    await useSnapshot(s.db);
    return ws.conflicts.length ? "\u041E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u043E; \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439" : "\u0417\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0431\u0430\u0437\u0430";
  }
  async function publish() {
    invariant(master, "\u0412\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
    invariant(folder, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
    invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F");
    const snapshot = await prepareSnapshot(ws);
    await publishSnapshot(folder, SQL, snapshot, readContent2);
    const db = await readSnapshot(SQL, snapshot.manifest, snapshot.bytes);
    replace(new Workspace(SQL, db, { device: ws.device }));
    return "\u0411\u0430\u0437\u0430 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430 \u043F\u043E SHA-256";
  }
  function storage(main) {
    const mode = el("input");
    mode.type = "checkbox";
    mode.checked = master;
    mode.onchange = () => {
      master = mode.checked;
      render();
    };
    const summary = pane("\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F", el("p", "ID \u0431\u0430\u0437\u044B: " + meta(ws.base, "database_id"), "muted"), el("p", "\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F: " + (meta(ws.base, "publication_id") || "\u0435\u0449\u0451 \u043D\u0435\u0442"), "muted"), el("p", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F: " + ws.pending.length + " \xB7 \u041F\u0440\u0438\u043D\u044F\u0442\u043E, \u043D\u043E \u043D\u0435 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043E: " + (ws.dirty ? "\u0434\u0430" : "\u043D\u0435\u0442")), add(el("label", void 0, "row"), mode, el("span", "\u0420\u0435\u0436\u0438\u043C \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F (\u0442\u043E\u043B\u044C\u043A\u043E \u0443\u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0435\u043D\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A)")), el("p", "\u0420\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F \u2014 \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0430\u0442\u0435\u043B\u044C, \u043D\u0435 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u044F. \u041F\u0440\u0430\u0432\u0430 \u043F\u0430\u043F\u043A\u0438 \u043D\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u044E\u0442\u0441\u044F \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F.", "muted"));
    main.append(summary);
    const controls = add(el("div", void 0, "row"), btn("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u0435\u0442\u0435\u0432\u0443\u044E \u043F\u0430\u043F\u043A\u0443", () => run(async () => {
      folder = await chooseFolder();
      if (cache) await save(cache, "folder", folder);
      return "\u0412\u044B\u0431\u0440\u0430\u043D\u0430 \u043F\u0430\u043F\u043A\u0430: " + folder.name;
    }, { save: false }), "primary"), btn("\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0434\u043E\u0441\u0442\u0443\u043F", () => run(async () => {
      invariant(folder, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
      await testFolder(folder);
      return "\u0427\u0442\u0435\u043D\u0438\u0435, \u0437\u0430\u043F\u0438\u0441\u044C \u0438 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u0442\u0435\u0441\u0442\u043E\u0432\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B";
    }, { save: false }), "", !folder), btn("\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0438\u0437 \u043F\u0430\u043F\u043A\u0438", () => run(refresh), "", !folder), btn("\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", () => run(async () => {
      invariant(folder, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
      await sendPackage(folder, await ws.package(), readContent2);
      return "\u041F\u0430\u043A\u0435\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0431\u0430\u0437\u043E\u0439";
    }, { save: false }), "", !folder || !ws.pending.length || !!ws.conflicts.length));
    main.append(pane("\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u043F\u0430\u043F\u043A\u0430", el("p", folder ? "\u041F\u0430\u043F\u043A\u0430: " + folder.name : "\u041D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u0430", "muted"), controls));
    const masterPanel = pane("\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u0438 \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", el("p", "\u0418\u0437\u0434\u0430\u0442\u0435\u043B\u044C \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438 \u043F\u0443\u0431\u043B\u0438\u043A\u0443\u0435\u0442 \u043D\u043E\u0432\u0443\u044E \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E. \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0444\u0430\u0439\u043B\u044B \u043D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u044E\u0442\u0441\u044F.", "muted"), add(el("div", void 0, "row"), btn("\u041F\u0440\u0438\u043D\u044F\u0442\u044C \u0441\u0432\u043E\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", () => run(async () => {
      const n = await ws.acceptOwn(readContent2);
      return "\u041F\u0440\u0438\u043D\u044F\u0442\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439: " + n;
    }), "", !master || !ws.pending.length || !!ws.conflicts.length), btn("\u0421\u043F\u0438\u0441\u043E\u043A \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0445", () => run(async () => {
      invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430");
      incoming = await listPackages(folder);
      return "\u041D\u0430\u0439\u0434\u0435\u043D\u043E \u043F\u0430\u043A\u0435\u0442\u043E\u0432: " + incoming.length;
    }, { save: false }), "", !folder || !master), btn("\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u0431\u0430\u0437\u0443", () => run(publish), "primary", !folder || !master || !!ws.pending.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u043F\u0430\u043A\u0435\u0442\u0430 \u0432\u0440\u0443\u0447\u043D\u0443\u044E", () => pick(".leanpkg,.json", async (p) => {
      invariant(master, "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
      const result = await acceptManualTransfer(p);
      return result.duplicate ? "\u041F\u0430\u043A\u0435\u0442 \u0443\u0436\u0435 \u043F\u0440\u0438\u043D\u044F\u0442" : "\u041F\u0440\u0438\u043D\u044F\u0442\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439: " + result.count;
    }, MAX_TRANSFER), "", !master)));
    for (const item of incoming) {
      const p = item.p, known = p && one(ws.base, "SELECT id FROM exchange_package WHERE id=?", [p.id]);
      masterPanel.append(add(el("div", void 0, "row"), el("span", item.name + " \xB7 " + (item.error || (known ? "\u043F\u0440\u0438\u043D\u044F\u0442" : p.events?.length + " \u0441\u043E\u0431\u044B\u0442\u0438\u0439")), "muted"), btn("\u041F\u0440\u0438\u043D\u044F\u0442\u044C", () => run(async () => {
        const x = await ws.accept(p, readContent2);
        return x.duplicate ? "\u0423\u0436\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u043E" : "\u041F\u0440\u0438\u043D\u044F\u0442\u043E: " + x.count;
      }), "", !!known || !master || !p || !!ws.pending.length)));
    }
    main.append(masterPanel);
    main.append(pane("\u041F\u0435\u0440\u0435\u043D\u043E\u0441 \u0438 \u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435", add(el("div", void 0, "row"), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043F\u0430\u043A\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", () => run(async () => {
      const p = await ws.package();
      download("change-" + p.id + ".leanpkg", await makeTransfer("package", p, refsForEvents(p.events), readContent2));
      return "\u041F\u0430\u043A\u0435\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false }), "", !ws.pending.length || !!ws.conflicts.length), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E", () => run(async () => {
      download("lean-" + uuid() + ".leanbackup", await backupTransfer());
      return "\u041A\u043E\u043F\u0438\u044F \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
    }, { save: false })), btn("\u041A\u043E\u043F\u0438\u044F \u043D\u0430 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u0434\u0438\u0441\u043A", () => run(async () => {
      await saveBackup(folder, await backupTransfer());
      return "\u041A\u043E\u043F\u0438\u044F \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430";
    }, { save: false }), "", !folder), btn("\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u043A\u043E\u043F\u0438\u044E", () => pick(".leanbackup,.json", async (obj2) => {
      const next = await restoreBackupTransfer(obj2);
      if (!empty() && !confirm("\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E? \u0423\u0431\u0435\u0434\u0438\u0442\u0435\u0441\u044C, \u0447\u0442\u043E \u0441\u043A\u0430\u0447\u0430\u043B\u0438 \u0435\u0451 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) {
        next.close();
        return "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
      }
      replace(next);
      return "\u041A\u043E\u043F\u0438\u044F \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 ID \u0431\u0430\u0437\u044B";
    })), btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A \u0434\u043B\u044F \u0440\u0443\u0447\u043D\u043E\u0433\u043E \u043E\u0431\u043C\u0435\u043D\u0430", () => run(async () => {
      invariant(master, "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
      const s = await prepareSnapshot(ws);
      download("snapshot-" + s.manifest.id + ".leansnapshot", await snapshotTransfer(s));
      replace(new Workspace(SQL, await readSnapshot(SQL, s.manifest, s.bytes), { device: ws.device }));
      return "\u0421\u043D\u0438\u043C\u043E\u043A \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0441\u043A\u0430\u0447\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u0439\u043B; \u0440\u0443\u0447\u043D\u0430\u044F \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430";
    }), "", !master || !!ws.pending.length || !!folder), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A", () => pick(".leansnapshot,.json", async (obj2) => {
      await openSnapshotTransfer(obj2);
      return "\u0421\u043D\u0438\u043C\u043E\u043A \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D \u0438 \u043E\u0442\u043A\u0440\u044B\u0442";
    })))));
    if (ws.conflicts.length) {
      const p = pane("\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", el("p", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E. \u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0438\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u044B; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u0430\u043D\u044B.", "bad"));
      for (const c of ws.conflicts) {
        p.append(el("p", c.error, "bad"));
        const v = one(ws.working, "SELECT * FROM " + c.event.entity_type + " WHERE id=?", [c.event.entity_id]);
        p.append(el("pre", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435: " + JSON.stringify(c.event.payload, null, 2) + "\n\u0422\u0435\u043A\u0443\u0449\u0435\u0435: " + JSON.stringify(v, null, 2), "muted"));
      }
      p.append(add(el("div", void 0, "row"), btn("\u041E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", () => {
        if (confirm("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0435\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435? \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
          ws.resolveConflict("discard");
          return "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0435\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435 \u043E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
        });
      }, "danger"), btn("\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0441\u0432\u043E\u0451 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435", () => {
        if (confirm("\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0432\u0430\u0448\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E\u0432\u0435\u0440\u0445 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0440\u0435\u0432\u0438\u0437\u0438\u0438? \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
          ws.resolveConflict("reapply");
          return "\u0421\u043E\u0437\u0434\u0430\u043D\u043E \u043D\u043E\u0432\u043E\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435; \u043E\u043D\u043E \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438";
        });
      }, "", Object.hasOwn(DOMAIN_TYPES, ws.conflicts[0].event.entity_type))));
      main.append(p);
    }
    main.append(pane("\u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u044F", el("p", "\u0422\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0443\u0441\u0442\u043E\u0439 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0439 \u0431\u0430\u0437\u0435. \u041D\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u043A\u0430\u043A \u0440\u0430\u0431\u043E\u0447\u0443\u044E.", "muted"), btn("\u041D\u043E\u0432\u0430\u044F \u043F\u0443\u0441\u0442\u0430\u044F \u0431\u0430\u0437\u0430", () => {
      if (confirm("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0443\u0441\u0442\u0443\u044E \u0431\u0430\u0437\u0443 \u0432\u043C\u0435\u0441\u0442\u043E \u0442\u0435\u043A\u0443\u0449\u0435\u0439? \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
        replace(new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration)));
        folder = null;
        incoming = [];
        master = false;
        importState = null;
        libraryDraft = null;
        if (cache) await save(cache, "folder", null);
        return "\u041D\u043E\u0432\u0430\u044F \u043F\u0443\u0441\u0442\u0430\u044F \u0431\u0430\u0437\u0430 \u0441\u043E\u0437\u0434\u0430\u043D\u0430";
      });
    }, "danger"), btn("\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0434\u0435\u043C\u043E-\u0434\u0430\u043D\u043D\u044B\u043C\u0438", () => run(async () => {
      invariant(empty(), "\u0414\u0435\u043C\u043E \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0443\u0441\u0442\u043E\u0439 \u0431\u0430\u0437\u0435");
      const u = ws.edit("org_unit", null, { code: "DEMO", name: "\u0423\u0447\u0435\u0431\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", kind: "\u041F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", parent_id: null });
      const v = ws.edit("org_unit", null, { code: "DEMO-M", name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0443\u0447\u0430\u0441\u0442\u043E\u043A", kind: "\u0423\u0447\u0430\u0441\u0442\u043E\u043A", parent_id: u });
      const p = ws.edit("profession", null, { code: "DEMO-MECH", name: "\u041C\u0435\u0445\u0430\u043D\u0438\u043A" });
      const a = ws.edit("person", null, { employee_code: "DEMO-001", display_name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A 01" });
      const e = ws.edit("equipment", null, { unit_id: v, code: "DEMO-E", name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0441\u0442\u0435\u043D\u0434" });
      ws.edit("operation", null, { unit_id: v, equipment_id: e, code: "DEMO-O", name: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u0442\u0435\u043D\u0434\u0430", criticality: "normal" });
      ws.edit("person_assignment", null, { person_id: a, unit_id: v, profession_id: p, shift_code: "1", valid_from: "2026-11-25", valid_to: null });
      return "\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u044B \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438";
    }), "", !empty())));
  }
  function render() {
    chart?.dispose();
    chart = null;
    document.documentElement.classList.toggle("dark", theme);
    const header = el("header", void 0, "corp-header");
    const brand = add(el("div", void 0, "brand-lockup"), el("div", void 0, "brand-mark"), add(el("div"), el("div", "LEAN CENTER", "brand"), el("div", "\u0426\u0435\u043D\u0442\u0440 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u044B", "brand-sub")));
    const metaPanel = add(el("div", void 0, "header-meta"), el("span", window.LC_BUILD.version || "lc3.0", "version"), btn(theme ? "\u0421\u0432\u0435\u0442\u043B\u0430\u044F \u0442\u0435\u043C\u0430" : "\u0422\u0451\u043C\u043D\u0430\u044F \u0442\u0435\u043C\u0430", () => {
      theme = !theme;
      render();
    }), btn("\u0425\u0440\u0430\u043D\u0435\u043D\u0438\u0435", () => navigate("storage")));
    header.append(brand, metaPanel);
    const side = el("aside", void 0, "sidebar");
    side.setAttribute("aria-label", "\u041D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F");
    const group = (name, keys) => {
      side.append(el("div", name, "navgroup"));
      for (const k of keys) side.append(navButton(k));
    };
    group("\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E", ["home", ...Object.keys(planned)]);
    group("\u041F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", ["org_unit", "person", "profession", "position", "work_shift", "equipment", "operation"]);
    group("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438 \u0440\u043E\u043B\u0438", ["person_assignment", "business_role", "role_assignment"]);
    group("\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438 \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u043D\u0438\u044F", ["skill_category", "skill", "rating_scale"]);
    group("\u0421\u0438\u0441\u0442\u0435\u043C\u0430", ["import_xlsx", "storage"]);
    const main = el("main", void 0, "main");
    const section = page === "home" ? "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E" : ["storage", "import_xlsx"].includes(page) ? "\u0421\u0438\u0441\u0442\u0435\u043C\u0430" : Object.hasOwn(definitions, page) ? "\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438" : "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E";
    const top = add(el("div", void 0, "top"), add(el("div"), el("div", section, "eyebrow"), el("h1", labels2[page]), el("div", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \xB7 " + ws.pending.length + " \u043E\u0436\u0438\u0434\u0430\u044E\u0449\u0438\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", "muted")), el("span", folder ? "\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u043F\u0430\u043F\u043A\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u0430" : "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F", "pill"));
    main.append(top);
    const stat = el("div", status, "status" + (error ? " error" : ""));
    stat.id = "status";
    stat.setAttribute("role", "status");
    main.append(stat);
    if (!cache) main.append(el("p", "IndexedDB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0430\u043C\u044F\u0442\u0438 \u2014 \u0441\u043A\u0430\u0447\u0438\u0432\u0430\u0439\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0434\u043E \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u044F.", "bad"));
    if (ws.conflicts.length) main.append(el("p", "\u0415\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \xAB\u0411\u0430\u0437\u0430 \u0438 \u043E\u0431\u043C\u0435\u043D\xBB.", "bad"));
    if (ws.dirty) main.append(el("p", "\u041F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0435\u0449\u0451 \u043D\u0435 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u044B.", "warn"));
    root.replaceChildren(add(el("div", void 0, "shell"), header, side, main));
    if (page === "home") home(main);
    else if (page === "storage") storage(main);
    else if (page === "import_xlsx") importScreen(main);
    else if (page === "sop" || page === "frv") libraryScreen(main, page);
    else if (Object.hasOwn(definitions, page)) registry(main, page);
    else if (page === "twi") main.append(pane("TWI \u0432 \u0441\u043E\u0441\u0442\u0430\u0432\u0435 \u0421\u041E\u041F", el("p", "\u041F\u043B\u0430\u043D TWI \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u0442\u0441\u044F \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u0432\u0435\u0440\u0441\u0438\u0435\u0439 \u0421\u041E\u041F \u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435 Stage43. \u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u0438 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043E\u0446\u0435\u043D\u043A\u0438 \u0431\u0443\u0434\u0443\u0442 \u0440\u0435\u0430\u043B\u0438\u0437\u043E\u0432\u0430\u043D\u044B \u043D\u0430 LC4.", "muted"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0443 \u0421\u041E\u041F", () => navigate("sop"), "primary")));
    else main.append(pane(labels2[page], el("p", "\u041C\u043E\u0434\u0443\u043B\u044C \u0437\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D \u043D\u0430 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0435 \u044D\u0442\u0430\u043F\u044B. \u0412 \u044D\u0442\u043E\u0439 \u0441\u0431\u043E\u0440\u043A\u0435 \u0433\u043E\u0442\u043E\u0432\u0438\u0442\u0441\u044F \u0435\u0434\u0438\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \u0438 \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u0430.", "muted")));
    main.append(el("p", "LC3.0 \xB7 \u0430\u0432\u0442\u043E\u043D\u043E\u043C\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F \xB7 \u043E\u0431\u0449\u0438\u0439 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u043E\u0431\u043C\u0435\u043D", "foot"));
  }
  window.addEventListener("resize", () => chart?.resize());
  async function init() {
    configureMigrations(LC_BUILD.migration3, LC_BUILD.migration4, LC_BUILD.migration5);
    SQL = await window.initSqlJs({ wasmBinary: decode(window.LC_BUILD.wasm) });
    try {
      cache = await openCache();
      const s = await load(cache, "workspace");
      generation = s?.generation || 0;
      folder = await load(cache, "folder");
      ws = s ? new Workspace(SQL, openDb(SQL, s.state.base), s.state) : new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration));
      if (!s) await persist();
      if (folder && await permission(folder, false)) {
        const prev = ws.state();
        try {
          const remote = await latestSnapshot(folder, SQL);
          if (remote) {
            await useSnapshot(remote.db);
            await persist();
            message(ws.conflicts.length ? "\u0411\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430, \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B" : "\u0411\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430 \u0438\u0437 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u043F\u0430\u043F\u043A\u0438");
          }
        } catch (e) {
          replace(new Workspace(SQL, openDb(SQL, prev.base), prev));
          message("\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u0431\u0430\u0437\u0430 \u043D\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430: " + e.message, true);
        }
      }
    } catch (e) {
      if (!cache) {
        ws = new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration));
        message("IndexedDB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D, \u0440\u0443\u0447\u043D\u043E\u0439 \u0440\u0435\u0436\u0438\u043C: " + e.message, true);
      } else if (ws) {
        message("\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043D\u0435 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u0430: " + e.message, true);
        cache = null;
      } else throw e;
    }
    render();
  }
  init().catch((e) => {
    console.error(e);
    root.replaceChildren(el("h1", "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C Lean Center"), el("p", e.message), el("p", "\u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0443\u0434\u0430\u043B\u0435\u043D\u044B. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0431\u0440\u0430\u0443\u0437\u0435\u0440 \u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E."));
  });
})();
