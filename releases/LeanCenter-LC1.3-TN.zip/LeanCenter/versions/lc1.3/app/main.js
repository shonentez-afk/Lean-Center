(() => {
  // src/analytics/palette.js
  var labels = Object.freeze({
    actual: "\u0424\u0430\u043A\u0442",
    comparison: "\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435",
    compliant: "\u0421\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442",
    attention: "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044F",
    risk: "\u0420\u0438\u0441\u043A / \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435",
    critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435",
    plan: "\u041F\u043B\u0430\u043D",
    not_assessed: "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E",
    not_applicable: "\u041D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E"
  });
  var palettes = {
    light: {
      surface: "#FFFFFF",
      text: "#5B626E",
      grid: "#DADDDF",
      actual: "#242E40",
      comparison: "#2563EB",
      compliant: "#27965A",
      attention: "#A17600",
      risk: "#C46708",
      critical: "#E30613",
      plan: "#85878C",
      unavailable: "#BFC0C0",
      unavailableOutline: "#686B71",
      categorical: ["#242E40", "#2563EB", "#687B98", "#79649A", "#476F83", "#65749E"]
    },
    dark: {
      surface: "#232B39",
      text: "#BDC6D3",
      grid: "#424E60",
      actual: "#A9BCD4",
      comparison: "#74A8FF",
      compliant: "#69CA90",
      attention: "#F0CE57",
      risk: "#FFAB62",
      critical: "#FF777F",
      plan: "#A6ADB8",
      unavailable: "#626E80",
      unavailableOutline: "#C0CAD7",
      categorical: ["#A9BCD4", "#74A8FF", "#91A7C7", "#C3A6E0", "#80C3D4", "#A5B4E8"]
    }
  };
  for (const p of Object.values(palettes)) {
    Object.freeze(p.categorical);
    Object.freeze(p);
  }
  Object.freeze(palettes);
  function analyticsPalette(dark = false) {
    return palettes[dark ? "dark" : "light"];
  }
  function registryCountChart(categories, counts, dark = false) {
    if (!Array.isArray(categories) || !Array.isArray(counts) || categories.length !== counts.length || counts.some((n) => !Number.isSafeInteger(n) || n < 0)) throw new TypeError("Invalid registry counts");
    const p = analyticsPalette(dark);
    return {
      backgroundColor: "transparent",
      animation: false,
      color: p.categorical.slice(),
      textStyle: { fontFamily: "Proxima Nova, Proxima Nova Rg, Arial, sans-serif" },
      aria: { enabled: true, description: "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439: " + categories.map((n, i) => n + " \u2014 " + counts[i]).join("; ") },
      tooltip: { trigger: "axis" },
      grid: { left: 24, right: 36, bottom: 8, top: 8, containLabel: true },
      xAxis: { type: "value", minInterval: 1, axisLabel: { color: p.text }, splitLine: { lineStyle: { color: p.grid } } },
      yAxis: { type: "category", inverse: true, data: categories.slice(), axisLabel: { color: p.text, fontSize: 11, width: 144, overflow: "truncate" }, axisLine: { show: false }, axisTick: { show: false } },
      series: [{ name: "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438", type: "bar", barMaxWidth: 20, data: counts.slice(), label: { show: true, position: "right", color: p.text }, itemStyle: { color: p.actual, borderRadius: [0, 2, 2, 0] } }]
    };
  }

  // src/core/db.js
  var SCHEMA_VERSION = 2;
  var MAX_DB = 100 * 1024 * 1024;
  var MAX_PACKAGE = 5 * 1024 * 1024;
  var uuid = () => crypto.randomUUID();
  var now = () => (/* @__PURE__ */ new Date()).toISOString();
  var isId = (x) => typeof x === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x);
  var invariant = (ok, msg) => {
    if (!ok) throw new Error(msg);
  };
  var canonical = (x) => x === null || typeof x !== "object" ? JSON.stringify(x) : Array.isArray(x) ? "[" + x.map(canonical).join(",") + "]" : "{" + Object.keys(x).sort().map((k) => JSON.stringify(k) + ":" + canonical(x[k])).join(",") + "}";
  async function sha256(data) {
    const b = typeof data === "string" ? new TextEncoder().encode(data) : data;
    return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", b)), (x) => x.toString(16).padStart(2, "0")).join("");
  }
  function encode(bytes) {
    let s = "";
    for (let i = 0; i < bytes.length; i += 16384) s += String.fromCharCode(...bytes.subarray(i, i + 16384));
    return btoa(s);
  }
  function decode(s) {
    invariant(typeof s === "string" && s.length <= MAX_DB * 1.4, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0444\u0430\u0439\u043B \u0431\u0430\u0437\u044B");
    return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  }
  function rows(db, sql, args = []) {
    const st = db.prepare(sql);
    try {
      st.bind(args);
      const result = [];
      while (st.step()) result.push(st.getAsObject());
      return result;
    } finally {
      st.free();
    }
  }
  var one = (db, sql, args = []) => rows(db, sql, args)[0] || null;
  var meta = (db, key) => one(db, "SELECT value FROM meta WHERE key=?", [key])?.value || null;
  var setMeta = (db, key, value) => db.run("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", [key, value]);
  function tx(db, fn) {
    db.run("BEGIN IMMEDIATE");
    try {
      const value = fn();
      db.run("COMMIT");
      return value;
    } catch (e) {
      db.run("ROLLBACK");
      throw e;
    }
  }
  function bytesOf(db) {
    const bytes = db.export();
    db.run("PRAGMA foreign_keys=ON");
    return bytes;
  }
  function verifyDb(db) {
    invariant(one(db, "PRAGMA integrity_check")?.integrity_check === "ok", "\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u0430 \u0446\u0435\u043B\u043E\u0441\u0442\u043D\u043E\u0441\u0442\u044C SQLite");
    invariant(rows(db, "PRAGMA foreign_key_check").length === 0, "\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u044B \u0441\u0432\u044F\u0437\u0438 \u0431\u0430\u0437\u044B");
    invariant(Number(meta(db, "schema_version")) === SCHEMA_VERSION && one(db, "PRAGMA user_version").user_version === SCHEMA_VERSION, "\u0412\u0435\u0440\u0441\u0438\u044F \u0431\u0430\u0437\u044B \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F");
    invariant(isId(meta(db, "database_id")), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 ID \u0431\u0430\u0437\u044B");
    const p = meta(db, "publication_id");
    invariant(!p || one(db, "SELECT id FROM publication WHERE id=?", [p]), "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438");
  }
  function openDb(SQL2, bytes) {
    invariant(bytes instanceof Uint8Array && bytes.length > 100 && bytes.length <= MAX_DB, "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u0440\u0430\u0437\u043C\u0435\u0440 \u0431\u0430\u0437\u044B");
    const d = new SQL2.Database(bytes);
    try {
      d.run("PRAGMA foreign_keys=ON");
      verifyDb(d);
      return d;
    } catch (e) {
      d.close();
      throw e;
    }
  }
  function createDb(SQL2, schema, migration, id = uuid()) {
    const d = new SQL2.Database();
    d.run(schema);
    d.run(migration);
    setMeta(d, "database_id", id);
    verifyDb(d);
    return d;
  }
  var definitions = {
    org_unit: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, kind: { label: "\u0422\u0438\u043F", options: ["\u041F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", "\u0426\u0435\u0445", "\u0423\u0447\u0430\u0441\u0442\u043E\u043A", "\u0421\u043B\u0443\u0436\u0431\u0430", "\u0413\u0440\u0443\u043F\u043F\u0430"], required: true }, parent_id: { label: "\u0420\u043E\u0434\u0438\u0442\u0435\u043B\u044C", ref: "org_unit" } } },
    person: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438", fields: { employee_code: { label: "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440", required: true }, display_name: { label: "\u0424\u0418\u041E / \u0438\u043C\u044F", required: true } } },
    profession: { label: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    equipment: { label: "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    operation: { label: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u0438", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, equipment_id: { label: "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", ref: "equipment" }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, criticality: { label: "\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u043E\u0441\u0442\u044C", options: ["normal", "important", "critical"], required: true } } },
    person_assignment: { label: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", fields: { person_id: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ref: "person", required: true }, unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, profession_id: { label: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", ref: "profession" }, shift_code: { label: "\u0421\u043C\u0435\u043D\u0430" }, valid_from: { label: "\u041D\u0430\u0447\u0430\u043B\u043E", date: true, required: true }, valid_to: { label: "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", date: true } } }
  };
  function list(db, type) {
    invariant(Object.hasOwn(definitions, type), "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A");
    return rows(db, "SELECT * FROM " + type + " ORDER BY " + (type === "person" ? "display_name" : type === "person_assignment" ? "valid_from DESC" : "name"));
  }
  function normalize(db, type, p, id, old) {
    const def = definitions[type];
    invariant(def && p && typeof p === "object" && !Array.isArray(p), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u0438\u043F \u0437\u0430\u043F\u0438\u0441\u0438");
    invariant(Object.keys(p).length === Object.keys(def.fields).length && Object.keys(p).every((k) => Object.hasOwn(def.fields, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u0437\u0430\u043F\u0438\u0441\u0438");
    const v = {};
    for (const [k, f] of Object.entries(def.fields)) {
      let x = p[k];
      invariant(x === null || typeof x === "string", "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: " + f.label);
      x = typeof x === "string" ? x.trim() : null;
      if (!x) x = null;
      invariant(!f.required || x !== null, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435: " + f.label);
      if (x !== null) {
        invariant(x.length <= 500, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0434\u043B\u0438\u043D\u043D\u043E\u0435 \u043F\u043E\u043B\u0435");
        if (f.options) invariant(f.options.includes(x), "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: " + f.label);
        if (f.date) invariant(/^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0434\u0430\u0442\u0430");
        if (f.ref) {
          invariant(isId(x), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440");
          const ref = one(db, "SELECT * FROM " + f.ref + " WHERE id=?", [x]);
          invariant(ref && (!ref.archived || old?.[k] === x), "\u0421\u0441\u044B\u043B\u043A\u0430 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430: " + f.label);
        }
      }
      v[k] = x;
    }
    if (type === "org_unit") {
      let x = v.parent_id;
      const seen = /* @__PURE__ */ new Set([id]);
      while (x) {
        invariant(!seen.has(x), "\u0426\u0438\u043A\u043B \u0432 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0435");
        seen.add(x);
        x = one(db, "SELECT parent_id FROM org_unit WHERE id=?", [x])?.parent_id;
      }
    }
    if (type === "operation" && v.equipment_id) invariant(one(db, "SELECT unit_id FROM equipment WHERE id=?", [v.equipment_id])?.unit_id === v.unit_id, "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F");
    if (type === "equipment" && old && v.unit_id !== old.unit_id) invariant(!one(db, "SELECT id FROM operation WHERE equipment_id=? LIMIT 1", [id]), "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0442\u0438 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0441 \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u043C\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C\u0438");
    if (type === "person_assignment") {
      invariant(!v.valid_to || v.valid_to >= v.valid_from, "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 \u0440\u0430\u043D\u044C\u0448\u0435 \u043D\u0430\u0447\u0430\u043B\u0430");
      if (old) {
        for (const k of ["person_id", "unit_id", "profession_id", "shift_code", "valid_from"]) invariant(old[k] === v[k], "\u0418\u0441\u0442\u043E\u0440\u0438\u044E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435");
        invariant(!old.valid_to || old.valid_to === v.valid_to, "\u0417\u0430\u043A\u0440\u044B\u0442\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u043E");
      }
      invariant(!one(db, "SELECT id FROM person_assignment WHERE person_id=? AND id<>? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? LIMIT 1", [v.person_id, id, v.valid_to || "9999-12-31", v.valid_from]), "\u041F\u0435\u0440\u0435\u0441\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
    }
    return v;
  }
  function validateEvent(e) {
    invariant(e && Object.keys(e).every((k) => ["id", "entity_type", "entity_id", "operation", "expected_revision", "payload", "occurred_at"].includes(k)) && isId(e.id) && isId(e.entity_id) && Object.hasOwn(definitions, e.entity_type) && ["create", "update", "archive"].includes(e.operation) && Number.isSafeInteger(e.expected_revision) && e.expected_revision >= 0 && typeof e.occurred_at === "string" && !isNaN(Date.parse(e.occurred_at)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435");
  }
  function applyEvent(db, e, packageId = null) {
    validateEvent(e);
    const prev = one(db, "SELECT * FROM change_event WHERE id=?", [e.id]);
    if (prev) {
      invariant(prev.entity_type === e.entity_type && prev.entity_id === e.entity_id && prev.operation === e.operation && prev.expected_revision === e.expected_revision && prev.occurred_at === e.occurred_at && canonical(JSON.parse(prev.payload_json)) === canonical(e.payload), "\u041F\u043E\u0432\u0442\u043E\u0440 ID \u0441 \u0434\u0440\u0443\u0433\u0438\u043C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u044B\u043C");
      return false;
    }
    const t = e.entity_type, old = one(db, "SELECT * FROM " + t + " WHERE id=?", [e.entity_id]);
    invariant((old?.rev || 0) === e.expected_revision, "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0432\u0435\u0440\u0441\u0438\u0438: " + definitions[t].label + " / " + e.entity_id + " (\u043E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C " + e.expected_revision + ", \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F " + (old?.rev || 0) + ")");
    if (e.operation === "create" || e.operation === "update") {
      invariant(e.operation === "create" ? !old : !!old && !old.archived, "\u041D\u0435\u043B\u044C\u0437\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u044D\u0442\u0443 \u0437\u0430\u043F\u0438\u0441\u044C");
      const p = normalize(db, t, e.payload, e.entity_id, old);
      const keys = Object.keys(p);
      if (!old) db.run("INSERT INTO " + t + "(id," + keys.join(",") + ",rev) VALUES(" + Array(keys.length + 2).fill("?").join(",") + ")", [e.entity_id, ...Object.values(p), 1]);
      else db.run("UPDATE " + t + " SET " + keys.map((k) => k + "=?").join(",") + ",rev=rev+1 WHERE id=?", [...Object.values(p), e.entity_id]);
    } else {
      invariant(old && !old.archived && t !== "person_assignment" && e.payload === null, "\u041D\u0435\u043B\u044C\u0437\u044F \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C");
      db.run("UPDATE " + t + " SET archived=1,rev=rev+1 WHERE id=?", [e.entity_id]);
    }
    db.run("INSERT INTO change_event(id,package_id,entity_type,entity_id,operation,expected_revision,payload_json,occurred_at) VALUES(?,?,?,?,?,?,?,?)", [e.id, packageId, t, e.entity_id, e.operation, e.expected_revision, canonical(e.payload), e.occurred_at]);
    return true;
  }
  async function makePackage(db, events, device) {
    invariant(events.length > 0 && events.length <= 2e3, "\u041D\u0435\u0442 \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u0438\u043B\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u043F\u0430\u043A\u0435\u0442\u0430");
    const body = { format: "lean-change-v1", id: uuid(), database_id: meta(db, "database_id"), base_publication_id: meta(db, "publication_id"), schema_version: SCHEMA_VERSION, device_id: device, created_at: now(), events: structuredClone(events) };
    const hash = await sha256(canonical(body));
    invariant(new TextEncoder().encode(canonical(body)).length < MAX_PACKAGE, "\u041F\u0430\u043A\u0435\u0442 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 5 \u041C\u0411");
    return { ...body, hash };
  }
  async function checkPackage(p) {
    invariant(p && typeof p === "object" && Object.keys(p).length === 9 && p.format === "lean-change-v1" && isId(p.id) && isId(p.database_id) && isId(p.device_id) && (p.base_publication_id === null || isId(p.base_publication_id)) && p.schema_version === SCHEMA_VERSION && typeof p.created_at === "string" && !isNaN(Date.parse(p.created_at)) && Array.isArray(p.events) && p.events.length > 0 && p.events.length <= 2e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043F\u0430\u043A\u0435\u0442");
    const { hash, ...body } = p;
    invariant(new TextEncoder().encode(canonical(body)).length < MAX_PACKAGE, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u043F\u0430\u043A\u0435\u0442");
    invariant(await sha256(canonical(body)) === hash, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 \u043F\u0430\u043A\u0435\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
    p.events.forEach(validateEvent);
    invariant(new Set(p.events.map((e) => e.id)).size === p.events.length, "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u0432 \u043F\u0430\u043A\u0435\u0442\u0435");
  }
  async function mergePackage(db, p) {
    await checkPackage(p);
    invariant(p.database_id === meta(db, "database_id"), "\u041F\u0430\u043A\u0435\u0442 \u0434\u0440\u0443\u0433\u043E\u0439 \u0431\u0430\u0437\u044B");
    const known = one(db, "SELECT * FROM exchange_package WHERE id=?", [p.id]);
    if (known) {
      invariant(known.manifest_sha256 === p.hash, "\u041F\u043E\u0432\u0442\u043E\u0440 ID \u043F\u0430\u043A\u0435\u0442\u0430 \u0441 \u0438\u043D\u044B\u043C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u044B\u043C");
      return { duplicate: true, count: 0 };
    }
    invariant(!p.base_publication_id || one(db, "SELECT id FROM publication WHERE id=?", [p.base_publication_id]), "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F");
    return tx(db, () => {
      db.run("INSERT INTO exchange_package(id,base_publication_id,schema_version,database_id,device_id,created_at,state,manifest_sha256) VALUES(?,?,?,?,?,?,?,?)", [p.id, p.base_publication_id, p.schema_version, p.database_id, p.device_id, p.created_at, "applied", p.hash]);
      let count = 0;
      for (const e of p.events) if (applyEvent(db, e, p.id)) count++;
      return { duplicate: false, count };
    });
  }
  var Workspace = class {
    constructor(SQL2, base, { pending = [], device = uuid(), dirty = false } = {}) {
      this.SQL = SQL2;
      this.base = base;
      this.pending = structuredClone(pending);
      this.device = device;
      this.dirty = dirty;
      this.rebuild();
    }
    rebuild() {
      this.working?.close();
      this.working = openDb(this.SQL, bytesOf(this.base));
      this.conflicts = [];
      const remaining = [];
      for (const e of this.pending) {
        if (this.conflicts.length) {
          remaining.push(e);
          continue;
        }
        try {
          tx(this.working, () => applyEvent(this.working, e));
          if (!one(this.base, "SELECT id FROM change_event WHERE id=?", [e.id])) remaining.push(e);
        } catch (err) {
          remaining.push(e);
          this.conflicts.push({ event: e, error: err.message });
        }
      }
      this.pending = remaining;
    }
    edit(type, id, payload, operation) {
      invariant(!this.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439");
      invariant(this.pending.length < 2e3, "\u0414\u043E\u0441\u0442\u0438\u0433\u043D\u0443\u0442 \u043B\u0438\u043C\u0438\u0442 \u043E\u0447\u0435\u0440\u0435\u0434\u0438. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0439\u0442\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F.");
      const old = id ? one(this.working, "SELECT * FROM " + (Object.hasOwn(definitions, type) ? type : "invalid") + " WHERE id=?", [id]) : null;
      const e = { id: uuid(), entity_type: type, entity_id: id || uuid(), operation: operation || (old ? "update" : "create"), expected_revision: old?.rev || 0, payload, occurred_at: now() };
      tx(this.working, () => applyEvent(this.working, e));
      this.pending.push(e);
      return e.entity_id;
    }
    async package() {
      return makePackage(this.base, this.pending, this.device);
    }
    async accept(p) {
      invariant(!this.pending.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0440\u0438\u043C\u0438\u0442\u0435 \u0438\u043B\u0438 \u044D\u043A\u0441\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u0438 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
      const r = await mergePackage(this.base, p);
      if (!r.duplicate) this.dirty = true;
      this.rebuild();
      return r;
    }
    async acceptOwn() {
      invariant(!this.conflicts.length, "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0442");
      if (!this.pending.length) return 0;
      const p = await this.package();
      const r = await mergePackage(this.base, p);
      this.dirty = true;
      this.rebuild();
      return r.count;
    }
    discardPending() {
      this.pending = [];
      this.rebuild();
    }
    resolveConflict(choice) {
      invariant(this.conflicts.length === 1 && ["discard", "reapply"].includes(choice), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0430\u0435\u043C\u043E\u0433\u043E \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0430");
      const e = this.conflicts[0].event, i = this.pending.findIndex((x) => x.id === e.id);
      invariant(i >= 0, "\u0421\u043E\u0431\u044B\u0442\u0438\u0435 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442");
      if (choice === "discard") {
        this.pending.splice(i, 1);
        this.rebuild();
        return;
      }
      const old = one(this.working, "SELECT * FROM " + e.entity_type + " WHERE id=?", [e.entity_id]);
      const next = { ...e, id: uuid(), expected_revision: old?.rev || 0, occurred_at: now() };
      invariant(e.operation === "create" ? !old : !!old && !old.archived, "\u0417\u0430\u043F\u0438\u0441\u044C \u0443\u0434\u0430\u043B\u0435\u043D\u0430, \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0438\u043B\u0438 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442; \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0440\u0443\u0447\u043D\u043E\u0435 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435");
      tx(this.working, () => applyEvent(this.working, next));
      this.pending.splice(i, 1, next);
      this.rebuild();
    }
    replaceBase(db) {
      try {
        invariant(meta(db, "database_id") === meta(this.base, "database_id"), "\u0414\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430");
        const current = meta(this.base, "publication_id");
        let p = meta(db, "publication_id"), found = !current;
        const seen = /* @__PURE__ */ new Set();
        while (p) {
          invariant(!seen.has(p), "\u0426\u0438\u043A\u043B \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
          seen.add(p);
          if (p === current) found = true;
          const row = one(db, "SELECT parent_id FROM publication WHERE id=?", [p]);
          invariant(row, "\u0420\u0430\u0437\u043E\u0440\u0432\u0430\u043D\u0430 \u0446\u0435\u043F\u043E\u0447\u043A\u0430 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
          p = row.parent_id;
        }
        invariant(found, "\u0421\u043D\u0438\u043C\u043E\u043A \u0443\u0441\u0442\u0430\u0440\u0435\u043B \u0438\u043B\u0438 \u0438\u043C\u0435\u0435\u0442 \u0434\u0440\u0443\u0433\u0443\u044E \u0432\u0435\u0442\u043A\u0443");
        if (this.dirty) {
          for (const e of rows(this.base, "SELECT * FROM change_event")) invariant(canonical(one(db, "SELECT * FROM change_event WHERE id=?", [e.id])) === canonical(e), "\u0415\u0441\u0442\u044C \u043D\u0435\u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
          for (const e of rows(this.base, "SELECT * FROM exchange_package")) invariant(canonical(one(db, "SELECT * FROM exchange_package WHERE id=?", [e.id])) === canonical(e), "\u0415\u0441\u0442\u044C \u043D\u0435\u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u0430\u043A\u0435\u0442\u044B");
        }
        const prev = this.base;
        this.base = db;
        this.dirty = false;
        this.rebuild();
        prev.close();
      } catch (e) {
        if (this.base !== db) db.close();
        throw e;
      }
    }
    state() {
      return { base: bytesOf(this.base), pending: structuredClone(this.pending), device: this.device, dirty: this.dirty };
    }
    close() {
      this.working.close();
      this.base.close();
    }
  };
  async function prepareSnapshot(ws2) {
    invariant(!ws2.pending.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0440\u0438\u043C\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
    const db = openDb(ws2.SQL, bytesOf(ws2.base));
    try {
      const descriptor = { format: "lean-snapshot-v1", id: uuid(), database_id: meta(db, "database_id"), parent_id: meta(db, "publication_id"), schema_version: SCHEMA_VERSION, created_at: now() };
      const descriptor_hash = await sha256(canonical(descriptor));
      db.run("INSERT INTO publication(id,parent_id,created_at,schema_version,manifest_sha256) VALUES(?,?,?,?,?)", [descriptor.id, descriptor.parent_id, descriptor.created_at, SCHEMA_VERSION, descriptor_hash]);
      setMeta(db, "publication_id", descriptor.id);
      verifyDb(db);
      const bytes = bytesOf(db);
      return { bytes, manifest: { ...descriptor, descriptor_hash, snapshot_sha256: await sha256(bytes), size: bytes.length } };
    } finally {
      db.close();
    }
  }
  async function readSnapshot(SQL2, manifest, bytes) {
    invariant(manifest && manifest.format === "lean-snapshot-v1" && isId(manifest.id) && isId(manifest.database_id) && (manifest.parent_id === null || isId(manifest.parent_id)) && manifest.schema_version === SCHEMA_VERSION && manifest.size === bytes.length && bytes.length <= MAX_DB, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442");
    const { descriptor_hash, snapshot_sha256, size, ...descriptor } = manifest;
    invariant(await sha256(canonical(descriptor)) === descriptor_hash && await sha256(bytes) === snapshot_sha256, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D \u0441\u043D\u0438\u043C\u043E\u043A");
    const db = openDb(SQL2, bytes);
    try {
      const p = one(db, "SELECT * FROM publication WHERE id=?", [manifest.id]);
      invariant(meta(db, "database_id") === manifest.database_id && meta(db, "publication_id") === manifest.id && p?.manifest_sha256 === descriptor_hash && p.parent_id === manifest.parent_id, "\u0421\u043D\u0438\u043C\u043E\u043A \u0438 \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442");
      return db;
    } catch (e) {
      db.close();
      throw e;
    }
  }
  async function backup(ws2) {
    const s = ws2.state();
    const body = { format: "lean-backup-v1", base: encode(s.base), pending: s.pending, device: s.device, dirty: s.dirty };
    return { ...body, hash: await sha256(canonical(body)) };
  }
  async function restore(SQL2, obj) {
    const { hash, ...body } = obj;
    invariant(body.format === "lean-backup-v1" && Array.isArray(body.pending) && body.pending.length <= 2e3 && isId(body.device) && typeof body.dirty === "boolean" && await sha256(canonical(body)) === hash, "\u0420\u0435\u0437\u0435\u0440\u0432\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0435\u043D\u0430");
    body.pending.forEach(validateEvent);
    return new Workspace(SQL2, openDb(SQL2, decode(body.base)), body);
  }

  // src/storage/local.js
  async function openCache() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open("lean-center-lc1", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("kv");
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  function load(cache2, key) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readonly"), r = t.objectStore("kv").get(key);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  function save(cache2, key, value) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readwrite");
      t.objectStore("kv").put(value, key);
      t.oncomplete = resolve;
      t.onabort = () => reject(t.error || new Error("\u0417\u0430\u043F\u0438\u0441\u044C \u043F\u0440\u0435\u0440\u0432\u0430\u043D\u0430"));
      t.onerror = () => reject(t.error);
    });
  }
  function saveWorkspace(cache2, expected, value) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readwrite"), s = t.objectStore("kv"), r = s.get("workspace");
      let reason;
      const next = expected + 1;
      r.onsuccess = () => {
        if ((r.result?.generation || 0) !== expected) {
          reason = new Error("\u0414\u0440\u0443\u0433\u0430\u044F \u0432\u043A\u043B\u0430\u0434\u043A\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430 \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E. \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443.");
          t.abort();
          return;
        }
        s.put({ generation: next, state: value }, "workspace");
      };
      t.oncomplete = () => resolve(next);
      t.onabort = () => reject(reason || t.error || new Error("\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430"));
      t.onerror = () => reject(t.error);
    });
  }

  // src/storage/network.js
  var textBytes = (s) => new TextEncoder().encode(s);
  async function chooseFolder() {
    invariant(window.showDirectoryPicker, "\u0412\u044B\u0431\u043E\u0440 \u043F\u0430\u043F\u043A\u0438 \u0437\u0430\u043F\u0440\u0435\u0449\u0451\u043D \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u043E\u043C. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0440\u0443\u0447\u043D\u043E\u0439 \u0438\u043C\u043F\u043E\u0440\u0442 \u0438 \u044D\u043A\u0441\u043F\u043E\u0440\u0442.");
    return window.showDirectoryPicker({ id: "lean-center-network", mode: "readwrite" });
  }
  async function permission(h, request = false) {
    if (!h) return false;
    let p = await h.queryPermission({ mode: "readwrite" });
    if (p !== "granted" && request) p = await h.requestPermission({ mode: "readwrite" });
    return p === "granted";
  }
  async function sub(h, name, create = false) {
    return h.getDirectoryHandle(name, { create });
  }
  async function readFile(dir, name, max = MAX_DB) {
    const f = await (await dir.getFileHandle(name)).getFile();
    invariant(f.size <= max, "\u0424\u0430\u0439\u043B \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043B\u0438\u043C\u0438\u0442: " + name);
    return new Uint8Array(await f.arrayBuffer());
  }
  async function writeNew(dir, name, data) {
    try {
      await dir.getFileHandle(name);
      throw new Error("\u0424\u0430\u0439\u043B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442: " + name);
    } catch (e) {
      if (e.name !== "NotFoundError") throw e;
    }
    const f = await dir.getFileHandle(name, { create: true }), w = await f.createWritable();
    try {
      await w.write(data);
      await w.close();
    } catch (e) {
      try {
        await w.abort();
      } catch {
      }
      throw e;
    }
    const expected = typeof data === "string" ? textBytes(data) : data;
    const back = await readFile(dir, name, Math.max(MAX_DB, expected.length));
    invariant(await sha256(back) === await sha256(expected), "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u043F\u0440\u043E\u0448\u043B\u0430 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C SHA-256: " + name);
  }
  async function testFolder(h) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043D\u0430 \u0437\u0430\u043F\u0438\u0441\u044C");
    const name = ".lean-test-" + uuid() + ".txt";
    await writeNew(h, name, "LEAN CENTER / TEST");
    await h.removeEntry(name);
    return true;
  }
  async function sendPackage(h, p) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const d = await sub(h, "Exchange", true);
    await writeNew(d, "change-" + p.id + ".leanpkg", canonical(p));
  }
  async function listPackages(h) {
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    let d;
    try {
      d = await sub(h, "Exchange");
    } catch (e) {
      if (e.name === "NotFoundError") return [];
      throw e;
    }
    const result = [];
    for await (const [name, entry] of d.entries()) {
      if (entry.kind !== "file" || !/^change-[0-9a-f-]+\.leanpkg$/i.test(name)) continue;
      try {
        const p = JSON.parse(new TextDecoder().decode(await readFile(d, name, MAX_PACKAGE)));
        invariant(name === "change-" + p.id + ".leanpkg", "\u0418\u043C\u044F \u043F\u0430\u043A\u0435\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 ID");
        result.push({ name, p });
      } catch (e) {
        result.push({ name, error: e.message });
      }
    }
    return result.sort((a, b) => (a.p?.created_at || "").localeCompare(b.p?.created_at || ""));
  }
  async function latestSnapshot(h, SQL2, databaseId = null) {
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    let d;
    try {
      d = await sub(h, "Database");
    } catch (e) {
      if (e.name === "NotFoundError") return null;
      throw e;
    }
    const manifests = [];
    for await (const [name, entry] of d.entries()) {
      if (entry.kind !== "file" || !/^publication-[0-9a-f-]+\.json$/i.test(name)) continue;
      const m = JSON.parse(new TextDecoder().decode(await readFile(d, name, 65536)));
      invariant(name === "publication-" + m.id + ".json", "\u0418\u043C\u044F \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
      if (!databaseId || m.database_id === databaseId) manifests.push(m);
    }
    if (!manifests.length) return null;
    invariant(new Set(manifests.map((m) => m.database_id)).size === 1, "\u0412 \u043F\u0430\u043F\u043A\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0431\u0430\u0437. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0439.");
    const ids = new Set(manifests.map((m) => m.id)), parents = new Set(manifests.map((m) => m.parent_id));
    const heads = manifests.filter((m) => !parents.has(m.id));
    invariant(heads.length === 1, "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u043F\u0430\u0440\u0430\u043B\u043B\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0430\u0437\u0431\u043E\u0440");
    const head = heads[0];
    const seen = /* @__PURE__ */ new Set();
    let node = head;
    while (node) {
      invariant(!seen.has(node.id), "\u0426\u0438\u043A\u043B \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
      seen.add(node.id);
      node = node.parent_id ? manifests.find((m) => m.id === node.parent_id) : null;
    }
    invariant(seen.size === ids.size, "\u0420\u0430\u0437\u043E\u0440\u0432\u0430\u043D\u0430 \u0446\u0435\u043F\u043E\u0447\u043A\u0430 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
    const bytes = await readFile(d, "snapshot-" + head.id + ".sqlite");
    const db = await readSnapshot(SQL2, head, bytes);
    return { manifest: head, db, bytes };
  }
  async function publishSnapshot(h, SQL2, snapshot) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const current = await latestSnapshot(h, SQL2);
    try {
      invariant(!current ? snapshot.manifest.parent_id === null : current.manifest.database_id === snapshot.manifest.database_id && current.manifest.id === snapshot.manifest.parent_id, "\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u0431\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u044D\u0442\u043E \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0435\u0451.");
    } finally {
      current?.db.close();
    }
    const d = await sub(h, "Database", true);
    await writeNew(d, "snapshot-" + snapshot.manifest.id + ".sqlite", snapshot.bytes);
    await writeNew(d, "publication-" + snapshot.manifest.id + ".json", canonical(snapshot.manifest));
    const verified = await latestSnapshot(h, SQL2, snapshot.manifest.database_id);
    try {
      invariant(verified?.manifest.id === snapshot.manifest.id, "\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430");
    } finally {
      verified?.db.close();
    }
  }
  async function saveBackup(h, obj) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const d = await sub(h, "Backups", true);
    await writeNew(d, "backup-" + uuid() + ".leanbackup", canonical(obj));
  }

  // src/app.js
  var root = document.getElementById("app");
  var SQL;
  var ws;
  var cache;
  var folder;
  var generation = 0;
  var busy = false;
  var master = false;
  var page = "home";
  var theme = false;
  var status = "\u0413\u043E\u0442\u043E\u0432\u043E";
  var error = false;
  var chart = null;
  var edit = null;
  var query = "";
  var incoming = [];
  var planned = { sop: "\u0421\u041E\u041F \u0438 \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430", frv: "\u0424\u0420\u0412", twi: "TWI \u0438 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", skills: "\u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438", mentoring: "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u0447\u0435\u0441\u0442\u0432\u043E", audit: "\u0410\u0443\u0434\u0438\u0442 \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F", calendar: "\u041F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435", actions: "\u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u044F", analytics: "\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430", ai: "\u0418\u0418-\u043F\u043E\u043C\u043E\u0449\u043D\u0438\u043A" };
  var labels2 = { home: "\u041E\u0431\u0437\u043E\u0440 \u0446\u0435\u043D\u0442\u0440\u0430", ...Object.fromEntries(Object.entries(definitions).map(([k, v]) => [k, v.label])), ...planned, storage: "\u0411\u0430\u0437\u0430 \u0438 \u043E\u0431\u043C\u0435\u043D" };
  function el(tag, text, cls) {
    const n = document.createElement(tag);
    if (text !== void 0) n.textContent = text;
    if (cls) n.className = cls;
    return n;
  }
  function add(parent, ...children) {
    parent.append(...children);
    return parent;
  }
  function btn(label, fn, cls = "", disabled = false) {
    const n = el("button", label, cls);
    n.type = "button";
    n.disabled = disabled || busy;
    n.addEventListener("click", fn);
    return n;
  }
  function pane(title, ...children) {
    return add(el("section", void 0, "panel"), el("h2", title), ...children);
  }
  function message(s, bad = false) {
    status = s;
    error = bad;
    const n = document.getElementById("status");
    if (n) {
      n.textContent = s;
      n.className = "status" + (bad ? " error" : "");
    }
  }
  function navigate(p) {
    page = p;
    edit = null;
    query = "";
    render();
  }
  async function persist() {
    if (cache) generation = await saveWorkspace(cache, generation, ws.state());
  }
  function replace(newWs) {
    ws?.close();
    ws = newWs;
  }
  async function run(fn, { save: save2 = true } = {}) {
    if (busy) return;
    const prev = ws.state();
    busy = true;
    document.querySelectorAll("button").forEach((b) => b.disabled = true);
    message("\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F\u2026");
    try {
      const m = await fn();
      if (save2) await persist();
      message(m || "\u0413\u043E\u0442\u043E\u0432\u043E");
    } catch (e) {
      console.error(e);
      replace(new Workspace(SQL, openDb(SQL, prev.base), prev));
      message(e.message, true);
    } finally {
      busy = false;
      render();
    }
  }
  function download(name, body) {
    const url = URL.createObjectURL(new Blob([canonical(body)], { type: "application/json" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function pick(accept, fn, max = 150 * 1024 * 1024) {
    const i = el("input");
    i.type = "file";
    i.accept = accept;
    i.onchange = () => {
      const f = i.files?.[0];
      if (f) run(async () => {
        invariant(f.size <= max, "\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
        return await fn(JSON.parse(await f.text()));
      });
    };
    i.click();
  }
  var empty = () => !ws.pending.length && !ws.dirty && !meta(ws.base, "publication_id") && Object.keys(definitions).every((t) => list(ws.base, t).length === 0);
  function refName(type, id) {
    if (!id) return "\u2014";
    const v = one(ws.working, "SELECT * FROM " + type + " WHERE id=?", [id]);
    return v?.display_name || v?.name || id;
  }
  function showVal(k, f, v) {
    if (f.ref) return refName(f.ref, v[k]);
    if (k === "criticality") return { normal: "\u041E\u0431\u044B\u0447\u043D\u0430\u044F", important: "\u0412\u0430\u0436\u043D\u0430\u044F", critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" }[v[k]] || v[k];
    return v[k] ?? "\u2014";
  }
  var ICON_PATHS = {
    home: ["M3 10 12 3l9 7v10H3z", "M9 20v-6h6v6"],
    sop: ["M6 3h9l4 4v14H6z", "M14 3v5h5", "M9 12h7M9 16h7"],
    frv: ["M12 5a7 7 0 1 0 7 7 7 7 0 0 0-7-7z", "M12 8v4l3 2M9 2h6"],
    twi: ["M3 5h7l2 2 2-2h7v15h-7l-2 1-2-1H3z", "M12 7v14"],
    skills: ["M3 4h18v16H3z", "M3 9h18M3 14h18M9 4v16M15 4v16"],
    mentoring: ["M9 4a3 3 0 1 0 0 6 3 3 0 0 0 0-6z", "M3 20v-3c0-3 12-3 12 0v3", "M16 6h5M18.5 3.5v5"],
    audit: ["M5 4h14v17H5z", "M9 4V2h6v2", "m8 10 2 2 4-4", "M8 16h8"],
    calendar: ["M3 6h18v15H3z", "M7 3v6M17 3v6M3 10h18", "M7 14h3M14 14h3"],
    actions: ["M4 5h16v15H4z", "m7 11 3 3 6-6"],
    analytics: ["M4 3v17h17", "M8 16v-5M13 16V7M18 16V4"],
    ai: ["m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"],
    org_unit: ["M8 3h8v5H8z", "M12 8v5M4 13h16M4 13v3M20 13v3", "M2 16h5v5H2zM17 16h5v5h-5z"],
    person: ["M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z", "M4 21v-3c0-6 16-6 16 0v3"],
    profession: ["M3 7h18v13H3z", "M8 7V4h8v3M3 12h18M10 12v3h4v-3"],
    equipment: ["M3 21V9l6 4V8l6 5V4h5v17z", "M6 17h2M11 17h2M16 17h2"],
    operation: ["M4 3h16v5H4zM4 16h16v5H4z", "M12 8v8m-3-3 3 3 3-3"],
    person_assignment: ["M3 4h18v16H3z", "M7 8h4M7 12h4M7 16h4", "m14 13 2 2 4-5"],
    storage: ["M4 7c0-4 16-4 16 0v10c0 4-16 4-16 0z", "M4 7c0 4 16 4 16 0M4 12c0 4 16 4 16 0"]
  };
  function icon(key, cls = "nav-icon") {
    const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
    for (const [k, v] of Object.entries({ viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.65", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", class: cls })) svg.setAttribute(k, v);
    for (const d of ICON_PATHS[key] || ICON_PATHS.home) {
      const p = document.createElementNS(ns, "path");
      p.setAttribute("d", d);
      svg.append(p);
    }
    return svg;
  }
  function navButton(k) {
    const n = btn("", () => navigate(k), "nav" + (page === k ? " active" : ""));
    n.append(icon(k), el("span", labels2[k]));
    if (page === k) n.setAttribute("aria-current", "page");
    return n;
  }
  function sectionHeading(title, caption) {
    return add(el("div", void 0, "section-heading"), el("h2", title), el("span", caption, "muted"));
  }
  function home(main) {
    main.append(sectionHeading("\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F", "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"));
    const g = el("div", void 0, "kpi-grid");
    const counts = Object.fromEntries(Object.keys(definitions).map((k) => [k, list(ws.working, k).filter((x) => !x.archived).length]));
    for (const [k, d] of Object.entries(definitions)) {
      const n = btn("", () => navigate(k), "tile");
      n.setAttribute("aria-label", d.label + ": " + counts[k]);
      add(n, add(el("div", void 0, "tile-head"), el("span", d.label, "muted"), icon(k, "tile-icon")), el("b", String(counts[k])), el("span", "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u2192", "tile-link"));
      g.append(n);
    }
    main.append(g);
    const c = el("div", void 0, "chart");
    main.append(pane("\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432", c));
    if (window.echarts) {
      chart = echarts.init(c, theme ? "dark" : null);
      chart.setOption(registryCountChart(Object.values(definitions).map((x) => x.label), Object.keys(definitions).map((k) => counts[k]), theme));
    }
    const links = el("div", void 0, "workspace-grid");
    for (const [k, n] of Object.entries(planned)) {
      const b = btn("", () => navigate(k), "workspace-link");
      b.append(icon(k), el("span", n));
      links.append(b);
    }
    main.append(pane("\u0420\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u043E\u0434\u0443\u043B\u0438", el("p", "\u0421\u041E\u041F, \u0424\u0420\u0412, TWI, \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438, \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0438 \u0430\u0443\u0434\u0438\u0442 \u2014 \u0440\u0430\u0432\u043D\u043E\u043F\u0440\u0430\u0432\u043D\u044B\u0435 \u043C\u043E\u0434\u0443\u043B\u0438 \u0446\u0435\u043D\u0442\u0440\u0430. \u041D\u0430 \u0442\u0435\u043A\u0443\u0449\u0435\u043C \u044D\u0442\u0430\u043F\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0431\u0430\u0437\u0430 \u0438 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438; \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u043C\u043E\u0434\u0443\u043B\u0438 \u0431\u0443\u0434\u0443\u0442 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0430\u0442\u044C\u0441\u044F \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E.", "muted"), links));
  }
  function form(type, v) {
    const d = definitions[type], f = el("form"), grid = el("div", void 0, "formgrid"), controls = {};
    for (const [k, x] of Object.entries(d.fields)) {
      let input;
      if (x.ref || x.options) {
        input = el("select");
        const option = el("option", "\u2014");
        option.value = "";
        input.append(option);
        const opts = x.ref ? list(ws.working, x.ref).filter((y) => !y.archived || v?.[k] === y.id).map((y) => [y.id, y.display_name || y.name]) : x.options.map((y) => [y, y === "normal" ? "\u041E\u0431\u044B\u0447\u043D\u0430\u044F" : y === "important" ? "\u0412\u0430\u0436\u043D\u0430\u044F" : y === "critical" ? "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" : y]);
        for (const [value, label] of opts) {
          const o = el("option", label);
          o.value = value;
          input.append(o);
        }
      } else {
        input = el("input");
        input.type = x.date ? "date" : "text";
        input.maxLength = 500;
      }
      input.name = k;
      input.required = !!x.required;
      input.value = v?.[k] ?? (k === "criticality" ? "normal" : k === "kind" ? "\u0423\u0447\u0430\u0441\u0442\u043E\u043A" : k === "valid_from" ? (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) : "");
      controls[k] = input;
      grid.append(add(el("label", void 0, "field"), el("span", x.label), input));
    }
    const submit = el("button", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C", "primary");
    submit.type = "submit";
    submit.disabled = busy;
    f.onsubmit = (e) => {
      e.preventDefault();
      const payload = Object.fromEntries(Object.entries(controls).map(([k, n]) => [k, n.value || null]));
      run(async () => {
        ws.edit(type, v?.id || null, payload);
        edit = null;
        return "\u0417\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
      });
    };
    return add(f, grid, add(el("div", void 0, "row"), submit, btn("\u041E\u0442\u043C\u0435\u043D\u0430", () => {
      edit = null;
      render();
    })));
  }
  function registry(main, type) {
    const d = definitions[type], items = list(ws.working, type), search = el("input");
    search.type = "search";
    search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0443";
    search.value = query;
    const panel = pane(d.label, add(el("div", void 0, "row"), search, btn("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C", () => {
      edit = {};
      render();
    }, "primary", !!ws.conflicts.length)));
    main.append(panel);
    if (edit !== null) panel.append(pane(edit.id ? "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435" : "\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C", form(type, edit)));
    const wrap = el("div", void 0, "tablewrap");
    panel.append(wrap);
    function draw() {
      wrap.replaceChildren();
      const data = items.filter((v) => Object.entries(d.fields).some(([k, f]) => String(showVal(k, f, v)).toLowerCase().includes(query.toLowerCase())));
      if (!data.length) {
        wrap.append(el("p", "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439", "empty"));
        return;
      }
      const t = el("table"), head = el("tr");
      for (const f of Object.values(d.fields)) head.append(el("th", f.label));
      head.append(el("th", "\u0412\u0435\u0440\u0441\u0438\u044F / \u0441\u0442\u0430\u0442\u0443\u0441"), el("th", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F"));
      t.append(add(el("thead"), head));
      const body = el("tbody");
      for (const v of data) {
        const tr = el("tr", void 0, v.archived ? "archive" : "");
        for (const [k, f] of Object.entries(d.fields)) tr.append(el("td", String(showVal(k, f, v))));
        tr.append(el("td", v.archived ? "\u0410\u0440\u0445\u0438\u0432 \xB7 v" + v.rev : "v" + v.rev));
        const a = el("td");
        if (!v.archived) {
          a.append(btn("\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C", () => {
            edit = v;
            render();
          }, "", !!ws.conflicts.length));
          if (type !== "person_assignment") a.append(btn("\u0410\u0440\u0445\u0438\u0432", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C? \u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F.")) run(async () => {
              ws.edit(type, v.id, null, "archive");
              return "\u0417\u0430\u043F\u0438\u0441\u044C \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
            });
          }, "danger", !!ws.conflicts.length));
        }
        tr.append(a);
        body.append(tr);
      }
      t.append(body);
      wrap.append(t);
    }
    search.oninput = () => {
      query = search.value;
      draw();
    };
    draw();
  }
  async function useSnapshot(db) {
    if (meta(db, "database_id") === meta(ws.base, "database_id")) {
      ws.replaceBase(db);
      return;
    }
    if (!empty()) {
      db.close();
      throw new Error("\u042D\u0442\u043E \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u0435\u0451 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.");
    }
    replace(new Workspace(SQL, db));
  }
  async function refresh() {
    invariant(folder, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
    invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F");
    const s = await latestSnapshot(folder, SQL);
    invariant(s, "\u0412 \u043F\u0430\u043F\u043A\u0435 \u043D\u0435\u0442 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0431\u0430\u0437\u044B");
    await useSnapshot(s.db);
    return ws.conflicts.length ? "\u041E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u043E; \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439" : "\u0417\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0431\u0430\u0437\u0430";
  }
  async function publish() {
    invariant(master, "\u0412\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
    invariant(folder, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
    invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F");
    const snapshot = await prepareSnapshot(ws);
    await publishSnapshot(folder, SQL, snapshot);
    const db = await readSnapshot(SQL, snapshot.manifest, snapshot.bytes);
    replace(new Workspace(SQL, db, { device: ws.device }));
    return "\u0411\u0430\u0437\u0430 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430 \u043F\u043E SHA-256";
  }
  function storage(main) {
    const mode = el("input");
    mode.type = "checkbox";
    mode.checked = master;
    mode.onchange = () => {
      master = mode.checked;
      render();
    };
    const summary = pane("\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F", el("p", "ID \u0431\u0430\u0437\u044B: " + meta(ws.base, "database_id"), "muted"), el("p", "\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F: " + (meta(ws.base, "publication_id") || "\u0435\u0449\u0451 \u043D\u0435\u0442"), "muted"), el("p", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F: " + ws.pending.length + " \xB7 \u041F\u0440\u0438\u043D\u044F\u0442\u043E, \u043D\u043E \u043D\u0435 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043E: " + (ws.dirty ? "\u0434\u0430" : "\u043D\u0435\u0442")), add(el("label", void 0, "row"), mode, el("span", "\u0420\u0435\u0436\u0438\u043C \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F (\u0442\u043E\u043B\u044C\u043A\u043E \u0443\u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0435\u043D\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A)")), el("p", "\u0420\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F \u2014 \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0430\u0442\u0435\u043B\u044C, \u043D\u0435 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u044F. \u041F\u0440\u0430\u0432\u0430 \u043F\u0430\u043F\u043A\u0438 \u043D\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u044E\u0442\u0441\u044F \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F.", "muted"));
    main.append(summary);
    const controls = add(el("div", void 0, "row"), btn("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u0435\u0442\u0435\u0432\u0443\u044E \u043F\u0430\u043F\u043A\u0443", () => run(async () => {
      folder = await chooseFolder();
      if (cache) await save(cache, "folder", folder);
      return "\u0412\u044B\u0431\u0440\u0430\u043D\u0430 \u043F\u0430\u043F\u043A\u0430: " + folder.name;
    }, { save: false }), "primary"), btn("\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0434\u043E\u0441\u0442\u0443\u043F", () => run(async () => {
      invariant(folder, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
      await testFolder(folder);
      return "\u0427\u0442\u0435\u043D\u0438\u0435, \u0437\u0430\u043F\u0438\u0441\u044C \u0438 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u0442\u0435\u0441\u0442\u043E\u0432\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B";
    }, { save: false }), "", !folder), btn("\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0438\u0437 \u043F\u0430\u043F\u043A\u0438", () => run(refresh), "", !folder), btn("\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", () => run(async () => {
      invariant(folder, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
      await sendPackage(folder, await ws.package());
      return "\u041F\u0430\u043A\u0435\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0431\u0430\u0437\u043E\u0439";
    }, { save: false }), "", !folder || !ws.pending.length || !!ws.conflicts.length));
    main.append(pane("\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u043F\u0430\u043F\u043A\u0430", el("p", folder ? "\u041F\u0430\u043F\u043A\u0430: " + folder.name : "\u041D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u0430", "muted"), controls));
    const masterPanel = pane("\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u0438 \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", el("p", "\u0418\u0437\u0434\u0430\u0442\u0435\u043B\u044C \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438 \u043F\u0443\u0431\u043B\u0438\u043A\u0443\u0435\u0442 \u043D\u043E\u0432\u0443\u044E \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E. \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0444\u0430\u0439\u043B\u044B \u043D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u044E\u0442\u0441\u044F.", "muted"), add(el("div", void 0, "row"), btn("\u041F\u0440\u0438\u043D\u044F\u0442\u044C \u0441\u0432\u043E\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", () => run(async () => {
      const n = await ws.acceptOwn();
      return "\u041F\u0440\u0438\u043D\u044F\u0442\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439: " + n;
    }), "", !master || !ws.pending.length || !!ws.conflicts.length), btn("\u0421\u043F\u0438\u0441\u043E\u043A \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0445", () => run(async () => {
      invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430");
      incoming = await listPackages(folder);
      return "\u041D\u0430\u0439\u0434\u0435\u043D\u043E \u043F\u0430\u043A\u0435\u0442\u043E\u0432: " + incoming.length;
    }, { save: false }), "", !folder || !master), btn("\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u0431\u0430\u0437\u0443", () => run(publish), "primary", !folder || !master || !!ws.pending.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u043F\u0430\u043A\u0435\u0442\u0430 \u0432\u0440\u0443\u0447\u043D\u0443\u044E", () => pick(".leanpkg,.json", async (p) => {
      invariant(master, "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
      const result = await ws.accept(p);
      return result.duplicate ? "\u041F\u0430\u043A\u0435\u0442 \u0443\u0436\u0435 \u043F\u0440\u0438\u043D\u044F\u0442" : "\u041F\u0440\u0438\u043D\u044F\u0442\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439: " + result.count;
    }, MAX_PACKAGE), "", !master)));
    for (const item of incoming) {
      const p = item.p, known = p && one(ws.base, "SELECT id FROM exchange_package WHERE id=?", [p.id]);
      masterPanel.append(add(el("div", void 0, "row"), el("span", item.name + " \xB7 " + (item.error || (known ? "\u043F\u0440\u0438\u043D\u044F\u0442" : p.events?.length + " \u0441\u043E\u0431\u044B\u0442\u0438\u0439")), "muted"), btn("\u041F\u0440\u0438\u043D\u044F\u0442\u044C", () => run(async () => {
        const x = await ws.accept(p);
        return x.duplicate ? "\u0423\u0436\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u043E" : "\u041F\u0440\u0438\u043D\u044F\u0442\u043E: " + x.count;
      }), "", !!known || !master || !p || !!ws.pending.length)));
    }
    main.append(masterPanel);
    main.append(pane("\u041F\u0435\u0440\u0435\u043D\u043E\u0441 \u0438 \u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435", add(el("div", void 0, "row"), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043F\u0430\u043A\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", () => run(async () => {
      const p = await ws.package();
      download("change-" + p.id + ".leanpkg", p);
      return "\u041F\u0430\u043A\u0435\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false }), "", !ws.pending.length || !!ws.conflicts.length), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E", () => run(async () => {
      download("lean-" + uuid() + ".leanbackup", await backup(ws));
      return "\u041A\u043E\u043F\u0438\u044F \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
    }, { save: false })), btn("\u041A\u043E\u043F\u0438\u044F \u043D\u0430 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u0434\u0438\u0441\u043A", () => run(async () => {
      await saveBackup(folder, await backup(ws));
      return "\u041A\u043E\u043F\u0438\u044F \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430";
    }, { save: false }), "", !folder), btn("\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u043A\u043E\u043F\u0438\u044E", () => pick(".leanbackup,.json", async (obj) => {
      const next = await restore(SQL, obj);
      if (!empty() && !confirm("\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E? \u0423\u0431\u0435\u0434\u0438\u0442\u0435\u0441\u044C, \u0447\u0442\u043E \u0441\u043A\u0430\u0447\u0430\u043B\u0438 \u0435\u0451 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) {
        next.close();
        return "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
      }
      replace(next);
      return "\u041A\u043E\u043F\u0438\u044F \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 ID \u0431\u0430\u0437\u044B";
    })), btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A \u0434\u043B\u044F \u0440\u0443\u0447\u043D\u043E\u0433\u043E \u043E\u0431\u043C\u0435\u043D\u0430", () => run(async () => {
      invariant(master, "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
      const s = await prepareSnapshot(ws);
      download("snapshot-" + s.manifest.id + ".leansnapshot", { manifest: s.manifest, base: encode(s.bytes) });
      replace(new Workspace(SQL, await readSnapshot(SQL, s.manifest, s.bytes), { device: ws.device }));
      return "\u0421\u043D\u0438\u043C\u043E\u043A \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0441\u043A\u0430\u0447\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u0439\u043B; \u0440\u0443\u0447\u043D\u0430\u044F \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430";
    }), "", !master || !!ws.pending.length || !!folder), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A", () => pick(".leansnapshot,.json", async (obj) => {
      await useSnapshot(await readSnapshot(SQL, obj.manifest, decode(obj.base)));
      return "\u0421\u043D\u0438\u043C\u043E\u043A \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D \u0438 \u043E\u0442\u043A\u0440\u044B\u0442";
    })))));
    if (ws.conflicts.length) {
      const p = pane("\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", el("p", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E. \u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0438\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u044B; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u0430\u043D\u044B.", "bad"));
      for (const c of ws.conflicts) {
        p.append(el("p", c.error, "bad"));
        const v = one(ws.working, "SELECT * FROM " + c.event.entity_type + " WHERE id=?", [c.event.entity_id]);
        p.append(el("pre", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435: " + JSON.stringify(c.event.payload, null, 2) + "\n\u0422\u0435\u043A\u0443\u0449\u0435\u0435: " + JSON.stringify(v, null, 2), "muted"));
      }
      p.append(add(el("div", void 0, "row"), btn("\u041E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", () => {
        if (confirm("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0435\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435? \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
          ws.resolveConflict("discard");
          return "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0435\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435 \u043E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
        });
      }, "danger"), btn("\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0441\u0432\u043E\u0451 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435", () => {
        if (confirm("\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0432\u0430\u0448\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E\u0432\u0435\u0440\u0445 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0440\u0435\u0432\u0438\u0437\u0438\u0438? \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
          ws.resolveConflict("reapply");
          return "\u0421\u043E\u0437\u0434\u0430\u043D\u043E \u043D\u043E\u0432\u043E\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435; \u043E\u043D\u043E \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438";
        });
      })));
      main.append(p);
    }
    main.append(pane("\u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u044F", el("p", "\u0422\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0443\u0441\u0442\u043E\u0439 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0439 \u0431\u0430\u0437\u0435. \u041D\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u043A\u0430\u043A \u0440\u0430\u0431\u043E\u0447\u0443\u044E.", "muted"), btn("\u041D\u043E\u0432\u0430\u044F \u043F\u0443\u0441\u0442\u0430\u044F \u0431\u0430\u0437\u0430", () => {
      if (confirm("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0443\u0441\u0442\u0443\u044E \u0431\u0430\u0437\u0443 \u0432\u043C\u0435\u0441\u0442\u043E \u0442\u0435\u043A\u0443\u0449\u0435\u0439? \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
        replace(new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration)));
        folder = null;
        incoming = [];
        master = false;
        if (cache) await save(cache, "folder", null);
        return "\u041D\u043E\u0432\u0430\u044F \u043F\u0443\u0441\u0442\u0430\u044F \u0431\u0430\u0437\u0430 \u0441\u043E\u0437\u0434\u0430\u043D\u0430";
      });
    }, "danger"), btn("\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0434\u0435\u043C\u043E-\u0434\u0430\u043D\u043D\u044B\u043C\u0438", () => run(async () => {
      invariant(empty(), "\u0414\u0435\u043C\u043E \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0443\u0441\u0442\u043E\u0439 \u0431\u0430\u0437\u0435");
      const u = ws.edit("org_unit", null, { code: "DEMO", name: "\u0423\u0447\u0435\u0431\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", kind: "\u041F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", parent_id: null });
      const v = ws.edit("org_unit", null, { code: "DEMO-M", name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0443\u0447\u0430\u0441\u0442\u043E\u043A", kind: "\u0423\u0447\u0430\u0441\u0442\u043E\u043A", parent_id: u });
      const p = ws.edit("profession", null, { code: "DEMO-MECH", name: "\u041C\u0435\u0445\u0430\u043D\u0438\u043A" });
      const a = ws.edit("person", null, { employee_code: "DEMO-001", display_name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A 01" });
      const e = ws.edit("equipment", null, { unit_id: v, code: "DEMO-E", name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0441\u0442\u0435\u043D\u0434" });
      ws.edit("operation", null, { unit_id: v, equipment_id: e, code: "DEMO-O", name: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u0442\u0435\u043D\u0434\u0430", criticality: "normal" });
      ws.edit("person_assignment", null, { person_id: a, unit_id: v, profession_id: p, shift_code: "1", valid_from: "2026-11-25", valid_to: null });
      return "\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u044B \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438";
    }), "", !empty())));
  }
  function render() {
    chart?.dispose();
    chart = null;
    document.documentElement.classList.toggle("dark", theme);
    const header = el("header", void 0, "corp-header");
    const brand = add(el("div", void 0, "brand-lockup"), el("div", void 0, "brand-mark"), add(el("div"), el("div", "LEAN CENTER", "brand"), el("div", "\u0426\u0435\u043D\u0442\u0440 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u044B", "brand-sub")));
    const metaPanel = add(el("div", void 0, "header-meta"), el("span", window.LC_BUILD.version || "lc1.3", "version"), btn(theme ? "\u0421\u0432\u0435\u0442\u043B\u0430\u044F \u0442\u0435\u043C\u0430" : "\u0422\u0451\u043C\u043D\u0430\u044F \u0442\u0435\u043C\u0430", () => {
      theme = !theme;
      render();
    }), btn("\u0425\u0440\u0430\u043D\u0435\u043D\u0438\u0435", () => navigate("storage")));
    header.append(brand, metaPanel);
    const side = el("aside", void 0, "sidebar");
    side.setAttribute("aria-label", "\u041D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F");
    const group = (name, keys) => {
      side.append(el("div", name, "navgroup"));
      for (const k of keys) side.append(navButton(k));
    };
    group("\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E", ["home", ...Object.keys(planned)]);
    group("\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438", Object.keys(definitions));
    group("\u0421\u0438\u0441\u0442\u0435\u043C\u0430", ["storage"]);
    const main = el("main", void 0, "main");
    const section = page === "home" ? "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E" : page === "storage" ? "\u0421\u0438\u0441\u0442\u0435\u043C\u0430" : Object.hasOwn(definitions, page) ? "\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438" : "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E";
    const top = add(el("div", void 0, "top"), add(el("div"), el("div", section, "eyebrow"), el("h1", labels2[page]), el("div", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \xB7 " + ws.pending.length + " \u043E\u0436\u0438\u0434\u0430\u044E\u0449\u0438\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", "muted")), el("span", folder ? "\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u043F\u0430\u043F\u043A\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u0430" : "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F", "pill"));
    main.append(top);
    const stat = el("div", status, "status" + (error ? " error" : ""));
    stat.id = "status";
    stat.setAttribute("role", "status");
    main.append(stat);
    if (!cache) main.append(el("p", "IndexedDB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0430\u043C\u044F\u0442\u0438 \u2014 \u0441\u043A\u0430\u0447\u0438\u0432\u0430\u0439\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0434\u043E \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u044F.", "bad"));
    if (ws.conflicts.length) main.append(el("p", "\u0415\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \xAB\u0411\u0430\u0437\u0430 \u0438 \u043E\u0431\u043C\u0435\u043D\xBB.", "bad"));
    if (ws.dirty) main.append(el("p", "\u041F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0435\u0449\u0451 \u043D\u0435 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u044B.", "warn"));
    root.replaceChildren(add(el("div", void 0, "shell"), header, side, main));
    if (page === "home") home(main);
    else if (page === "storage") storage(main);
    else if (Object.hasOwn(definitions, page)) registry(main, page);
    else main.append(pane(labels2[page], el("p", "\u041C\u043E\u0434\u0443\u043B\u044C \u0437\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D \u043D\u0430 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0435 \u044D\u0442\u0430\u043F\u044B. \u0412 \u044D\u0442\u043E\u0439 \u0441\u0431\u043E\u0440\u043A\u0435 \u0433\u043E\u0442\u043E\u0432\u0438\u0442\u0441\u044F \u0435\u0434\u0438\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \u0438 \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u0430.", "muted")));
    main.append(el("p", "LC1.3 \xB7 \u0430\u0432\u0442\u043E\u043D\u043E\u043C\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F \xB7 \u043E\u0431\u0449\u0438\u0439 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u043E\u0431\u043C\u0435\u043D", "foot"));
  }
  window.addEventListener("resize", () => chart?.resize());
  async function init() {
    SQL = await window.initSqlJs({ wasmBinary: decode(window.LC_BUILD.wasm) });
    try {
      cache = await openCache();
      const s = await load(cache, "workspace");
      generation = s?.generation || 0;
      folder = await load(cache, "folder");
      ws = s ? new Workspace(SQL, openDb(SQL, s.state.base), s.state) : new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration));
      if (!s) await persist();
      if (folder && await permission(folder, false)) {
        const prev = ws.state();
        try {
          const remote = await latestSnapshot(folder, SQL);
          if (remote) {
            await useSnapshot(remote.db);
            await persist();
            message(ws.conflicts.length ? "\u0411\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430, \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B" : "\u0411\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430 \u0438\u0437 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u043F\u0430\u043F\u043A\u0438");
          }
        } catch (e) {
          replace(new Workspace(SQL, openDb(SQL, prev.base), prev));
          message("\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u0431\u0430\u0437\u0430 \u043D\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430: " + e.message, true);
        }
      }
    } catch (e) {
      if (!cache) {
        ws = new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration));
        message("IndexedDB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D, \u0440\u0443\u0447\u043D\u043E\u0439 \u0440\u0435\u0436\u0438\u043C: " + e.message, true);
      } else if (ws) {
        message("\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043D\u0435 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u0430: " + e.message, true);
        cache = null;
      } else throw e;
    }
    render();
  }
  init().catch((e) => {
    console.error(e);
    root.replaceChildren(el("h1", "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C Lean Center"), el("p", e.message), el("p", "\u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0443\u0434\u0430\u043B\u0435\u043D\u044B. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0431\u0440\u0430\u0443\u0437\u0435\u0440 \u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E."));
  });
})();
