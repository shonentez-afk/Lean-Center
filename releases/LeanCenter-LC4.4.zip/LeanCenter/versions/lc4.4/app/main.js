(() => {
  // src/modules/master-data/people-directory.js
  var personKey = (value) => String(value ?? "").normalize("NFKC").toLocaleLowerCase("ru-RU").replaceAll("\u0451", "\u0435").trim();
  var aliases = {
    instructor: ["instructor", "trainer", "internal_trainer", "internal trainer", "twi_instructor", "\u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 twi", "\u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440", "\u0432\u0442"],
    mentor: ["mentor", "\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", "twi_mentor"],
    trainee: ["trainee", "learner", "\u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0441\u0442\u0430\u0436\u0435\u0440", "twi_trainee"],
    evaluator: ["evaluator", "assessor", "\u043E\u0446\u0435\u043D\u0449\u0438\u043A", "\u0430\u0443\u0434\u0438\u0442\u043E\u0440"]
  };
  function roleKind(code, name) {
    for (const value of [name, code]) {
      const key3 = personKey(value).replaceAll("-", "_");
      for (const [kind, values] of Object.entries(aliases)) if (values.includes(key3)) return kind;
    }
    return null;
  }
  function directoryPeople(db, day) {
    const all = rows(db, `SELECT p.id,p.employee_code,p.display_name,COALESCE(pos.name,prof.name,'') position,COALESCE(u.name,'') unit FROM person p
 LEFT JOIN person_assignment a ON a.id=(SELECT a2.id FROM person_assignment a2 WHERE a2.person_id=p.id AND a2.valid_from<=? AND (a2.valid_to IS NULL OR a2.valid_to>=?) ORDER BY a2.valid_from DESC,a2.id LIMIT 1)
 LEFT JOIN position pos ON pos.id=a.position_id LEFT JOIN profession prof ON prof.id=a.profession_id LEFT JOIN org_unit u ON u.id=a.unit_id
 WHERE p.archived=0 ORDER BY p.display_name,p.employee_code`, [day, day]);
    const assigned = rows(db, `SELECT a.person_id,b.code,b.name FROM role_assignment a JOIN business_role b ON b.id=a.role_id WHERE b.archived=0 AND a.valid_from<=? AND (a.valid_to IS NULL OR a.valid_to>=?) ORDER BY b.name`, [day, day]);
    const index = /* @__PURE__ */ new Map();
    for (const x of assigned) {
      if (!index.has(x.person_id)) index.set(x.person_id, []);
      index.get(x.person_id).push({ code: x.code, name: x.name, kind: roleKind(x.code, x.name) });
    }
    return all.map((p) => ({ ...p, roles: index.get(p.id) || [] }));
  }

  // src/modules/library/linked-materials.js
  var str = (x) => typeof x === "string" ? x : "";
  var part = (x) => x === null || x === void 0 || String(x).trim() === "" ? 0 : Number(x);
  var twiFields = [
    ["prepare", "purpose", "\u0426\u0435\u043B\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"],
    ["prepare", "known", "\u041E\u043F\u044B\u0442 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E"],
    ["prepare", "prep", "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430"],
    ["prepare", "interest", "\u041C\u043E\u0442\u0438\u0432\u0430\u0446\u0438\u044F"],
    ["present", "round1", "\u041F\u0435\u0440\u0432\u044B\u0439 \u043F\u043E\u043A\u0430\u0437"],
    ["present", "round2", "\u0428\u0430\u0433\u0438 \u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B"],
    ["present", "round3", "\u041F\u0440\u0438\u0447\u0438\u043D\u044B"],
    ["tryOut", "perform", "\u041F\u0440\u043E\u0431\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435"],
    ["tryOut", "explain", "\u041E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435 \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u043E\u043C"],
    ["tryOut", "check", "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F"],
    ["tryOut", "correct", "\u0418\u0441\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043E\u0448\u0438\u0431\u043E\u043A"],
    ["followUp", "help", "\u041A \u043A\u043E\u043C\u0443 \u043E\u0431\u0440\u0430\u0449\u0430\u0442\u044C\u0441\u044F"],
    ["followUp", "control", "\u041F\u043E\u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C"],
    ["followUp", "observe", "\u0427\u0442\u043E \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u044C"],
    ["followUp", "close", "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"]
  ];
  function sopTwiInput(s) {
    const meta2 = s.meta || {};
    return { operation: meta2.operation, executor: meta2.executor, workplace: meta2.workplace, safety: meta2.safety, ...meta2.tools ? { tools: meta2.tools } : {}, ...meta2.material ? { material: meta2.material } : {}, steps: (s.steps || []).map((v, i) => ({ stepNumber: i + 1, action: v.action, keyPoints: Array.isArray(v.keyMoments) ? v.keyMoments.filter(Boolean) : [], reason: v.reason, successCriteria: v.successCriteria, decisionPoints: v.decisionPoints })) };
  }
  function sopTwiSignature(s) {
    const raw = JSON.stringify(sopTwiInput(s));
    let a = 2166136261, b = 0;
    for (let i = 0; i < raw.length; i++) {
      const n = raw.charCodeAt(i);
      a = Math.imul(a ^ n, 16777619) >>> 0;
      b = b + n >>> 0;
      b = b + (b << 10 >>> 0) >>> 0;
      b ^= b >>> 6;
    }
    b = b + (b << 3 >>> 0) >>> 0;
    b ^= b >>> 11;
    b = b + (b << 15 >>> 0) >>> 0;
    return "sop1:" + raw.length + ":" + a.toString(16) + ":" + (b >>> 0).toString(16);
  }
  function linkedTwi(s) {
    const t = s.twi || {}, fields = twiFields.map(([section, key3, label]) => ({ section, key: key3, label, value: str(t[section]?.[key3] ?? (key3 === "control" ? t[section]?.frequency : "")) }));
    const exists = fields.some((f) => f.value.trim()), signature = t.sourceSignature;
    return { exists, filled: fields.filter((f) => f.value.trim()).length, fields, trainer: str(t.trainer), trainee: str(t.trainee), status: !exists ? "\u041D\u0435 \u0441\u043E\u0437\u0434\u0430\u043D" : !signature ? "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438" : signature !== sopTwiSignature(s) ? "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u0430\u043A\u0442\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438" : "\u0421\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D", outdated: !!(exists && signature && signature !== sopTwiSignature(s)) };
  }
  function linkedFrv(s) {
    const totals = { seconds: 0, vdc: 0, m1: 0, m2: 0, unclassified: 0, distance: 0 };
    let start = 0;
    const rows2 = (s.steps || []).map((v, i) => {
      const f = v.frv || {}, seconds = v.durationSeconds, m1 = part(f.m1), m2 = part(f.m2), distance = part(f.move);
      const valid = [seconds, m1, m2, distance].every((x) => Number.isFinite(x) && x >= 0) && m1 + m2 <= seconds + 1e-4;
      const vdc = valid ? f.vdc === true ? Math.max(0, seconds - m1 - m2) : 0 : null;
      const unclassified = valid ? Math.max(0, seconds - vdc - m1 - m2) : null;
      const row = { position: i + 1, action: str(v.action), start, seconds, valid, vdc, m1: valid ? m1 : null, m2: valid ? m2 : null, unclassified, distance: valid ? distance : null, comment: str(f.comment) || v.keyMoments?.filter(Boolean).join("; ") || "" };
      if (Number.isFinite(seconds) && seconds >= 0) {
        start += seconds;
        totals.seconds += seconds;
      }
      if (valid) {
        for (const k of ["vdc", "m1", "m2", "unclassified", "distance"]) totals[k] += row[k];
      }
      return row;
    });
    return { rows: rows2, totals, invalid: rows2.filter((x) => !x.valid).length, exists: rows2.some((x) => x.action.trim()), meta: s.frvMeta || {} };
  }

  // src/modules/library/sop-review.js
  var text = (x, n = 500) => typeof x === "string" && x.trim() && x.length <= n;
  var sha = (x) => typeof x === "string" && /^[0-9a-f]{64}$/.test(x);
  var exact = (p, ks) => invariant(p && typeof p === "object" && !Array.isArray(p) && Object.keys(p).length === ks.length && ks.every((k) => Object.hasOwn(p, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F");
  var SOP_CHECKLIST_CODE = "SOP_APP4";
  function validDate(x) {
    return typeof x === "string" && /^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x;
  }
  function reviewDue(changed) {
    invariant(validDate(changed), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0421\u041E\u041F");
    const [y, m, d] = changed.split("-").map(Number);
    const day = Math.min(d, new Date(Date.UTC(y + 1, m, 0)).getUTCDate());
    return String(y + 1).padStart(4, "0") + "-" + String(m).padStart(2, "0") + "-" + String(day).padStart(2, "0");
  }
  function validateChecklist(p) {
    exact(p, ["format", "title", "source_sha256", "criteria"]);
    invariant(["lean-sop-checklist-v1", "lean-sop-checklist-v2"].includes(p.format) && text(p.title, 200) && sha(p.source_sha256) && Array.isArray(p.criteria) && (p.format === "lean-sop-checklist-v1" ? p.criteria.length === 20 : p.criteria.length >= 1 && p.criteria.length <= 100), "\u041D\u0443\u0436\u043D\u0430 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F: 20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 v1 \u043B\u0438\u0431\u043E 1\u2013100 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 v2");
    p.criteria.forEach((q, i) => {
      exact(q, ["code", "question"]);
      invariant(q.code === i + 1 && text(q.question, 2500), "\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u044F \u0438\u043B\u0438 \u0442\u0435\u043A\u0441\u0442 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u044F " + (i + 1));
    });
    return p;
  }
  function sopMethods(db) {
    return rows(db, "SELECT v.*,c.name FROM checklist_version v JOIN checklist c ON c.id=v.checklist_id WHERE c.code=? ORDER BY version_no DESC", [SOP_CHECKLIST_CODE]);
  }
  function sopCriteria(db, id) {
    return rows(db, "SELECT * FROM checklist_criterion WHERE version_id=? ORDER BY position", [id]);
  }
  function evaluationResult(responses, total = 20) {
    const rated = responses.filter((r) => r.value === 0 || r.value === 1);
    const yes = rated.filter((r) => r.value === 1).length;
    return { rated: rated.length, yes, no: rated.length - yes, total, fraction: total > 0 && responses.length === total && rated.length === total ? yes / total : null };
  }
  function applySopMethod(db, e, old) {
    invariant(e.operation === "create" && !old, "\u0412\u0435\u0440\u0441\u0438\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
    const p = validateChecklist(e.payload);
    const methods = sopMethods(db);
    invariant(!methods.some((m) => {
      const d = JSON.parse(m.methodology_json);
      return canonical(d.criteria) === canonical(p.criteria) && d.source_sha256 === p.source_sha256;
    }), "\u0422\u0430\u043A\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0443\u0436\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430");
    let c = one(db, "SELECT * FROM checklist WHERE code=?", [SOP_CHECKLIST_CODE]);
    if (!c) {
      db.run("INSERT INTO checklist(id,code,name) VALUES(?,?,?)", [e.id, SOP_CHECKLIST_CODE, "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F"]);
      c = { id: e.id };
    }
    const n = methods.length ? methods[0].version_no + 1 : 1;
    db.run("INSERT INTO checklist_version(id,checklist_id,version_no,state,methodology_json,rev) VALUES(?,?,?,'draft',?,1)", [e.entity_id, c.id, n, canonical(p)]);
    for (const q of p.criteria) db.run("INSERT INTO checklist_criterion(id,version_id,code,section_code,position,question) VALUES(?,?,?,?,?,?)", [e.entity_id + ":" + q.code, e.entity_id, String(q.code), "SOP", q.code, q.question]);
    db.run("UPDATE checklist_version SET state='retired',rev=rev+1 WHERE checklist_id=? AND state='active'", [c.id]);
    db.run("UPDATE checklist_version SET state='active' WHERE id=?", [e.entity_id]);
  }
  function applySopEvaluation(db, e, old) {
    invariant(e.operation === "create" && !old, "\u0417\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E");
    const p = e.payload;
    exact(p, ["revision_id", "method_id", "actor_id", "evaluated_on", "place", "source_sha256", "responses"]);
    invariant(isId(p.revision_id) && isId(p.method_id) && isId(p.actor_id) && validDate(p.evaluated_on) && text(p.place, 500) && sha(p.source_sha256), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0434\u0430\u0442\u0443, \u043C\u0435\u0441\u0442\u043E, \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u0435\u043C\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u0438 \u043E\u0446\u0435\u043D\u0449\u0438\u043A\u0430");
    const rev = one(db, "SELECT * FROM document_revision WHERE id=?", [p.revision_id]);
    invariant(rev && JSON.parse(rev.payload_json).source.sha256 === p.source_sha256, "\u0412\u0435\u0440\u0441\u0438\u044F \u0421\u041E\u041F \u0438\u043B\u0438 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C");
    const person2 = one(db, "SELECT display_name FROM person WHERE id=? AND archived=0", [p.actor_id]);
    invariant(person2, "\u041E\u0446\u0435\u043D\u0449\u0438\u043A \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442");
    invariant(sopMethods(db).some((m) => m.id === p.method_id && m.state === "active"), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F");
    const criteria = sopCriteria(db, p.method_id);
    invariant(criteria.length > 0 && Array.isArray(p.responses) && p.responses.length === criteria.length, "\u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043E\u0442\u0432\u0435\u0442\u0438\u0442\u044C \u043D\u0430 \u0432\u0441\u0435 " + criteria.length + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    p.responses.forEach((q, i) => {
      exact(q, ["criterion_id", "value", "note"]);
      invariant(q.criterion_id === criteria[i].id && (q.value === 0 || q.value === 1) && typeof q.note === "string" && q.note.length <= 2e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 " + (i + 1));
    });
    db.run("INSERT INTO sop_evaluation(id,revision_id,method_id,actor_id,evaluated_on,place,actor_name,source_sha256,recorded_at,rev) VALUES(?,?,?,?,?,?,?,?,?,1)", [e.entity_id, p.revision_id, p.method_id, p.actor_id, p.evaluated_on, p.place.trim(), person2.display_name, p.source_sha256, e.occurred_at]);
    for (const q of p.responses) db.run("INSERT INTO sop_evaluation_response(evaluation_id,method_id,criterion_id,value,note) VALUES(?,?,?,?,?)", [e.entity_id, p.method_id, q.criterion_id, q.value, q.note]);
  }

  // src/modules/training/domain.js
  var TRAINING_TYPES = Object.freeze({
    competency_matrix: "\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439",
    audit_session: "\u0410\u0443\u0434\u0438\u0442 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430",
    mentor_self_evaluation: "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430",
    mentor_order: "\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0439 \u043F\u0440\u0438\u043A\u0430\u0437",
    mentor_credential: "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u043E \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0435",
    mentor_appointment: "\u041F\u0440\u0438\u043A\u0430\u0437\u044B \u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0438",
    mentor_authorization: "\u041F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u044F \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430",
    training_program: "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F",
    training_enrollment: "\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430",
    training_task_result: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B",
    training_assignment: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F",
    training_session: "\u0424\u0430\u043A\u0442 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430",
    training_verification: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0437\u043D\u0430\u043D\u0438\u0439",
    assessment_session: "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 / \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F",
    admission_decision: "\u0420\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435",
    role_requirement: "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435 \u043A \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438",
    coverage_requirement: "\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C \u0432 \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u0438",
    development_plan: "\u041F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F",
    development_goal: "\u0426\u0435\u043B\u044C \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F"
  });
  var isLC41Event = (e) => e.entity_type === "mentor_order" || e.entity_type === "training_enrollment" && Object.hasOwn(e.payload || {}, "internship_start");
  var PRACTICAL_CODE = "PRACTICAL_APP8";
  var AUDIT_CODE = "TWI_L1_RC1";
  var SELF_CODE = "TWI_SELF_APP12";
  var extraFormats = ["lean-practical-checklist-v2", "lean-audit-checklist-v1", "lean-self-checklist-v1"];
  var isLC43Event = (e) => e.entity_type === "competency_matrix";
  var isLC42Event = (e) => ["audit_session", "mentor_self_evaluation"].includes(e.entity_type) || e.entity_type === "checklist_version" && [...extraFormats, "lean-sop-checklist-v2"].includes(e.payload?.format);
  var isTrainingEvent = (e) => Object.hasOwn(TRAINING_TYPES, e.entity_type) || e.entity_type === "checklist_version" && ["lean-practical-checklist-v1", ...extraFormats].includes(e.payload?.format);
  var exact2 = (p, keys) => invariant(p && typeof p === "object" && !Array.isArray(p) && Object.keys(p).length === keys.length && keys.every((k) => Object.hasOwn(p, k)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u043F\u043E\u043B\u044F LC4");
  var text2 = (x, n = 2e3) => typeof x === "string" && x.length <= n;
  var required = (x, n = 500) => text2(x, n) && x.trim().length > 0;
  var integer = (x, min = 0, max2 = 1e5) => Number.isSafeInteger(x) && x >= min && x <= max2;
  var date = (x) => validDate(x);
  var period = (a, b) => date(a) && (b === null || date(b) && b >= a);
  var plusDays = (day, n) => {
    const v = /* @__PURE__ */ new Date(day + "T00:00:00Z");
    v.setUTCDate(v.getUTCDate() + n);
    return v.toISOString().slice(0, 10);
  };
  var within = (x, a, b) => a <= x && (!b || b >= x);
  var beforeRevocation = (x, d) => !x || x.slice(0, 10) > d;
  var sha2 = (x) => typeof x === "string" && /^[0-9a-f]{64}$/.test(x);
  var roles = ["instructor", "mentor", "internal_trainer"];
  var programKinds = { entry: "\u0412\u0432\u043E\u0434 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E", internship: "\u0421\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0430", production: "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435" };
  var parts = { general: "\u041E\u0431\u0449\u0430\u044F \u0447\u0430\u0441\u0442\u044C", individual: "\u0418\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C", practice: "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043D\u0430\u0432\u044B\u043A\u0438", knowledge: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0437\u043D\u0430\u043D\u0438\u0439" };
  var variants = { classic: "\u041A\u043B\u0430\u0441\u0441\u0438\u0447\u0435\u0441\u043A\u0438\u0439", special: "\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u043D\u0430\u0432\u044B\u043A\u0438", smed: "\u0421\u043B\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u043F\u043E\u0432\u0442\u043E\u0440\u0430 / SMED", hazardous: "\u041E\u0441\u043E\u0431\u044B\u0435 \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438" };
  var conclusions = { not_meet: "\u041D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442", basic: "\u0421\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0431\u0430\u0437\u043E\u0432\u043E\u043C\u0443 \u0443\u0440\u043E\u0432\u043D\u044E", exceeds: "\u041F\u0440\u0435\u0432\u043E\u0441\u0445\u043E\u0434\u0438\u0442 \u0431\u0430\u0437\u043E\u0432\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C" };
  var prepare = [["prepare", "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430"]];
  var show = [["show1", "\u041F\u043E\u043A\u0430\u0437: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F"], ["show2", "\u041F\u043E\u043A\u0430\u0437: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B"], ["show3", "\u041F\u043E\u043A\u0430\u0437: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F, \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u044B"]];
  var practice = [["try1", "\u041F\u0440\u043E\u0431\u0430: \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435"], ["try2", "\u041F\u0440\u043E\u0431\u0430: \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439"], ["try3", "\u041F\u0440\u043E\u0431\u0430: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B"], ["try4", "\u041F\u0440\u043E\u0431\u0430: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F, \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u044B"]];
  var support = [["support", "\u0421\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u0438 \u043F\u043E\u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430"], ...Array.from({ length: 5 }, (_, i) => ["follow" + (i + 1), "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 " + (i + 1)])];
  function jiStages(variant) {
    invariant(Object.hasOwn(variants, variant), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0432\u0438\u0434 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430");
    let middle;
    if (variant === "classic") middle = [...show, ...practice];
    if (variant === "special") middle = [...show.map(([k, v]) => [k, v + " \xB7 \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0442\u043E\u0440 \u0438 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440"]), ...practice];
    if (variant === "smed") middle = [...Array.from({ length: 3 }, (_, i) => ["show_sim" + (i + 1), "\u041F\u043E\u043A\u0430\u0437: \u0438\u043C\u0438\u0442\u0430\u0446\u0438\u044F " + (i + 1)]), ["show_real", "\u041F\u043E\u043A\u0430\u0437: \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435"], ...Array.from({ length: 3 }, (_, i) => ["try_sim" + (i + 1), "\u041F\u0440\u043E\u0431\u0430: \u0438\u043C\u0438\u0442\u0430\u0446\u0438\u044F " + (i + 1)]), ["try_real", "\u041F\u0440\u043E\u0431\u0430: \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435"]];
    if (variant === "hazardous") middle = [["show_explanation", "\u041F\u043E\u043A\u0430\u0437 / \u0432\u0438\u0434\u0435\u043E\u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B \u0441 \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435\u043C"], ["try_preparatory", "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0440\u0430\u0431\u043E\u0442\u044B / \u0442\u0440\u0435\u043D\u0430\u0436\u0451\u0440"], ["try_individual", "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430: \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u043C \u0443\u0441\u043B\u043E\u0432\u0438\u044F\u043C"], ["try_team", "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \u0432 \u043A\u043E\u043C\u0430\u043D\u0434\u0435"]];
    return [...prepare, ...middle, ...support].map(([code, label]) => ({ code, label, phase: code.startsWith("follow") ? "followup" : code === "support" ? "support" : code.startsWith("try") ? "practice" : code.startsWith("show") ? "presentation" : "prepare" }));
  }
  function progressFor(db, a) {
    const stages = jiStages(a.method_variant), facts = rows(db, "SELECT * FROM training_session WHERE assignment_id=? AND stage_code IS NOT NULL ORDER BY held_at,recorded_at,id", [a.id]);
    const done = new Set(facts.filter((x) => x.result === "completed").map((x) => x.stage_code)), next = stages.find((x) => !done.has(x.code)) || null;
    const intro = stages.filter((x) => !["support", "followup"].includes(x.phase)).every((x) => done.has(x.code));
    const followup = stages.filter((x) => x.phase === "followup" && done.has(x.code)).length;
    const supportOn = facts.find((x) => x.stage_code === "support" && x.result === "completed")?.held_at.slice(0, 10) || null;
    let followupDue = null;
    if (supportOn) {
      const [y, m, d] = supportOn.split("-").map(Number);
      const end = new Date(Date.UTC(y, m, Math.min(d, new Date(Date.UTC(y, m + 1, 0)).getUTCDate())));
      followupDue = end.toISOString().slice(0, 10);
    }
    return { stages, facts, done, next, intro, followup, followupDue, complete: !next, completed: stages.filter((x) => done.has(x.code)).length };
  }
  var active = (db, table2, id) => {
    invariant(isId(id), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u0430\u043F\u0438\u0441\u044C: " + table2);
    const x = one(db, "SELECT * FROM " + table2 + " WHERE id=?", [id]);
    invariant(x && !x.archived, "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430: " + table2);
    return x;
  };
  var person = (db, id) => active(db, "person", id);
  var optional = (db, table2, id) => id === null ? null : active(db, table2, id);
  var eventDay = (e) => new Date(Date.parse(e.occurred_at) + 14 * 36e5).toISOString().slice(0, 10);
  function roleMatches(db, id, day, allowed) {
    return directoryPeople(db, day).find((x) => x.id === id)?.roles.some((x) => {
      const vt = [x.code, x.name].some((v) => ["internal_trainer", "internal trainer", "\u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440", "\u0432\u0442"].includes(personKey(v).replaceAll("-", "_")));
      return allowed.includes(x.kind) || allowed.includes("internal_trainer") && vt;
    });
  }
  function hasRole(db, id, day, allowed) {
    person(db, id);
    invariant(roleMatches(db, id, day, allowed), "\u0423 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u043D\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043D\u0443\u0436\u043D\u043E\u0439 \u0440\u043E\u043B\u0438");
  }
  function roleForCredential(role) {
    return role === "internal_trainer" ? ["internal_trainer"] : role === "mentor" ? ["mentor"] : ["instructor"];
  }
  function level(db, scale, levelValue) {
    active(db, "rating_scale", scale);
    invariant(integer(levelValue, 0, 1e3) && one(db, "SELECT value FROM rating_level WHERE scale_id=? AND value=?", [scale, levelValue]), "\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0439 \u0448\u043A\u0430\u043B\u0435");
  }
  function currentStandard(db, revisionId) {
    const r = one(db, "SELECT r.*,d.operation_id,d.code,d.title,d.archived FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.id=? AND d.kind=?", [revisionId, "sop"]);
    if (!r) return null;
    return { ...r, source: JSON.parse(r.payload_json).source };
  }
  function isCurrentStandard(db, revisionId) {
    const r = currentStandard(db, revisionId);
    return !!(r && r.state === "effective" && !r.archived);
  }
  function effective(db, revisionId) {
    const r = currentStandard(db, revisionId);
    invariant(r && r.state === "effective" && !r.archived && r.operation_id && r.source?.kind === "sop", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044E \u0421\u041E\u041F, \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u043D\u0443\u044E \u043A \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
    active(db, "operation", r.operation_id);
    return r;
  }
  function names(db, ids) {
    return Object.fromEntries(Object.entries(ids).map(([k, id]) => [k, id ? person(db, id).display_name : ""]));
  }
  function orderPosition(db, id, day) {
    return one(db, "SELECT pos.name FROM person_assignment a JOIN position pos ON pos.id=a.position_id WHERE a.person_id=? AND a.valid_from<=? AND coalesce(a.valid_to,'9999-12-31')>=? ORDER BY a.valid_from DESC,a.id LIMIT 1", [id, day, day])?.name || "";
  }
  function certificateValid(db, id, day) {
    const x = one(db, "SELECT * FROM mentor_credential WHERE id=?", [id]);
    return x && x.kind === "certificate" && within(day, x.issued_on, x.valid_until) && beforeRevocation(x.revoked_at, day) ? x : null;
  }
  function appointmentValid(db, id, day) {
    const x = one(db, "SELECT * FROM mentor_appointment WHERE id=?", [id]);
    if (!x || !within(day, x.valid_from, x.valid_to) || x.acknowledged_on > day || !beforeRevocation(x.revoked_at, day)) return null;
    const c = certificateValid(db, x.credential_id, day);
    return c && c.person_id === x.person_id && c.role === x.role ? x : null;
  }
  function authorizationValid(db, id, day) {
    const a = one(db, "SELECT * FROM mentor_authorization WHERE id=?", [id]);
    if (!a || !a.credential_id || !a.appointment_id || !within(day, a.valid_from, a.valid_to) || !beforeRevocation(a.revoked_at, day)) return false;
    const o = appointmentValid(db, a.appointment_id, day), c = certificateValid(db, a.credential_id, day);
    return !!(o && c && o.person_id === a.person_id && c.person_id === a.person_id && o.credential_id === c.id && roleMatches(db, a.person_id, day, roleForCredential(c.role)) && one(db, "SELECT id FROM operation WHERE id=? AND archived=0", [a.operation_id]));
  }
  function activeAuthorizations(db, operationId, day) {
    return rows(db, "SELECT * FROM mentor_authorization WHERE operation_id=? ORDER BY valid_from DESC,id", [operationId]).filter((x) => authorizationValid(db, x.id, day));
  }
  function trainingMethods(db, code) {
    return rows(db, "SELECT v.* FROM checklist_version v JOIN checklist c ON c.id=v.checklist_id WHERE c.code=? ORDER BY v.version_no DESC", [code]);
  }
  function practicalMethods(db) {
    return trainingMethods(db, PRACTICAL_CODE);
  }
  function practicalCriteria(db, id) {
    return rows(db, "SELECT * FROM checklist_criterion WHERE version_id=? ORDER BY position", [id]);
  }
  function practicalResult(responses, total = 11) {
    const rated = responses.filter((x) => x.value === 0 || x.value === 1), yes = rated.filter((x) => x.value === 1).length;
    return { rated: rated.length, yes, total, fraction: total > 0 && responses.length === total && rated.length === total ? yes / total : null };
  }
  function validatePracticalMethod(p) {
    exact2(p, ["format", "title", "source_sha256", "criteria"]);
    invariant(["lean-practical-checklist-v1", "lean-practical-checklist-v2"].includes(p.format) && required(p.title, 200) && sha2(p.source_sha256) && Array.isArray(p.criteria) && (p.format === "lean-practical-checklist-v1" ? p.criteria.length === 11 : p.criteria.length >= 1 && p.criteria.length <= 100), "\u041D\u0443\u0436\u043D\u0430 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438: 11 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 v1 \u043B\u0438\u0431\u043E 1\u2013100 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 v2");
    p.criteria.forEach((x, i) => {
      exact2(x, ["code", "section", "question"]);
      invariant(x.code === i + 1 && required(x.section, 100) && required(x.question, 2500), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0439 " + (i + 1));
    });
    return p;
  }
  function verifyTrainingSource(e, source, raw) {
    invariant(e.entity_type === "training_assignment" && e.operation === "create" && source.kind === "sop" && canonical(source) === canonical(e.payload.source), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F");
    const t = linkedTwi(raw.constructor);
    invariant(t.exists && !t.outdated && e.payload.plan_reviewed === true, "\u0421\u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0439\u0442\u0435 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0439 \u043F\u043B\u0430\u043D TWI \u0432 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0438 \u0421\u041E\u041F");
  }
  function validateMentorMethod(p, format) {
    exact2(p, ["format", "title", "source_sha256", "criteria"]);
    invariant(["lean-audit-checklist-v1", "lean-self-checklist-v1"].includes(format) && p.format === format && required(p.title, 200) && sha2(p.source_sha256) && Array.isArray(p.criteria) && p.criteria.length > 0 && p.criteria.length <= 100, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430");
    p.criteria.forEach((x, i) => {
      exact2(x, ["code", "section", "question", ...Object.hasOwn(x, "recommendation") ? ["recommendation"] : []]);
      invariant(x.code === i + 1 && required(x.section, 100) && required(x.question, 2500) && (!Object.hasOwn(x, "recommendation") || text2(x.recommendation, 2500)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0439 " + (i + 1));
    });
    return p;
  }
  function createOnly(e, old) {
    invariant(e.operation === "create" && !old, "\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435");
  }
  function changeOnly(e, old) {
    invariant(e.operation === "update" && old, "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u0430\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441 \u0437\u0430\u043F\u0438\u0441\u044C\u044E");
  }
  function assignment(db, id) {
    const a = one(db, "SELECT * FROM training_assignment WHERE id=? AND source_sha256 IS NOT NULL", [id]);
    invariant(a, "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E");
    return a;
  }
  function freshAssignment(db, p) {
    const a = assignment(db, p.assignment_id);
    invariant(integer(p.assignment_rev, 1) && p.assignment_rev === a.rev, "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0443\u044E \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443.");
    return a;
  }
  function latest(db, table2, where, args, dayColumn) {
    return one(db, "SELECT * FROM " + table2 + " WHERE " + where + " ORDER BY " + dayColumn + " DESC,recorded_at DESC,id DESC LIMIT 1", args);
  }
  function latestVerification(db, id, kind) {
    return latest(db, "training_verification", "assignment_id=? AND kind=?", [id, kind], "evaluated_on");
  }
  function latestAssessment(db, id, kind) {
    return latest(db, "assessment_session", "assignment_id=? AND assessment_kind=? AND state='confirmed'", [id, kind], "assessed_at");
  }
  function admissionRecordStatus(db, a, day) {
    if (!a) return { record: null, status: "\u041D\u0435\u0442 \u0440\u0435\u0448\u0435\u043D\u0438\u044F", current: false };
    if (a.decision === "denied") return { record: a, status: "\u041D\u0435 \u0434\u043E\u043F\u0443\u0449\u0435\u043D", current: false };
    if (!beforeRevocation(a.revoked_at, day)) return { record: a, status: "\u041E\u0442\u043E\u0437\u0432\u0430\u043D", current: false };
    if (a.valid_until && a.valid_until < day) return { record: a, status: "\u0421\u0440\u043E\u043A \u0438\u0441\u0442\u0451\u043A", current: false };
    const current = isCurrentStandard(db, a.revision_id);
    if (!current) return { record: a, status: "\u0414\u043E\u043F\u0443\u0441\u043A \u043F\u043E \u043F\u0440\u0435\u0436\u043D\u0435\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \xB7 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0430\u043D\u0430\u043B\u0438\u0437", current: false };
    const item2 = one(db, "SELECT * FROM assessment_item WHERE session_id=?", [a.qualification_id]);
    if (item2?.valid_until && item2.valid_until < day) return { record: a, status: "\u0421\u0440\u043E\u043A \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0438 \u0438\u0441\u0442\u0451\u043A \xB7 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0430\u043D\u0430\u043B\u0438\u0437", current: false };
    const q = latestAssessment(db, a.assignment_id, "qualification"), p = latestAssessment(db, a.assignment_id, "practical"), s = latestVerification(db, a.assignment_id, "safety"), t = latestVerification(db, a.assignment_id, "theory");
    if (q?.id !== a.qualification_id || p?.id !== a.practical_id || s?.id !== a.safety_id || t?.id !== a.theory_id) return { record: a, status: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C \xB7 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u0435", current: false };
    return { record: a, status: "\u0414\u043E\u043F\u0443\u0441\u043A \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D", current: true };
  }
  function admissionStatus(db, personId, operationId, day) {
    return admissionRecordStatus(db, latest(db, "admission_decision", "person_id=? AND operation_id=? AND decided_on<=?", [personId, operationId, day], "decided_on"), day);
  }
  function enrollmentTasks(db, enrollment) {
    return rows(db, "SELECT * FROM training_program_task WHERE program_id=? ORDER BY position", [enrollment.program_id]).map((task) => {
      const a = latestTaskAssignment(db, enrollment.id, task.id), result = latest(db, "training_task_result", "enrollment_id=? AND task_id=?", [enrollment.id, task.id], "held_on");
      return { ...task, assignment: a, result, done: task.sop_revision_id ? a?.state === "completed" : result?.result === "completed" };
    });
  }
  function latestTaskAssignment(db, enrollmentId, taskId) {
    return one(db, "SELECT * FROM training_assignment WHERE enrollment_id=? AND program_task_id=? AND state<>'cancelled' ORDER BY assigned_on DESC,id DESC LIMIT 1", [enrollmentId, taskId]);
  }
  function store(db, table2, data) {
    const ks = Object.keys(data);
    db.run("INSERT INTO " + table2 + "(" + ks.join(",") + ") VALUES(" + ks.map(() => "?").join(",") + ")", ks.map((k) => data[k]));
  }
  function update(db, table2, id, data) {
    const ks = Object.keys(data);
    db.run("UPDATE " + table2 + " SET " + ks.map((k) => k + "=?").join(",") + ",rev=rev+1 WHERE id=?", [...ks.map((k) => data[k]), id]);
  }
  function revoke(db, table2, e, old) {
    changeOnly(e, old);
    exact2(e.payload, ["command", "reason"]);
    invariant(e.payload.command === "revoke" && required(e.payload.reason) && !old.revoked_at, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0442\u0437\u044B\u0432\u0430");
    update(db, table2, old.id, { revoked_at: e.occurred_at });
  }
  function noFuture(day, e) {
    invariant(date(day) && day <= eventDay(e), "\u0414\u0430\u0442\u0430 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u0432 \u0431\u0443\u0434\u0443\u0449\u0435\u043C");
  }
  function validClock(s) {
    return typeof s === "string" && /^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d$/.test(s) && date(s.slice(0, 10));
  }
  function exactAssignmentTarget(db, p, r) {
    const skill = active(db, "skill", p.skill_id);
    invariant(skill.operation_id === r.operation_id, "\u041D\u0430\u0432\u044B\u043A \u0434\u043E\u043B\u0436\u0435\u043D \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u044C\u0441\u044F \u043A \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u0421\u041E\u041F");
    level(db, p.scale_id, p.target_level);
  }
  function applyTrainingEvent(db, e, old) {
    const p = e.payload, id = e.entity_id, t = e.entity_type;
    if (t === "checklist_version") {
      createOnly(e, old);
      const mentor = p.format === "lean-audit-checklist-v1" || p.format === "lean-self-checklist-v1";
      if (mentor) validateMentorMethod(p, p.format);
      else validatePracticalMethod(p);
      const code = p.format === "lean-audit-checklist-v1" ? AUDIT_CODE : p.format === "lean-self-checklist-v1" ? SELF_CODE : PRACTICAL_CODE, methods = trainingMethods(db, code);
      invariant(!methods.some((m) => canonical(JSON.parse(m.methodology_json)) === canonical(p)), "\u0422\u0430\u043A\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0443\u0436\u0435 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430");
      let c = one(db, "SELECT * FROM checklist WHERE code=?", [code]);
      if (!c) {
        c = { id: e.id };
        store(db, "checklist", { id: c.id, code, name: code === AUDIT_CODE ? "\u0410\u0443\u0434\u0438\u0442 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F" : code === SELF_CODE ? "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430" : "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430" });
      }
      store(db, t, { id, checklist_id: c.id, version_no: (methods[0]?.version_no || 0) + 1, state: "draft", methodology_json: canonical(p), rev: 1 });
      p.criteria.forEach((q) => store(db, "checklist_criterion", { id: id + ":" + q.code, version_id: id, code: String(q.code), section_code: q.section, position: q.code, question: q.question }));
      db.run("UPDATE checklist_version SET state='retired',rev=rev+1 WHERE checklist_id=? AND state='active'", [c.id]);
      db.run("UPDATE checklist_version SET state='active' WHERE id=?", [id]);
      return;
    }
    if (t === "mentor_credential") {
      if (old) return revoke(db, t, e, old);
      createOnly(e, old);
      exact2(p, ["person_id", "kind", "role", "number", "issuer", "issued_on", "valid_until", "evidence", "registered_by"]);
      person(db, p.person_id);
      person(db, p.registered_by);
      noFuture(p.issued_on, e);
      invariant(["certificate", "attendance"].includes(p.kind) && roles.includes(p.role) && required(p.number, 200) && required(p.issuer) && required(p.evidence) && period(p.issued_on, p.valid_until), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043E \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0435");
      store(db, t, { id, ...p, rev: 1 });
      return;
    }
    if (t === "competency_matrix") {
      if (old) {
        changeOnly(e, old);
        exact2(p, ["command", "reason"]);
        invariant(old.state === "active" && p.command === "retire" && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u044F \u043C\u0430\u0442\u0440\u0438\u0446\u044B");
        update(db, t, id, { state: "retired" });
        return;
      }
      createOnly(e, old);
      exact2(p, ["code", "title", "author_id", "unit_id", "shift_id", "scale_id", "base_on", "target_on", "roster", "columns", "baseline", "previous_id", "previous_rev"]);
      invariant(required(p.code, 80) && required(p.title, 200) && period(p.base_on, p.target_on) && p.target_on && p.base_on <= eventDay(e), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043A\u043E\u0434, \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435, \u0434\u0430\u0442\u0443 \u0441\u0440\u0435\u0437\u0430 \u0438 \u0446\u0435\u043B\u0435\u0432\u0443\u044E \u0434\u0430\u0442\u0443");
      person(db, p.author_id);
      if (p.unit_id) active(db, "org_unit", p.unit_id);
      if (p.shift_id) active(db, "work_shift", p.shift_id);
      const scale = active(db, "rating_scale", p.scale_id), levels = rows(db, "SELECT value,label FROM rating_level WHERE scale_id=? ORDER BY value", [p.scale_id]);
      invariant(scale.name === "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F (1\u20134)" && canonical(levels.map((x) => [x.value, x.label])) === canonical([[1, "\u041E\u0431\u0443\u0447\u0435\u043D"], [2, "\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0440\u0430\u0431\u043E\u0442\u0443 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E"], [3, "\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0440\u0430\u0431\u043E\u0442\u0443 \u043C\u0430\u0441\u0442\u0435\u0440\u0441\u043A\u0438"], [4, "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A"]]), "\u0414\u043B\u044F \u043C\u0430\u0442\u0440\u0438\u0446\u044B \u043D\u0443\u0436\u043D\u0430 \u0442\u043E\u0447\u043D\u0430\u044F \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u0448\u043A\u0430\u043B\u0430 1\u20134");
      invariant(Array.isArray(p.roster) && p.roster.length > 0 && p.roster.length <= 300 && Array.isArray(p.columns) && p.columns.length > 0 && p.columns.length <= 150 && p.roster.length * p.columns.length <= 12e3, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 1\u2013300 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0438 1\u2013150 \u043D\u0430\u0432\u044B\u043A\u043E\u0432; \u0434\u043E 12000 \u044F\u0447\u0435\u0435\u043A");
      const people = /* @__PURE__ */ new Set(), skills = /* @__PURE__ */ new Set();
      const allowedUnits = new Set(p.unit_id ? rows(db, "WITH RECURSIVE scope(id) AS (SELECT ? UNION SELECT u.id FROM org_unit u JOIN scope s ON u.parent_id=s.id) SELECT id FROM scope", [p.unit_id]).map((x) => x.id) : []);
      for (const r of p.roster) {
        exact2(r, ["person_id", "name", "position", "instructor"]);
        const who = person(db, r.person_id);
        invariant(!people.has(r.person_id) && r.name === who.display_name && text2(r.position, 500) && typeof r.instructor === "boolean", "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0438\u043B\u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A");
        people.add(r.person_id);
        const a = one(db, "SELECT * FROM person_assignment WHERE person_id=? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? ORDER BY valid_from DESC,id LIMIT 1", [r.person_id, p.base_on, p.base_on]);
        invariant(a && (!p.unit_id || allowedUnits.has(a.unit_id)) && (!p.shift_id || a.shift_id === p.shift_id), "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u0441\u043E\u0441\u0442\u0430\u0432 \u043D\u0430 \u0434\u0430\u0442\u0443 \u043C\u0430\u0442\u0440\u0438\u0446\u044B");
        const expected = one(db, "SELECT name FROM position WHERE id=?", [a.position_id])?.name || one(db, "SELECT name FROM profession WHERE id=?", [a.profession_id])?.name || "";
        invariant(r.position === expected && r.instructor === roleMatches(db, r.person_id, p.base_on, ["instructor", "mentor", "internal_trainer"]), "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C \u0438\u043B\u0438 \u0440\u043E\u043B\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C");
      }
      for (const c of p.columns) {
        exact2(c, ["skill_id", "document_id", "title"]);
        const s = active(db, "skill", c.skill_id);
        invariant(!skills.has(c.skill_id) && required(c.title, 500), "\u041F\u043E\u0432\u0442\u043E\u0440 \u043D\u0430\u0432\u044B\u043A\u0430 \u0438\u043B\u0438 \u043F\u0443\u0441\u0442\u043E\u0439 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A");
        skills.add(c.skill_id);
        if (c.document_id) {
          const doc = active(db, "document", c.document_id);
          invariant(doc.kind === "sop" && doc.operation_id === s.operation_id && one(db, "SELECT id FROM document_revision WHERE document_id=? AND state='effective'", [doc.id]) && c.title === doc.code + " \xB7 " + doc.title, "\u0421\u041E\u041F \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043D\u0430\u0432\u044B\u043A\u0443 \u0438\u043B\u0438 \u043D\u0435 \u0432\u0432\u0435\u0434\u0451\u043D \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435");
        } else invariant(!s.operation_id && c.title === s.name, "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0439 \u043D\u0430\u0432\u044B\u043A \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0441\u0432\u044F\u0437\u0430\u043D \u0441 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u0421\u041E\u041F");
      }
      const m = matrixData(db, p.base_on), n = p.roster.length * p.columns.length;
      invariant(Array.isArray(p.baseline) && p.baseline.length === n, "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0440\u0435\u0437 \u043C\u0430\u0442\u0440\u0438\u0446\u044B");
      let i = 0;
      for (const r of p.roster) for (const c of p.columns) {
        const b = p.baseline[i++], x = m.cells.get(r.person_id + ":" + c.skill_id), fact = x?.fact, doc = fact?.standard_revision_id ? one(db, "SELECT document_id FROM document_revision WHERE id=?", [fact.standard_revision_id]) : null;
        const actual = x?.valid && x.revisionCurrent && fact.scale_id === p.scale_id && (!c.document_id || doc?.document_id === c.document_id) && [1, 2, 3, 4].includes(fact.level) ? fact.level : null;
        exact2(b, ["person_id", "skill_id", "value", "assessment_id"]);
        invariant(b.person_id === r.person_id && b.skill_id === c.skill_id && b.value === actual && b.assessment_id === (actual === null ? null : fact.session_id), "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0440\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0441\u044F. \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440");
      }
      const current = one(db, "SELECT id,rev FROM competency_matrix WHERE code=? AND state='active'", [p.code]);
      invariant(p.previous_id === (current?.id || null) && p.previous_rev === (current?.rev || 0), "\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u0443\u0436\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430 \u0434\u0440\u0443\u0433\u0438\u043C \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u043C. \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u0435\u0440\u0435\u0434 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435\u043C");
      const prev = one(db, "SELECT MAX(version_no) n FROM competency_matrix WHERE code=?", [p.code])?.n || 0;
      db.run("UPDATE competency_matrix SET state='retired',rev=rev+1 WHERE code=? AND state='active'", [p.code]);
      store(db, t, { id, code: p.code, title: p.title, author_id: p.author_id, unit_id: p.unit_id, shift_id: p.shift_id, scale_id: p.scale_id, base_on: p.base_on, target_on: p.target_on, roster_json: canonical(p.roster), columns_json: canonical(p.columns), baseline_json: canonical(p.baseline), created_at: e.occurred_at, state: "active", version_no: prev + 1, rev: 1 });
      return;
    }
    if (t === "mentor_self_evaluation") {
      createOnly(e, old);
      exact2(p, ["person_id", "method_id", "evaluated_on", "place", "responses", "feedback"]);
      noFuture(p.evaluated_on, e);
      const who = person(db, p.person_id);
      hasRole(db, p.person_id, p.evaluated_on, ["mentor", "instructor", "internal_trainer"]);
      invariant(trainingMethods(db, SELF_CODE).some((x) => x.id === p.method_id && x.state === "active") && required(p.place) && text2(p.feedback), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u0441\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0438 \u0438 \u043C\u0435\u0441\u0442\u043E");
      const criteria = practicalCriteria(db, p.method_id);
      invariant(Array.isArray(p.responses) && criteria.length > 0 && p.responses.length === criteria.length, "\u041E\u0446\u0435\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0438 \u0441\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0438");
      p.responses.forEach((x, i) => {
        exact2(x, ["criterion_id", "value", "note"]);
        invariant(x.criterion_id === criteria[i].id && integer(x.value, 1, 5) && text2(x.note), "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430: \u0443\u0440\u043E\u0432\u0435\u043D\u044C 1\u20135, \u043D\u0435\u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u043E\u0435 \u043D\u0435 \u0440\u0430\u0432\u043D\u043E \u043D\u0443\u043B\u044E");
      });
      store(db, t, { id, person_id: p.person_id, method_id: p.method_id, evaluated_on: p.evaluated_on, place: p.place, person_name: who.display_name, responses_json: canonical(p.responses), feedback: p.feedback, recorded_at: e.occurred_at, rev: 1 });
      return;
    }
    if (t === "audit_session") {
      if (old) {
        changeOnly(e, old);
        exact2(p, ["command", "reason"]);
        invariant(old.assignment_id && old.state === "final" && p.command === "void" && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0430\u043D\u043D\u0443\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F");
        update(db, t, id, { state: "void", void_reason: p.reason });
        return;
      }
      createOnly(e, old);
      exact2(p, ["assignment_id", "assignment_rev", "method_id", "auditor_id", "session_id", "observed_on", "responses", "feedback"]);
      const a = freshAssignment(db, p);
      noFuture(p.observed_on, e);
      person(db, p.auditor_id);
      hasRole(db, p.auditor_id, p.observed_on, ["internal_trainer"]);
      invariant(p.auditor_id !== a.mentor_id && p.auditor_id !== a.trainee_id, "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440 \u0434\u043E\u043B\u0436\u0435\u043D \u043E\u0442\u043B\u0438\u0447\u0430\u0442\u044C\u0441\u044F \u043E\u0442 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E");
      const fact = one(db, "SELECT * FROM training_session WHERE id=? AND assignment_id=? AND stage_code IS NOT NULL", [p.session_id, a.id]);
      invariant(a.state !== "cancelled" && a.approval_json && fact && fact.held_at.slice(0, 10) <= p.observed_on && p.observed_on >= a.assigned_on && required(p.feedback), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u0430\u043A\u0442 \u044D\u0442\u043E\u0433\u043E \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430, \u0434\u0430\u0442\u0443 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F \u0438 \u043E\u0431\u0440\u0430\u0442\u043D\u0443\u044E \u0441\u0432\u044F\u0437\u044C");
      invariant(trainingMethods(db, AUDIT_CODE).some((x) => x.id === p.method_id && x.state === "active"), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u0430\u0443\u0434\u0438\u0442\u0430 L1");
      const criteria = practicalCriteria(db, p.method_id);
      invariant(Array.isArray(p.responses) && criteria.length > 0 && p.responses.length === criteria.length, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0438 \u0430\u0443\u0434\u0438\u0442\u0430");
      p.responses.forEach((x, i) => {
        exact2(x, ["criterion_id", "value", "note"]);
        invariant(x.criterion_id === criteria[i].id && (x.value === 0 || x.value === 1) && text2(x.note), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u0430\u0443\u0434\u0438\u0442\u0430");
      });
      store(db, t, { id, version_id: p.method_id, mentor_id: a.mentor_id, auditor_id: p.auditor_id, trainee_id: a.trainee_id, operation_id: a.operation_id, standard_revision_id: a.sop_revision_id, training_session_id: fact.id, observed_at: p.observed_on, state: "draft", recorded_names_json: canonical(names(db, { mentor: a.mentor_id, auditor: p.auditor_id, trainee: a.trainee_id })), assignment_id: a.id, summary: p.feedback, recorded_at: e.occurred_at, rev: 1 });
      p.responses.forEach((x) => store(db, "audit_response", { id: id + ":" + x.criterion_id, audit_id: id, version_id: p.method_id, criterion_id: x.criterion_id, response: x.value ? "yes" : "no", note: x.note }));
      db.run("UPDATE audit_session SET state='final' WHERE id=?", [id]);
      return;
    }
    if (t === "mentor_order") {
      createOnly(e, old);
      exact2(p, ["order_number", "order_on", "organization", "city", "approved_by", "valid_from", "valid_to", "supplement_from", "instructor_amount", "trainer_amount", "evidence", "members"]);
      const approver = person(db, p.approved_by);
      noFuture(p.order_on, e);
      invariant(required(p.order_number, 200) && required(p.organization, 300) && required(p.city, 150) && required(p.evidence) && period(p.valid_from, p.valid_to) && p.order_on <= p.valid_from && Array.isArray(p.members) && p.members.length > 0 && p.members.length <= 200, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u043E\u0433\u043E \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0433\u043E \u043F\u0440\u0438\u043A\u0430\u0437\u0430");
      invariant([p.instructor_amount, p.trainer_amount].every((v) => v === null || integer(v, 0, 1e7)), "\u0414\u043E\u043F\u043B\u0430\u0442\u0430: \u0446\u0435\u043B\u0430\u044F \u0441\u0443\u043C\u043C\u0430 \u0440\u0443\u0431\u043B\u0435\u0439 \u0438\u043B\u0438 \u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430");
      invariant(p.instructor_amount === null && p.trainer_amount === null ? p.supplement_from === null : date(p.supplement_from) && p.supplement_from >= p.order_on, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0430\u0442\u0443 \u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u043E\u043F\u043B\u0430\u0442\u044B");
      invariant(!one(db, "SELECT id FROM mentor_order WHERE organization=? AND order_number=? AND order_on=?", [p.organization, p.order_number, p.order_on]), "\u0422\u0430\u043A\u043E\u0439 \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 \u0443\u0436\u0435 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D");
      const seen = /* @__PURE__ */ new Set(), ids = /* @__PURE__ */ new Set();
      const members = p.members.map((m) => {
        exact2(m, ["id", "credential_id", "acknowledged_on"]);
        invariant(isId(m.id) && !ids.has(m.id), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F");
        ids.add(m.id);
        noFuture(m.acknowledged_on, e);
        invariant(m.acknowledged_on >= p.order_on, "\u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u043F\u0440\u0435\u0434\u0448\u0435\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u0438\u043A\u0430\u0437\u0443");
        const c = certificateValid(db, m.credential_id, p.valid_from);
        invariant(c && roles.includes(c.role), "\u041D\u0443\u0436\u0435\u043D \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442, \u0430 \u043D\u0435 \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E");
        const who = person(db, c.person_id), position = orderPosition(db, who.id, p.valid_from);
        invariant(position.trim(), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0435: " + who.display_name);
        const key3 = who.id + ":" + (c.role === "internal_trainer" ? "internal_trainer" : "instructor");
        invariant(!seen.has(key3), "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0435\u0442\u0441\u044F \u0432 \u043E\u0434\u043D\u043E\u0439 \u0433\u0440\u0443\u043F\u043F\u0435 \u043F\u0440\u0438\u043A\u0430\u0437\u0430");
        seen.add(key3);
        return { id: m.id, person_id: who.id, credential_id: c.id, role: c.role, order_number: p.order_number, order_on: p.order_on, approved_by: p.approved_by, valid_from: p.valid_from, valid_to: p.valid_to, acknowledged_on: m.acknowledged_on, evidence: p.evidence, order_id: id, person_name: who.display_name, position_name: position, rev: 1 };
      });
      const { members: ignored, ...header2 } = p;
      store(db, t, { id, ...header2, approved_name: approver.display_name, recorded_at: e.occurred_at, rev: 1 });
      for (const m of members) store(db, "mentor_appointment", m);
      return;
    }
    if (t === "mentor_appointment") {
      if (old) return revoke(db, t, e, old);
      createOnly(e, old);
      exact2(p, ["person_id", "credential_id", "role", "order_number", "order_on", "approved_by", "valid_from", "valid_to", "acknowledged_on", "evidence"]);
      person(db, p.person_id);
      person(db, p.approved_by);
      noFuture(p.order_on, e);
      noFuture(p.acknowledged_on, e);
      invariant(roles.includes(p.role) && period(p.valid_from, p.valid_to) && p.order_on <= p.valid_from && p.acknowledged_on >= p.order_on && required(p.order_number, 200) && required(p.evidence), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 \u0438 \u043E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435");
      const c = certificateValid(db, p.credential_id, p.valid_from);
      invariant(c && c.person_id === p.person_id && c.role === p.role, "\u041D\u0443\u0436\u0435\u043D \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u044D\u0442\u043E\u0439 \u0440\u043E\u043B\u0438, \u043D\u0435 \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u043E \u043F\u0440\u043E\u0441\u043B\u0443\u0448\u0438\u0432\u0430\u043D\u0438\u0438");
      store(db, t, { id, ...p, rev: 1 });
      return;
    }
    if (t === "mentor_authorization") {
      if (old) return revoke(db, t, e, old);
      createOnly(e, old);
      exact2(p, ["person_id", "operation_id", "approved_by", "valid_from", "valid_to", "credential_id", "appointment_id"]);
      person(db, p.approved_by);
      active(db, "operation", p.operation_id);
      invariant(period(p.valid_from, p.valid_to), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043F\u0435\u0440\u0438\u043E\u0434 \u043F\u0440\u0430\u0432\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C");
      const o = appointmentValid(db, p.appointment_id, p.valid_from), c = certificateValid(db, p.credential_id, p.valid_from);
      invariant(o && c && o.person_id === p.person_id && o.credential_id === c.id, "\u041F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u0430 \u0438 \u043F\u0440\u0438\u043A\u0430\u0437\u0430");
      hasRole(db, p.person_id, p.valid_from, roleForCredential(c.role));
      invariant(!rows(db, "SELECT * FROM mentor_authorization WHERE person_id=? AND operation_id=?", [p.person_id, p.operation_id]).some((a) => !a.revoked_at && a.valid_from <= (p.valid_to || "9999-12-31") && (!a.valid_to || a.valid_to >= p.valid_from)), "\u0415\u0441\u0442\u044C \u043F\u0435\u0440\u0435\u0441\u0435\u043A\u0430\u044E\u0449\u0435\u0435\u0441\u044F \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0435 \u043F\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
      store(db, t, { id, ...p, rev: 1 });
      return;
    }
    if (t === "training_program") {
      if (old) {
        changeOnly(e, old);
        exact2(p, ["command", "reason"]);
        invariant(p.command === "retire" && required(p.reason) && old.state === "active", "\u0412\u0435\u0440\u0441\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0443\u0436\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430");
        update(db, t, id, { state: "retired" });
        return;
      }
      createOnly(e, old);
      exact2(p, ["code", "kind", "title", "profession_id", "position_id", "created_by", "tasks"]);
      invariant(required(p.code, 100) && required(p.title) && Object.hasOwn(programKinds, p.kind) && Array.isArray(p.tasks) && p.tasks.length > 0 && p.tasks.length <= 100, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443 \u0438 \u0437\u0430\u0434\u0430\u043D\u0438\u044F");
      optional(db, "profession", p.profession_id);
      optional(db, "position", p.position_id);
      person(db, p.created_by);
      if (p.kind === "internship") invariant(Object.keys(parts).every((k) => p.tasks.some((x) => x.part === k)), "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438 \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u0432\u0441\u0435 \u0447\u0435\u0442\u044B\u0440\u0435 \u0447\u0430\u0441\u0442\u0438");
      p.tasks.forEach((x) => {
        exact2(x, ["part", "title", "hours", "day_offset", "sop_revision_id", "skill_id", "scale_id", "target_level"]);
        invariant(Object.hasOwn(parts, x.part) && required(x.title) && typeof x.hours === "number" && Number.isFinite(x.hours) && x.hours >= 0 && x.hours <= 1e3 && integer(x.day_offset, 0, 3660), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
        if (x.sop_revision_id) {
          const r = effective(db, x.sop_revision_id);
          exactAssignmentTarget(db, x, r);
        } else invariant(x.skill_id === null && x.scale_id === null && x.target_level === null, "\u0414\u043B\u044F \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0441 \u0446\u0435\u043B\u0435\u0432\u043E\u0439 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0435\u0439 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0421\u041E\u041F");
      });
      const previous = rows(db, "SELECT * FROM training_program").filter((x) => foldKey(x.code) === foldKey(p.code));
      invariant(previous.every((x) => x.kind === p.kind), "\u041A\u043E\u0434 \u0443\u0436\u0435 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0434\u0440\u0443\u0433\u043E\u043C\u0443 \u0432\u0438\u0434\u0443 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
      const version = Math.max(0, ...previous.map((x) => x.version_no)) + 1, code = previous[0]?.code || p.code.trim();
      for (const x of previous.filter((x2) => x2.state === "active")) update(db, t, x.id, { state: "retired" });
      store(db, t, { id, code, version_no: version, kind: p.kind, title: p.title.trim(), profession_id: p.profession_id, position_id: p.position_id, created_by: p.created_by, created_at: e.occurred_at, state: "active", rev: 1 });
      p.tasks.forEach((x, i) => store(db, "training_program_task", { id: id + ":" + (i + 1), program_id: id, position: i + 1, ...x }));
      return;
    }
    if (t === "training_enrollment") {
      if (!old) {
        createOnly(e, old);
        const hasPeriods = Object.hasOwn(p, "internship_start"), baseKeys = ["program_id", "trainee_id", "mentor_id", "manager_id", "start_on", "due_on", "reason"];
        exact2(p, hasPeriods ? [...baseKeys, "internship_start", "internship_end", "entry_start", "entry_end"] : baseKeys);
        const program = one(db, "SELECT * FROM training_program WHERE id=? AND state=?", [p.program_id, "active"]);
        invariant(program && period(p.start_on, p.due_on) && p.due_on && required(p.reason), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u0443\u044E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443, \u0441\u0440\u043E\u043A\u0438 \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u0443");
        if (hasPeriods) {
          for (const [a2, b] of [[p.internship_start, p.internship_end], [p.entry_start, p.entry_end]]) invariant(a2 === null && b === null || date(a2) && date(b) && a2 <= b && a2 >= p.start_on && b <= p.due_on, "\u041F\u0435\u0440\u0438\u043E\u0434\u044B \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438 \u0438 \u0432\u0432\u043E\u0434\u0430 \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0443\u043A\u0430\u0437\u0430\u043D\u044B \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u0438 \u0432\u0445\u043E\u0434\u0438\u0442\u044C \u0432 \u043E\u0431\u0449\u0438\u0439 \u0441\u0440\u043E\u043A");
          if (program.kind === "internship") invariant(p.internship_start && p.internship_end && p.entry_start && p.entry_end, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0431\u0430 \u043F\u0435\u0440\u0438\u043E\u0434\u0430 \u0438\u0437 \u0444\u043E\u0440\u043C\u044B \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438");
        }
        invariant(rows(db, "SELECT day_offset FROM training_program_task WHERE program_id=?", [program.id]).every((x) => plusDays(p.start_on, x.day_offset) <= p.due_on), "\u0421\u0440\u043E\u043A \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0434\u043E\u043B\u0436\u0435\u043D \u0432\u043A\u043B\u044E\u0447\u0430\u0442\u044C \u0432\u0441\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F");
        hasRole(db, p.trainee_id, p.start_on, ["trainee"]);
        hasRole(db, p.mentor_id, p.start_on, ["mentor", "instructor"]);
        person(db, p.manager_id);
        invariant(p.trainee_id !== p.mentor_id, "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u0441\u0435\u0431\u044F");
        const a = one(db, "SELECT * FROM person_assignment WHERE person_id=? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? ORDER BY valid_from DESC LIMIT 1", [p.trainee_id, p.start_on, p.start_on]);
        invariant((!program.profession_id || a?.profession_id === program.profession_id) && (!program.position_id || a?.position_id === program.position_id), "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u043C\u0443 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
        invariant(!one(db, "SELECT id FROM training_enrollment WHERE program_id=? AND trainee_id=? AND state='active'", [p.program_id, p.trainee_id]), "\u0422\u0430\u043A\u0430\u044F \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u0443\u0436\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u0430");
        store(db, t, { id, ...p, state: "active", rev: 1 });
        return;
      }
      changeOnly(e, old);
      exact2(p, ["command", "actor_id", "conclusion", "feedback"]);
      person(db, p.actor_id);
      invariant(old.state === "active" && ["finish", "cancel"].includes(p.command) && required(p.feedback), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0438\u0442\u043E\u0433 \u0438 \u043E\u0431\u0440\u0430\u0442\u043D\u0443\u044E \u0441\u0432\u044F\u0437\u044C");
      if (p.command === "finish") invariant(Object.hasOwn(conclusions, p.conclusion) && enrollmentTasks(db, old).every((x) => x.done), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0438 \u0443\u043A\u0430\u0436\u0438\u0442\u0435 \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435");
      else invariant(p.conclusion === null, "\u041E\u0442\u043C\u0435\u043D\u0430 \u043D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u043C \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435\u043C");
      if (p.command === "cancel") invariant(!one(db, "SELECT id FROM training_assignment WHERE enrollment_id=? AND state IN('planned','in_progress')", [id]), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u043D\u0435\u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u044B\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
      update(db, t, id, { state: p.command === "finish" ? "completed" : "cancelled", conclusion: p.conclusion, feedback: p.feedback, finished_by: p.actor_id, finished_at: e.occurred_at });
      return;
    }
    if (t === "training_task_result") {
      createOnly(e, old);
      exact2(p, ["enrollment_id", "task_id", "actor_id", "held_on", "result", "minutes", "evidence", "enrollment_rev"]);
      person(db, p.actor_id);
      noFuture(p.held_on, e);
      const n = one(db, "SELECT * FROM training_enrollment WHERE id=?", [p.enrollment_id]), task = one(db, "SELECT * FROM training_program_task WHERE id=?", [p.task_id]);
      invariant(n?.state === "active" && n.rev === p.enrollment_rev && task?.program_id === n.program_id && !task.sop_revision_id && p.held_on >= n.start_on && ["completed", "incomplete"].includes(p.result) && integer(p.minutes, 0, 1440) && required(p.evidence), "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435 / \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442. \u0417\u0430\u0434\u0430\u043D\u0438\u044F \u043F\u043E \u0421\u041E\u041F \u0437\u0430\u043A\u0440\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u0444\u0430\u043A\u0442\u043E\u043C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430.");
      const { enrollment_rev, ...data } = p;
      store(db, t, { id, ...data, recorded_at: e.occurred_at, rev: 1 });
      update(db, "training_enrollment", n.id, { state: n.state });
      return;
    }
    if (t === "training_assignment") {
      if (!old) {
        createOnly(e, old);
        exact2(p, ["trainee_id", "mentor_id", "supervisor_id", "authorization_id", "revision_id", "source", "skill_id", "scale_id", "target_level", "assigned_by", "assigned_on", "due_on", "reason", "variant", "shift_id", "enrollment_id", "program_task_id", "plan_reviewed"]);
        const r = effective(db, p.revision_id);
        invariant(canonical(r.source) === canonical(p.source) && p.plan_reviewed === true, "\u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u0435\u043D \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0439 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0438 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u043C\u0443 TWI");
        invariant(period(p.assigned_on, p.due_on) && p.due_on && required(p.reason) && Object.hasOwn(variants, p.variant), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0430\u0442\u044B, \u0432\u0438\u0434 \u0438 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F");
        invariant(r.effective_at && p.assigned_on >= r.effective_at.slice(0, 10), "\u041D\u0430\u0447\u0430\u043B\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u043F\u0440\u0435\u0434\u0448\u0435\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0432\u0441\u0442\u0443\u043F\u043B\u0435\u043D\u0438\u044E \u0421\u041E\u041F \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435");
        hasRole(db, p.trainee_id, p.assigned_on, ["trainee"]);
        person(db, p.assigned_by);
        invariant(p.trainee_id !== p.mentor_id, "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 \u0434\u043E\u043B\u0436\u043D\u044B \u0440\u0430\u0437\u043B\u0438\u0447\u0430\u0442\u044C\u0441\u044F");
        const auth = one(db, "SELECT * FROM mentor_authorization WHERE id=?", [p.authorization_id]);
        invariant(auth?.person_id === p.mentor_id && auth.operation_id === r.operation_id && authorizationValid(db, auth.id, p.assigned_on), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0441 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u043F\u0440\u0430\u0432\u043E\u043C \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u044D\u0442\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
        if (p.supervisor_id) {
          hasRole(db, p.supervisor_id, p.assigned_on, ["mentor", "instructor"]);
          invariant(p.supervisor_id !== p.trainee_id, "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 \u0434\u043E\u043B\u0436\u043D\u044B \u0440\u0430\u0437\u043B\u0438\u0447\u0430\u0442\u044C\u0441\u044F");
        }
        optional(db, "work_shift", p.shift_id);
        exactAssignmentTarget(db, p, r);
        if (p.enrollment_id !== null || p.program_task_id !== null) {
          const n = one(db, "SELECT * FROM training_enrollment WHERE id=?", [p.enrollment_id]), task = one(db, "SELECT * FROM training_program_task WHERE id=?", [p.program_task_id]);
          invariant(n?.state === "active" && n.trainee_id === p.trainee_id && task?.program_id === n.program_id && task.sop_revision_id === r.id && task.skill_id === p.skill_id && task.scale_id === p.scale_id && task.target_level === p.target_level && p.assigned_on >= n.start_on && p.due_on <= n.due_on && !latestTaskAssignment(db, n.id, task.id), "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0437\u0430\u0434\u0430\u043D\u0438\u044E \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
        }
        invariant(!one(db, "SELECT id FROM training_assignment WHERE trainee_id=? AND sop_revision_id=? AND skill_id=? AND state IN('planned','in_progress')", [p.trainee_id, r.id, p.skill_id]), "\u0423 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0443\u0436\u0435 \u0435\u0441\u0442\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u044D\u0442\u043E\u043C\u0443 \u043D\u0430\u0432\u044B\u043A\u0443 \u0438 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0438");
        store(db, t, { id, trainee_id: p.trainee_id, mentor_id: p.mentor_id, supervisor_id: p.supervisor_id, operation_id: r.operation_id, sop_revision_id: r.id, twi_revision_id: r.id, due_on: p.due_on, state: "planned", rev: 1, source_sha256: r.source.sha256, skill_id: p.skill_id, scale_id: p.scale_id, target_level: p.target_level, assigned_by: p.assigned_by, assigned_on: p.assigned_on, reason: p.reason, method_variant: p.variant, method_version: "JI-1", authorization_id: p.authorization_id, shift_id: p.shift_id, enrollment_id: p.enrollment_id, program_task_id: p.program_task_id, recorded_names_json: canonical(names(db, { trainee: p.trainee_id, instructor: p.mentor_id, supervisor: p.supervisor_id, assignedBy: p.assigned_by })) });
        return;
      }
      changeOnly(e, old);
      invariant(old.source_sha256 && ["planned", "in_progress"].includes(old.state), "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0437\u0430\u043A\u0440\u044B\u0442\u043E \u0438\u043B\u0438 \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0441\u044F \u043A legacy");
      if (p.command === "approve") {
        exact2(p, ["command", "responsible_id", "head_id", "approved_on", "note"]);
        person(db, p.responsible_id);
        person(db, p.head_id);
        noFuture(p.approved_on, e);
        const r = effective(db, old.sop_revision_id);
        invariant(r.effective_at && p.approved_on >= r.effective_at.slice(0, 10) && text2(p.note) && !old.approval_json, "\u041F\u043B\u0430\u043D \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u043C \u0438 \u0435\u0449\u0451 \u043D\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D. \u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u043E\u043F\u0443\u0441\u043A\u0430\u0435\u0442\u0441\u044F \u0434\u043E \u043F\u043B\u0430\u043D\u043E\u0432\u043E\u0433\u043E \u043D\u0430\u0447\u0430\u043B\u0430 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F.");
        update(db, t, id, { approval_json: canonical({ ...p, names: names(db, { responsible: p.responsible_id, head: p.head_id }) }) });
        return;
      }
      if (p.command === "reschedule") {
        exact2(p, ["command", "due_on", "reason"]);
        invariant(date(p.due_on) && p.due_on >= old.assigned_on && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043D\u043E\u0432\u044B\u0439 \u0441\u0440\u043E\u043A \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u0443");
        if (old.enrollment_id) {
          const n = one(db, "SELECT * FROM training_enrollment WHERE id=?", [old.enrollment_id]);
          invariant(n?.state === "active" && p.due_on <= n.due_on, "\u0421\u0440\u043E\u043A \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0432\u044B\u0445\u043E\u0434\u0438\u0442\u044C \u0437\u0430 \u043F\u0440\u0435\u0434\u0435\u043B\u044B \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B");
        }
        update(db, t, id, { due_on: p.due_on, change_reason: p.reason, approval_json: null });
        return;
      }
      exact2(p, ["command", "reason"]);
      invariant(p.command === "cancel" && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043F\u0440\u0438\u0447\u0438\u043D\u0443 \u043E\u0442\u043C\u0435\u043D\u044B");
      update(db, t, id, { state: "cancelled", change_reason: p.reason });
      return;
    }
    if (t === "training_session") {
      createOnly(e, old);
      exact2(p, ["assignment_id", "assignment_rev", "stage_code", "held_at", "duration_minutes", "result", "notes", "witness_id", "mentor_ack", "trainee_ack"]);
      const a = freshAssignment(db, p), day = String(p.held_at).slice(0, 10), pr = progressFor(db, a), stage = pr.stages.find((x) => x.code === p.stage_code);
      invariant(a.state !== "cancelled" && a.approval_json && isCurrentStandard(db, a.sop_revision_id), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u0443\u0439\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435. \u0414\u043B\u044F \u0438\u0437\u043C\u0435\u043D\u0451\u043D\u043D\u043E\u0433\u043E \u0421\u041E\u041F \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440.");
      invariant(stage && validClock(p.held_at) && day >= a.assigned_on && day >= JSON.parse(a.approval_json).approved_on && day <= eventDay(e) && integer(p.duration_minutes, 1, 1440) && ["completed", "incomplete"].includes(p.result) && required(p.notes), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u044D\u0442\u0430\u043F, \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443/\u0432\u0440\u0435\u043C\u044F, \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442");
      invariant(!pr.facts.some((f) => f.held_at > p.held_at), "\u0424\u0430\u043A\u0442\u044B \u0434\u043E\u043B\u0436\u043D\u044B \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u0432 \u0445\u0440\u043E\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u043F\u043E\u0440\u044F\u0434\u043A\u0435");
      invariant(pr.done.has(stage.code) || stage.code === pr.next?.code, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u043F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0438\u0439 \u044D\u0442\u0430\u043F; \u043F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u044F \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u044B");
      invariant(authorizationValid(db, a.authorization_id, day), "\u041F\u0440\u0430\u0432\u043E \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043D\u0435\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043D\u0430 \u0434\u0430\u0442\u0443 \u0444\u0430\u043A\u0442\u0430");
      invariant(p.mentor_ack === true && p.trainee_ack === true, "\u041D\u0443\u0436\u043D\u044B \u043E\u0442\u043C\u0435\u0442\u043A\u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043E\u0431\u0435\u0438\u0445 \u0441\u0442\u043E\u0440\u043E\u043D (\u043D\u0435 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0434\u043F\u0438\u0441\u044C)");
      const witness = optional(db, "person", p.witness_id);
      if (a.method_variant === "special" && stage.phase === "presentation") invariant(witness && witness.id !== a.trainee_id, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0430");
      if (a.method_variant === "hazardous" && stage.phase === "practice") {
        const safety = latestVerification(db, a.id, "safety");
        invariant(safety?.result === "pass" && safety.evaluated_on <= day, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438");
      }
      store(db, t, { id, assignment_id: a.id, mentor_id: a.mentor_id, held_at: p.held_at, notes: p.notes, result: p.result, steps_json: canonical({ version: a.method_version, variant: a.method_variant, stage: stage.code, label: stage.label, repeat: pr.done.has(stage.code) }), rev: 1, stage_code: stage.code, duration_minutes: p.duration_minutes, witness_id: p.witness_id, witness_name: witness?.display_name || null, mentor_ack: 1, trainee_ack: 1, recorded_at: e.occurred_at });
      const done = progressFor(db, a);
      update(db, "training_assignment", a.id, { state: done.complete ? "completed" : "in_progress" });
      if (a.enrollment_id) {
        const n = one(db, "SELECT * FROM training_enrollment WHERE id=?", [a.enrollment_id]);
        if (n?.state === "active") update(db, "training_enrollment", n.id, { state: n.state });
      }
      return;
    }
    if (t === "training_verification") {
      createOnly(e, old);
      exact2(p, ["assignment_id", "assignment_rev", "kind", "evaluator_id", "evaluated_on", "result", "evidence", "feedback"]);
      const a = freshAssignment(db, p);
      person(db, p.evaluator_id);
      noFuture(p.evaluated_on, e);
      invariant(a.state !== "cancelled" && a.approval_json && isCurrentStandard(db, a.sop_revision_id) && p.evaluator_id !== a.trainee_id && p.evaluated_on >= a.assigned_on && p.evaluated_on >= JSON.parse(a.approval_json).approved_on && ["safety", "theory"].includes(p.kind) && ["pass", "fail"].includes(p.result) && required(p.evidence) && required(p.feedback), "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F, \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043E\u0446\u0435\u043D\u0449\u0438\u043A\u0430, \u0434\u0430\u0442\u044B, \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430 \u0438 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u044F");
      const prev = latestVerification(db, a.id, p.kind);
      invariant(!prev || p.evaluated_on >= prev.evaluated_on, "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0434\u043C\u0435\u043D\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0431\u043E\u043B\u0435\u0435 \u0440\u0430\u043D\u043D\u0435\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u043E\u0439");
      const { assignment_rev, ...data } = p;
      store(db, t, { id, ...data, recorded_at: e.occurred_at, rev: 1 });
      update(db, "training_assignment", a.id, { state: a.state });
      return;
    }
    if (t === "assessment_session") {
      createOnly(e, old);
      const a = freshAssignment(db, p);
      person(db, p.evaluator_id);
      noFuture(p.assessed_on, e);
      invariant(a.state !== "cancelled" && a.approval_json && isCurrentStandard(db, a.sop_revision_id) && p.evaluator_id !== a.trainee_id && p.assessed_on >= a.assigned_on && p.assessed_on >= JSON.parse(a.approval_json).approved_on && required(p.feedback), "\u041D\u0443\u0436\u043D\u0430 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C, \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u043E\u0446\u0435\u043D\u0449\u0438\u043A \u0438 \u043E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C");
      const prev = latestAssessment(db, a.id, p.command);
      invariant(!prev || p.assessed_on >= prev.assessed_at.slice(0, 10), "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0434\u043C\u0435\u043D\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0431\u043E\u043B\u0435\u0435 \u0440\u0430\u043D\u043D\u0435\u0439 \u043E\u0446\u0435\u043D\u043A\u043E\u0439");
      const pr = progressFor(db, a), latestTrial = pr.facts.filter((x) => x.stage_code.startsWith("try") && x.result === "completed").at(-1);
      invariant(pr.intro && latestTrial && p.assessed_on >= latestTrial.held_at.slice(0, 10), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0432\u0432\u043E\u0434\u043D\u0443\u044E \u0447\u0430\u0441\u0442\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 \u0438 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0440\u043E\u0431\u044B");
      const common = { id, person_id: a.trainee_id, evaluator_id: p.evaluator_id, training_session_id: latestTrial.id, operation_id: a.operation_id, standard_revision_id: a.sop_revision_id, assessed_at: p.assessed_on, state: "draft", assignment_id: a.id, assessment_kind: p.command, feedback: p.feedback, recorded_at: e.occurred_at, recorded_names_json: canonical(names(db, { trainee: a.trainee_id, evaluator: p.evaluator_id })), rev: 1 };
      if (p.command === "practical") {
        exact2(p, ["command", "assignment_id", "assignment_rev", "evaluator_id", "assessed_on", "method_id", "responses", "conclusion", "feedback"]);
        invariant(practicalMethods(db).some((x) => x.id === p.method_id && x.state === "active") && Object.hasOwn(conclusions, p.conclusion), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 \u0438 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435");
        const c = practicalCriteria(db, p.method_id);
        invariant(c.length > 0 && Array.isArray(p.responses) && p.responses.length === c.length, "\u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u043E\u0442\u0432\u0435\u0442\u0438\u0442\u044C \u043D\u0430 \u0432\u0441\u0435 " + c.length + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
        p.responses.forEach((x, i) => {
          exact2(x, ["criterion_id", "value", "note"]);
          invariant(x.criterion_id === c[i].id && (x.value === 0 || x.value === 1) && text2(x.note), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043E\u0446\u0435\u043D\u043A\u0438");
        });
        store(db, t, { ...common, method_id: p.method_id, responses_json: canonical(p.responses), conclusion: p.conclusion });
      } else {
        exact2(p, ["command", "assignment_id", "assignment_rev", "evaluator_id", "assessed_on", "practical_id", "observation_state", "level", "valid_until", "evidence", "feedback"]);
        invariant(p.command === "qualification" && ["rated", "not_observed", "not_applicable"].includes(p.observation_state) && required(p.evidence), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E\u0431 \u0443\u0440\u043E\u0432\u043D\u0435 \u043D\u0430\u0432\u044B\u043A\u0430");
        const practical = latestAssessment(db, a.id, "practical");
        invariant(practical && practical.id === p.practical_id && p.assessed_on >= practical.assessed_at.slice(0, 10), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u044E\u044E \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u043E\u0446\u0435\u043D\u043A\u0443 \u044D\u0442\u043E\u0433\u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F");
        invariant(p.valid_until === null || period(p.assessed_on, p.valid_until), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0441\u0440\u043E\u043A \u0443\u0440\u043E\u0432\u043D\u044F");
        if (p.observation_state === "rated") level(db, a.scale_id, p.level);
        else invariant(p.level === null && p.valid_until === null, "\u041D\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u043B\u043E\u0441\u044C / \u043D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E \u2014 \u043D\u0435 \u0447\u0438\u0441\u043B\u043E\u0432\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430");
        store(db, t, { ...common, practical_id: practical.id, notes: p.evidence });
        store(db, "assessment_item", { id: e.id, session_id: id, skill_id: a.skill_id, scale_id: a.scale_id, level: p.level, observation_state: p.observation_state, valid_until: p.valid_until, evidence_note: p.evidence });
      }
      db.run("UPDATE assessment_session SET state='confirmed' WHERE id=?", [id]);
      update(db, "training_assignment", a.id, { state: a.state });
      return;
    }
    if (t === "admission_decision") {
      if (old) {
        changeOnly(e, old);
        exact2(p, ["command", "reason"]);
        invariant(p.command === "revoke" && old.decision === "granted" && !old.revoked_at && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0442\u0437\u044B\u0432\u0430 \u0434\u043E\u043F\u0443\u0441\u043A\u0430");
        update(db, t, id, { revoked_at: e.occurred_at, revoke_reason: p.reason });
        return;
      }
      createOnly(e, old);
      exact2(p, ["assignment_id", "assignment_rev", "actor_id", "decided_on", "valid_until", "decision", "evidence", "feedback"]);
      const a = freshAssignment(db, p);
      person(db, p.actor_id);
      noFuture(p.decided_on, e);
      invariant(a.state !== "cancelled" && a.approval_json && isCurrentStandard(db, a.sop_revision_id) && p.actor_id !== a.trainee_id && p.decided_on >= a.assigned_on && p.decided_on >= JSON.parse(a.approval_json).approved_on && period(p.decided_on, p.valid_until) && ["granted", "denied"].includes(p.decision) && required(p.evidence) && required(p.feedback), "\u0414\u043E\u043F\u0443\u0441\u043A \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u044F\u0432\u043D\u043E\u0433\u043E \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E, \u0434\u0430\u0442\u044B, \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u043E\u0431\u0440\u0430\u0442\u043D\u043E\u0439 \u0441\u0432\u044F\u0437\u0438");
      const q = latestAssessment(db, a.id, "qualification"), pr = latestAssessment(db, a.id, "practical"), s = latestVerification(db, a.id, "safety"), th = latestVerification(db, a.id, "theory");
      const previous = latest(db, "admission_decision", "person_id=? AND operation_id=?", [a.trainee_id, a.operation_id], "decided_on");
      invariant(!previous || p.decided_on >= previous.decided_on, "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0434\u043C\u0435\u043D\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0431\u043E\u043B\u0435\u0435 \u0440\u0430\u043D\u043D\u0438\u043C \u0440\u0435\u0448\u0435\u043D\u0438\u0435\u043C");
      if (p.decision === "granted") {
        const item2 = q && one(db, "SELECT * FROM assessment_item WHERE session_id=?", [q.id]);
        invariant(pr && q && q.practical_id === pr.id && pr.conclusion !== "not_meet" && item2?.observation_state === "rated" && (!item2.valid_until || item2.valid_until >= p.decided_on) && s?.result === "pass" && th?.result === "pass" && [q.assessed_at, pr.assessed_at, s.evaluated_on, th.evaluated_on].every((x) => x.slice(0, 10) <= p.decided_on), "\u041D\u0443\u0436\u043D\u044B \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430, \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C, \u043F\u043E\u043B\u043E\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u041E\u0422 \u0438 \u0442\u0435\u043E\u0440\u0438\u0438. \u041F\u0440\u043E\u0446\u0435\u043D\u0442 \u0441\u0430\u043C \u043F\u043E \u0441\u0435\u0431\u0435 \u043D\u0435 \u0432\u044B\u0434\u0430\u0451\u0442 \u0434\u043E\u043F\u0443\u0441\u043A.");
      } else invariant(p.valid_until === null, "\u041E\u0442\u043A\u0430\u0437 \u043D\u0435 \u0438\u043C\u0435\u0435\u0442 \u0441\u0440\u043E\u043A\u0430 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F");
      const { assignment_rev, ...data } = p;
      store(db, t, { id, ...data, person_id: a.trainee_id, operation_id: a.operation_id, revision_id: a.sop_revision_id, qualification_id: q?.id || null, practical_id: pr?.id || null, safety_id: s?.id || null, theory_id: th?.id || null, recorded_at: e.occurred_at, rev: 1 });
      update(db, "training_assignment", a.id, { state: a.state });
      return;
    }
    if (t === "role_requirement") {
      if (old) {
        changeOnly(e, old);
        exact2(p, ["command", "valid_to"]);
        invariant(p.command === "close" && !old.valid_to && period(old.valid_from, p.valid_to) && p.valid_to, "\u0417\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0434\u0430\u0442\u043E\u0439");
        update(db, t, id, { valid_to: p.valid_to });
        return;
      }
      createOnly(e, old);
      exact2(p, ["profession_id", "skill_id", "scale_id", "required_level", "criticality", "valid_from", "valid_to"]);
      active(db, "profession", p.profession_id);
      active(db, "skill", p.skill_id);
      level(db, p.scale_id, p.required_level);
      invariant(period(p.valid_from, p.valid_to) && ["normal", "important", "critical"].includes(p.criticality) && !one(db, "SELECT id FROM role_requirement WHERE profession_id=? AND skill_id=? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=?", [p.profession_id, p.skill_id, p.valid_to || "9999-12-31", p.valid_from]), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0438\u043B\u0438 \u043F\u0435\u0440\u0435\u0441\u0435\u043A\u0430\u044E\u0449\u0435\u0435\u0441\u044F \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435");
      store(db, t, { id, ...p, rev: 1 });
      return;
    }
    if (t === "coverage_requirement") {
      exact2(p, ["unit_id", "skill_id", "shift_code", "min_people", "scale_id", "required_level"]);
      active(db, "org_unit", p.unit_id);
      active(db, "skill", p.skill_id);
      level(db, p.scale_id, p.required_level);
      invariant(text2(p.shift_code, 100) && (!p.shift_code || one(db, "SELECT id FROM work_shift WHERE code=? AND archived=0", [p.shift_code])) && integer(p.min_people, 0, 1e5), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u044F");
      if (old) {
        changeOnly(e, old);
        invariant(old.unit_id === p.unit_id && old.skill_id === p.skill_id && old.shift_code === p.shift_code, "\u041E\u0431\u043B\u0430\u0441\u0442\u044C \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
        update(db, t, id, p);
      } else {
        createOnly(e, old);
        store(db, t, { id, ...p, rev: 1 });
      }
      return;
    }
    if (t === "development_plan") {
      if (!old) {
        createOnly(e, old);
        exact2(p, ["person_id", "title", "start_on", "due_on"]);
        person(db, p.person_id);
        invariant(required(p.title) && period(p.start_on, p.due_on) && p.due_on, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0446\u0435\u043B\u044C \u0438 \u043F\u0435\u0440\u0438\u043E\u0434 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F");
        store(db, t, { id, ...p, state: "active", rev: 1 });
        return;
      }
      changeOnly(e, old);
      exact2(p, ["command", "reason"]);
      invariant(old.state === "active" && ["finish", "cancel"].includes(p.command) && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043F\u043E \u043F\u043B\u0430\u043D\u0443");
      if (p.command === "finish") invariant(!!one(db, "SELECT id FROM development_goal WHERE plan_id=?", [id]) && !one(db, "SELECT id FROM development_goal WHERE plan_id=? AND state='open'", [id]), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0446\u0435\u043B\u0438 \u043F\u043B\u0430\u043D\u0430");
      if (p.command === "cancel") db.run("UPDATE development_goal SET state='cancelled',rev=rev+1 WHERE plan_id=? AND state='open'", [id]);
      update(db, t, id, { state: p.command === "finish" ? "completed" : "cancelled" });
      return;
    }
    if (t === "development_goal") {
      if (!old) {
        createOnly(e, old);
        exact2(p, ["plan_id", "skill_id", "scale_id", "target_level", "title", "due_on"]);
        const plan = one(db, "SELECT * FROM development_plan WHERE id=? AND state=?", [p.plan_id, "active"]);
        invariant(plan && required(p.title) && period(plan.start_on, p.due_on) && p.due_on && p.due_on <= plan.due_on, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u043F\u043B\u0430\u043D \u0438 \u0441\u0440\u043E\u043A \u0446\u0435\u043B\u0438");
        if (p.skill_id) {
          active(db, "skill", p.skill_id);
          level(db, p.scale_id, p.target_level);
        } else invariant(p.scale_id === null && p.target_level === null, "\u0411\u0435\u0437 \u043D\u0430\u0432\u044B\u043A\u0430 \u043D\u0435 \u0432\u044B\u0431\u0438\u0440\u0430\u0435\u0442\u0441\u044F \u0443\u0440\u043E\u0432\u0435\u043D\u044C");
        store(db, t, { id, plan_id: p.plan_id, skill_id: p.skill_id, title: p.title, target_json: canonical({ scale_id: p.scale_id, target_level: p.target_level }), due_on: p.due_on, state: "open", rev: 1 });
        return;
      }
      changeOnly(e, old);
      exact2(p, ["command", "reason"]);
      invariant(old.state === "open" && ["finish", "cancel"].includes(p.command) && required(p.reason), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0446\u0435\u043B\u0438");
      update(db, t, id, { state: p.command === "finish" ? "completed" : "cancelled" });
      return;
    }
    invariant(false, "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435 LC4");
  }
  function matrixData(db, day) {
    const people = rows(db, `SELECT p.id,p.display_name,p.employee_code,a.profession_id,a.position_id,a.unit_id,a.shift_id,a.shift_code FROM person p LEFT JOIN person_assignment a ON a.id=(SELECT id FROM person_assignment a2 WHERE a2.person_id=p.id AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? ORDER BY valid_from DESC,id LIMIT 1) WHERE p.archived=0 ORDER BY p.display_name,p.employee_code`, [day, day]);
    const skills = rows(db, "SELECT s.*,c.name category FROM skill s JOIN skill_category c ON c.id=s.category_id WHERE s.archived=0 AND c.archived=0 ORDER BY c.name,s.name");
    const requirements = rows(db, "SELECT * FROM role_requirement WHERE valid_from<=? AND coalesce(valid_to,'9999-12-31')>=?", [day, day]);
    const req = new Map(requirements.map((x) => [x.profession_id + ":" + x.skill_id, x]));
    const facts = rows(db, `SELECT * FROM (SELECT i.*,s.person_id,s.assessed_at,s.standard_revision_id,s.evaluator_id,s.assignment_id,s.recorded_at,
 ROW_NUMBER() OVER(PARTITION BY s.person_id,i.skill_id ORDER BY s.assessed_at DESC,coalesce(s.recorded_at,'') DESC,s.id DESC) rn
 FROM assessment_item i JOIN assessment_session s ON s.id=i.session_id WHERE s.state='confirmed' AND substr(s.assessed_at,1,10)<=?) WHERE rn=1`, [day]);
    const observed = new Map(facts.map((x) => [x.person_id + ":" + x.skill_id, x]));
    const records = rows(db, `SELECT * FROM (SELECT a.*,ROW_NUMBER() OVER(PARTITION BY person_id,operation_id ORDER BY decided_on DESC,recorded_at DESC,id DESC) rn FROM admission_decision a WHERE decided_on<=?) WHERE rn=1`, [day]);
    const admissions = new Map(records.map((a) => [a.person_id + ":" + a.operation_id, admissionRecordStatus(db, a, day)]));
    const current = new Set(rows(db, "SELECT r.id FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.state='effective' AND d.archived=0").map((x) => x.id));
    const cells2 = /* @__PURE__ */ new Map();
    for (const p of people) for (const s of skills) {
      const goal = req.get(p.profession_id + ":" + s.id) || null, fact = observed.get(p.id + ":" + s.id) || null, same = !goal || fact?.scale_id === goal.scale_id;
      const valid = !!(fact?.observation_state === "rated" && (!fact.valid_until || fact.valid_until >= day)), revisionCurrent = !s.operation_id || !!(fact?.standard_revision_id && current.has(fact.standard_revision_id));
      const adm = s.operation_id ? admissions.get(p.id + ":" + s.operation_id) || { record: null, status: "\u041D\u0435\u0442 \u0440\u0435\u0448\u0435\u043D\u0438\u044F", current: false } : null;
      cells2.set(p.id + ":" + s.id, { goal, fact, same, valid, revisionCurrent, admission: adm, gap: !!(goal && (!valid || !same || !revisionCurrent || fact.level < goal.required_level)), qualified: !!(valid && same && revisionCurrent && (!goal || fact.level >= goal.required_level) && (!adm || adm.current && adm.record.revision_id === fact.standard_revision_id)) });
    }
    return { people, skills, cells: cells2 };
  }
  function coverageData(db, day, matrix = matrixData(db, day)) {
    return rows(db, "SELECT * FROM coverage_requirement ORDER BY unit_id,skill_id,shift_code").map((r) => {
      const skill = matrix.skills.find((s) => s.id === r.skill_id), scope = matrix.people.filter((p) => p.unit_id === r.unit_id && (!r.shift_code || p.shift_code === r.shift_code || one(db, "SELECT code FROM work_shift WHERE id=?", [p.shift_id])?.code === r.shift_code));
      const actual = scope.filter((p) => {
        const c = matrix.cells.get(p.id + ":" + r.skill_id);
        return c?.valid && c.revisionCurrent && c.fact.scale_id === r.scale_id && c.fact.level >= r.required_level && (!skill?.operation_id || c.admission?.current && c.admission.record.revision_id === c.fact.standard_revision_id);
      }).length;
      return { ...r, actual, deficit: Math.max(0, r.min_people - actual), fraction: r.min_people ? actual / r.min_people : null, scope: scope.length };
    });
  }

  // src/modules/library/stage43-checklist.js
  var scores = [0, 0.3, 0.7, 1];
  var origins = ["seed", "auto", "manual", "legacy"];
  var text3 = (v, n) => typeof v === "string" && v.length <= n;
  var exact3 = (x, ks) => x && typeof x === "object" && !Array.isArray(x) && Object.keys(x).length === ks.length && ks.every((k) => Object.hasOwn(x, k));
  function validateRows(data) {
    invariant(Array.isArray(data) && data.length === 13, "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 Stage43 \u0434\u043E\u043B\u0436\u0435\u043D \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C 13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    data.forEach((x, i) => invariant(exact3(x, ["id", "req", "weight", "score", "comment", "scoreSource"]) && x.id === i + 1 && text3(x.req, 2500) && x.req.trim() && Number.isFinite(x.weight) && x.weight > 0 && x.weight <= 100 && scores.includes(x.score) && text3(x.comment, 2e3) && origins.includes(x.scoreSource), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0439 Stage43 " + (i + 1)));
    return data;
  }
  function stage43Checklist(constructor) {
    const raw = constructor?.checklist;
    if (raw == null) return [];
    invariant(Array.isArray(raw), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0430");
    if (!raw.length) return [];
    return validateRows(raw.map((x) => ({ id: x.id, req: x.req, weight: x.weight, score: x.score, comment: x.comment ?? "", scoreSource: origins.includes(x.scoreSource) ? x.scoreSource : "legacy" })));
  }
  function weightedResult(data) {
    const weight = data.reduce((n, x) => n + x.weight, 0), points = data.reduce((n, x) => n + x.score * x.weight, 0);
    return { weight, points, fraction: weight ? points / weight : null, seed: data.filter((x) => x.scoreSource === "seed").length };
  }
  function stage43Checks(db, revisionId) {
    return rows(db, "SELECT * FROM sop_stage43_checklist WHERE revision_id=? ORDER BY updated_at DESC", [revisionId]);
  }
  function verifyStage43Checklist(p, original) {
    invariant(exact3(p, ["revision_id", "source", "rows", "actor_id"]) && isId(p.revision_id) && (p.actor_id === null || isId(p.actor_id)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430");
    const proposed = validateRows(p.rows), base = stage43Checklist(original);
    invariant(base.length === 13, "\u0423 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0421\u041E\u041F \u043D\u0435\u0442 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430 Stage43");
    proposed.forEach((x, i) => {
      const y = base[i];
      invariant(x.id === y.id && x.req === y.req && x.weight === y.weight, "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u0432\u0435\u0441\u0430 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0439 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u044B");
      invariant(x.scoreSource === "manual" || x.scoreSource === y.scoreSource && x.score === y.score, "\u0418\u0437\u043C\u0435\u043D\u0451\u043D\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043E\u0442\u043C\u0435\u0447\u0435\u043D\u0430 \u043A\u0430\u043A \u0440\u0443\u0447\u043D\u0430\u044F");
    });
    return proposed;
  }
  function applyStage43Checklist(db, e, old) {
    const p = e.payload;
    invariant(exact3(p, ["revision_id", "source", "rows", "actor_id"]) && isId(p.revision_id) && (p.actor_id === null || isId(p.actor_id)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430");
    const data = validateRows(p.rows), v = one(db, "SELECT r.payload_json,d.archived FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.id=? AND d.kind=?", [p.revision_id, "sop"]);
    invariant(v && !v.archived && p.source?.kind === "sop" && canonical(JSON.parse(v.payload_json).source) === canonical(p.source), "\u0418\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u0421\u041E\u041F \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D");
    const person2 = p.actor_id ? one(db, "SELECT display_name FROM person WHERE id=? AND archived=0", [p.actor_id]) : null;
    invariant(!p.actor_id || person2, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u043E\u0446\u0435\u043D\u0449\u0438\u043A\u0430");
    if (e.operation === "create") {
      invariant(!old && !one(db, "SELECT id FROM sop_stage43_checklist WHERE revision_id=? AND source_sha256=?", [p.revision_id, p.source.sha256]), "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u044D\u0442\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0443\u0436\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D");
      db.run("INSERT INTO sop_stage43_checklist(id,revision_id,source_sha256,rows_json,actor_id,actor_name,updated_at,rev) VALUES(?,?,?,?,?,?,?,1)", [e.entity_id, p.revision_id, p.source.sha256, canonical(data), p.actor_id, person2?.display_name || "", e.occurred_at]);
    } else {
      invariant(e.operation === "update" && old && old.revision_id === p.revision_id && old.source_sha256 === p.source.sha256, "\u041D\u0435\u043B\u044C\u0437\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0443 \u0438\u043B\u0438 \u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0447\u0435\u043A-\u043B\u0438\u0441\u0442");
      const prior = validateRows(JSON.parse(old.rows_json));
      data.forEach((x, i) => invariant(x.id === prior[i].id && x.req === prior[i].req && x.weight === prior[i].weight, "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430"));
      db.run("UPDATE sop_stage43_checklist SET rows_json=?,actor_id=?,actor_name=?,updated_at=?,rev=rev+1 WHERE id=?", [canonical(data), p.actor_id, person2?.display_name || "", e.occurred_at, e.entity_id]);
    }
  }

  // src/modules/library/domain.js
  var DOMAIN_TYPES = Object.freeze({ document: "\u0411\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0421\u041E\u041F", frv_study: "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u0424\u0420\u0412", checklist_version: "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F", sop_evaluation: "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F", sop_stage43_checklist: "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 Stage43", ...TRAINING_TYPES });
  var MAX_CONTENT = 30 * 1024 * 1024;
  var MIME = { sop: "application/vnd.lean.stage43.sop+json", frv: "application/vnd.lean.stage43.frv+json" };
  var encoder = new TextEncoder();
  var obj = (x) => x && typeof x === "object" && !Array.isArray(x);
  var string = (x, max2 = 2e4) => typeof x === "string" && x.length <= max2;
  var nonempty = (x, max2 = 500) => string(x, max2) && x.trim().length > 0;
  var date2 = (x) => string(x, 10) && /^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x;
  var digest = (x) => typeof x === "string" && /^[0-9a-f]{64}$/.test(x);
  var types = /* @__PURE__ */ new Set(["VA", "NVA_Necessary", "NVA_Waste", "WAIT", "BREAK", "OTHER"]);
  var exact4 = (p, keys) => invariant(obj(p) && Object.keys(p).length === keys.length && keys.every((k) => Object.hasOwn(p, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u0441\u043E\u0431\u044B\u0442\u0438\u044F LC3");
  var num = (x) => typeof x === "number" && Number.isFinite(x) && x >= 0;
  var safeImage = (x) => string(x, MAX_CONTENT) && /^data:image\/(?:jpeg|png|webp|gif);base64,[A-Za-z0-9+/]+={0,2}$/i.test(x);
  function validateRef(ref) {
    exact4(ref, ["sha256", "size", "kind"]);
    invariant(digest(ref.sha256) && Number.isSafeInteger(ref.size) && ref.size > 0 && ref.size <= MAX_CONTENT && Object.hasOwn(MIME, ref.kind), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0441\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B");
    return ref;
  }
  async function checkContent(ref, text4) {
    validateRef(ref);
    invariant(typeof text4 === "string" && text4.length <= MAX_CONTENT, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0432\u0435\u043B\u0438\u043A");
    const bytes = encoder.encode(text4);
    invariant(bytes.length === ref.size && await sha256(bytes) === ref.sha256, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D: " + ref.sha256);
    return text4;
  }
  function verifyPeople(source, kind) {
    const refs = source.leanCenterPeople;
    if (refs === void 0) return;
    invariant(Array.isArray(refs) && refs.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0441\u0441\u044B\u043B\u043A\u0438 \u043D\u0430 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432");
    const seen = /* @__PURE__ */ new Set(), single = /* @__PURE__ */ new Set();
    for (const x of refs) {
      exact4(x, ["slot", "person_id", "employee_code", "display_name", "position", "unit"]);
      invariant(isId(x.person_id) && nonempty(x.display_name, 500) && nonempty(x.employee_code, 200) && string(x.position, 500) && string(x.unit, 500) && string(x.slot, 100), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0441\u043D\u0438\u043C\u043E\u043A \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
      const key3 = x.slot + ":" + x.person_id;
      invariant(!seen.has(key3), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u0441\u044B\u043B\u043A\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
      seen.add(key3);
      if (x.slot !== "sop_observer") {
        invariant(!single.has(x.slot), "\u0414\u0432\u0430 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0432 \u043E\u0434\u043D\u043E\u043C \u043F\u043E\u043B\u0435");
        single.add(x.slot);
      }
      let name, post = null;
      if (kind === "frv") {
        invariant(["operator", "observer"].includes(x.slot), "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u0430\u044F \u0440\u043E\u043B\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0432 \u0424\u0420\u0412");
        name = source[x.slot];
      } else if (x.slot === "approver") {
        name = source.meta.approverName;
        post = source.meta.approverPost || "";
      } else if (x.slot === "sop_observer") {
        invariant(String(source.frvMeta?.observers || "").split(/\r?\n/).includes(x.display_name), "\u0421\u043D\u0438\u043C\u043E\u043A \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u0435\u043B\u044F \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043F\u0435\u0447\u0430\u0442\u043D\u043E\u043C\u0443 \u043F\u043E\u043B\u044E");
        continue;
      } else if (["trainer", "trainee"].includes(x.slot)) name = source.twi?.[x.slot];
      else {
        const m = /^(workgroup|agree):(\d+)$/.exec(x.slot);
        invariant(m, "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u0430\u044F \u0440\u043E\u043B\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0432 \u0421\u041E\u041F");
        if (m[1] === "workgroup") name = source.responsibles?.[Number(m[2])];
        else {
          const a = source.agreedList?.[Number(m[2])];
          name = a?.name;
          post = a?.post || "";
        }
      }
      invariant(name === x.display_name && (post === null || post === x.position), "\u0421\u043D\u0438\u043C\u043E\u043A \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043F\u0435\u0447\u0430\u0442\u043D\u044B\u043C \u043F\u043E\u043B\u044F\u043C");
    }
  }
  async function inspectSource(text4, kind) {
    invariant(Object.hasOwn(MIME, kind) && typeof text4 === "string" && text4.length <= MAX_CONTENT, "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u0438\u043F \u0438\u043B\u0438 \u0440\u0430\u0437\u043C\u0435\u0440 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430");
    const bytes = encoder.encode(text4);
    invariant(bytes.length > 0 && bytes.length <= MAX_CONTENT, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u043D\u0435 \u0434\u043E\u043B\u0436\u0435\u043D \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0442\u044C 30 \u041C\u0411");
    const p = JSON.parse(text4);
    invariant(obj(p), "\u041E\u0436\u0438\u0434\u0430\u043B\u0441\u044F JSON Stage43");
    let projection;
    if (kind === "sop") {
      invariant(p.schemaVersion === 2 && obj(p.document) && Object.hasOwn(p, "constructor") && obj(p.constructor) && Array.isArray(p.constructor.steps) && obj(p.photoAssets) && p.integrity?.algorithm === "SHA-256" && digest(p.integrity.sha256), "\u041E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u0421\u041E\u041F Stage43 \u0441 SHA-256");
      const base = { schemaVersion: p.schemaVersion, document: p.document, constructor: p.constructor, photoAssets: p.photoAssets };
      invariant(await sha256(JSON.stringify(base)) === p.integrity.sha256, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C\u043E\u0433\u043E \u0421\u041E\u041F \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
      const s = p.constructor, d = p.document, seen = /* @__PURE__ */ new Set();
      invariant(obj(s.meta) && s.steps.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0448\u0430\u0433\u0438 \u0421\u041E\u041F");
      verifyPeople(s, "sop");
      const steps = s.steps.map((st) => {
        invariant(obj(st) && Number.isSafeInteger(st.id) && st.id > 0 && !seen.has(st.id) && string(st.action) && Array.isArray(st.keyMoments) && st.keyMoments.length <= 5 && st.keyMoments.every((x) => string(x)) && string(st.reason) && num(st.durationSeconds) && typeof st.hasPhoto === "boolean", "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0448\u0430\u0433 \u0421\u041E\u041F");
        seen.add(st.id);
        if (st.hasPhoto) {
          const a = p.photoAssets[String(st.id)];
          invariant(obj(a) && safeImage(a.original) && (!a.rendered || safeImage(a.rendered)), "\u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u043D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u043E\u0435 \u0444\u043E\u0442\u043E \u0448\u0430\u0433\u0430 " + st.id);
        }
        return { source_id: String(st.id), action: st.action, key_points: st.keyMoments, reason: st.reason, seconds: st.durationSeconds, photo: st.hasPhoto };
      });
      invariant(Object.keys(p.photoAssets).every((k) => steps.some((st) => st.source_id === k && st.photo)), "\u0415\u0441\u0442\u044C \u0444\u043E\u0442\u043E \u0431\u0435\u0437 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u0448\u0430\u0433\u0430");
      projection = { title: String(s.meta.operation || "").slice(0, 500), number: String(d.number || s.meta.sopNumber || "").slice(0, 200), legacy_id: String(d.id || "").slice(0, 200), legacy_version: String(d.version ?? "").slice(0, 50), legacy_status: String(d.status || "").slice(0, 80), photos: steps.filter((x) => x.photo).length, twi: !!s.twi?.enabled, steps };
    } else {
      invariant(["FRV-1.2", "FRV-1.3"].includes(p.schemaVersion) && obj(p.study) && Array.isArray(p.cycles) && p.cycles.length <= 1e3, "\u041E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C \u043A\u043E\u043F\u0438\u044F \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u0424\u0420\u0412 FRV-1.2/1.3");
      verifyPeople(p.study, "frv");
      const seen = /* @__PURE__ */ new Set(), measurements = [];
      let complete = 0, unmeasured = 0, count = 0;
      for (const [i, c] of p.cycles.entries()) {
        invariant(obj(c) && Array.isArray(c.observations) && c.observations.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0446\u0438\u043A\u043B \u0424\u0420\u0412");
        let full = c.observations.length > 0;
        const phase = ["baseline", "improved", "unassigned"].includes(c.phase) ? c.phase : "unassigned";
        for (const o of c.observations) {
          count++;
          invariant(count <= 5e3 && obj(o) && nonempty(o.id, 200) && !seen.has(o.id) && string(o.actionRaw) && (!o.valueType || types.has(o.valueType)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435 \u0424\u0420\u0412");
          seen.add(o.id);
          const v = o.durationSec;
          invariant(v == null || num(v), "\u0412\u0440\u0435\u043C\u044F \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u0447\u0438\u0441\u043B\u043E\u043C \u0441\u0435\u043A\u0443\u043D\u0434 \u0438\u043B\u0438 null");
          if (v == null || !o.actionRaw.trim()) {
            unmeasured++;
            full = false;
            continue;
          }
          if (v === 0) full = false;
          measurements.push({ source_id: o.id, cycle: i + 1, phase, action: o.actionRaw, category: o.valueType || "OTHER", seconds: v });
        }
        if (full) complete++;
      }
      projection = { title: String(p.study.operationId || p.study.processDescription || p.study.studyId || "").slice(0, 500), number: String(p.study.studyId || "").slice(0, 200), legacy_id: String(p.study.libraryId || "").slice(0, 200), legacy_version: String(p.study.version || "").slice(0, 50), legacy_status: String(p.study.status || "").slice(0, 80), cycles: p.cycles.length, complete, unmeasured, measurements };
    }
    invariant(encoder.encode(canonical(projection)).length <= 2 * 1024 * 1024, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u0430\u044F \u043F\u0440\u043E\u0435\u043A\u0446\u0438\u044F \u0434\u043B\u044F \u043E\u0434\u043D\u043E\u0433\u043E \u043F\u0430\u043A\u0435\u0442\u0430; \u0440\u0430\u0437\u0434\u0435\u043B\u0438\u0442\u0435 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A");
    return { source: { sha256: await sha256(bytes), size: bytes.length, kind }, projection };
  }
  function refsForEvents(events) {
    const out = /* @__PURE__ */ new Map();
    for (const e of events || []) if (Object.hasOwn(DOMAIN_TYPES, e.entity_type) && e.payload?.source) {
      const r = validateRef(e.payload.source);
      out.set(r.sha256, r);
    }
    return [...out.values()];
  }
  function frvOriginSnapshot(db, revisionId) {
    const x = one(db, `SELECT o.study_id,o.source_sha256,o.created_at,f.title,f.state,f.context_json,a.byte_size,a.mime
 FROM sop_frv_origin o JOIN frv_study f ON f.id=o.study_id JOIN attachment a ON a.sha256=o.source_sha256
 WHERE o.revision_id=?`, [revisionId]);
    if (!x) return null;
    invariant(x.mime === MIME.frv, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0442\u0438\u043F \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0437\u0430\u043C\u0435\u0440\u043E\u0432");
    const source = validateRef({ sha256: x.source_sha256, size: x.byte_size, kind: "frv" });
    return { study_id: x.study_id, title: x.title, state: x.state, created_at: x.created_at, source, current: JSON.parse(x.context_json).source.sha256 === source.sha256 };
  }
  function refsForDb(db) {
    return rows(db, "SELECT sha256,byte_size,mime FROM attachment WHERE mime IN (?,?) ORDER BY sha256", [MIME.sop, MIME.frv]).map((x) => validateRef({ sha256: x.sha256, size: x.byte_size, kind: x.mime === MIME.sop ? "sop" : "frv" }));
  }
  function unionRefs(...groups) {
    const m = /* @__PURE__ */ new Map();
    for (const refs of groups) for (const ref of refs) {
      validateRef(ref);
      const old = m.get(ref.sha256);
      invariant(!old || canonical(old) === canonical(ref), "\u041D\u0435\u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430");
      m.set(ref.sha256, ref);
    }
    return [...m.values()];
  }
  async function verifyDomainEvents(events, readContent3) {
    const checked = /* @__PURE__ */ new Map();
    for (const e of events || []) {
      if (!Object.hasOwn(DOMAIN_TYPES, e.entity_type) || !e.payload?.source) continue;
      const ref = validateRef(e.payload.source);
      invariant(typeof readContent3 === "function", "\u041F\u0430\u043A\u0435\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043F\u043E\u043B\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432");
      let result = checked.get(ref.sha256);
      if (!result) {
        const text4 = await checkContent(ref, await readContent3(ref));
        result = await inspectSource(text4, ref.kind);
        result.raw = JSON.parse(text4);
        checked.set(ref.sha256, result);
      }
      if (isTrainingEvent(e)) {
        verifyTrainingSource(e, result.source, result.raw);
        continue;
      }
      if (e.entity_type === "sop_stage43_checklist") {
        invariant(ref.kind === "sop" && canonical(result.source) === canonical(ref), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430");
        verifyStage43Checklist(e.payload, result.raw.constructor);
        continue;
      }
      invariant(canonical(result.source) === canonical(ref) && canonical(result.projection) === canonical(e.payload.projection), "\u041F\u0440\u043E\u0435\u043A\u0446\u0438\u044F \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u043C \u0444\u0430\u0439\u043B\u043E\u043C");
    }
  }
  function register(db, ref) {
    validateRef(ref);
    const old = one(db, "SELECT * FROM attachment WHERE sha256=?", [ref.sha256]);
    if (old) {
      invariant(old.mime === MIME[ref.kind] && old.byte_size === ref.size, "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E");
      return;
    }
    db.run("INSERT INTO attachment(sha256,mime,byte_size,original_name) VALUES(?,?,?,?)", [ref.sha256, MIME[ref.kind], ref.size, ref.sha256 + ".json"]);
  }
  function link(db, ref, type, id) {
    register(db, ref);
    db.run("DELETE FROM attachment_link WHERE entity_type=? AND entity_id=? AND purpose='stage43-source'", [type, id]);
    db.run("INSERT INTO attachment_link(id,sha256,entity_type,entity_id,purpose) VALUES(?,?,?,?,?)", [id + ":source", ref.sha256, type, id, "stage43-source"]);
  }
  function active2(db, table2, id) {
    invariant(isId(id) && one(db, "SELECT id FROM " + table2 + " WHERE id=? AND archived=0", [id]), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u0437\u0430\u043F\u0438\u0441\u044C: " + table2);
  }
  function operation(db, id) {
    if (id !== null) active2(db, "operation", id);
  }
  function sourcePayload(p, kind) {
    validateRef(p.source);
    invariant(p.source.kind === kind && obj(p.projection) && nonempty(p.title) && string(p.projection.title, 500), "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435");
    return canonical({ source: p.source, projection: p.projection });
  }
  function docSteps(db, rid, p) {
    invariant(Array.isArray(p.projection.steps) && p.projection.steps.length <= 1e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u0448\u0430\u0433\u0438");
    db.run("DELETE FROM document_step WHERE revision_id=?", [rid]);
    for (const [i, s] of p.projection.steps.entries()) {
      invariant(string(s.action) && Array.isArray(s.key_points) && s.key_points.every((x) => string(x)) && string(s.reason) && num(s.seconds), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0448\u0430\u0433");
      db.run("INSERT INTO document_step(id,revision_id,position,action_text,key_points_json,reason_text,duration_seconds) VALUES(?,?,?,?,?,?,?)", [rid + ":" + (i + 1), rid, i + 1, s.action, canonical(s.key_points), s.reason, s.seconds]);
    }
  }
  function revision(db, id, docId) {
    const r = one(db, "SELECT * FROM document_revision WHERE id=? AND document_id=?", [id, docId]);
    invariant(r, "\u0412\u0435\u0440\u0441\u0438\u044F \u043D\u0435 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0443");
    return r;
  }
  function openRevision(db, id) {
    return one(db, "SELECT id FROM document_revision WHERE document_id=? AND state IN ('draft','review','approved')", [id]);
  }
  function newRevision(db, e, p, version) {
    const payload = sourcePayload(p, "sop");
    register(db, p.source);
    db.run("INSERT INTO document_revision(id,document_id,version_no,state,payload_json,created_at) VALUES(?,?,?,'draft',?,?)", [e.id, e.entity_id, version, payload, e.occurred_at]);
    docSteps(db, e.id, p);
    link(db, p.source, "document_revision", e.id);
  }
  function applyDomainEvent(db, e, old) {
    const p = e.payload, id = e.entity_id;
    if (isTrainingEvent(e)) return applyTrainingEvent(db, e, old);
    if (e.entity_type === "checklist_version") return applySopMethod(db, e, old);
    if (e.entity_type === "sop_evaluation") return applySopEvaluation(db, e, old);
    if (e.entity_type === "sop_stage43_checklist") return applyStage43Checklist(db, e, old);
    if (e.entity_type === "document") {
      if (e.operation === "create") {
        exact4(p, ["command", "code", "title", "operation_id", "source", "projection"]);
        invariant(!old && p.command === "create" && nonempty(p.code, 200) && nonempty(p.title), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043D\u043E\u0432\u044B\u0439 \u0421\u041E\u041F");
        operation(db, p.operation_id);
        invariant(!rows(db, "SELECT code FROM document").some((x) => foldKey(x.code) === foldKey(p.code)), "\u041D\u043E\u043C\u0435\u0440 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442");
        db.run("INSERT INTO document(id,code,kind,operation_id,title,rev) VALUES(?,?,'sop',?,?,1)", [id, p.code.trim(), p.operation_id, p.title.trim()]);
        newRevision(db, e, p, 1);
        return;
      }
      invariant(old && !old.archived && old.kind === "sop", "\u0421\u041E\u041F \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D");
      if (e.operation === "archive") {
        invariant(p === null && !one(db, "SELECT id FROM document_revision WHERE document_id=? AND state NOT IN ('superseded','withdrawn')", [id]), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0432\u0435\u0434\u0438\u0442\u0435 \u0432\u0435\u0440\u0441\u0438\u0438 \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F");
        db.run("UPDATE document SET archived=1,rev=rev+1 WHERE id=?", [id]);
        return;
      }
      invariant(e.operation === "update" && obj(p), "\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441 \u0421\u041E\u041F");
      if (p.command === "passport") {
        exact4(p, ["command", "revision_id", "print_format", "changed_on"]);
        const v2 = revision(db, p.revision_id, id);
        invariant(v2.state === "draft", "\u041F\u0430\u0441\u043F\u043E\u0440\u0442 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0443 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430");
        invariant(["portrait", "landscape"].includes(p.print_format) && validDate(p.changed_on) && p.changed_on <= e.occurred_at.slice(0, 10), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u043E\u0440\u043C\u0430\u0442 \u0438 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
        const steps = rows(db, "SELECT * FROM document_step WHERE revision_id=?", [v2.id]);
        invariant(steps.length <= (p.print_format === "portrait" ? 9 : 12), "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0448\u0430\u0433\u043E\u0432 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u04103");
        const op = old.operation_id ? one(db, "SELECT * FROM operation WHERE id=? AND archived=0", [old.operation_id]) : null;
        const w = op?.workplace_id ? one(db, "SELECT * FROM workplace WHERE id=? AND archived=0", [op.workplace_id]) : null;
        const equipment = op?.equipment_id ? one(db, "SELECT * FROM equipment WHERE id=?", [op.equipment_id]) : null;
        db.run("UPDATE document_revision SET print_format=?,changed_on=?,review_due=?,workplace_id=?,workplace_name=?,equipment_name=? WHERE id=?", [p.print_format, p.changed_on, reviewDue(p.changed_on), w?.id || null, w?.name || null, equipment?.name || null, v2.id]);
        db.run("UPDATE document SET rev=rev+1 WHERE id=?", [id]);
        return;
      }
      if (p.command === "origin") {
        exact4(p, ["command", "revision_id", "study_id", "source_sha256"]);
        const v2 = revision(db, p.revision_id, id);
        invariant(v2.state === "draft", "\u0421\u0432\u044F\u0437\u044C \u0424\u0420\u0412 \u0437\u0430\u0434\u0430\u0451\u0442\u0441\u044F \u0443 \u043D\u043E\u0432\u043E\u0433\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430");
        const f = one(db, "SELECT * FROM frv_study WHERE id=?", [p.study_id]);
        invariant(f && f.state !== "archived" && f.operation_id === old.operation_id && JSON.parse(f.context_json).source.sha256 === p.source_sha256, "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C \u0438\u043B\u0438 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
        invariant(!one(db, "SELECT revision_id FROM sop_frv_origin WHERE revision_id=?", [v2.id]), "\u0421\u0432\u044F\u0437\u044C \u0441 \u0424\u0420\u0412 \u0443\u0436\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430");
        db.run("INSERT INTO sop_frv_origin VALUES(?,?,?,?)", [v2.id, f.id, p.source_sha256, e.occurred_at]);
        db.run("UPDATE document SET rev=rev+1 WHERE id=?", [id]);
        return;
      }
      if (p.command === "save" || p.command === "revise") {
        exact4(p, ["command", "revision_id", "title", "operation_id", "source", "projection"]);
        operation(db, p.operation_id);
        const payload = sourcePayload(p, "sop");
        if (p.command === "save") {
          const v2 = revision(db, p.revision_id, id);
          invariant(v2.state === "draft", "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A");
          db.run("UPDATE document_revision SET payload_json=?,print_format=NULL,changed_on=NULL,review_due=NULL,workplace_id=NULL,workplace_name=NULL,equipment_name=NULL WHERE id=?", [payload, v2.id]);
          docSteps(db, v2.id, p);
          link(db, p.source, "document_revision", v2.id);
        } else {
          invariant(p.revision_id === null && !openRevision(db, id), "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E");
          const version = one(db, "SELECT max(version_no) n FROM document_revision WHERE document_id=?", [id]).n + 1;
          newRevision(db, e, p, version);
        }
        invariant(old.operation_id === p.operation_id || !one(db, "SELECT id FROM document_revision WHERE document_id=? AND state IN ('approved','effective','superseded','withdrawn')", [id]), "\u0421\u0432\u044F\u0437\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u043E\u0432\u0430\u0432\u0448\u0435\u0433\u043E \u0421\u041E\u041F \u0441 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0435\u0439 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
        db.run("UPDATE document SET title=?,operation_id=?,rev=rev+1 WHERE id=?", [p.title.trim(), p.operation_id, id]);
        return;
      }
      exact4(p, ["command", "revision_id", "actor_id", "note"]);
      const v = revision(db, p.revision_id, id);
      invariant(string(p.note, 2e3), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u043F\u0440\u0438\u043C\u0435\u0447\u0430\u043D\u0438\u0435");
      active2(db, "person", p.actor_id);
      const transitions = { submit: ["draft", "review"], return: ["review", "draft"], approve: ["review", "approved"], effect: ["approved", "effective"], withdraw: ["effective", "withdrawn"] };
      const tr = Object.hasOwn(transitions, p.command) && transitions[p.command];
      invariant(tr && v.state === tr[0], "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u043F\u0435\u0440\u0435\u0445\u043E\u0434 \u0441\u0442\u0430\u0442\u0443\u0441\u0430");
      if (["submit", "approve", "effect"].includes(p.command)) {
        active2(db, "operation", old.operation_id);
        const steps = rows(db, "SELECT action_text FROM document_step WHERE revision_id=?", [v.id]);
        invariant(steps.length && steps.every((s) => s.action_text.trim()), "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0432\u0441\u0435\u0445 \u0448\u0430\u0433\u043E\u0432");
        invariant(v.print_format && v.changed_on && v.review_due, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043F\u0430\u0441\u043F\u043E\u0440\u0442: \u0444\u043E\u0440\u043C\u0430\u0442 \u04103 \u0438 \u0434\u0430\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
        invariant(steps.length <= (v.print_format === "portrait" ? 9 : 12), "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0448\u0430\u0433\u043E\u0432 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u0444\u043E\u0440\u043C\u0430\u0442 \u04103");
        invariant(v.workplace_id && one(db, "SELECT workplace_id FROM operation WHERE id=?", [old.operation_id])?.workplace_id === v.workplace_id, "\u041F\u0430\u0441\u043F\u043E\u0440\u0442: \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
        if (p.command !== "submit") {
          const src = JSON.parse(v.payload_json).projection;
          invariant(src.steps.every((s) => s.seconds > 0 && s.key_points.some((k) => k.trim()) && s.reason.trim() && s.photo), "\u041F\u0435\u0440\u0435\u0434 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435\u043C \u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0432\u0440\u0435\u043C\u044F, \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B, \u043F\u0440\u0438\u0447\u0438\u043D\u044B \u0438 \u0432\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044E \u0432\u0441\u0435\u0445 \u0448\u0430\u0433\u043E\u0432");
        }
      }
      if (p.command === "return" || p.command === "withdraw") invariant(p.note.trim(), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043F\u0440\u0438\u0447\u0438\u043D\u0443");
      if (p.command === "effect") {
        db.run("UPDATE document_revision SET state='superseded' WHERE document_id=? AND state='effective'", [id]);
        db.run("UPDATE document_revision SET state='effective',effective_at=? WHERE id=?", [e.occurred_at, v.id]);
      } else db.run("UPDATE document_revision SET state=? WHERE id=?", [tr[1], v.id]);
      if (p.command === "approve" || p.command === "return") db.run("INSERT INTO document_approval(id,revision_id,actor_id,decision,decided_at,note) VALUES(?,?,?,?,?,?)", [e.id, v.id, p.actor_id, p.command === "approve" ? "approved" : "returned", e.occurred_at, p.note]);
      db.run("UPDATE document SET rev=rev+1 WHERE id=?", [id]);
      return;
    }
    invariant(e.entity_type === "frv_study", "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435");
    if (e.operation === "archive") {
      invariant(old && old.state !== "archived" && p === null, "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E");
      db.run("UPDATE frv_study SET state='archived',rev=rev+1 WHERE id=?", [id]);
      return;
    }
    if (e.operation === "update" && p?.command === "finalize") {
      exact4(p, ["command", "actor_id", "note"]);
      active2(db, "person", p.actor_id);
      invariant(old?.state === "draft" && string(p.note, 2e3), "\u0424\u0438\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430");
      active2(db, "operation", old.operation_id);
      invariant(JSON.parse(old.context_json).projection.complete > 0, "\u041D\u0435\u0442 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u043D\u043E\u0433\u043E \u0446\u0438\u043A\u043B\u0430");
      db.run("UPDATE frv_study SET state='final',rev=rev+1 WHERE id=?", [id]);
      return;
    }
    exact4(p, ["command", "title", "operation_id", "observed_at", "source", "projection"]);
    invariant(date2(p.observed_at), "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0434\u0430\u0442\u0443 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F");
    operation(db, p.operation_id);
    const context = sourcePayload(p, "frv");
    invariant(e.operation === "create" ? !old && p.command === "create" : old?.state === "draft" && p.command === "save", "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0424\u0420\u0412");
    if (!old) db.run("INSERT INTO frv_study(id,operation_id,title,observed_at,state,context_json,rev) VALUES(?,?,?,?,'draft',?,1)", [id, p.operation_id, p.title.trim(), p.observed_at, context]);
    else db.run("UPDATE frv_study SET operation_id=?,title=?,observed_at=?,context_json=?,rev=rev+1 WHERE id=?", [p.operation_id, p.title.trim(), p.observed_at, context, id]);
    db.run("DELETE FROM frv_measurement WHERE study_id=?", [id]);
    invariant(Array.isArray(p.projection.measurements) && p.projection.measurements.length <= 5e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F");
    for (const [i, m] of p.projection.measurements.entries()) {
      invariant(nonempty(m.action, 2e4) && types.has(m.category) && num(m.seconds), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0435");
      db.run("INSERT INTO frv_measurement(id,study_id,position,activity,category,duration_seconds,raw_json) VALUES(?,?,?,?,?,?,?)", [id + ":" + (i + 1), id, i + 1, m.action, m.category, m.seconds, canonical(m)]);
    }
    link(db, p.source, "frv_study", id);
  }

  // src/core/db.js
  var SCHEMA_VERSION = 10;
  var migration3 = null;
  var migration4 = null;
  var migration5 = null;
  var migration6 = null;
  var migration7 = null;
  var migration8 = null;
  var migration9 = null;
  var migration10 = null;
  function configureMigrations(sql, next, last, assessment, training, forms, methods, matrix) {
    invariant(typeof sql === "string" && sql.includes("PRAGMA user_version=3") && typeof next === "string" && next.includes("PRAGMA user_version=4") && typeof last === "string" && last.includes("PRAGMA user_version=5"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0439 LC2/LC3");
    migration3 = sql;
    migration4 = next;
    migration5 = last;
    invariant(typeof assessment === "string" && assessment.includes("PRAGMA user_version=6"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430");
    migration6 = assessment;
    invariant(typeof training === "string" && training.includes("PRAGMA user_version=7"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 LC4");
    migration7 = training;
    invariant(typeof forms === "string" && forms.includes("PRAGMA user_version=8"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 LC4.1");
    migration8 = forms;
    invariant(typeof methods === "string" && methods.includes("PRAGMA user_version=9"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 LC4.2");
    migration9 = methods;
    invariant(typeof matrix === "string" && matrix.includes("PRAGMA user_version=10"), "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 LC4.3");
    migration10 = matrix;
  }
  var MAX_DB = 100 * 1024 * 1024;
  var MAX_PACKAGE = 5 * 1024 * 1024;
  var uuid = () => crypto.randomUUID();
  var now = () => (/* @__PURE__ */ new Date()).toISOString();
  var isId = (x) => typeof x === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x);
  var invariant = (ok, msg) => {
    if (!ok) throw new Error(msg);
  };
  var canonical = (x) => x === null || typeof x !== "object" ? JSON.stringify(x) : Array.isArray(x) ? "[" + x.map(canonical).join(",") + "]" : "{" + Object.keys(x).sort().map((k) => JSON.stringify(k) + ":" + canonical(x[k])).join(",") + "}";
  async function sha256(data) {
    const b = typeof data === "string" ? new TextEncoder().encode(data) : data;
    return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", b)), (x) => x.toString(16).padStart(2, "0")).join("");
  }
  function encode(bytes) {
    let s = "";
    for (let i = 0; i < bytes.length; i += 16384) s += String.fromCharCode(...bytes.subarray(i, i + 16384));
    return btoa(s);
  }
  function decode(s) {
    invariant(typeof s === "string" && s.length <= MAX_DB * 1.4, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0444\u0430\u0439\u043B \u0431\u0430\u0437\u044B");
    return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  }
  function rows(db, sql, args = []) {
    const st = db.prepare(sql);
    try {
      st.bind(args);
      const result = [];
      while (st.step()) result.push(st.getAsObject());
      return result;
    } finally {
      st.free();
    }
  }
  var one = (db, sql, args = []) => rows(db, sql, args)[0] || null;
  var meta = (db, key3) => one(db, "SELECT value FROM meta WHERE key=?", [key3])?.value || null;
  var setMeta = (db, key3, value) => db.run("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", [key3, value]);
  function tx(db, fn) {
    db.run("BEGIN IMMEDIATE");
    try {
      const value = fn();
      db.run("COMMIT");
      return value;
    } catch (e) {
      db.run("ROLLBACK");
      throw e;
    }
  }
  function bytesOf(db) {
    const bytes = db.export();
    db.run("PRAGMA foreign_keys=ON");
    return bytes;
  }
  function verifyDb(db, version = SCHEMA_VERSION) {
    invariant(one(db, "PRAGMA integrity_check")?.integrity_check === "ok", "\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u0430 \u0446\u0435\u043B\u043E\u0441\u0442\u043D\u043E\u0441\u0442\u044C SQLite");
    invariant(rows(db, "PRAGMA foreign_key_check").length === 0, "\u041D\u0430\u0440\u0443\u0448\u0435\u043D\u044B \u0441\u0432\u044F\u0437\u0438 \u0431\u0430\u0437\u044B");
    invariant(Number(meta(db, "schema_version")) === version && one(db, "PRAGMA user_version").user_version === version, "\u0412\u0435\u0440\u0441\u0438\u044F \u0431\u0430\u0437\u044B \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F");
    invariant(isId(meta(db, "database_id")), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 ID \u0431\u0430\u0437\u044B");
    const p = meta(db, "publication_id");
    invariant(!p || one(db, "SELECT id FROM publication WHERE id=?", [p]), "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438");
  }
  function upgradeDb(db) {
    const version = Number(meta(db, "schema_version"));
    invariant([2, 3, 4, 5, 6, 7, 8, 9, SCHEMA_VERSION].includes(version), "\u0412\u0435\u0440\u0441\u0438\u044F \u0431\u0430\u0437\u044B \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F: " + version);
    verifyDb(db, version);
    if (version === 2) {
      invariant(migration3, "\u041C\u0438\u0433\u0440\u0430\u0446\u0438\u044F LC2 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0430");
      invariant(!one(db, "SELECT person_id FROM person_role LIMIT 1"), "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u0440\u043E\u043B\u0438 legacy v1/v2. \u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u044F\u0432\u043D\u043E\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u0435\u0440\u0435\u0434 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0435\u0439; \u0438\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430.");
      db.run(migration3);
      verifyDb(db, 3);
    }
    if (version < 4) {
      invariant(migration4, "\u041D\u0435\u0442 \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u0438 LC3");
      invariant(!one(db, "SELECT id FROM document LIMIT 1") && !one(db, "SELECT id FROM frv_study LIMIT 1"), "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u0440\u0430\u043D\u0435\u0435 \u043D\u0435 \u0438\u043D\u0442\u0435\u0433\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/\u0424\u0420\u0412; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u043C\u0438\u0433\u0440\u0430\u0446\u0438\u044F");
      db.run(migration4);
      verifyDb(db, 4);
    }
    if (version < 5) {
      db.run(migration5);
      verifyDb(db, 5);
    }
    if (version < 6) {
      db.run(migration6);
      verifyDb(db, 6);
    }
    if (version < 7) {
      db.run(migration7);
      verifyDb(db, 7);
    }
    if (version < 8) {
      db.run(migration8);
      verifyDb(db, 8);
    }
    if (version < 9) {
      db.run(migration9);
      verifyDb(db, 9);
    }
    if (version < 10) {
      db.run(migration10);
      verifyDb(db);
    }
    return db;
  }
  function openDb(SQL2, bytes, { upgrade = true } = {}) {
    invariant(bytes instanceof Uint8Array && bytes.length > 100 && bytes.length <= MAX_DB, "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u0440\u0430\u0437\u043C\u0435\u0440 \u0431\u0430\u0437\u044B");
    const d = new SQL2.Database(bytes);
    try {
      d.run("PRAGMA foreign_keys=ON");
      if (upgrade) upgradeDb(d);
      else verifyDb(d, Number(meta(d, "schema_version")));
      return d;
    } catch (e) {
      d.close();
      throw e;
    }
  }
  function createDb(SQL2, schema, migration, id = uuid()) {
    const d = new SQL2.Database();
    try {
      d.run(schema);
      d.run(migration);
      setMeta(d, "database_id", id);
      return upgradeDb(d);
    } catch (e) {
      d.close();
      throw e;
    }
  }
  var definitions = {
    org_unit: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, kind: { label: "\u0422\u0438\u043F", options: ["\u041F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", "\u0426\u0435\u0445", "\u0423\u0447\u0430\u0441\u0442\u043E\u043A", "\u0421\u043B\u0443\u0436\u0431\u0430", "\u0413\u0440\u0443\u043F\u043F\u0430"], required: true }, parent_id: { label: "\u0420\u043E\u0434\u0438\u0442\u0435\u043B\u044C", ref: "org_unit" } } },
    person: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438", fields: { employee_code: { label: "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440", required: true }, display_name: { label: "\u0424\u0418\u041E / \u0438\u043C\u044F", required: true } } },
    profession: { label: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    equipment: { label: "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    workplace: { label: "\u0420\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u0435\u0441\u0442\u0430", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    operation: { label: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u0438", fields: { unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, equipment_id: { label: "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", ref: "equipment" }, workplace_id: { label: "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E", ref: "workplace" }, code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, criticality: { label: "\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u043E\u0441\u0442\u044C", options: ["normal", "important", "critical"], required: true } } },
    position: { label: "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    work_shift: { label: "\u0421\u043C\u0435\u043D\u044B", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    business_role: { label: "\u0420\u043E\u043B\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", fields: { code: { label: "\u041A\u043E\u0434", required: true }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    person_assignment: { label: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", history: true, fields: { person_id: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ref: "person", required: true }, unit_id: { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", ref: "org_unit", required: true }, profession_id: { label: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", ref: "profession" }, position_id: { label: "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", ref: "position" }, shift_id: { label: "\u0421\u043C\u0435\u043D\u0430", ref: "work_shift" }, shift_code: { label: "\u041A\u043E\u0434 \u0441\u043C\u0435\u043D\u044B LC1", legacy: true }, valid_from: { label: "\u041D\u0430\u0447\u0430\u043B\u043E", date: true, required: true }, valid_to: { label: "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", date: true } } },
    role_assignment: { label: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0440\u043E\u043B\u0435\u0439", history: true, fields: { person_id: { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ref: "person", required: true }, role_id: { label: "\u0420\u043E\u043B\u044C", ref: "business_role", required: true }, valid_from: { label: "\u041D\u0430\u0447\u0430\u043B\u043E", date: true, required: true }, valid_to: { label: "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", date: true } } },
    skill_category: { label: "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043D\u0430\u0432\u044B\u043A\u043E\u0432", fields: { name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    skill: { label: "\u041D\u0430\u0432\u044B\u043A\u0438", fields: { category_id: { label: "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F", ref: "skill_category", required: true }, operation_id: { label: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", ref: "operation" }, name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true } } },
    rating_scale: { label: "\u0428\u043A\u0430\u043B\u044B \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u043D\u0438\u044F", immutable: true, fields: { name: { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true }, version_no: { label: "\u0412\u0435\u0440\u0441\u0438\u044F", required: true, integer: true }, levels: { label: "\u0423\u0440\u043E\u0432\u043D\u0438 (\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435)", required: true, multiline: true, virtual: true } } }
  };
  var legacyTypes = /* @__PURE__ */ new Set(["org_unit", "person", "profession", "equipment", "operation", "person_assignment"]);
  var foldKey = (x) => String(x ?? "").normalize("NFKC").trim().toLocaleLowerCase("ru-RU");
  function parseLevels(text4) {
    invariant(typeof text4 === "string" && text4.length <= 5e3, "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u0435\u0439");
    const lines = text4.split(/\r?\n/).filter((x) => x.trim());
    invariant(lines.length >= 2 && lines.length <= 20, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0442 2 \u0434\u043E 20 \u0443\u0440\u043E\u0432\u043D\u0435\u0439");
    const levels = lines.map((line) => {
      const m = line.match(/^\s*(-?\d+)\s*:\s*(\S.*)$/);
      invariant(m, "\u041A\u0430\u0436\u0434\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C: \u0447\u0438\u0441\u043B\u043E: \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435");
      const value = Number(m[1]), label = m[2].trim();
      invariant(Number.isSafeInteger(value) && value >= 0 && value <= 1e3 && label.length <= 200, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C");
      return { value, label };
    });
    invariant(new Set(levels.map((x) => x.value)).size === levels.length, "\u041F\u043E\u0432\u0442\u043E\u0440 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0443\u0440\u043E\u0432\u043D\u044F");
    return levels.sort((a, b) => a.value - b.value);
  }
  function recordPayload(type, record) {
    const d = definitions[type];
    return Object.fromEntries(Object.entries(d.fields).map(([k, f]) => [k, record[k] == null ? null : String(record[k])]));
  }
  function list(db, type) {
    invariant(Object.hasOwn(definitions, type), "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A");
    const result = rows(db, "SELECT * FROM " + type + " ORDER BY " + (type === "person" ? "display_name" : definitions[type].history ? "valid_from DESC" : type === "rating_scale" ? "name,version_no" : "name"));
    if (type === "rating_scale") for (const v of result) v.levels = rows(db, "SELECT value,label FROM rating_level WHERE scale_id=? ORDER BY value", [v.id]).map((x) => x.value + ": " + x.label).join("\n");
    return result;
  }
  function identityKey(type, v) {
    if (type === "person") return foldKey(v.employee_code);
    if (type === "person_assignment") return [v.person_id, v.valid_from].join("|");
    if (type === "role_assignment") return [v.person_id, v.role_id, v.valid_from].join("|");
    if (type === "skill_category") return foldKey(v.name);
    if (type === "skill") return [v.category_id, foldKey(v.name)].join("|");
    if (type === "rating_scale") return [foldKey(v.name), Number(v.version_no)].join("|");
    if (["equipment", "operation", "workplace"].includes(type)) return [v.unit_id, foldKey(v.code)].join("|");
    return foldKey(v.code);
  }
  function normalize(db, type, p, id, old) {
    const def = definitions[type];
    invariant(def && p && typeof p === "object" && !Array.isArray(p), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u0438\u043F \u0437\u0430\u043F\u0438\u0441\u0438");
    const legacy = type === "person_assignment" && !Object.hasOwn(p, "position_id") && !Object.hasOwn(p, "shift_id");
    if (legacy) p = { ...p, position_id: old?.position_id ?? null, shift_id: old?.shift_id ?? null };
    if (type === "operation" && !Object.hasOwn(p, "workplace_id")) p = { ...p, workplace_id: old?.workplace_id ?? null };
    invariant(Object.keys(p).length === Object.keys(def.fields).length && Object.keys(p).every((k) => Object.hasOwn(def.fields, k)), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043F\u043E\u043B\u044F \u0437\u0430\u043F\u0438\u0441\u0438");
    const v = {};
    for (const [k, f] of Object.entries(def.fields)) {
      let x = p[k];
      invariant(x === null || typeof x === "string", "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: " + f.label);
      x = typeof x === "string" ? x.trim() : null;
      if (!x) x = null;
      invariant(!f.required || x !== null, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435: " + f.label);
      if (x !== null) {
        invariant(x.length <= (f.multiline ? 5e3 : 500), "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0434\u043B\u0438\u043D\u043D\u043E\u0435 \u043F\u043E\u043B\u0435");
        if (f.integer) invariant(/^\d+$/.test(x) && Number.isSafeInteger(Number(x)) && Number(x) > 0 && Number(x) <= 1e5, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0432\u0435\u0440\u0441\u0438\u0438");
        if (f.options) invariant(f.options.includes(x), "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: " + f.label);
        if (f.date) invariant(/^\d{4}-\d{2}-\d{2}$/.test(x) && !isNaN(Date.parse(x)) && new Date(x).toISOString().slice(0, 10) === x, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0434\u0430\u0442\u0430");
        if (f.ref) {
          invariant(isId(x), "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440");
          const ref = one(db, "SELECT * FROM " + f.ref + " WHERE id=?", [x]);
          invariant(ref && (!ref.archived || old?.[k] === x), "\u0421\u0441\u044B\u043B\u043A\u0430 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430: " + f.label);
        }
      }
      v[k] = x;
    }
    if (type === "org_unit") {
      let x = v.parent_id;
      const seen = /* @__PURE__ */ new Set([id]);
      while (x) {
        invariant(!seen.has(x), "\u0426\u0438\u043A\u043B \u0432 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0435");
        seen.add(x);
        x = one(db, "SELECT parent_id FROM org_unit WHERE id=?", [x])?.parent_id;
      }
    }
    if (type === "operation" && v.equipment_id) invariant(one(db, "SELECT unit_id FROM equipment WHERE id=?", [v.equipment_id])?.unit_id === v.unit_id, "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F");
    if (type === "operation" && v.workplace_id) invariant(one(db, "SELECT unit_id FROM workplace WHERE id=?", [v.workplace_id])?.unit_id === v.unit_id, "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F");
    if (type === "operation" && old && (v.workplace_id !== old.workplace_id || v.unit_id !== old.unit_id || v.equipment_id !== old.equipment_id)) invariant(!one(db, "SELECT r.id FROM document_revision r JOIN document d ON d.id=r.document_id WHERE d.operation_id=? AND r.state IN ('review','approved','effective','superseded','withdrawn') LIMIT 1", [id]), "\u041D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0441 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u044B\u043C\u0438 \u0421\u041E\u041F; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E");
    if (type === "workplace" && old && v.unit_id !== old.unit_id) invariant(!one(db, "SELECT id FROM operation WHERE workplace_id=? LIMIT 1", [id]), "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0441\u0432\u044F\u0437\u0430\u043D\u043E \u0441 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C\u0438");
    if (type === "equipment" && old && v.unit_id !== old.unit_id) invariant(!one(db, "SELECT id FROM operation WHERE equipment_id=? LIMIT 1", [id]), "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0442\u0438 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0441 \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u043C\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C\u0438");
    if (type === "person_assignment") {
      invariant(!v.valid_to || v.valid_to >= v.valid_from, "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 \u0440\u0430\u043D\u044C\u0448\u0435 \u043D\u0430\u0447\u0430\u043B\u0430");
      invariant(!v.shift_id || !v.shift_code, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043C\u0435\u043D\u0443 \u0438\u0437 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u043B\u0438\u0431\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043A\u043E\u0434, \u043D\u0435 \u043E\u0431\u0430");
      if (old) {
        for (const k of ["person_id", "unit_id", "profession_id", "position_id", "shift_id", "shift_code", "valid_from"]) invariant(old[k] === v[k], "\u0418\u0441\u0442\u043E\u0440\u0438\u044E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435");
        invariant(!old.valid_to || old.valid_to === v.valid_to, "\u0417\u0430\u043A\u0440\u044B\u0442\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u043E");
      }
      invariant(!one(db, "SELECT id FROM person_assignment WHERE person_id=? AND id<>? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? LIMIT 1", [v.person_id, id, v.valid_to || "9999-12-31", v.valid_from]), "\u041F\u0435\u0440\u0435\u0441\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
    }
    if (type === "role_assignment") {
      invariant(!v.valid_to || v.valid_to >= v.valid_from, "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 \u0440\u0430\u043D\u044C\u0448\u0435 \u043D\u0430\u0447\u0430\u043B\u0430");
      if (old) {
        for (const k of ["person_id", "role_id", "valid_from"]) invariant(old[k] === v[k], "\u0418\u0441\u0442\u043E\u0440\u0438\u044E \u0440\u043E\u043B\u0438 \u043D\u0435\u043B\u044C\u0437\u044F \u043C\u0435\u043D\u044F\u0442\u044C; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435");
        invariant(!old.valid_to || old.valid_to === v.valid_to, "\u0417\u0430\u043A\u0440\u044B\u0442\u0430\u044F \u0440\u043E\u043B\u044C \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430");
      }
      invariant(!one(db, "SELECT id FROM role_assignment WHERE person_id=? AND role_id=? AND id<>? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? LIMIT 1", [v.person_id, v.role_id, id, v.valid_to || "9999-12-31", v.valid_from]), "\u041F\u0435\u0440\u0435\u0441\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043E\u0434\u043D\u043E\u0439 \u0440\u043E\u043B\u0438");
    }
    if (type === "rating_scale") {
      invariant(!old, "\u0428\u043A\u0430\u043B\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430; \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E");
      parseLevels(v.levels);
    }
    const key3 = identityKey(type, v);
    if (!old || identityKey(type, old) !== key3) invariant(!list(db, type).some((x) => x.id !== id && identityKey(type, x) === key3), "\u0414\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u043A\u043B\u044E\u0447\u0430 / UNIQUE");
    return v;
  }
  function validateEvent(e) {
    invariant(e && Object.keys(e).every((k) => ["id", "entity_type", "entity_id", "operation", "expected_revision", "payload", "occurred_at"].includes(k)) && isId(e.id) && isId(e.entity_id) && (Object.hasOwn(definitions, e.entity_type) || Object.hasOwn(DOMAIN_TYPES, e.entity_type)) && ["create", "update", "archive"].includes(e.operation) && Number.isSafeInteger(e.expected_revision) && e.expected_revision >= 0 && typeof e.occurred_at === "string" && !isNaN(Date.parse(e.occurred_at)), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435");
  }
  function applyEvent(db, e, packageId = null) {
    validateEvent(e);
    const prev = one(db, "SELECT * FROM change_event WHERE id=?", [e.id]);
    if (prev) {
      invariant(prev.entity_type === e.entity_type && prev.entity_id === e.entity_id && prev.operation === e.operation && prev.expected_revision === e.expected_revision && prev.occurred_at === e.occurred_at && canonical(JSON.parse(prev.payload_json)) === canonical(e.payload), "\u041F\u043E\u0432\u0442\u043E\u0440 ID \u0441 \u0434\u0440\u0443\u0433\u0438\u043C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u044B\u043C");
      return false;
    }
    const t = e.entity_type, old = one(db, "SELECT * FROM " + t + " WHERE id=?", [e.entity_id]);
    invariant((old?.rev || 0) === e.expected_revision, "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0432\u0435\u0440\u0441\u0438\u0438: " + (definitions[t]?.label || DOMAIN_TYPES[t]) + " / " + e.entity_id + " (\u043E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C " + e.expected_revision + ", \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F " + (old?.rev || 0) + ")");
    if (Object.hasOwn(DOMAIN_TYPES, t)) applyDomainEvent(db, e, old);
    else if (e.operation === "create" || e.operation === "update") {
      invariant(e.operation === "create" ? !old : !!old && !old.archived, "\u041D\u0435\u043B\u044C\u0437\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u044D\u0442\u0443 \u0437\u0430\u043F\u0438\u0441\u044C");
      const p = normalize(db, t, e.payload, e.entity_id, old);
      const keys = Object.keys(p).filter((k) => !definitions[t].fields[k].virtual);
      const values = keys.map((k) => p[k]);
      if (!old) {
        db.run("INSERT INTO " + t + "(id," + keys.join(",") + ",rev) VALUES(" + Array(keys.length + 2).fill("?").join(",") + ")", [e.entity_id, ...values, 1]);
        if (t === "rating_scale") for (const l of parseLevels(p.levels)) db.run("INSERT INTO rating_level(scale_id,value,label) VALUES(?,?,?)", [e.entity_id, l.value, l.label]);
      } else db.run("UPDATE " + t + " SET " + keys.map((k) => k + "=?").join(",") + ",rev=rev+1 WHERE id=?", [...values, e.entity_id]);
    } else {
      invariant(old && !old.archived && !definitions[t].history && e.payload === null, "\u041D\u0435\u043B\u044C\u0437\u044F \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C");
      const date3 = e.occurred_at.slice(0, 10);
      const active4 = " AND (valid_to IS NULL OR valid_to>=?)";
      const deps = {
        org_unit: [["org_unit", "parent_id", false], ["equipment", "unit_id", false], ["workplace", "unit_id", false], ["operation", "unit_id", false], ["person_assignment", "unit_id", true]],
        person: [["person_assignment", "person_id", true], ["role_assignment", "person_id", true]],
        profession: [["person_assignment", "profession_id", true]],
        position: [["person_assignment", "position_id", true]],
        work_shift: [["person_assignment", "shift_id", true]],
        business_role: [["role_assignment", "role_id", true]],
        equipment: [["operation", "equipment_id", false]],
        workplace: [["operation", "workplace_id", false]],
        operation: [["skill", "operation_id", false]],
        skill_category: [["skill", "category_id", false]]
      };
      if (t === "person") invariant(!one(db, "SELECT id FROM training_assignment WHERE state IN('planned','in_progress') AND (trainee_id=? OR mentor_id=? OR supervisor_id=?) LIMIT 1", [e.entity_id, e.entity_id, e.entity_id]) && !one(db, "SELECT id FROM training_enrollment WHERE state='active' AND (trainee_id=? OR mentor_id=? OR manager_id=?) LIMIT 1", [e.entity_id, e.entity_id, e.entity_id]), "\u0417\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
      if (t === "skill" || t === "rating_scale") {
        const key3 = t === "skill" ? "skill_id" : "scale_id";
        invariant(!one(db, "SELECT id FROM training_assignment WHERE " + key3 + "=? AND state IN('planned','in_progress') LIMIT 1", [e.entity_id]) && !one(db, "SELECT id FROM role_requirement WHERE " + key3 + "=? AND coalesce(valid_to,'9999-12-31')>=? LIMIT 1", [e.entity_id, date3]) && !one(db, "SELECT id FROM coverage_requirement WHERE " + key3 + "=? LIMIT 1", [e.entity_id]), "\u0417\u0430\u043F\u0438\u0441\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F\u0445 \u0438\u043B\u0438 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0438");
      }
      if (t === "operation") invariant(!one(db, "SELECT id FROM document WHERE operation_id=? AND archived=0 LIMIT 1", [e.entity_id]) && !one(db, "SELECT id FROM frv_study WHERE operation_id=? AND state<>'archived' LIMIT 1", [e.entity_id]), "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441\u0432\u044F\u0437\u0430\u043D\u0430 \u0441 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u043C\u0438 \u0438\u043B\u0438 \u0424\u0420\u0412");
      for (const [table2, column, history] of deps[t] || []) invariant(!one(db, "SELECT id FROM " + table2 + " WHERE " + column + "=?" + (history ? active4 : " AND archived=0") + " LIMIT 1", history ? [e.entity_id, date3] : [e.entity_id]), "\u0417\u0430\u043F\u0438\u0441\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0441\u0432\u044F\u0437\u044F\u0445; \u0437\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u0443\u0439\u0442\u0435 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438");
      db.run("UPDATE " + t + " SET archived=1,rev=rev+1 WHERE id=?", [e.entity_id]);
    }
    db.run("INSERT INTO change_event(id,package_id,entity_type,entity_id,operation,expected_revision,payload_json,occurred_at) VALUES(?,?,?,?,?,?,?,?)", [e.id, packageId, t, e.entity_id, e.operation, e.expected_revision, canonical(e.payload), e.occurred_at]);
    return true;
  }
  async function makePackage(db, events, device) {
    invariant(events.length > 0 && events.length <= 2e3, "\u041D\u0435\u0442 \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u0438\u043B\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u043F\u0430\u043A\u0435\u0442\u0430");
    const body = { format: "lean-change-v1", id: uuid(), database_id: meta(db, "database_id"), base_publication_id: meta(db, "publication_id"), schema_version: SCHEMA_VERSION, device_id: device, created_at: now(), events: structuredClone(events) };
    const hash = await sha256(canonical(body));
    invariant(new TextEncoder().encode(canonical(body)).length < MAX_PACKAGE, "\u041F\u0430\u043A\u0435\u0442 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 5 \u041C\u0411");
    return { ...body, hash };
  }
  async function checkPackage(p) {
    invariant(p && typeof p === "object" && Object.keys(p).length === 9 && p.format === "lean-change-v1" && isId(p.id) && isId(p.database_id) && isId(p.device_id) && (p.base_publication_id === null || isId(p.base_publication_id)) && [2, 3, 4, 5, 6, 7, 8, 9, SCHEMA_VERSION].includes(p.schema_version) && typeof p.created_at === "string" && !isNaN(Date.parse(p.created_at)) && Array.isArray(p.events) && p.events.length > 0 && p.events.length <= 2e3, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043F\u0430\u043A\u0435\u0442");
    const { hash, ...body } = p;
    invariant(new TextEncoder().encode(canonical(body)).length < MAX_PACKAGE, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u043F\u0430\u043A\u0435\u0442");
    invariant(await sha256(canonical(body)) === hash, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 \u043F\u0430\u043A\u0435\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
    p.events.forEach((e) => {
      validateEvent(e);
      if (p.schema_version < 10) invariant(!isLC43Event(e), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC4.3");
      if (p.schema_version < 9) invariant(!isLC42Event(e), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC4.2");
      if (p.schema_version < 8) invariant(!isLC41Event(e), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC4.1");
      if (p.schema_version < 7) invariant(!isTrainingEvent(e), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC4");
      if (p.schema_version < 6) invariant(e.entity_type !== "sop_stage43_checklist", "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC3.5");
      if (p.schema_version < 4) invariant(!Object.hasOwn(DOMAIN_TYPES, e.entity_type), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC3");
      if (p.schema_version < 5) invariant(!["workplace", "checklist_version", "sop_evaluation"].includes(e.entity_type) && !(e.entity_type === "operation" && e.payload && Object.hasOwn(e.payload, "workplace_id")) && !(e.entity_type === "document" && ["passport", "origin"].includes(e.payload?.command)), "\u041F\u0430\u043A\u0435\u0442 \u0441\u0442\u0430\u0440\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 LC3.1");
      if (p.schema_version === 2) invariant(legacyTypes.has(e.entity_type) && (e.entity_type !== "person_assignment" || e.payload === null || !Object.hasOwn(e.payload, "position_id") && !Object.hasOwn(e.payload, "shift_id")), "\u041F\u0430\u043A\u0435\u0442 v2 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u043F\u043E\u043B\u044F LC2");
    });
    invariant(new Set(p.events.map((e) => e.id)).size === p.events.length, "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u0432 \u043F\u0430\u043A\u0435\u0442\u0435");
  }
  async function mergePackage(db, p, readContent3) {
    await checkPackage(p);
    invariant(p.database_id === meta(db, "database_id"), "\u041F\u0430\u043A\u0435\u0442 \u0434\u0440\u0443\u0433\u043E\u0439 \u0431\u0430\u0437\u044B");
    const known = one(db, "SELECT * FROM exchange_package WHERE id=?", [p.id]);
    if (known) {
      invariant(known.manifest_sha256 === p.hash, "\u041F\u043E\u0432\u0442\u043E\u0440 ID \u043F\u0430\u043A\u0435\u0442\u0430 \u0441 \u0438\u043D\u044B\u043C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u044B\u043C");
      return { duplicate: true, count: 0 };
    }
    invariant(!p.base_publication_id || one(db, "SELECT id FROM publication WHERE id=?", [p.base_publication_id]), "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F");
    await verifyDomainEvents(p.events, readContent3);
    return tx(db, () => {
      db.run("INSERT INTO exchange_package(id,base_publication_id,schema_version,database_id,device_id,created_at,state,manifest_sha256) VALUES(?,?,?,?,?,?,?,?)", [p.id, p.base_publication_id, p.schema_version, p.database_id, p.device_id, p.created_at, "applied", p.hash]);
      let count = 0;
      for (const e of p.events) if (applyEvent(db, e, p.id)) count++;
      return { duplicate: false, count };
    });
  }
  var Workspace = class {
    constructor(SQL2, base, { pending = [], device = uuid(), dirty = false } = {}) {
      this.SQL = SQL2;
      this.base = base;
      this.pending = structuredClone(pending);
      this.device = device;
      this.dirty = dirty;
      this.rebuild();
    }
    rebuild() {
      this.working?.close();
      this.working = openDb(this.SQL, bytesOf(this.base));
      this.conflicts = [];
      const remaining = [];
      for (const e of this.pending) {
        if (this.conflicts.length) {
          remaining.push(e);
          continue;
        }
        try {
          tx(this.working, () => applyEvent(this.working, e));
          if (!one(this.base, "SELECT id FROM change_event WHERE id=?", [e.id])) remaining.push(e);
        } catch (err) {
          remaining.push(e);
          this.conflicts.push({ event: e, error: err.message });
        }
      }
      this.pending = remaining;
    }
    edit(type, id, payload, operation2) {
      invariant(Object.hasOwn(definitions, type), "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0441\u0435\u0440\u0432\u0438\u0441 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430");
      invariant(!this.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439");
      invariant(this.pending.length < 2e3, "\u0414\u043E\u0441\u0442\u0438\u0433\u043D\u0443\u0442 \u043B\u0438\u043C\u0438\u0442 \u043E\u0447\u0435\u0440\u0435\u0434\u0438. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0439\u0442\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F.");
      const old = id ? one(this.working, "SELECT * FROM " + (Object.hasOwn(definitions, type) ? type : "invalid") + " WHERE id=?", [id]) : null;
      const e = { id: uuid(), entity_type: type, entity_id: id || uuid(), operation: operation2 || (old ? "update" : "create"), expected_revision: old?.rev || 0, payload, occurred_at: now() };
      tx(this.working, () => applyEvent(this.working, e));
      this.pending.push(e);
      return e.entity_id;
    }
    // Whole import is committed locally in one SQLite transaction, with checked revisions.
    applyBatch(events) {
      invariant(events.every((e) => Object.hasOwn(definitions, e.entity_type)), "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432");
      return this._applyBatch(events);
    }
    async applyContentEvents(events, readContent3) {
      await verifyDomainEvents(events, readContent3);
      return this._applyBatch(events);
    }
    _applyBatch(events) {
      invariant(!this.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B");
      invariant(Array.isArray(events) && events.length > 0 && this.pending.length + events.length <= 2e3, "\u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u043E\u0447\u0435\u0440\u0435\u0434\u0438 (2000)");
      invariant(new TextEncoder().encode(canonical([...this.pending, ...events])).length < MAX_PACKAGE - 4096, "\u041E\u0447\u0435\u0440\u0435\u0434\u044C \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043B\u0438\u043C\u0438\u0442 \u043F\u0430\u043A\u0435\u0442\u0430");
      tx(this.working, () => {
        for (const e of events) {
          invariant(applyEvent(this.working, e), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u0438\u043C\u043F\u043E\u0440\u0442\u0430");
        }
      });
      this.pending.push(...structuredClone(events));
      return events.length;
    }
    async package() {
      return makePackage(this.base, this.pending, this.device);
    }
    async accept(p, readContent3) {
      invariant(!this.pending.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0440\u0438\u043C\u0438\u0442\u0435 \u0438\u043B\u0438 \u044D\u043A\u0441\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u0438 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
      const r = await mergePackage(this.base, p, readContent3);
      if (!r.duplicate) this.dirty = true;
      this.rebuild();
      return r;
    }
    async acceptOwn(readContent3) {
      invariant(!this.conflicts.length, "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0442");
      if (!this.pending.length) return 0;
      const p = await this.package();
      const r = await mergePackage(this.base, p, readContent3);
      this.dirty = true;
      this.rebuild();
      return r.count;
    }
    discardPending() {
      this.pending = [];
      this.rebuild();
    }
    resolveConflict(choice) {
      invariant(this.conflicts.length === 1 && ["discard", "reapply"].includes(choice), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0430\u0435\u043C\u043E\u0433\u043E \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0430");
      const e = this.conflicts[0].event, i = this.pending.findIndex((x) => x.id === e.id);
      invariant(i >= 0, "\u0421\u043E\u0431\u044B\u0442\u0438\u0435 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442");
      if (choice === "discard") {
        this.pending.splice(i, 1);
        this.rebuild();
        return;
      }
      invariant(!Object.hasOwn(DOMAIN_TYPES, e.entity_type), "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430: \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u0432\u0440\u0443\u0447\u043D\u0443\u044E");
      const old = one(this.working, "SELECT * FROM " + e.entity_type + " WHERE id=?", [e.entity_id]);
      const next = { ...e, id: uuid(), expected_revision: old?.rev || 0, occurred_at: now() };
      invariant(e.operation === "create" ? !old : !!old && !old.archived, "\u0417\u0430\u043F\u0438\u0441\u044C \u0443\u0434\u0430\u043B\u0435\u043D\u0430, \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0438\u043B\u0438 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442; \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0440\u0443\u0447\u043D\u043E\u0435 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435");
      tx(this.working, () => applyEvent(this.working, next));
      this.pending.splice(i, 1, next);
      this.rebuild();
    }
    replaceBase(db) {
      try {
        invariant(meta(db, "database_id") === meta(this.base, "database_id"), "\u0414\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430");
        const current = meta(this.base, "publication_id");
        let p = meta(db, "publication_id"), found = !current;
        const seen = /* @__PURE__ */ new Set();
        while (p) {
          invariant(!seen.has(p), "\u0426\u0438\u043A\u043B \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
          seen.add(p);
          if (p === current) found = true;
          const row = one(db, "SELECT parent_id FROM publication WHERE id=?", [p]);
          invariant(row, "\u0420\u0430\u0437\u043E\u0440\u0432\u0430\u043D\u0430 \u0446\u0435\u043F\u043E\u0447\u043A\u0430 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
          p = row.parent_id;
        }
        invariant(found, "\u0421\u043D\u0438\u043C\u043E\u043A \u0443\u0441\u0442\u0430\u0440\u0435\u043B \u0438\u043B\u0438 \u0438\u043C\u0435\u0435\u0442 \u0434\u0440\u0443\u0433\u0443\u044E \u0432\u0435\u0442\u043A\u0443");
        if (this.dirty) {
          for (const e of rows(this.base, "SELECT * FROM change_event")) invariant(canonical(one(db, "SELECT * FROM change_event WHERE id=?", [e.id])) === canonical(e), "\u0415\u0441\u0442\u044C \u043D\u0435\u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
          for (const e of rows(this.base, "SELECT * FROM exchange_package")) invariant(canonical(one(db, "SELECT * FROM exchange_package WHERE id=?", [e.id])) === canonical(e), "\u0415\u0441\u0442\u044C \u043D\u0435\u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u0430\u043A\u0435\u0442\u044B");
        }
        const prev = this.base;
        this.base = db;
        this.dirty = false;
        this.rebuild();
        prev.close();
      } catch (e) {
        if (this.base !== db) db.close();
        throw e;
      }
    }
    state() {
      return { base: bytesOf(this.base), pending: structuredClone(this.pending), device: this.device, dirty: this.dirty };
    }
    close() {
      this.working.close();
      this.base.close();
    }
  };
  async function prepareSnapshot(ws2) {
    invariant(!ws2.pending.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0440\u0438\u043C\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
    const db = openDb(ws2.SQL, bytesOf(ws2.base));
    try {
      const descriptor = { format: "lean-snapshot-v1", id: uuid(), database_id: meta(db, "database_id"), parent_id: meta(db, "publication_id"), schema_version: SCHEMA_VERSION, created_at: now() };
      const descriptor_hash = await sha256(canonical(descriptor));
      db.run("INSERT INTO publication(id,parent_id,created_at,schema_version,manifest_sha256) VALUES(?,?,?,?,?)", [descriptor.id, descriptor.parent_id, descriptor.created_at, SCHEMA_VERSION, descriptor_hash]);
      setMeta(db, "publication_id", descriptor.id);
      verifyDb(db);
      const bytes = bytesOf(db);
      return { bytes, manifest: { ...descriptor, descriptor_hash, snapshot_sha256: await sha256(bytes), size: bytes.length } };
    } finally {
      db.close();
    }
  }
  async function readSnapshot(SQL2, manifest, bytes) {
    invariant(manifest && manifest.format === "lean-snapshot-v1" && isId(manifest.id) && isId(manifest.database_id) && (manifest.parent_id === null || isId(manifest.parent_id)) && [2, 3, 4, 5, 6, 7, 8, 9, SCHEMA_VERSION].includes(manifest.schema_version) && manifest.size === bytes.length && bytes.length <= MAX_DB, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442");
    const { descriptor_hash, snapshot_sha256, size, ...descriptor } = manifest;
    invariant(await sha256(canonical(descriptor)) === descriptor_hash && await sha256(bytes) === snapshot_sha256, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D \u0441\u043D\u0438\u043C\u043E\u043A");
    const db = openDb(SQL2, bytes, { upgrade: false });
    try {
      const p = one(db, "SELECT * FROM publication WHERE id=?", [manifest.id]);
      invariant(Number(meta(db, "schema_version")) === manifest.schema_version && p?.schema_version === manifest.schema_version && meta(db, "database_id") === manifest.database_id && meta(db, "publication_id") === manifest.id && p?.manifest_sha256 === descriptor_hash && p.parent_id === manifest.parent_id, "\u0421\u043D\u0438\u043C\u043E\u043A \u0438 \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442");
      return upgradeDb(db);
    } catch (e) {
      db.close();
      throw e;
    }
  }
  async function backup(ws2) {
    const s = ws2.state();
    const body = { format: "lean-backup-v1", base: encode(s.base), pending: s.pending, device: s.device, dirty: s.dirty };
    return { ...body, hash: await sha256(canonical(body)) };
  }
  async function restore(SQL2, obj2, readContent3) {
    const { hash, ...body } = obj2;
    invariant(body.format === "lean-backup-v1" && Array.isArray(body.pending) && body.pending.length <= 2e3 && isId(body.device) && typeof body.dirty === "boolean" && await sha256(canonical(body)) === hash, "\u0420\u0435\u0437\u0435\u0440\u0432\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0435\u043D\u0430");
    body.pending.forEach(validateEvent);
    await verifyDomainEvents(body.pending, readContent3);
    return new Workspace(SQL2, openDb(SQL2, decode(body.base)), body);
  }

  // src/modules/master-data/employee-records.js
  var parse = (s) => {
    try {
      return JSON.parse(s || "{}");
    } catch {
      return {};
    }
  };
  var names2 = { trainee_id: "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", mentor_id: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 / \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", supervisor_id: "\u0420\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C", assigned_by: "\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u043B", person_id: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", evaluator_id: "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", actor_id: "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439", auditor_id: "\u0410\u0443\u0434\u0438\u0442\u043E\u0440", author_id: "\u0410\u0432\u0442\u043E\u0440", created_by: "\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u043B", approved_by: "\u0423\u0442\u0432\u0435\u0440\u0434\u0438\u043B", registered_by: "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043B", manager_id: "\u0420\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C", finished_by: "\u0417\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435", witness_id: "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C", responsible_id: "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439", head_id: "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043B", owner_id: "\u0418\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C", verifier_id: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0449\u0438\u0439" };
  var roles2 = (r, id, fields) => fields.filter((k) => r[k] === id).map((k) => names2[k] || k).join(" \xB7 ");
  var link2 = (page2, options) => ({ page: page2, options });
  var item = (r, title, role, date3, state, dest = null, extra = "") => ({ id: r.id, title, role, date: date3 || "", state: state || "", dest, extra });
  var docLink = (id, rev) => link2("sop", { documentId: id, revisionId: rev });
  var goAssignment = (r, tab) => r.assignment_id ? link2("twi", { id: r.assignment_id, tab }) : null;
  function employeeRelations(db, id) {
    const groups = { matrices: [], training: [], assessments: [], mentoring: [], documents: [], development: [], history: [] };
    const query2 = (sql) => rows(db, sql, [id]);
    const revision2 = (rid) => one(db, "SELECT d.id document_id,d.code,d.title,r.version_no FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.id=?", [rid]);
    const revLabel = (rid) => {
      const r = rid && revision2(rid);
      return r ? r.code + " \xB7 " + r.title + " \xB7 v" + r.version_no : "\u2014";
    };
    const ref = (t, id2) => id2 ? one(db, "SELECT * FROM " + t + " WHERE id=?", [id2])?.name || "\u2014" : "\u2014";
    const person2 = (id2) => id2 ? one(db, "SELECT display_name FROM person WHERE id=?", [id2])?.display_name || "\u2014" : "\u2014";
    for (const r of query2("SELECT * FROM competency_matrix WHERE author_id=?1 OR EXISTS(SELECT 1 FROM json_each(roster_json) WHERE json_extract(value,'$.person_id')=?1) ORDER BY code,version_no DESC")) {
      const member = parse(r.roster_json).some((x) => x.person_id === id);
      groups.matrices.push(item(r, r.title + " \xB7 v" + r.version_no, [member ? "\u0423\u0447\u0430\u0441\u0442\u043D\u0438\u043A" : "", r.author_id === id ? "\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u043B" : ""].filter(Boolean).join(" \xB7 "), r.base_on, r.state, link2("skills", { matrixId: r.id, ...member ? { personId: id } : {} }), "\u0426\u0435\u043B\u044C: " + r.target_on));
    }
    for (const r of query2("SELECT * FROM training_assignment WHERE trainee_id=?1 OR mentor_id=?1 OR supervisor_id=?1 OR assigned_by=?1 OR json_extract(approval_json,'$.responsible_id')=?1 OR json_extract(approval_json,'$.head_id')=?1 ORDER BY assigned_on DESC,id")) {
      const role = [roles2(r, id, ["trainee_id", "mentor_id", "supervisor_id", "assigned_by"]), roles2(parse(r.approval_json), id, ["responsible_id", "head_id"])].filter(Boolean).join(" \xB7 ");
      groups.training.push(item(r, revLabel(r.sop_revision_id), role, r.assigned_on, r.state, r.source_sha256 ? link2("twi", { id: r.id }) : null, "\u0421\u0440\u043E\u043A: " + (r.due_on || "\u2014") + " \xB7 \u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439: " + person2(r.trainee_id) + " \xB7 \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440: " + person2(r.mentor_id)));
    }
    for (const r of query2("SELECT e.*,p.title,p.kind,p.version_no FROM training_enrollment e JOIN training_program p ON p.id=e.program_id WHERE e.trainee_id=?1 OR e.mentor_id=?1 OR e.manager_id=?1 OR e.finished_by=?1 OR EXISTS(SELECT 1 FROM training_task_result t WHERE t.enrollment_id=e.id AND t.actor_id=?1) ORDER BY e.start_on DESC")) {
      let role = roles2(r, id, ["trainee_id", "mentor_id", "manager_id", "finished_by"]);
      if (!role) role = "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0437\u0430 \u0437\u0430\u0434\u0430\u043D\u0438\u0435";
      groups.training.push(item(r, r.title + " \xB7 v" + r.version_no, role, r.start_on, r.state, link2(r.kind === "internship" ? "internship" : "programs", { enrollmentId: r.id }), "\u0421\u0440\u043E\u043A: " + r.due_on));
    }
    for (const r of query2("SELECT * FROM training_program WHERE created_by=?1 ORDER BY created_at DESC")) groups.training.push(item(r, r.title + " \xB7 v" + r.version_no, "\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u043B \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", r.created_at, r.state, link2(r.kind === "internship" ? "internship" : "programs", { programId: r.id })));
    for (const r of query2("SELECT s.*,a.trainee_id,a.sop_revision_id FROM training_session s JOIN training_assignment a ON a.id=s.assignment_id WHERE s.mentor_id=?1 OR s.witness_id=?1 OR a.trainee_id=?1 ORDER BY s.held_at DESC")) {
      const step = parse(r.steps_json).label || r.stage_code || "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436";
      groups.training.push(item(r, step + " \xB7 " + revLabel(r.sop_revision_id), roles2(r, id, ["trainee_id", "mentor_id", "witness_id"]), r.held_at, r.result, goAssignment(r, "instruction"), r.duration_minutes == null ? "" : r.duration_minutes + " \u043C\u0438\u043D"));
    }
    for (const r of query2("SELECT * FROM assessment_session WHERE person_id=?1 OR evaluator_id=?1 ORDER BY assessed_at DESC")) {
      const kind = r.assessment_kind === "practical" ? "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430" : r.assessment_kind === "qualification" ? "\u041E\u0446\u0435\u043D\u043A\u0430 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438" : "\u041E\u0446\u0435\u043D\u043A\u0430";
      const levels = rows(db, "SELECT i.level,i.observation_state,s.name FROM assessment_item i JOIN skill s ON s.id=i.skill_id WHERE i.session_id=?", [r.id]).map((x) => x.name + ": " + (x.level ?? x.observation_state)).join("; ");
      groups.assessments.push(item(r, kind + " \xB7 " + revLabel(r.standard_revision_id), roles2(r, id, ["person_id", "evaluator_id"]), r.assessed_at, r.state, goAssignment(r, "practice"), [levels, r.conclusion, r.feedback].filter(Boolean).join(" \xB7 ")));
    }
    for (const r of query2("SELECT v.*,a.trainee_id,a.sop_revision_id FROM training_verification v JOIN training_assignment a ON a.id=v.assignment_id WHERE a.trainee_id=?1 OR v.evaluator_id=?1 ORDER BY v.evaluated_on DESC")) groups.assessments.push(item(r, (r.kind === "safety" ? "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u041E\u0422" : "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0442\u0435\u043E\u0440\u0438\u0438") + " \xB7 " + revLabel(r.sop_revision_id), roles2(r, id, ["trainee_id", "evaluator_id"]), r.evaluated_on, r.result, goAssignment(r, "practice"), r.evidence));
    for (const r of query2("SELECT * FROM admission_decision WHERE person_id=?1 OR actor_id=?1 ORDER BY decided_on DESC")) groups.assessments.push(item(r, "\u0414\u043E\u043F\u0443\u0441\u043A \xB7 " + revLabel(r.revision_id), roles2(r, id, ["person_id", "actor_id"]), r.decided_on, r.revoked_at ? "revoked" : r.decision, goAssignment(r, "practice"), "\u0414\u043E: " + (r.valid_until || "\u2014") + " \xB7 " + r.evidence));
    for (const r of query2("SELECT * FROM mentor_credential WHERE person_id=?1 OR registered_by=?1 ORDER BY issued_on DESC")) groups.mentoring.push(item(r, (r.kind === "certificate" ? "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442" : "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E") + " \u2116 " + r.number, roles2(r, id, ["person_id", "registered_by"]), r.issued_on, r.revoked_at ? "revoked" : "registered", link2("certification", { id: r.id }), r.role + " \xB7 " + r.issuer));
    for (const r of query2("SELECT * FROM mentor_appointment WHERE person_id=?1 OR approved_by=?1 ORDER BY order_on DESC")) groups.mentoring.push(item(r, "\u041F\u0440\u0438\u043A\u0430\u0437 \u2116 " + r.order_number, roles2(r, id, ["person_id", "approved_by"]), r.order_on, r.revoked_at ? "revoked" : "registered", link2("appointments", { id: r.id }), person2(r.person_id) + " \xB7 " + r.role));
    for (const r of query2("SELECT * FROM mentor_order WHERE approved_by=?1 OR EXISTS(SELECT 1 FROM mentor_appointment a WHERE a.order_id=mentor_order.id AND a.person_id=?1) ORDER BY order_on DESC")) groups.mentoring.push(item(r, "\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 \u2116 " + r.order_number, r.approved_by === id ? "\u0423\u0442\u0432\u0435\u0440\u0434\u0438\u043B" : "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D \u043F\u0440\u0438\u043A\u0430\u0437\u043E\u043C", r.order_on, "registered", link2("appointments", { groupId: r.id }), r.organization));
    for (const r of query2("SELECT * FROM mentor_authorization WHERE person_id=?1 OR approved_by=?1 ORDER BY valid_from DESC")) groups.mentoring.push(item(r, "\u041F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C \xB7 " + ref("operation", r.operation_id), roles2(r, id, ["person_id", "approved_by"]), r.valid_from, r.revoked_at ? "revoked" : "registered", link2("mentoring", { personId: r.person_id }), "\u0414\u043E: " + (r.valid_to || "\u2014")));
    for (const r of query2("SELECT * FROM mentor_self_evaluation WHERE person_id=?1 ORDER BY evaluated_on DESC")) groups.mentoring.push(item(r, "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430", "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430", r.evaluated_on, "registered", link2("self_eval", { id: r.id }), r.feedback));
    for (const r of query2("SELECT * FROM audit_session WHERE mentor_id=?1 OR auditor_id=?1 OR trainee_id=?1 ORDER BY observed_at DESC")) groups.mentoring.push(item(r, "\u0410\u0443\u0434\u0438\u0442 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F \xB7 " + revLabel(r.standard_revision_id), roles2(r, id, ["mentor_id", "auditor_id", "trainee_id"]), r.observed_at, r.state, r.assignment_id ? link2("audit", { auditId: r.id }) : null, r.summary || ""));
    for (const r of query2("SELECT r.*,d.code,d.title FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.author_id=?1 OR EXISTS(SELECT 1 FROM document_approval a WHERE a.revision_id=r.id AND a.actor_id=?1) ORDER BY d.code,r.version_no DESC")) {
      const role = [r.author_id === id ? "\u0410\u0432\u0442\u043E\u0440" : "", one(db, "SELECT id FROM document_approval WHERE revision_id=? AND actor_id=?", [r.id, id]) ? "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435" : ""].filter(Boolean).join(" \xB7 ");
      groups.documents.push(item(r, r.code + " \xB7 " + r.title + " \xB7 v" + r.version_no, role, r.created_at, r.state, docLink(r.document_id, r.id)));
    }
    for (const r of query2("SELECT e.*,r.document_id FROM sop_evaluation e JOIN document_revision r ON r.id=e.revision_id WHERE e.actor_id=?1 ORDER BY e.evaluated_on DESC")) groups.documents.push(item(r, "\u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F \xB7 " + revLabel(r.revision_id), "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", r.evaluated_on, "registered", link2("sop_evaluation", { revisionId: r.revision_id, tab: "corporate" })));
    for (const r of query2("SELECT * FROM sop_stage43_checklist WHERE actor_id=?1 ORDER BY updated_at DESC")) groups.documents.push(item(r, "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \xB7 " + revLabel(r.revision_id), "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", r.updated_at, "registered", link2("sop_evaluation", { revisionId: r.revision_id, tab: "weighted" })));
    for (const r of query2("SELECT * FROM frv_study WHERE author_id=?1 ORDER BY observed_at DESC")) groups.documents.push(item(r, "\u0424\u0420\u0412 \xB7 " + r.title, "\u0410\u0432\u0442\u043E\u0440", r.observed_at, r.state, link2("frv", { studyId: r.id })));
    for (const r of query2("SELECT * FROM development_plan WHERE person_id=?1 ORDER BY start_on DESC")) groups.development.push(item(r, r.title, "\u041F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", r.start_on, r.state, link2("development", { id: r.id }), "\u0421\u0440\u043E\u043A: " + r.due_on));
    for (const r of query2("SELECT a.* FROM action_item a WHERE a.owner_id=?1 ORDER BY a.due_on")) groups.development.push(item(r, r.title, "\u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u0435 \xB7 \u0438\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C", r.due_on, r.state, null, r.result_note || ""));
    for (const r of query2("SELECT * FROM action_verification WHERE verifier_id=?1 ORDER BY checked_at DESC")) groups.development.push(item(r, "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u044F", "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0449\u0438\u0439", r.checked_at, r.outcome, null, r.evidence_note));
    for (const r of query2("SELECT * FROM schedule_event WHERE owner_id=?1 ORDER BY due_on")) groups.development.push(item(r, "\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u044C \xB7 " + r.kind, "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439", r.due_on, r.state));
    for (const r of query2("SELECT * FROM person_assignment WHERE person_id=?1 ORDER BY valid_from DESC")) groups.history.push(item(r, ref("org_unit", r.unit_id) + " \xB7 " + (r.position_id ? ref("position", r.position_id) : ref("profession", r.profession_id)), "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C / \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", r.valid_from, r.valid_to ? "closed" : "registered", link2("person_assignment", { personId: id }), "\u0414\u043E: " + (r.valid_to || "\u2014") + " \xB7 \u0421\u043C\u0435\u043D\u0430: " + (r.shift_id ? ref("work_shift", r.shift_id) : r.shift_code || "\u2014")));
    for (const r of query2("SELECT * FROM role_assignment WHERE person_id=?1 ORDER BY valid_from DESC")) groups.history.push(item(r, ref("business_role", r.role_id), "\u0420\u043E\u043B\u044C", r.valid_from, r.valid_to ? "closed" : "registered", link2("role_assignment", { personId: id }), "\u0414\u043E: " + (r.valid_to || "\u2014")));
    return groups;
  }
  async function employeeSourceLinks(db, id, readContent3, onProgress = () => {
  }) {
    const sources = [...rows(db, "SELECT r.id,r.document_id,d.code,d.title,r.version_no,r.created_at,r.state,r.payload_json data FROM document_revision r JOIN document d ON d.id=r.document_id").map((x) => ({ ...x, kind: "sop" })), ...rows(db, "SELECT id,title,observed_at created_at,state,context_json data FROM frv_study").map((x) => ({ ...x, kind: "frv" }))];
    const result = [], errors = [];
    let count = 0;
    for (const r of sources) {
      try {
        const source = parse(r.data).source;
        if (!source) {
          errors.push(r.title + " \xB7 \u043D\u0435\u0442 \u0441\u0441\u044B\u043B\u043A\u0438 \u043D\u0430 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B");
          continue;
        }
        const raw = JSON.parse(await checkContent(source, await readContent3(source))), root2 = r.kind === "sop" ? raw.constructor : raw.study, links = (root2?.leanCenterPeople || []).filter((x) => x.person_id === id);
        if (links.length) {
          const label = (x) => x.startsWith("workgroup:") ? "\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u0433\u0440\u0443\u043F\u043F\u0430" : x.startsWith("agree:") ? "\u0421\u043E\u0433\u043B\u0430\u0441\u0443\u044E\u0449\u0438\u0439" : { approver: "\u0423\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0439", trainer: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 TWI", trainee: "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 TWI", sop_observer: "\u041D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u0435\u043B\u044C \u0424\u0420\u0412", operator: "\u0418\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C \u0424\u0420\u0412", observer: "\u041D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u0435\u043B\u044C \u0424\u0420\u0412" }[x] || x;
          result.push(item(r, r.kind === "sop" ? r.code + " \xB7 " + r.title + " \xB7 v" + r.version_no : "\u0424\u0420\u0412 \xB7 " + r.title, [...new Set(links.map((x) => label(x.slot)))].join(" \xB7 "), r.created_at, r.state, r.kind === "sop" ? docLink(r.document_id, r.id) : link2("frv", { studyId: r.id })));
        }
      } catch (e) {
        errors.push(r.title + " \xB7 " + e.message);
      } finally {
        onProgress(++count, sources.length);
      }
    }
    return { items: result, errors, scanned: count };
  }

  // src/modules/training/local-docx.js
  var enc = new TextEncoder();
  var dec = new TextDecoder("utf-8", { fatal: true });
  var max = 32 * 1024 * 1024;
  var W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
  var table = Uint32Array.from({ length: 256 }, (_, i) => {
    let x = i;
    for (let j = 0; j < 8; j++) x = x & 1 ? 3988292384 ^ x >>> 1 : x >>> 1;
    return x >>> 0;
  });
  function crc32(b) {
    let c = 4294967295;
    for (const x of b) c = table[(c ^ x) & 255] ^ c >>> 8;
    return (c ^ 4294967295) >>> 0;
  }
  function concat(arr) {
    const out = new Uint8Array(arr.reduce((n, b) => n + b.length, 0));
    let p = 0;
    for (const b of arr) {
      out.set(b, p);
      p += b.length;
    }
    return out;
  }
  function zipStored(entries) {
    let offset = 0;
    const local = [], central = [];
    invariant(entries.length <= 2e3, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u043D\u043E\u0433\u043E \u0447\u0430\u0441\u0442\u0435\u0439 DOCX");
    for (const e of entries) {
      const name = enc.encode(e.name), bytes = typeof e.bytes === "string" ? enc.encode(e.bytes) : e.bytes;
      invariant(name.length > 0 && name.length < 65536 && bytes.length <= max, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C DOCX");
      const crc = crc32(bytes), lh = new Uint8Array(30), a = new DataView(lh.buffer);
      a.setUint32(0, 67324752, true);
      a.setUint16(4, 20, true);
      a.setUint16(6, 2048, true);
      a.setUint32(14, crc, true);
      a.setUint32(18, bytes.length, true);
      a.setUint32(22, bytes.length, true);
      a.setUint16(26, name.length, true);
      const ch = new Uint8Array(46), b = new DataView(ch.buffer);
      b.setUint32(0, 33639248, true);
      b.setUint16(4, 20, true);
      b.setUint16(6, 20, true);
      b.setUint16(8, 2048, true);
      b.setUint32(16, crc, true);
      b.setUint32(20, bytes.length, true);
      b.setUint32(24, bytes.length, true);
      b.setUint16(28, name.length, true);
      b.setUint32(42, offset, true);
      local.push(lh, name, bytes);
      central.push(ch, name);
      offset += lh.length + name.length + bytes.length;
    }
    const c = concat(central), end = new Uint8Array(22), d = new DataView(end.buffer);
    d.setUint32(0, 101010256, true);
    d.setUint16(8, entries.length, true);
    d.setUint16(10, entries.length, true);
    d.setUint32(12, c.length, true);
    d.setUint32(16, offset, true);
    return concat([...local, c, end]);
  }
  async function readZip(bytes) {
    invariant(bytes instanceof Uint8Array && bytes.length >= 22 && bytes.length <= max, "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u0440\u0430\u0437\u043C\u0435\u0440 DOCX");
    const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), u16 = (i) => v.getUint16(i, true), u32 = (i) => v.getUint32(i, true);
    let end = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) if (u32(i) === 101010256 && i + 22 + u16(i + 20) === bytes.length) {
      end = i;
      break;
    }
    invariant(end >= 0 && u16(end + 4) === 0 && u16(end + 6) === 0 && u16(end + 8) === u16(end + 10), "\u041D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0439 ZIP");
    const count = u16(end + 10), size = u32(end + 12), start = u32(end + 16);
    invariant(count > 0 && count <= 2e3 && start + size <= end, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D \u043A\u0430\u0442\u0430\u043B\u043E\u0433 DOCX");
    const result = [], names3 = /* @__PURE__ */ new Set();
    let p = start, total = 0;
    for (let i = 0; i < count; i++) {
      invariant(p + 46 <= start + size && u32(p) === 33639248, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D \u043A\u0430\u0442\u0430\u043B\u043E\u0433 ZIP");
      const flag = u16(p + 8), method = u16(p + 10), crc = u32(p + 16), packed = u32(p + 20), len = u32(p + 24), nl = u16(p + 28), extra = u16(p + 30), comment = u16(p + 32), offset = u32(p + 42);
      invariant(!(flag & 1) && [0, 8].includes(method) && len <= max && p + 46 + nl + extra + comment <= start + size && offset + 30 <= start, "\u041D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0439 \u0430\u0440\u0445\u0438\u0432 DOCX");
      const name = dec.decode(bytes.subarray(p + 46, p + 46 + nl));
      invariant(name && !names3.has(name) && !name.includes("\\") && !name.startsWith("/") && !name.split("/").includes(".."), "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0435 \u0438\u043C\u044F \u0447\u0430\u0441\u0442\u0438 DOCX");
      names3.add(name);
      invariant(u32(offset) === 67324752, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A ZIP");
      const data = offset + 30 + u16(offset + 26) + u16(offset + 28);
      invariant(data + packed <= start, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D \u0440\u0430\u0437\u043C\u0435\u0440 \u0447\u0430\u0441\u0442\u0438");
      total += len;
      invariant(total <= max, "\u0420\u0430\u0441\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0439 DOCX \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
      let body = bytes.slice(data, data + packed);
      if (method === 8) {
        const stream = new Blob([body]).stream().pipeThrough(new DecompressionStream("deflate-raw")), reader = stream.getReader(), chunks = [];
        let n = 0;
        try {
          for (; ; ) {
            const x = await reader.read();
            if (x.done) break;
            n += x.value.length;
            invariant(n <= len && n <= max, "\u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u0440\u0430\u0437\u043C\u0435\u0440 \u0447\u0430\u0441\u0442\u0438 DOCX");
            chunks.push(x.value);
          }
        } finally {
          await reader.cancel().catch(() => {
          });
        }
        body = concat(chunks);
      }
      invariant(body.length === len && crc32(body) === crc, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 DOCX \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
      result.push({ name, bytes: body });
      p += 46 + nl + extra + comment;
    }
    invariant(p === start + size, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u0430\u0442\u0430\u043B\u043E\u0433 ZIP");
    return result;
  }
  function parse2(xml) {
    const x = new DOMParser().parseFromString(xml, "application/xml");
    invariant(!x.getElementsByTagName("parsererror").length && !x.doctype, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 XML \u0448\u0430\u0431\u043B\u043E\u043D\u0430");
    return x;
  }
  var pText = (p) => Array.from(p.getElementsByTagNameNS(W, "t")).map((t) => t.textContent).join("");
  function setText(p, text4) {
    const x = p.ownerDocument, first = p.getElementsByTagNameNS(W, "r")[0], style = first?.getElementsByTagNameNS(W, "rPr")[0]?.cloneNode(true);
    for (const child of Array.from(p.children)) if (child.namespaceURI === W && child.localName !== "pPr") child.remove();
    const r = x.createElementNS(W, "w:r");
    if (style) r.append(style);
    const lines = String(text4).split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (i) r.append(x.createElementNS(W, "w:br"));
      const t = x.createElementNS(W, "w:t");
      t.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve");
      t.textContent = lines[i];
      r.append(t);
    }
    p.append(r);
  }
  var fmt = (s) => s ? String(s).split("-").reverse().join(".") : "________________";
  function orderPayment(order) {
    const parts2 = [];
    if (order.instructor_amount !== null) parts2.push("\u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430\u043C \u2014 " + order.instructor_amount + " \u0440\u0443\u0431. \u043D\u0430 \u0440\u0443\u043A\u0438");
    if (order.trainer_amount !== null) parts2.push("\u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u043C \u0442\u0440\u0435\u043D\u0435\u0440\u0430\u043C \u2014 " + order.trainer_amount + " \u0440\u0443\u0431. \u043D\u0430 \u0440\u0443\u043A\u0438");
    return parts2.length ? "\u0423\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u0435\u0436\u0435\u043C\u0435\u0441\u044F\u0447\u043D\u0443\u044E \u0434\u043E\u043F\u043B\u0430\u0442\u0443: " + parts2.join("; ") + " \u0441 " + fmt(order.supplement_from) + "." : "\u0414\u043E\u043F\u043B\u0430\u0442\u0430 \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u043C \u043F\u0440\u0438\u043A\u0430\u0437\u043E\u043C \u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u0430\u0432\u043B\u0438\u0432\u0430\u0435\u0442\u0441\u044F.";
  }
  async function fillOrderTemplate(bytes, order, members, { registered = false } = {}) {
    const entries = await readZip(bytes);
    invariant(!entries.some((e) => /vbaProject|embeddings\/|_xmlsignatures\//i.test(e.name)), "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0447\u0438\u0441\u0442\u044B\u0439 DOCX-\u043E\u0431\u0440\u0430\u0437\u0435\u0446 \u0431\u0435\u0437 \u043C\u0430\u043A\u0440\u043E\u0441\u043E\u0432, \u0432\u043B\u043E\u0436\u0435\u043D\u0438\u0439 \u0438 \u043F\u043E\u0434\u043F\u0438\u0441\u0438");
    const doc = entries.find((x) => x.name === "word/document.xml");
    invariant(doc, "\u042D\u0442\u043E \u043D\u0435 DOCX");
    const xml = parse2(dec.decode(doc.bytes)), body = xml.getElementsByTagNameNS(W, "body")[0], p = Array.from(body?.children || []).filter((x) => x.localName === "p" && x.namespaceURI === W);
    invariant(p.length === 56 && pText(p[1]).trim() === "\u041E\u0411\u0420\u0410\u0417\u0415\u0426" && [20, 21, 22, 27, 28, 29].every((i) => pText(p[i]).trim() === "\u0424\u0418\u041E, \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C") && /ПРИКАЗ/.test(pText(p[8])) && /Директор/.test(pText(p[38])), "\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u043C \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u043E\u043C \u043F\u0440\u0438\u043A\u0430\u0437\u0430. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u043E\u0431\u0440\u0430\u0437\u0435\u0446.");
    const groups = [{ indexes: [20, 21, 22], members: members.filter((m) => m.role === "internal_trainer") }, { indexes: [27, 28, 29], members: members.filter((m) => m.role !== "internal_trainer") }];
    setText(p[1], registered ? "\u041A\u041E\u041F\u0418\u042F \u0420\u0415\u041A\u0412\u0418\u0417\u0418\u0422\u041E\u0412 \xB7 \u0411\u0415\u0417 \u041F\u041E\u0414\u041F\u0418\u0421\u0418" : "\u041F\u0420\u041E\u0415\u041A\u0422 \xB7 \u0411\u0415\u0417 \u041F\u041E\u0414\u041F\u0418\u0421\u0418");
    setText(p[3], order.organization);
    setText(p[6], fmt(order.order_on) + "    \u0433. " + order.city);
    setText(p[8], "\u041F\u0420\u0418\u041A\u0410\u0417 \u2116 " + order.order_number);
    setText(p[34], orderPayment(order));
    setText(p[38], "\u0414\u0438\u0440\u0435\u043A\u0442\u043E\u0440 \u0437\u0430\u0432\u043E\u0434\u0430        ____________ / " + order.approved_name + " /");
    for (const g of groups) {
      const [first, ...rest] = g.indexes.map((i) => p[i]), parent = first.parentNode, anchor = first.nextSibling;
      const values = g.members.length ? g.members.map((m) => m.person_name + ", " + m.position_name) : ["\u2014"];
      setText(first, values[0]);
      for (const v of values.slice(1)) {
        const clone = first.cloneNode(true);
        setText(clone, v);
        parent.insertBefore(clone, anchor);
      }
      for (const x of rest) x.remove();
    }
    doc.bytes = enc.encode(new XMLSerializer().serializeToString(xml));
    return zipStored(entries);
  }
  var escape = (x) => String(x ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[c]);
  function paragraph(value, { bold = false, size = 22, center = false } = {}) {
    return "<w:p><w:pPr>" + (center ? '<w:jc w:val="center"/>' : "") + '<w:spacing w:after="120"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>' + (bold ? "<w:b/>" : "") + '<w:sz w:val="' + size + '"/></w:rPr><w:t xml:space="preserve">' + escape(value) + "</w:t></w:r></w:p>";
  }
  function draftDocx(lines, { landscape = false } = {}) {
    const content = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="' + W + '"><w:body>' + lines.map((x) => typeof x === "string" ? paragraph(x) : paragraph(x.text, x)).join("") + '<w:sectPr><w:pgSz w:w="' + (landscape ? "16838" : "11906") + '" w:h="' + (landscape ? "11906" : "16838") + '"' + (landscape ? ' w:orient="landscape"' : "") + '/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr></w:body></w:document>';
    return zipStored([{ name: "[Content_Types].xml", bytes: '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>' }, { name: "_rels/.rels", bytes: '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>' }, { name: "word/document.xml", bytes: content }]);
  }
  function builtinOrderDocx(order, members, { registered = false } = {}) {
    const names3 = (role) => members.filter((m) => role === "internal_trainer" ? m.role === role : m.role !== "internal_trainer").map((m, i) => i + 1 + ". " + m.person_name + ", " + m.position_name);
    return draftDocx([{ text: registered ? "\u041A\u041E\u041F\u0418\u042F \u0420\u0415\u041A\u0412\u0418\u0417\u0418\u0422\u041E\u0412 \xB7 \u0411\u0415\u0417 \u041F\u041E\u0414\u041F\u0418\u0421\u0418" : "\u041F\u0420\u041E\u0415\u041A\u0422 \xB7 \u0411\u0415\u0417 \u041F\u041E\u0414\u041F\u0418\u0421\u0418", bold: true, center: true }, { text: order.organization, bold: true, center: true }, fmt(order.order_on) + "    \u0433. " + order.city, { text: "\u041F\u0420\u0418\u041A\u0410\u0417 \u2116 " + order.order_number, bold: true, size: 28, center: true }, { text: "\xAB\u041E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0438 \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432 \u0438 \u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0442\u0440\u0435\u043D\u0435\u0440\u043E\u0432\xBB", bold: true, center: true }, "\u0421 \u0446\u0435\u043B\u044C\u044E \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438, \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u0435 \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u043D\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u043C \u043C\u0435\u0441\u0442\u0435", { text: "\u041F\u0420\u0418\u041A\u0410\u0417\u042B\u0412\u0410\u042E:", bold: true }, "\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u043C\u0438 \u0442\u0440\u0435\u043D\u0435\u0440\u0430\u043C\u0438 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043F\u043E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0435 TWI \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432:", ...names3("internal_trainer").length ? names3("internal_trainer") : ["\u2014"], "\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430\u043C\u0438 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043F\u043E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0435 TWI \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432:", ...names3("instructor").length ? names3("instructor") : ["\u2014"], "\u041E\u0442\u0434\u0435\u043B\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0430 \u043E\u0437\u043D\u0430\u043A\u043E\u043C\u0438\u0442\u044C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044B\u0445 \u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0442\u0440\u0435\u043D\u0435\u0440\u043E\u0432 \u0438 \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432 \u0441 \u0437\u0430\u0434\u0430\u0447\u0430\u043C\u0438 \u043F\u043E \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u044B\u043C \u0440\u043E\u043B\u044F\u043C \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u043E \u0421\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u0430 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u0438 \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u043D\u0430 \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u043C\u0435\u0441\u0442\u0430\u0445 (\u0441 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0435\u043C \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 TWI).", orderPayment(order), "\u0414\u0438\u0440\u0435\u043A\u0442\u043E\u0440 \u0437\u0430\u0432\u043E\u0434\u0430        ____________ / " + order.approved_name + " /"]);
  }
  async function sopCriteriaFromDocx(bytes) {
    const entries = await readZip(bytes), doc = entries.find((x) => x.name === "word/document.xml");
    invariant(doc, "\u042D\u0442\u043E \u043D\u0435 DOCX");
    const xml = parse2(dec.decode(doc.bytes)), out = [];
    for (const row of Array.from(xml.getElementsByTagNameNS(W, "tr"))) {
      const cells2 = Array.from(row.children).filter((x) => x.namespaceURI === W && x.localName === "tc");
      if (cells2.length < 2) continue;
      const value = (x) => Array.from(x.getElementsByTagNameNS(W, "p")).map(pText).join(" ").trim(), number = value(cells2[0]);
      if (!/^\d{1,3}$/.test(number)) continue;
      const code = Number(number), question = value(cells2[1]);
      invariant(code === out.length + 1 && question, "\u041D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u044F \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0439");
      out.push({ code, question });
    }
    invariant(out.length > 0 && out.length <= 100, "\u0412 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 DOCX \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B 1\u2013100 \u043F\u0440\u043E\u043D\u0443\u043C\u0435\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439");
    return out;
  }

  // src/modules/training/builtin-forms.js
  var BUILTIN_PRACTICAL = {
    "format": "lean-practical-checklist-v1",
    "title": "\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 8. \u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043E\u0446\u0435\u043D\u043A\u0438 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u0421\u0442\u0430\u0436\u0435\u0440\u043E\u043C",
    "source_sha256": "2555971f502c79958de74500b4dccc3622066b32e9687c6d1b15757834b88a00",
    "criteria": [
      {
        "code": 1,
        "section": "\u0428\u0430\u0433 1. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043C\u0435\u0441\u0442\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u043B \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E"
      },
      {
        "code": 2,
        "section": "\u0428\u0430\u0433 1. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043C\u0435\u0441\u0442\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u043B \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442"
      },
      {
        "code": 3,
        "section": "\u0428\u0430\u0433 2. \u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443 \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E?"
      },
      {
        "code": 4,
        "section": "\u0428\u0430\u0433 2. \u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443 \u0438 \u043E\u0431\u044A\u044F\u0441\u043D\u0438\u043B \u043E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u044D\u0442\u0430\u043F\u044B?"
      },
      {
        "code": 5,
        "section": "\u0428\u0430\u0433 2. \u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443, \u043E\u0431\u044A\u044F\u0441\u043D\u0438\u043B \u044D\u0442\u0430\u043F\u044B \u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B?"
      },
      {
        "code": 6,
        "section": "\u0428\u0430\u0433 2. \u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443, \u043E\u0431\u044A\u044F\u0441\u043D\u0438\u043B \u044D\u0442\u0430\u043F\u044B, \u041A\u041C \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u044B?"
      },
      {
        "code": 7,
        "section": "\u0428\u0430\u0433 2. \u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043B \u0421\u041E\u041F?"
      },
      {
        "code": 8,
        "section": "\u0428\u0430\u0433 2. \u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043B \u0421\u0418\u0417 \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u043E \u0421\u041E\u041F?"
      },
      {
        "code": 9,
        "section": "\u0428\u0430\u0433 2. \u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043B \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442 \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u043E \u0421\u041E\u041F?"
      },
      {
        "code": 10,
        "section": "\u0428\u0430\u0433 2. \u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
        "question": "\u0421\u0442\u0430\u0436\u0435\u0440 \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E?"
      },
      {
        "code": 11,
        "section": "\u0428\u0430\u0433 2. \u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
        "question": "\u0412 \u0446\u0435\u043B\u043E\u043C \u0441\u0442\u0430\u0436\u0435\u0440 \u043F\u0440\u043E\u0432\u0435\u043B \u0440\u0430\u0431\u043E\u0442\u0443 \u0447\u0435\u0442\u043A\u043E, \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u043E \u0438 \u043E\u043D\u0430 \u0431\u044B\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430?"
      }
    ]
  };
  var BUILTIN_SOP = {
    "format": "lean-sop-checklist-v1",
    "title": "\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 4. \u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F",
    "source_sha256": "14771eab2f74cdecadc76b9ac11ee89fd5c7cbb8a7c34c79c61f0928c329ec04",
    "criteria": [
      {
        "code": 1,
        "question": "\u0415\u0441\u0442\u044C \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0421\u041E\u041F"
      },
      {
        "code": 2,
        "question": "\u0423\u043A\u0430\u0437\u0430\u043D\u043E \u043C\u0435\u0441\u0442\u043E \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B"
      },
      {
        "code": 3,
        "question": "\u041F\u0435\u0440\u0435\u0447\u0438\u0441\u043B\u0435\u043D\u044B \u0432\u0441\u0435 \u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0435 \u0437\u0430 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u0438 \u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0438\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u0435\u0439, \u0435\u0441\u043B\u0438 \u0438\u0445 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E"
      },
      {
        "code": 4,
        "question": "\u0423\u043A\u0430\u0437\u0430\u043D\u043E \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435, \u043D\u0430 \u043A\u043E\u0442\u043E\u0440\u043E\u043C \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F"
      },
      {
        "code": 5,
        "question": "\u0412\u043D\u0435\u0441\u0435\u043D\u043E \u043E\u0431\u0449\u0435\u0435 \u0432\u0440\u0435\u043C\u044F \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u0421\u041E\u041F"
      },
      {
        "code": 6,
        "question": "\u0423\u043A\u0430\u0437\u0430\u043D\u0430 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F"
      },
      {
        "code": 7,
        "question": "\u041E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D \u0441\u043E\u0441\u0442\u0430\u0432 \u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0439 \u0440\u0430\u0431\u043E\u0447\u0435\u0439 \u0433\u0440\u0443\u043F\u043F\u044B, \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u0432\u0448\u0435\u0439 \u0421\u041E\u041F"
      },
      {
        "code": 8,
        "question": "\u0415\u0441\u0442\u044C \u043F\u043E\u0434\u043F\u0438\u0441\u044C \u0440\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044F \u0440\u0430\u0431\u043E\u0447\u0435\u0439 \u0433\u0440\u0443\u043F\u043F\u044B \u2013 \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A\u0430 \u0421\u041E\u041F"
      },
      {
        "code": 9,
        "question": "\u0423\u043A\u0430\u0437\u0430\u043D\u043E \u0432\u0440\u0435\u043C\u044F \u0432\u0441\u0435\u0439 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B (\u043E\u0440\u0438\u0435\u043D\u0442\u0438\u0440 \u0434\u043B\u044F \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F)"
      },
      {
        "code": 10,
        "question": "\u041F\u0435\u0440\u0435\u0447\u0438\u0441\u043B\u0435\u043D\u044B \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u043A \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438, \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u044B\u0435 \u0421\u0418\u0417"
      },
      {
        "code": 11,
        "question": "\u0423\u043A\u0430\u0437\u0430\u043D\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B, \u043E\u0441\u043D\u0430\u0441\u0442\u043A\u0430, \u043F\u0440\u0438\u0441\u043F\u043E\u0441\u043E\u0431\u043B\u0435\u043D\u0438\u044F"
      },
      {
        "code": 12,
        "question": "\u0423\u043A\u0430\u0437\u0430\u043D\u044B \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B"
      },
      {
        "code": 13,
        "question": "\u0412\u0441\u0435 \u0448\u0430\u0433\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0432\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u044B (\u0444\u043E\u0442\u043E, \u0440\u0438\u0441\u0443\u043D\u043E\u043A, \u0441\u0445\u0435\u043C\u0430, \u0447\u0435\u0440\u0442\u0435\u0436 \u0438 \u043F\u0440.)"
      },
      {
        "code": 14,
        "question": "\u041E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u044B \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F - \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0448\u0430\u0433\u0438, \u0441\u043F\u043E\u0441\u043E\u0431\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043F\u0440\u043E\u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044E \u0440\u0430\u0431\u043E\u0442\u044B \u0432\u043F\u0435\u0440\u0451\u0434 (\u0447\u0442\u043E \u0434\u0435\u043B\u0430\u0442\u044C?), \u0442\u043E\u0447\u043D\u043E \u043E\u0442\u0440\u0430\u0436\u0430\u044E\u0449\u0438\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0441\u043E\u043F\u0440\u043E\u0432\u043E\u0436\u0434\u0430\u044E\u0449\u0435\u0439 \u0432\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438, \u0441\u043F\u043E\u0441\u043E\u0431\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0439 \u043E\u0431\u043B\u0435\u0433\u0447\u0435\u043D\u0438\u044E \u0432\u043E\u0441\u043F\u0440\u0438\u044F\u0442\u0438\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u043C"
      },
      {
        "code": 15,
        "question": "\u0423\u043A\u0430\u0437\u0430\u043D\u044B \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u043C\u044B\u0445 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439 (\u043A\u0430\u043A \u0434\u0435\u043B\u0430\u0442\u044C?)"
      },
      {
        "code": 16,
        "question": "\u041F\u0440\u0438 \u043D\u0430\u043B\u0438\u0447\u0438\u0438 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u0438\u0445 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0445 \u043C\u043E\u043C\u0435\u043D\u0442\u043E\u0432 (\u041A\u041C \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438, \u041A\u041C \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0430, \u041A\u041C \u0437\u0430\u0442\u0440\u0430\u0442, \u041A\u041C \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u0438(\u0438\u043B\u0438) \u041A\u041C \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0445 \u043C\u0435\u0442\u043E\u0434\u0438\u043A) \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0440\u0430\u0437\u0431\u0438\u0442\u0430 \u043D\u0430 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043C\u0435\u043B\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439"
      },
      {
        "code": 17,
        "question": "\u0423\u043C\u0435\u0449\u0430\u0435\u0442\u0441\u044F \u0432 \u04103 - \u0421\u041E\u041F \u0443\u0434\u043E\u0431\u0435\u043D \u043A\u0430\u043A \u043A\u043E\u043D\u0441\u043F\u0435\u043A\u0442 \u0434\u043B\u044F \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 \u043F\u043E \u043C\u0435\u0442\u043E\u0434\u0443 1+3+4+1"
      },
      {
        "code": 18,
        "question": "\u0421\u041E\u041F \u0443\u0434\u043E\u0431\u043D\u043E \u0440\u0430\u0441\u043F\u043E\u043B\u043E\u0436\u0435\u043D \u0434\u043B\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u044F \u0438\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u0435\u043C"
      },
      {
        "code": 19,
        "question": "\u041B\u0435\u0433\u043A\u043E \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u0434\u0430\u0442\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439, \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0445 (\u0447\u0435\u043A-\u043B\u0438\u0441\u0442 / \u0436\u0443\u0440\u043D\u0430\u043B)"
      },
      {
        "code": 20,
        "question": "\u0414\u0430\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0421\u041E\u041F \u043D\u0435 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 12 \u043C\u0435\u0441\u044F\u0446\u0435\u0432 \u043D\u0430 \u043C\u043E\u043C\u0435\u043D\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438"
      }
    ]
  };
  var BUILTIN_SELF = {
    "format": "lean-self-checklist-v1",
    "title": "\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 12. \u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430 \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430 \u0438 \u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0435\u0433\u043E \u0442\u0440\u0435\u043D\u0435\u0440\u0430",
    "source_sha256": "26b174932fb2289bb0757602913c797adb6eb4bc7e111edd87837d28190416ef",
    "criteria": [
      {
        "code": 1,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0438 \u044D\u0432\u043E\u043B\u044E\u0446\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B TWI"
      },
      {
        "code": 2,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0412\u0430\u0436\u043D\u043E\u0441\u0442\u044C \u041E\u0420\u041C/TWI \u0434\u043B\u044F \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u0438 \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0430"
      },
      {
        "code": 3,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0412\u043E\u0437\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043D\u0435\u044D\u0444\u0444\u0435\u043A\u0442\u0438\u0432\u043D\u043E\u0433\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u043D\u0430 \u0443\u0447\u0435\u043D\u0438\u043A\u0430 \u0438 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044E"
      },
      {
        "code": 4,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "4 \u043C\u043E\u0434\u0443\u043B\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B TWI"
      },
      {
        "code": 5,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0414\u0435\u043A\u043E\u043C\u043F\u043E\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0440\u0430\u0431\u043E\u0447\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441 \u043D\u0430 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B (\u0436\u0435\u043B\u0430\u0442\u0435\u043B\u044C\u043D\u043E \u043F\u043E \u0443\u0440\u043E\u0432\u043D\u044F\u043C \u0441\u043B\u043E\u0436\u043D\u043E\u0441\u0442\u0438)"
      },
      {
        "code": 6,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0412\u044B\u0434\u0435\u043B\u044F\u0442\u044C \u043E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u044D\u0442\u0430\u043F\u044B \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B, \u0432\u0438\u0434\u0435\u0442\u044C \u043E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F"
      },
      {
        "code": 7,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0412\u044B\u0434\u0435\u043B\u044F\u0442\u044C \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B"
      },
      {
        "code": 8,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u041F\u043E\u043D\u0438\u043C\u0430\u0442\u044C \u043F\u0435\u0440\u0432\u043E\u043F\u0440\u0438\u0447\u0438\u043D\u044B \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0445 \u043C\u043E\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      {
        "code": 9,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0421\u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u043D\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B/\u043A\u0430\u0440\u0442\u044B (\u0421\u041E\u041F/\u0421\u041E\u041A)"
      },
      {
        "code": 10,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u042D\u043B\u0435\u043C\u0435\u043D\u0442\u044B \u044D\u0444\u0444\u0435\u043A\u0442\u0438\u0432\u043D\u043E\u0433\u043E \u0438 \u043D\u0430\u0434\u0435\u0436\u043D\u043E\u0433\u043E \u043C\u0435\u0442\u043E\u0434\u0430 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F 1+3+4+1"
      },
      {
        "code": 11,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u041E\u0441\u043E\u0431\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430"
      },
      {
        "code": 12,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u041C\u0435\u0442\u043E\u0434\u044B \u043F\u043E\u0441\u0442\u0440\u043E\u0435\u043D\u0438\u044F \u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u044F \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u043E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u0439"
      },
      {
        "code": 13,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0421\u0443\u0442\u044C \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u0447\u0435\u0441\u0442\u0432\u0430 \u0438 \u0435\u0433\u043E \u0440\u043E\u043B\u044C \u0432 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u0438 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0430"
      },
      {
        "code": 14,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u041F\u0440\u043E\u0432\u0435\u0441\u0442\u0438 \u0430\u0443\u0434\u0438\u0442/\u0441\u0443\u043F\u0435\u0440\u0432\u0430\u0439\u0437\u0438\u043D\u0433 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430"
      },
      {
        "code": 15,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u043C\u0430\u0442\u0440\u0438\u0446\u0443 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0430 (\u041C\u041A)"
      },
      {
        "code": 16,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0439 \u043F\u043B\u0430\u043D \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"
      },
      {
        "code": 17,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u0421\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043F\u043B\u0430\u043D \u0432\u0432\u043E\u0434\u0430 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E"
      },
      {
        "code": 18,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u041A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u043B\u0430\u043D \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0435 \u0432\u044B\u044F\u0432\u043B\u0435\u043D\u043D\u044B\u0445 \u043F\u0440\u043E\u0431\u043B\u0435\u043C \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0430"
      },
      {
        "code": 19,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u041E\u0431\u0443\u0447\u0430\u0442\u044C \u043D\u043E\u0432\u044B\u0445 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432 \u043D\u0430 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u043C \u0441\u0435\u043C\u0438\u043D\u0430\u0440\u0435"
      },
      {
        "code": 20,
        "section": "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430",
        "question": "\u041E\u0440\u0433\u0430\u043D\u0438\u0437\u043E\u0432\u0430\u0442\u044C \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0438 \u0440\u0430\u0431\u043E\u0442\u0443 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432"
      }
    ]
  };
  var SELF_LEVELS = { 1: "\u0417\u043D\u0430\u0435\u0442, \u043F\u043E\u043D\u0438\u043C\u0430\u0435\u0442", 2: "\u0423\u043C\u0435\u0435\u0442", 3: "\u0414\u0435\u043B\u0430\u0435\u0442 \u043F\u043E\u0441\u0442\u043E\u044F\u043D\u043D\u043E", 4: "\u0423\u043C\u0435\u0435\u0442 \u043E\u0431\u044A\u044F\u0441\u043D\u0438\u0442\u044C \u0438 \u043E\u0431\u0443\u0447\u0438\u0442\u044C \u0434\u0440\u0443\u0433\u0438\u0445", 5: "\u041F\u043E\u0441\u0442\u043E\u044F\u043D\u043D\u043E \u043E\u0431\u0443\u0447\u0430\u0435\u0442 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432" };
  var RC1_CRITERIA = [
    {
      "code": 1,
      "section": "\u0428\u0430\u0433 1. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043C\u0435\u0441\u0442\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
      "question": "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u043B \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E",
      "recommendation": "\u0413\u043E\u0442\u043E\u0432\u0438\u0442\u044C \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0438 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B \u0437\u0430\u0440\u0430\u043D\u0435\u0435 \u2014 \u0434\u043E \u043F\u0440\u0438\u0445\u043E\u0434\u0430 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
      "rc1_id": "s1c1"
    },
    {
      "code": 2,
      "section": "\u0428\u0430\u0433 1. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043C\u0435\u0441\u0442\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
      "question": "\u0420\u0435\u0448\u0438\u043B, \u043A\u043E\u0433\u043E \u0438 \u043A \u043A\u0430\u043A\u043E\u043C\u0443 \u0441\u0440\u043E\u043A\u0443 \u0433\u043E\u0442\u043E\u0432\u0438\u0442",
      "recommendation": "\u0417\u0430\u0440\u0430\u043D\u0435\u0435 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u044F\u0442\u044C, \u043A\u043E\u0433\u043E \u0438 \u043A \u043A\u0430\u043A\u043E\u043C\u0443 \u0441\u0440\u043E\u043A\u0443 \u043E\u0431\u0443\u0447\u0430\u0442\u044C, \u043F\u043E \u043F\u043B\u0430\u043D\u0443 \u0440\u043E\u0442\u0430\u0446\u0438\u0438",
      "rc1_id": "s1c2"
    },
    {
      "code": 3,
      "section": "\u0428\u0430\u0433 1. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043C\u0435\u0441\u0442\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
      "question": "\u0421\u043E\u0437\u0434\u0430\u043B \u043D\u0435\u043F\u0440\u0438\u043D\u0443\u0436\u0434\u0451\u043D\u043D\u0443\u044E \u0430\u0442\u043C\u043E\u0441\u0444\u0435\u0440\u0443",
      "recommendation": "\u041D\u0430\u0447\u0438\u043D\u0430\u0442\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436 \u0441 \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u0439 \u043D\u0435\u0444\u043E\u0440\u043C\u0430\u043B\u044C\u043D\u043E\u0439 \u0431\u0435\u0441\u0435\u0434\u044B, \u0441\u043D\u0438\u0436\u0430\u044E\u0449\u0435\u0439 \u043D\u0430\u043F\u0440\u044F\u0436\u0435\u043D\u0438\u0435",
      "rc1_id": "s1c3"
    },
    {
      "code": 4,
      "section": "\u0428\u0430\u0433 1. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043C\u0435\u0441\u0442\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
      "question": "\u041D\u0430\u0437\u0432\u0430\u043B \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u0443",
      "recommendation": "\u041F\u0440\u043E\u0433\u043E\u0432\u0430\u0440\u0438\u0432\u0430\u0442\u044C \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B \u0438 \u0435\u0451 \u043C\u0435\u0441\u0442\u043E \u0432 \u043E\u0431\u0449\u0435\u043C \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435",
      "rc1_id": "s1c4"
    },
    {
      "code": 5,
      "section": "\u0428\u0430\u0433 1. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043C\u0435\u0441\u0442\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
      "question": "\u0412\u044B\u044F\u0441\u043D\u0438\u043B, \u0447\u0442\u043E \u0437\u043D\u0430\u0435\u0442 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439",
      "recommendation": "\u0417\u0430\u0434\u0430\u0432\u0430\u0442\u044C 1\u20132 \u0432\u043E\u043F\u0440\u043E\u0441\u0430, \u0447\u0442\u043E\u0431\u044B \u043E\u0446\u0435\u043D\u0438\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
      "rc1_id": "s1c5"
    },
    {
      "code": 6,
      "section": "\u0428\u0430\u0433 1. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043C\u0435\u0441\u0442\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
      "question": "\u041E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u043B \u043D\u0430\u0438\u043B\u0443\u0447\u0448\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0434\u043B\u044F \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F",
      "recommendation": "\u0420\u0430\u0441\u043F\u043E\u043B\u0430\u0433\u0430\u0442\u044C \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E \u0442\u0430\u043A, \u0447\u0442\u043E\u0431\u044B \u043E\u043D \u0432\u0438\u0434\u0435\u043B \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E \u0441 \u0440\u0430\u0431\u043E\u0447\u0435\u0439 \u0441\u0442\u043E\u0440\u043E\u043D\u044B",
      "rc1_id": "s1c6"
    },
    {
      "code": 7,
      "section": "\u0428\u0430\u0433 1. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043C\u0435\u0441\u0442\u0430 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E",
      "question": "\u041E\u0431\u044A\u044F\u0441\u043D\u0438\u043B \u0432\u0430\u0436\u043D\u043E\u0441\u0442\u044C \u0438 \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u0439 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F",
      "recommendation": "\u041E\u0431\u044A\u044F\u0441\u043D\u044F\u0442\u044C, \u0437\u0430\u0447\u0435\u043C \u043D\u0443\u0436\u043D\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0438 \u043A\u0430\u043A \u043E\u043D\u0430 \u0432\u043B\u0438\u044F\u0435\u0442 \u043D\u0430 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0443\u0447\u0430\u0441\u0442\u043A\u0430",
      "rc1_id": "s1c7"
    },
    {
      "code": 8,
      "section": "\u0428\u0430\u0433 2. \u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
      "question": "\u041F\u0440\u043E\u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043B \u0440\u0430\u0431\u043E\u0442\u0443, \u043D\u0430\u0437\u0432\u0430\u043B \u044D\u0442\u0430\u043F\u044B",
      "recommendation": "\u041F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E \u0446\u0435\u043B\u0438\u043A\u043E\u043C, \u043F\u0440\u043E\u0433\u043E\u0432\u0430\u0440\u0438\u0432\u0430\u044F \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u044D\u0442\u0430\u043F\u043E\u0432",
      "rc1_id": "s2c1"
    },
    {
      "code": 9,
      "section": "\u0428\u0430\u0433 2. \u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
      "question": "\u0412\u044B\u0434\u0435\u043B\u0438\u043B \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B \u044D\u0442\u0430\u043F\u043E\u0432",
      "recommendation": "\u041F\u0440\u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u043C \u043F\u043E\u043A\u0430\u0437\u0435 \u0432\u044B\u0434\u0435\u043B\u044F\u0442\u044C \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B \u0432\u043D\u0443\u0442\u0440\u0438 \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u044D\u0442\u0430\u043F\u0430",
      "rc1_id": "s2c2"
    },
    {
      "code": 10,
      "section": "\u0428\u0430\u0433 2. \u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
      "question": "\u041E\u0431\u044A\u044F\u0441\u043D\u0438\u043B \u043F\u0440\u0438\u0447\u0438\u043D\u044B \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0445 \u043C\u043E\u043C\u0435\u043D\u0442\u043E\u0432",
      "recommendation": "\u0414\u043E\u0431\u0430\u0432\u043B\u044F\u0442\u044C \u043A \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u043C \u043C\u043E\u043C\u0435\u043D\u0442\u0430\u043C \u043E\u0431\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435 \u043F\u0440\u0438\u0447\u0438\u043D \u2014 \u043F\u043E\u0447\u0435\u043C\u0443 \u0438\u043C\u0435\u043D\u043D\u043E \u0442\u0430\u043A",
      "rc1_id": "s2c3"
    },
    {
      "code": 11,
      "section": "\u0428\u0430\u0433 2. \u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438",
      "question": "\u0420\u0430\u0431\u043E\u0442\u0430 \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0430 \u0447\u0451\u0442\u043A\u043E \u0438 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430",
      "recommendation": "\u041E\u0442\u0440\u0430\u0431\u0430\u0442\u044B\u0432\u0430\u0442\u044C \u0442\u0435\u043C\u043F \u043F\u043E\u043A\u0430\u0437\u0430: \u0431\u0435\u0437 \u0441\u043F\u0435\u0448\u043A\u0438, \u0441 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u0435\u043C \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u0446\u0438\u043A\u043B\u0430",
      "rc1_id": "s2c4"
    },
    {
      "code": 12,
      "section": "\u0428\u0430\u0433 3. \u041F\u0440\u043E\u0431\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435",
      "question": "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443 \u0441 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u043C",
      "recommendation": "\u0414\u0430\u0432\u0430\u0442\u044C \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u043C\u0443 \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u043C, \u0441 \u043F\u043E\u0434\u0441\u0442\u0440\u0430\u0445\u043E\u0432\u043A\u043E\u0439",
      "rc1_id": "s3c1"
    },
    {
      "code": 13,
      "section": "\u0428\u0430\u0433 3. \u041F\u0440\u043E\u0431\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435",
      "question": "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u0438 \u043D\u0430\u0437\u0432\u0430\u043B \u044D\u0442\u0430\u043F\u044B",
      "recommendation": "\u041F\u0440\u043E\u0441\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E \u043F\u0440\u043E\u0433\u043E\u0432\u0430\u0440\u0438\u0432\u0430\u0442\u044C \u044D\u0442\u0430\u043F\u044B \u0432\u0441\u043B\u0443\u0445 \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F",
      "rc1_id": "s3c2"
    },
    {
      "code": 14,
      "section": "\u0428\u0430\u0433 3. \u041F\u0440\u043E\u0431\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435",
      "question": "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 \u043D\u0430\u0437\u0432\u0430\u043B \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B",
      "recommendation": "\u041F\u0440\u043E\u0441\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E \u043D\u0430\u0437\u044B\u0432\u0430\u0442\u044C \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B, \u0430 \u043D\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F",
      "rc1_id": "s3c3"
    },
    {
      "code": 15,
      "section": "\u0428\u0430\u0433 3. \u041F\u0440\u043E\u0431\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435",
      "question": "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 \u043E\u0431\u044A\u044F\u0441\u043D\u0438\u043B \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u044B",
      "recommendation": "\u0414\u043E\u0431\u0438\u0432\u0430\u0442\u044C\u0441\u044F, \u0447\u0442\u043E\u0431\u044B \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439 \u043E\u0431\u044A\u044F\u0441\u043D\u044F\u043B \u0438 \u043F\u0440\u0438\u0447\u0438\u043D\u044B \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0445 \u043C\u043E\u043C\u0435\u043D\u0442\u043E\u0432",
      "rc1_id": "s3c4"
    },
    {
      "code": 16,
      "section": "\u0428\u0430\u0433 4. \u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430",
      "question": "\u041F\u043E\u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u0438\u043B \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E \u0437\u0430 \u0443\u0441\u0435\u0440\u0434\u0438\u0435",
      "recommendation": "\u041E\u0442\u043C\u0435\u0447\u0430\u0442\u044C \u0443\u0441\u0438\u043B\u0438\u044F \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E \u0441\u043B\u043E\u0432\u0435\u0441\u043D\u043E \u2014 \u044D\u0442\u043E \u0437\u0430\u043A\u0440\u0435\u043F\u043B\u044F\u0435\u0442 \u043C\u043E\u0442\u0438\u0432\u0430\u0446\u0438\u044E",
      "rc1_id": "s4c1"
    },
    {
      "code": 17,
      "section": "\u0428\u0430\u0433 4. \u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430",
      "question": "\u041F\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u043B \u0432\u043E\u043F\u0440\u043E\u0441\u044B",
      "recommendation": "\u041F\u0440\u044F\u043C\u043E \u043F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0442\u044C \u0437\u0430\u0434\u0430\u0432\u0430\u0442\u044C \u0432\u043E\u043F\u0440\u043E\u0441\u044B, \u0430 \u043D\u0435 \u043F\u0440\u043E\u0441\u0442\u043E \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436",
      "rc1_id": "s4c2"
    },
    {
      "code": 18,
      "section": "\u0428\u0430\u0433 4. \u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430",
      "question": "\u0423\u043A\u0430\u0437\u0430\u043B, \u043A \u043A\u043E\u043C\u0443 \u043E\u0431\u0440\u0430\u0449\u0430\u0442\u044C\u0441\u044F \u0437\u0430 \u043F\u043E\u043C\u043E\u0449\u044C\u044E",
      "recommendation": "\u041D\u0430\u0437\u044B\u0432\u0430\u0442\u044C \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E\u0433\u043E \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430, \u043A \u043A\u043E\u0442\u043E\u0440\u043E\u043C\u0443 \u043E\u0431\u0440\u0430\u0449\u0430\u0442\u044C\u0441\u044F \u043F\u0440\u0438 \u0437\u0430\u0442\u0440\u0443\u0434\u043D\u0435\u043D\u0438\u044F\u0445",
      "rc1_id": "s4c3"
    },
    {
      "code": 19,
      "section": "\u0428\u0430\u0433 4. \u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430",
      "question": "\u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043B \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438",
      "recommendation": "\u0424\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u0430\u0442\u044B \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u044B\u0445 \u043F\u0440\u043E\u0432\u0435\u0440\u043E\u043A \u0432 \u043F\u043B\u0430\u043D\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F",
      "rc1_id": "s4c4"
    },
    {
      "code": 20,
      "section": "\u0428\u0430\u0433 4. \u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430",
      "question": "\u041E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u043B \u0434\u043E\u043F. \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u043F\u0440\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u0438",
      "recommendation": "\u041F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u0441\u043B\u0430\u0431\u044B\u043C \u043C\u0435\u0441\u0442\u0430\u043C, \u0441 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u043C\u0438 \u0441\u0440\u043E\u043A\u0430\u043C\u0438",
      "rc1_id": "s4c5"
    }
  ];
  var FORM_CATALOG = [
    [1, "\u041F\u043B\u0430\u043D \u0432\u0432\u043E\u0434\u0430 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E", "programs", "\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u043D\u044B\u0435 \u0434\u043D\u0438, \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u043D\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u0438, \u0421\u041E\u041F, \u0447\u0430\u0441\u044B"],
    [2, "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0438 \u043D\u0430 \u043F\u0435\u0440\u0438\u043E\u0434 \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438", "internship", "\u0427\u0435\u0442\u044B\u0440\u0435 \u0447\u0430\u0441\u0442\u0438, \u0434\u0432\u0430 \u043F\u0435\u0440\u0438\u043E\u0434\u0430, \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0438 \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435"],
    [3, "\u0421\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u043D\u0430\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u0430\u044F \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u0430", "sop_constructor", "\u041A\u043D\u0438\u0436\u043D\u044B\u0439 \u0438 \u0430\u043B\u044C\u0431\u043E\u043C\u043D\u044B\u0439 \u04103; \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 Stage43"],
    [4, "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F", "sop_evaluation", "20 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432, \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438"],
    [5, "\u041F\u043B\u0430\u043D \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", "twi", "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F, \u0446\u0435\u043B\u0435\u0432\u043E\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C, \u043F\u043B\u0430\u043D/\u0444\u0430\u043A\u0442"],
    [6, "\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", "skills", "\u0428\u043A\u0430\u043B\u0430 1\u20134, \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430"],
    [7, "\u0416\u0443\u0440\u043D\u0430\u043B \u0437\u0430\u0434\u0430\u043D\u0438\u0439 \u0440\u0430\u0431\u043E\u0442\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432", "journal", "\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0434\u0430\u0442\u044B, \u043C\u0438\u043D\u0443\u0442\u044B, \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 \u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439"],
    [8, "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043E\u0446\u0435\u043D\u043A\u0438 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u0421\u0442\u0430\u0436\u0435\u0440\u043E\u043C", "practical", "11 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432, \u0438\u0442\u043E\u0433 \u0432 \u043C\u0430\u0442\u0440\u0438\u0446\u0435 \u043F\u043E\u0441\u043B\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F"],
    [9, "\u0424\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u044F \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438", "frv", "\u0421\u0432\u044F\u0437\u0430\u043D\u043D\u043E\u0435 \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435, \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0424\u0420\u0412"],
    [10, "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0435\u0433\u043E \u0442\u0440\u0435\u043D\u0435\u0440\u0430 / \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430", "certification", "\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0432\u044B\u0434\u0430\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430; \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0431\u0435\u0437 \u043F\u043E\u0434\u043F\u0438\u0441\u0438"],
    [11, "\u0410\u0443\u0434\u0438\u0442 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F", "audit", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0430\u044F \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u0430\u044F RC1: 20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432"],
    [12, "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430 \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0438 \u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0435\u0433\u043E \u0442\u0440\u0435\u043D\u0435\u0440\u0430", "self_eval", "20 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432, \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u0430\u044F \u0448\u043A\u0430\u043B\u0430 1\u20135"],
    [13, "\u041F\u0440\u0438\u043A\u0430\u0437 \u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0438 \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432 \u0438 \u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0445 \u0442\u0440\u0435\u043D\u0435\u0440\u043E\u0432", "appointments", "\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 \u0438 \u0434\u043E\u043F\u043B\u0430\u0442\u044B, \u043F\u0443\u0441\u0442\u044B\u0435 \u043F\u043E\u0434\u043F\u0438\u0441\u0438"]
  ];
  var INITIAL_PROGRAM_TASKS = [
    ["general", "\u041E\u0431\u0449\u0435\u0435 \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043E \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438. \u041C\u0438\u0441\u0441\u0438\u044F, \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0438, \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u044B \u0422\u0435\u0445\u043D\u043E\u041D\u0418\u041A\u041E\u041B\u042C. \u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438. \u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u0441 \u041A\u043E\u0434\u0435\u043A\u0441\u043E\u043C \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0445 \u043F\u0440\u0430\u0432\u0438\u043B \u0438 \u044D\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043D\u043E\u0440\u043C."],
    ["general", "\u041F\u0440\u0438\u0435\u043C \u043D\u0430 \u0440\u0430\u0431\u043E\u0442\u0443. \u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u0441 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u043C\u0438 \u043D\u043E\u0440\u043C\u0430\u0442\u0438\u0432\u043D\u044B\u043C\u0438 \u0430\u043A\u0442\u0430\u043C\u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F (\u041F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043E\u0431 \u043E\u043F\u043B\u0430\u0442\u0435 \u0442\u0440\u0443\u0434\u0430, \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043E \u0437\u0430\u0449\u0438\u0442\u0435 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445, \u043F\u043E\u043B\u0438\u0442\u0438\u043A\u0430 \u0432 \u043E\u0431\u043B\u0430\u0441\u0442\u0438 \u043E\u0445\u0440\u0430\u043D\u044B \u0442\u0440\u0443\u0434\u0430 \u0438 \u0442.\u0434.)."],
    ["general", "\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E\u0431 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u0441\u043E\u0446\u0438\u0430\u043B\u044C\u043D\u043E-\u0431\u044B\u0442\u043E\u0432\u044B\u0445 \u0443\u0441\u043B\u043E\u0432\u0438\u0439 (\u0440\u0430\u0441\u043F\u043E\u0440\u044F\u0434\u043E\u043A \u043F\u043E\u0441\u0435\u0449\u0435\u043D\u0438\u044F \u0441\u0442\u043E\u043B\u043E\u0432\u043E\u0439, \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u043E\u0433\u043E \u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u0430, \u0440\u0430\u0441\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u0431\u044B\u0442\u043E\u0432\u044B\u0445 \u043F\u043E\u043C\u0435\u0449\u0435\u043D\u0438\u0439 \u0438 \u043A\u0430\u0431\u0438\u043D\u0435\u0442\u043E\u0432 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432, \u0441\u0438\u0441\u0442\u0435\u043C\u0430 \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430 \u043D\u0430 \u0442\u0435\u0440\u0440\u0438\u0442\u043E\u0440\u0438\u044E, \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0435 \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u043E\u0439 \u0430\u0432\u0442\u043E\u0441\u0442\u043E\u044F\u043D\u043A\u043E\u0439, \u0441\u043F\u0438\u0441\u043E\u043A \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u043E\u0432, \u0438 \u0442.\u0434.)"],
    ["general", "\u0417\u043D\u0430\u043A\u043E\u043C\u0441\u0442\u0432\u043E \u0441 \u043A\u043E\u043B\u043B\u0435\u043A\u0442\u0438\u0432\u043E\u043C, \u0440\u0430\u0441\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u043C \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u044B\u0445 \u043F\u043E\u043C\u0435\u0449\u0435\u043D\u0438\u0439."],
    ["general", "\u041F\u0440\u0430\u0432\u0438\u043B\u0430 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0435\u0433\u043E \u0442\u0440\u0443\u0434\u043E\u0432\u043E\u0433\u043E \u0440\u0430\u0441\u043F\u043E\u0440\u044F\u0434\u043A\u0430, \u043E\u0431\u044F\u0437\u0430\u043D\u043D\u043E\u0441\u0442\u0438 \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u043E\u0432 \u0438 \u0440\u0430\u0431\u043E\u0442\u043E\u0434\u0430\u0442\u0435\u043B\u044F."],
    ["general", "\u0412\u0432\u043E\u0434\u043D\u044B\u0439 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436 \u043F\u043E \u043E\u0445\u0440\u0430\u043D\u0435 \u0442\u0440\u0443\u0434\u0430"],
    ["general", "\u0412\u0432\u043E\u0434\u043D\u044B\u0439 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436 \u043F\u043E \u043F\u043E\u0436\u0430\u0440\u043D\u043E\u0439 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438"],
    ["general", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436 \u043F\u043E \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438 (1 \u0433\u0440.)"],
    ["general", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436 \u043F\u043E \u043E\u0445\u0440\u0430\u043D\u0435 \u0442\u0440\u0443\u0434\u0430 \u043D\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u043C \u043C\u0435\u0441\u0442\u0435. \u041F\u043E\u0440\u044F\u0434\u043E\u043A \u043F\u0435\u0440\u0435\u043C\u0435\u0449\u0435\u043D\u0438\u044F \u043F\u043E \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u043C \u043F\u043E\u043C\u0435\u0449\u0435\u043D\u0438\u044F\u043C \u0438 \u0442\u0435\u0440\u0440\u0438\u0442\u043E\u0440\u0438\u0438. \u041E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430. \u041E\u0431\u0449\u0438\u0435 \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435. \u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u043E\u0445\u0440\u0430\u043D\u044B \u0442\u0440\u0443\u0434\u0430 \u043A \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430 \u0438 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u043C\u0443 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044E."],
    ["general", "\u041E\u043F\u0430\u0441\u043D\u044B\u0435 \u0438 \u0432\u0440\u0435\u0434\u043D\u044B\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0435 \u0444\u0430\u043A\u0442\u043E\u0440\u044B \u043D\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u043C \u043C\u0435\u0441\u0442\u0435, \u043C\u0435\u0440\u044B \u0437\u0430\u0449\u0438\u0442\u044B \u043E\u0442 \u0438\u0445 \u0432\u043E\u0437\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F."],
    ["general", "\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u0430\u044F \u043E\u0434\u0435\u0436\u0434\u0430, \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u0430\u044F \u043E\u0431\u0443\u0432\u044C \u0438 \u0438\u043D\u044B\u0435 \u0421\u0418\u0417 \u2013 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435, \u043F\u043E\u0440\u044F\u0434\u043E\u043A \u0438\u0445 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F, \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F, \u043E\u0431\u043C\u0435\u043D\u0430, \u0441\u0442\u0438\u0440\u043A\u0438, \u0441\u0440\u043E\u043A\u0438 \u043D\u043E\u0441\u043A\u0438. \u0421\u0440\u0435\u0434\u0441\u0442\u0432\u0430 \u0437\u0430\u0449\u0438\u0442\u044B \u043E\u0440\u0433\u0430\u043D\u043E\u0432 \u0434\u044B\u0445\u0430\u043D\u0438\u044F: \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435, \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A\u0438, \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435, \u0441\u043F\u043E\u0441\u043E\u0431\u044B \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438."],
    ["general", "\u041F\u0440\u0430\u0432\u0430 \u0438 \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0438 \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u043E\u0432 \u043F\u043E \u043E\u0445\u0440\u0430\u043D\u0435 \u0442\u0440\u0443\u0434\u0430. \u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u0441 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430\u043C\u0438 \u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0439 \u043E\u0446\u0435\u043D\u043A\u0438 \u0443\u0441\u043B\u043E\u0432\u0438\u0439 \u0442\u0440\u0443\u0434\u0430."],
    ["general", "\u041E\u0441\u043D\u043E\u0432\u044B \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438. \u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043C\u0430\u0448\u0438\u043D, \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435, \u0440\u0430\u0437\u043C\u0435\u0449\u0435\u043D\u0438\u0435."],
    ["general", "\u041F\u043E\u0436\u0430\u0440\u043D\u0430\u044F \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u044C. \u0421\u043F\u043E\u0441\u043E\u0431\u044B \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438\u043C\u0435\u044E\u0449\u0438\u0445\u0441\u044F \u043D\u0430 \u0443\u0447\u0430\u0441\u0442\u043A\u0435 \u0441\u0440\u0435\u0434\u0441\u0442\u0432 \u043F\u0435\u0440\u0432\u0438\u0447\u043D\u043E\u0433\u043E \u043F\u043E\u0436\u0430\u0440\u043E\u0442\u0443\u0448\u0435\u043D\u0438\u044F, \u043F\u0440\u043E\u0442\u0438\u0432\u043E\u0430\u0432\u0430\u0440\u0438\u0439\u043D\u043E\u0439 \u0437\u0430\u0449\u0438\u0442\u044B \u0438 \u0441\u0438\u0433\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438, \u043C\u0435\u0441\u0442\u0430 \u0438\u0445 \u0440\u0430\u0441\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u044F."],
    ["general", "\u041F\u043E\u0440\u044F\u0434\u043E\u043A \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u0430 \u0432 \u043C\u043E\u043C\u0435\u043D\u0442 \u0432\u043E\u0437\u043D\u0438\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u044F \u0430\u0432\u0430\u0440\u0438\u0438, \u0438\u043D\u0446\u0438\u0434\u0435\u043D\u0442\u0430."],
    ["general", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u0430 \u043F\u0440\u0438 \u043D\u0435\u0441\u0447\u0430\u0441\u0442\u043D\u043E\u043C \u0441\u043B\u0443\u0447\u0430\u0435. \u0421\u043F\u043E\u0441\u043E\u0431\u044B \u043E\u043A\u0430\u0437\u0430\u043D\u0438\u044F \u043F\u0435\u0440\u0432\u043E\u0439 \u043F\u043E\u043C\u043E\u0449\u0438 \u043F\u0440\u0438 \u043D\u0435\u0441\u0447\u0430\u0441\u0442\u043D\u044B\u0445 \u0441\u043B\u0443\u0447\u0430\u044F\u0445 \u043D\u0430 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435. \u0410\u043F\u0442\u0435\u0447\u043A\u0430 \u0434\u043B\u044F \u043E\u043A\u0430\u0437\u0430\u043D\u0438\u044F \u043F\u0435\u0440\u0432\u043E\u0439 \u043F\u043E\u043C\u043E\u0449\u0438 \u043F\u0440\u0438 \u043D\u0435\u0441\u0447\u0430\u0441\u0442\u043D\u044B\u0445 \u0441\u043B\u0443\u0447\u0430\u044F\u0445. \u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u0441 \u043C\u0435\u0441\u0442\u0430\u043C\u0438 \u0440\u0430\u0441\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0441\u0442\u0435\u043D\u0434\u043E\u0432 \u0441 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0435\u0439 \u043E \u0421\u043F\u0430\u0441\u0430\u0442\u0435\u043B\u044F\u0445 \u0437\u0430\u0432\u043E\u0434\u0430."],
    ["individual", "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u043D\u0430\u044F \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F. \u0420\u0430\u0437\u044A\u044F\u0441\u043D\u0435\u043D\u0438\u0435 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u043D\u044B\u0445 \u043E\u0431\u044F\u0437\u0430\u043D\u043D\u043E\u0441\u0442\u0435\u0439."],
    ["individual", "\u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u0441 \u0440\u0430\u0431\u043E\u0447\u0438\u043C \u043C\u0435\u0441\u0442\u043E\u043C. \u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u043E\u0445\u0440\u0430\u043D\u044B \u0442\u0440\u0443\u0434\u0430 \u043A \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430 \u0438 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u043C\u0443 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044E."],
    ["individual", "\u0418\u0437\u0443\u0447\u0435\u043D\u0438\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0439 \u043F\u043E \u043E\u0445\u0440\u0430\u043D\u0435 \u0442\u0440\u0443\u0434\u0430."],
    ["individual", "\u0418\u0437\u0443\u0447\u0435\u043D\u0438\u0435 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0438 \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0439 \u043F\u043E \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438"],
    ["individual", "\u041F\u043E\u0440\u044F\u0434\u043E\u043A \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0430 \u0440\u0430\u0431\u043E\u0442 \u043F\u043E\u0432\u044B\u0448\u0435\u043D\u043D\u043E\u0439 \u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438, \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u044F \u043D\u0430\u0440\u044F\u0434\u0430-\u0434\u043E\u043F\u0443\u0441\u043A\u0430 \u0438 \u043E\u0431\u044F\u0437\u0430\u043D\u043D\u043E\u0441\u0442\u0438 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u043D\u044B\u0445 \u043B\u0438\u0446, \u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0445 \u0437\u0430 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044E \u0438 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u043E \u0440\u0430\u0431\u043E\u0442."],
    ...["\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u044F \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0430", "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0445\u0440\u0430\u043D\u0430 \u0442\u0440\u0443\u0434\u0430", "\u041A\u0443\u0440\u0441 \u043F\u043E \u0411\u0435\u0440\u0435\u0436\u043B\u0438\u0432\u043E\u043C\u0443 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0443", "\u0422\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u043E \u041A\u043E\u0434\u0435\u043A\u0441\u0443 \u044D\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0430\u0432\u0438\u043B \u0438 \u043D\u043E\u0440\u043C", "\u0422\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u043E \u043A\u0430\u0436\u0434\u043E\u043C\u0443 \u0431\u043B\u043E\u043A\u0443 + \u043E\u0431\u0449\u0435\u0435 \u0442\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435"].map((s) => ["individual", "XPS-\u041F\u0440\u043E\u0444\u0438: " + s]),
    ["practice", "\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u043D\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u043C \u043C\u0435\u0441\u0442\u0435 (TWI): \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0421\u041E\u041F \u0438 \u043D\u0430\u0432\u044B\u043A"],
    ["knowledge", "\u041E\u0445\u0440\u0430\u043D\u0430 \u0442\u0440\u0443\u0434\u0430"],
    ["knowledge", "\u0422\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 XPS-\u041F\u0440\u043E\u0444\u0438"],
    ["knowledge", "\u041E\u0432\u043B\u0430\u0434\u0435\u043D\u0438\u0435 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u043C\u0438 \u043D\u0430\u0432\u044B\u043A\u0430\u043C\u0438 \u043D\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u043C \u043C\u0435\u0441\u0442\u0435 (\u0447\u0435\u043A-\u043B\u0438\u0441\u0442 TWI)"],
    ["knowledge", "\u0422\u0435\u043E\u0440\u0435\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0447\u0430\u0441\u0442\u044C: \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435, \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u043E, \u0411\u041F"]
  ].map(([part2, title]) => ({ part: part2, title, hours: 0, day_offset: 0 }));
  function previewCriteria(method, id) {
    return method.criteria.map((q) => ({ id: id + ":" + q.code, position: q.code, section_code: q.section || "SOP", question: q.question }));
  }

  // src/modules/training/corporate-forms.js
  var SCALE_NAME = "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F (1\u20134)";
  var CORPORATE_LEVELS = "1: \u041E\u0431\u0443\u0447\u0435\u043D\n2: \u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0440\u0430\u0431\u043E\u0442\u0443 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E\n3: \u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0440\u0430\u0431\u043E\u0442\u0443 \u043C\u0430\u0441\u0442\u0435\u0440\u0441\u043A\u0438\n4: \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A";
  var PRACTICAL_ROWS = [8, 9, 11, 12, 13, 14, 15, 16, 17, 18, 19];
  var dt = (x) => /* @__PURE__ */ new Date(x + "T00:00:00Z");
  function plusDays2(day, n) {
    const d = dt(day);
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  }
  function practicalCriteriaFromSheet(sheet2) {
    invariant(sheet2 && sheet2.name.trim().toLocaleLowerCase("ru-RU") === "\u0447\u0435\u043A \u043B\u0438\u0441\u0442", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043B\u0438\u0441\u0442 \xAB\u0427\u0435\u043A \u043B\u0438\u0441\u0442\xBB \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u043E\u0433\u043E XLSX");
    const sections = [sheet2.getCell("A7").text.trim(), sheet2.getCell("A10").text.trim()];
    invariant(sections.every(Boolean), "\u0412 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0435 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u044E\u0442 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u0438 \u0434\u0432\u0443\u0445 \u0440\u0430\u0437\u0434\u0435\u043B\u043E\u0432");
    const criteria = PRACTICAL_ROWS.map((r, i) => ({ code: i + 1, section: sections[r <= 9 ? 0 : 1], question: sheet2.getCell("A" + r).text.trim() }));
    invariant(criteria.every((x) => x.question) && new Set(criteria.map((x) => x.question)).size === 11, "\u041D\u0443\u0436\u043D\u043E 11 \u0440\u0430\u0437\u043D\u044B\u0445 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u044B\u0445 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0430");
    return criteria;
  }
  function calendarData(start, tasks) {
    const days = [...new Set(tasks.map((t) => t.day_offset))].sort((a, b) => a - b).map((i) => ({ offset: i, date: plusDays2(start, i), hours: tasks.filter((t) => t.day_offset === i).reduce((n, t) => n + t.hours, 0) }));
    return { days, total: tasks.reduce((n, t) => n + t.hours, 0) };
  }
  function calendarFacts(start, tasks, facts = []) {
    const plan = calendarData(start, tasks), map = new Map(plan.days.map((d) => [d.date, { date: d.date, planned: d.hours, actual: 0, plannedTasks: tasks.filter((t) => t.day_offset === d.offset).map((t) => t.title), actualTasks: [] }]));
    for (const x of facts) {
      if (!map.has(x.date)) map.set(x.date, { date: x.date, planned: 0, actual: 0, plannedTasks: [], actualTasks: [] });
      const d = map.get(x.date);
      d.actual += x.minutes / 60;
      if (!d.actualTasks.includes(x.title)) d.actualTasks.push(x.title);
    }
    return [...map.values()].sort((a, b) => a.date.localeCompare(b.date));
  }
  function matrixPoints(matrix, people, skills, scaleId, personalGoals = []) {
    const goals = /* @__PURE__ */ new Map();
    for (const g of personalGoals) {
      if (g.scale_id !== scaleId) continue;
      const k = g.person_id + ":" + g.skill_id;
      goals.set(k, Math.max(goals.get(k) ?? 0, g.target_level));
    }
    const cells2 = /* @__PURE__ */ new Map(), byPerson = /* @__PURE__ */ new Map(), bySkill = /* @__PURE__ */ new Map();
    const empty3 = () => ({ actual: 0, rated: 0, target: 0, targeted: 0, need: 0, unknown: 0, other: 0 });
    function add2(a, x) {
      a.actual += x.actual ?? 0;
      a.rated += x.actual === null ? 0 : 1;
      a.target += x.target ?? 0;
      a.targeted += x.target === null ? 0 : 1;
      a.need += x.need ?? 0;
      a.unknown += x.target !== null && x.actual === null ? 1 : 0;
      a.other += x.other ? 1 : 0;
    }
    for (const p of people) {
      byPerson.set(p.id, empty3());
      for (const s of skills) {
        if (!bySkill.has(s.id)) bySkill.set(s.id, empty3());
        const c = matrix.cells.get(p.id + ":" + s.id), fact = c?.fact;
        const actual = c?.valid && c.revisionCurrent && fact.scale_id === scaleId && [1, 2, 3, 4].includes(fact.level) ? fact.level : null;
        const required2 = c?.goal?.scale_id === scaleId && [1, 2, 3, 4].includes(c.goal.required_level) ? c.goal.required_level : null;
        const personal = goals.get(p.id + ":" + s.id) ?? null;
        const target = personal === null ? required2 : required2 === null ? personal : Math.max(personal, required2);
        const x = { actual, target, need: actual === null || target === null ? null : Math.max(0, target - actual), other: !!(fact && fact.scale_id !== scaleId) };
        cells2.set(p.id + ":" + s.id, x);
        add2(byPerson.get(p.id), x);
        add2(bySkill.get(s.id), x);
      }
    }
    return { cells: cells2, byPerson, bySkill };
  }
  function personalTargets(db, day, horizon) {
    return rows(db, "SELECT p.person_id,g.skill_id,g.target_json FROM development_goal g JOIN development_plan p ON p.id=g.plan_id WHERE p.state='active' AND g.state='open' AND p.start_on<=? AND g.due_on<=? AND g.skill_id IS NOT NULL", [day, horizon]).map((x) => ({ person_id: x.person_id, skill_id: x.skill_id, ...JSON.parse(x.target_json) }));
  }
  var productionHeaders = ["\u2116 \u043F/\u043F", "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", "\u0424.\u0418.\u041E. \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430", "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0421\u041E\u041F", "\u0424.\u0418.\u041E. \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E", "\u0414\u0430\u0442\u0430 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", "\u0412\u0440\u0435\u043C\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C, \u0447:\u043C\u043C", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439"];
  function productionRows(assignments, facts, label) {
    const map = /* @__PURE__ */ new Map();
    for (const fact of facts) {
      if (!map.has(fact.assignment_id)) map.set(fact.assignment_id, []);
      map.get(fact.assignment_id).push(fact);
    }
    const out = [];
    for (const a of assignments) {
      const names3 = JSON.parse(a.recorded_names_json || "{}"), base = [label.unit(a), names3.instructor || label.person(a.mentor_id), label.revision(a.sop_revision_id), names3.trainee || label.person(a.trainee_id)];
      const events = map.get(a.id) || [];
      if (!events.length) out.push({ assignment: a, fact: null, facts: [], values: [...base, null, null, null, "", ""] });
      else {
        const byDay = /* @__PURE__ */ new Map();
        for (const e of events.slice().sort((x, y) => x.held_at.localeCompare(y.held_at))) {
          const d = e.held_at.slice(0, 10);
          if (!byDay.has(d)) byDay.set(d, []);
          byDay.get(d).push(e);
        }
        for (const [date3, facts2] of byDay) {
          const first = facts2[0];
          out.push({ assignment: a, fact: first, facts: facts2, values: [...base, date3, first.held_at.slice(11, 16), facts2.reduce((n, f) => n + f.duration_minutes, 0) / 1440, "", ""] });
        }
      }
    }
    return out;
  }
  var thin = { style: "thin", color: { argb: "FFB4B4B4" } };
  var border = { top: thin, bottom: thin, left: thin, right: thin };
  function sheet(book, name, widths, paperSize = 9) {
    const s = book.addWorksheet(name, { pageSetup: { orientation: "landscape", paperSize, fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: 0.3, right: 0.3, top: 0.35, bottom: 0.35, header: 0.15, footer: 0.15 } } });
    s.columns = widths.map((width) => ({ width }));
    return s;
  }
  function merge(s, r, c1, c2, value, bold = false) {
    if (c2 > c1) s.mergeCells(r, c1, r, c2);
    const c = s.getCell(r, c1);
    c.value = value;
    c.font = { name: "Arial", size: 11, bold };
    c.alignment = { vertical: "middle", wrapText: true, horizontal: "left" };
  }
  function header(s, r, last) {
    for (let c = 1; c <= last; c++) {
      const x = s.getCell(r, c);
      x.font = { name: "Arial", size: 10, bold: true };
      x.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE7E9EC" } };
      x.border = border;
      x.alignment = { vertical: "middle", horizontal: "center", wrapText: true };
    }
    s.getRow(r).height = 32;
  }
  function cells(s, r, values) {
    values.forEach((v, i) => {
      const x = s.getCell(r, i + 1);
      x.value = v ?? null;
      x.font = { name: "Arial", size: 10 };
      x.border = border;
      x.alignment = { vertical: "middle", wrapText: true, horizontal: i === 0 ? "center" : "left" };
    });
    s.getRow(r).height = Math.max(23, Math.min(90, 15 * Math.ceil(Math.max(1, ...values.map((x) => typeof x === "string" ? x.length / 35 : 1)))));
  }
  function productionWorkbook(ExcelJS2, records, { title = "\u041F\u043B\u0430\u043D \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", organization = "", scope = "", date: date3 = "", approver = "" } = {}) {
    const w = new ExcelJS2.Workbook(), s = sheet(w, "\u041F\u043B\u0430\u043D \u0438 \u0440\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F", [7, 25, 25, 43, 25, 15, 12, 15, 17, 17]);
    merge(s, 1, 1, 10, title, true);
    merge(s, 2, 1, 10, organization);
    merge(s, 3, 1, 6, scope);
    merge(s, 3, 7, 10, "\u0414\u0430\u0442\u0430: " + date3);
    merge(s, 4, 1, 6, "\u0423\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0439: " + (approver || "________________"));
    merge(s, 4, 7, 10, "\u041F\u043E\u0434\u043F\u0438\u0441\u044C: ________________");
    merge(s, 5, 1, 5, "\u041F\u043B\u0430\u043D", true);
    merge(s, 5, 6, 10, "\u0420\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F", true);
    header(s, 5, 10);
    productionHeaders.forEach((x, i) => s.getCell(6, i + 1).value = i >= 8 ? "\u041F\u043E\u0434\u043F\u0438\u0441\u044C " + x.toLocaleLowerCase("ru-RU") : x);
    header(s, 6, 10);
    records.forEach((x, i) => {
      cells(s, i + 7, [i + 1, ...x.values]);
      s.getCell(i + 7, 8).numFmt = "[h]:mm";
    });
    s.pageSetup.printTitlesRow = "5:6";
    s.pageSetup.printArea = "A1:J" + (records.length + 8);
    s.views = [{ state: "frozen", ySplit: 6 }];
    merge(s, records.length + 8, 1, 10, "\u0421\u0442\u0440\u043E\u043A\u0430 \u0444\u0430\u043A\u0442\u0430 \u2014 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0437\u0430 \u0434\u0435\u043D\u044C: \u043F\u0435\u0440\u0432\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u0438 \u0441\u0443\u043C\u043C\u0430 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043C\u0438\u043D\u0443\u0442. \u041F\u043E\u0434\u043F\u0438\u0441\u0438 \u043F\u0443\u0441\u0442\u044B\u0435. \u041E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0435 \u044D\u0442\u0430\u043F\u044B \u2014 \u043D\u0430 \u0432\u0442\u043E\u0440\u043E\u043C \u043B\u0438\u0441\u0442\u0435.");
    const detail = sheet(w, "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438 \u0444\u0430\u043A\u0442\u044B", [25, 25, 42, 15, 15, 23, 23, 15, 15, 45, 16, 16]);
    cells(detail, 1, ["\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0421\u041E\u041F \u0438 \u0432\u0435\u0440\u0441\u0438\u044F", "\u041D\u0430\u0447\u0430\u043B\u043E \u043F\u043B\u0430\u043D\u0430", "\u0421\u0440\u043E\u043A \u043F\u043B\u0430\u043D\u0430", "\u0421\u0442\u0430\u0442\u0443\u0441", "\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u044D\u0442\u0430\u043F", "\u0414\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F", "\u041C\u0438\u043D\u0443\u0442", "\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435", "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430", "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E"]);
    header(detail, 1, 12);
    let detailRow = 2;
    for (const x of records) for (const fact of x.facts.length ? x.facts : [null]) cells(detail, detailRow++, [x.values[1], x.values[3], x.values[2], x.assignment.assigned_on, x.assignment.due_on, x.assignment.state, fact ? JSON.parse(fact.steps_json).label : "", fact?.held_at || "", fact?.duration_minutes ?? null, fact?.notes || "", fact?.mentor_ack ? "\u0414\u0430" : "", fact?.trainee_ack ? "\u0414\u0430" : ""]);
    return w;
  }
  function entryWorkbook(ExcelJS2, program, enrollment, tasks, { organization = "", scope = "", trainee = "", mentor = "", manager = "", revision: revision2 = () => "", responsible = () => "", facts = [] } = {}) {
    const cal = calendarData(enrollment.start_on, tasks), w = new ExcelJS2.Workbook(), dayCount = Math.max(1, cal.days.length), last = 3 + dayCount + 1;
    const s = sheet(w, "\u041F\u043B\u0430\u043D \u0432\u0432\u043E\u0434\u0430", [7, 45, 40, ...Array(dayCount).fill(13), 16], 8);
    merge(s, 1, 1, last, "\u041F\u043B\u0430\u043D \u0432\u0432\u043E\u0434\u0430 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E \xB7 " + program.title, true);
    merge(s, 2, 1, last, organization + " \xB7 " + scope);
    merge(s, 3, 1, last, "\u0424\u0418\u041E: " + trainee + " \xB7 \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A: " + mentor + " \xB7 \u0420\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C: " + manager);
    merge(s, 4, 1, last, "\u041F\u0435\u0440\u0438\u043E\u0434: " + enrollment.start_on + " \u2014 " + enrollment.due_on + " \xB7 \u0412\u0435\u0440\u0441\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B " + program.version_no);
    if (enrollment.internship_start) merge(s, 5, 1, last, "\u0421\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0430: " + enrollment.internship_start + " \u2014 " + enrollment.internship_end + " \xB7 \u0412\u0432\u043E\u0434: " + enrollment.entry_start + " \u2014 " + enrollment.entry_end);
    const dates = cal.days.length ? cal.days : [{ offset: 0, date: enrollment.start_on, hours: 0 }];
    cells(s, 6, ["\u2116", "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u043D\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u0438", "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0421\u041E\u041F", ...dates.map((d) => d.offset + 1), "\u0418\u0442\u043E\u0433\u043E \u0447\u0430\u0441\u043E\u0432"]);
    header(s, 6, last);
    cells(s, 7, ["", "", "\u0414\u0430\u0442\u0430", ...dates.map((d) => dt(d.date)), ""]);
    for (let j = 4; j < last; j++) s.getCell(7, j).numFmt = "dd.mm.yyyy";
    tasks.forEach((t, i) => {
      const row = i + 8, values = [i + 1, t.title, t.sop_revision_id ? revision2(t.sop_revision_id) : "", ...dates.map((d) => d.offset === t.day_offset ? t.hours : null)];
      cells(s, row, [...values, 0]);
      s.getCell(row, last).value = { formula: "SUM(" + s.getCell(row, 4).address + ":" + s.getCell(row, last - 1).address + ")", result: t.hours };
      s.getCell(row, last).numFmt = "0.##";
    });
    const total = tasks.length + 8;
    cells(s, total, ["", "\u0418\u0442\u043E\u0433\u043E \u0447\u0430\u0441\u043E\u0432", "", ...dates.map((d) => d.hours), cal.total]);
    for (let col = 4; col <= last; col++) {
      const result = col === last ? cal.total : dates[col - 4].hours;
      s.getCell(total, col).value = tasks.length ? { formula: "SUM(" + s.getCell(8, col).address + ":" + s.getCell(total - 1, col).address + ")", result } : 0;
    }
    header(s, total, last);
    s.pageSetup.printTitlesRow = "6:7";
    s.views = [{ state: "frozen", xSplit: 3, ySplit: 7 }];
    const detail = sheet(w, "\u0417\u0430\u0434\u0430\u043D\u0438\u044F \u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B", [22, 47, 38, 16, 15, 25, 22, 43, 20, 20]);
    cells(detail, 1, ["\u0427\u0430\u0441\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", "\u0417\u0430\u0434\u0430\u043D\u0438\u0435", "\u0421\u041E\u041F", "\u0421\u0440\u043E\u043A", "\u0427\u0430\u0441\u044B", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 (\u0444\u0430\u043A\u0442)", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", "\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 / \u043E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C", "\u041F\u043E\u0434\u043F\u0438\u0441\u044C \u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E", "\u041F\u043E\u0434\u043F\u0438\u0441\u044C \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u0433\u043E"]);
    header(detail, 1, 10);
    tasks.forEach((t, i) => cells(detail, i + 2, [t.part, t.title, t.sop_revision_id ? revision2(t.sop_revision_id) : "", plusDays2(enrollment.start_on, t.day_offset), t.hours, responsible(t), t.done ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E" : "\u041D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E", t.result?.evidence || "", "", ""]));
    const factSheet = sheet(w, "\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u044C \u043F\u043B\u0430\u043D \u0438 \u0444\u0430\u043A\u0442", [15, 45, 15, 45, 15]);
    cells(factSheet, 1, ["\u0414\u0430\u0442\u0430", "\u041F\u043B\u0430\u043D\u043E\u0432\u044B\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F", "\u041F\u043B\u0430\u043D, \u0447", "\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F", "\u0424\u0430\u043A\u0442, \u0447"]);
    header(factSheet, 1, 5);
    calendarFacts(enrollment.start_on, tasks, facts).forEach((x, i) => cells(factSheet, i + 2, [x.date, x.plannedTasks.join("; "), x.planned, x.actualTasks.join("; "), Math.round(x.actual * 100) / 100]));
    return w;
  }
  function practicalWorkbook(ExcelJS2, method, assessments, { trainee = "", title = "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043E\u0446\u0435\u043D\u043A\u0438 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u0441\u0442\u0430\u0436\u0451\u0440\u043E\u043C" } = {}) {
    invariant(assessments.length > 0 && assessments.length <= 100 && method.criteria.length >= 1 && method.criteria.length <= 100, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043E\u0442 1 \u0434\u043E 100 \u043E\u0446\u0435\u043D\u043E\u043A \u043E\u0434\u043D\u043E\u0439 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438");
    const w = new ExcelJS2.Workbook(), s = sheet(w, "\u0427\u0435\u043A \u043B\u0438\u0441\u0442", [83, ...assessments.map(() => 23)], 8), last = assessments.length + 1;
    merge(s, 1, 1, last, title, true);
    merge(s, 2, 1, last, "\u0421\u0442\u0430\u0436\u0451\u0440: " + trainee);
    merge(s, 3, 1, last, "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430: " + method.title + " \xB7 SHA-256 " + method.source_sha256);
    cells(s, 4, ["\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F / \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F", ...assessments.map((x) => x.operation)]);
    header(s, 4, last);
    cells(s, 5, ["\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u0441\u0442\u0430\u0436\u0451\u0440\u0430", ...assessments.map(() => null)]);
    cells(s, 6, ["\u0411\u0430\u043B\u043B\u044B", ...assessments.map(() => null)]);
    const total = method.criteria.length, criterionRows = [];
    let row = 7, previous = null;
    for (const [i2, q] of method.criteria.entries()) {
      if (q.section !== previous) {
        merge(s, row, 1, last, q.section, true);
        header(s, row, last);
        row++;
        previous = q.section;
      }
      criterionRows.push(row);
      cells(s, row++, [q.question, ...assessments.map((x) => x.responses[i2]?.value ?? null)]);
    }
    assessments.forEach((a, i2) => {
      const col = i2 + 2, refs = criterionRows.map((r) => s.getCell(r, col).address).join(","), values = a.responses.map((x) => x.value), sum = values.reduce((n, v) => n + (v === 1 ? 1 : 0), 0), valid = values.length === total && values.every((v) => v === 0 || v === 1);
      s.getCell(6, col).value = { formula: "IF(COUNT(" + refs + ")=" + total + ",SUM(" + refs + '),"")', result: valid ? sum : "" };
      s.getCell(5, col).value = { formula: "IF(COUNT(" + refs + ")=" + total + "," + s.getCell(6, col).address + "/" + total + ',"")', result: valid ? sum / total : "" };
      s.getCell(5, col).numFmt = "0.0%";
    });
    cells(s, row++, ["\u041D\u0430\u0434 \u0447\u0435\u043C \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0443 \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C? / \u043E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C", ...assessments.map((x) => x.feedback)]);
    cells(s, row++, ["\u0417\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 (\u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u0435)", ...assessments.map((x) => x.conclusion)]);
    cells(s, row++, ["\u0414\u0430\u0442\u0430 / \u043E\u0446\u0435\u043D\u0449\u0438\u043A", ...assessments.map((x) => x.date + " \xB7 " + x.evaluator)]);
    const notes = sheet(w, "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0438", [35, 8, 70, 50]);
    cells(notes, 1, ["\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", "\u2116", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"]);
    header(notes, 1, 4);
    let i = 2;
    for (const a of assessments) for (let j = 0; j < total; j++) cells(notes, i++, [a.operation, j + 1, method.criteria[j].question, a.responses[j]?.note || ""]);
    s.pageSetup.printArea = "A1:" + s.getCell(row - 1, last).address;
    s.views = [{ state: "frozen", xSplit: 1, ySplit: 6 }];
    return w;
  }
  function criteriaFromTabularSheet(sheet2) {
    invariant(sheet2 && sheet2.getCell("A1").text.trim() === "\u2116" && sheet2.getCell("B1").text.trim() === "\u0420\u0430\u0437\u0434\u0435\u043B" && sheet2.getCell("C1").text.trim() === "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041D\u0443\u0436\u0435\u043D \u043B\u0438\u0441\u0442 \xAB\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438\xBB: \u2116 / \u0420\u0430\u0437\u0434\u0435\u043B / \u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439");
    invariant(sheet2.rowCount <= 101, "\u0414\u043E 100 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    const result = [];
    for (let r = 2; r <= sheet2.rowCount; r++) {
      const code = sheet2.getCell(r, 1).text.trim(), section = sheet2.getCell(r, 2).text.trim(), question = sheet2.getCell(r, 3).text.trim();
      if (!code && !section && !question) continue;
      invariant(Number(code) === result.length + 1 && section && question, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440, \u0440\u0430\u0437\u0434\u0435\u043B \u0438 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0439 \u0432 \u0441\u0442\u0440\u043E\u043A\u0435 " + r);
      result.push({ code: Number(code), section, question });
    }
    invariant(result.length > 0, "\u041D\u0435\u0442 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432");
    return result;
  }

  // src/modules/training/matrix-view.js
  var LEVEL_COLORS = { 1: "D9E2F3", 2: "FFFF00", 3: "FFD966", 4: "FF7C80" };
  var LEVEL_TEXT = { 1: "\u041E\u0431\u0443\u0447\u0435\u043D", 2: "\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0440\u0430\u0431\u043E\u0442\u0443 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E", 3: "\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0440\u0430\u0431\u043E\u0442\u0443 \u043C\u0430\u0441\u0442\u0435\u0440\u0441\u043A\u0438", 4: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A" };
  var matrixKey = (p, s) => p + ":" + s;
  function matrixRoster(db, day, unit = "", shift = "", profession = "") {
    const units = new Set(unit ? rows(db, "WITH RECURSIVE scope(id) AS (SELECT ? UNION SELECT u.id FROM org_unit u JOIN scope s ON u.parent_id=s.id) SELECT id FROM scope", [unit]).map((x) => x.id) : []);
    const assigned = rows(db, "SELECT a.* FROM person_assignment a WHERE a.id=(SELECT id FROM person_assignment b WHERE b.person_id=a.person_id AND b.valid_from<=? AND coalesce(b.valid_to,'9999-12-31')>=? ORDER BY b.valid_from DESC,b.id LIMIT 1)", [day, day]);
    const assignments = new Map(assigned.map((a) => [a.person_id, a]));
    return directoryPeople(db, day).filter((p) => {
      const a = assignments.get(p.id);
      return a && (!unit || units.has(a.unit_id)) && (!shift || a.shift_id === shift) && (!profession || a.profession_id === profession);
    }).map((p) => ({ person_id: p.id, name: p.display_name, position: p.position, instructor: p.roles.some((x) => ["instructor", "mentor"].includes(x.kind) || [x.code, x.name].some((v) => ["internal_trainer", "internal trainer", "\u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440", "\u0432\u0442"].includes(String(v).toLocaleLowerCase("ru-RU").trim().replaceAll("-", "_")))) }));
  }
  function columnChoices(db, unit = "", workplace = "", category = "") {
    const units = new Set(unit ? rows(db, "WITH RECURSIVE scope(id) AS (SELECT ? UNION SELECT u.id FROM org_unit u JOIN scope s ON u.parent_id=s.id) SELECT id FROM scope", [unit]).map((x) => x.id) : []);
    const ops = new Map(rows(db, "SELECT * FROM operation WHERE archived=0").filter((o) => (!unit || units.has(o.unit_id)) && (!workplace || o.workplace_id === workplace)).map((o) => [o.id, o]));
    const docs = rows(db, "SELECT d.id,d.code,d.title,d.operation_id FROM document d JOIN document_revision r ON r.document_id=d.id WHERE d.kind='sop' AND d.archived=0 AND r.state='effective' ORDER BY d.code,d.title").filter((d) => ops.has(d.operation_id));
    const skills = rows(db, "SELECT s.*,c.name category FROM skill s JOIN skill_category c ON c.id=s.category_id WHERE s.archived=0 AND c.archived=0 ORDER BY c.name,s.name");
    const out = [];
    for (const d of docs) {
      const all = skills.filter((s) => s.operation_id === d.operation_id), matching = all.filter((s) => !category || s.category_id === category);
      for (const s of matching) out.push({ key: s.id + ":" + d.id, skill_id: s.id, document_id: d.id, title: d.code + " \xB7 " + d.title, skill: s.name, operation_id: d.operation_id });
      if (!all.length && !category) out.push({ key: "new:" + d.id, skill_id: null, document_id: d.id, title: d.code + " \xB7 " + d.title, skill: "\u0411\u0443\u0434\u0435\u0442 \u0441\u043E\u0437\u0434\u0430\u043D \u043D\u0430\u0432\u044B\u043A \u0438\u0437 \u0421\u041E\u041F", operation_id: d.operation_id });
    }
    if (!workplace) for (const s of skills.filter((s2) => !s2.operation_id && (!category || s2.category_id === category))) out.push({ key: s.id, skill_id: s.id, document_id: null, title: s.name, skill: s.category, operation_id: null });
    return out;
  }
  function factValue(db, m, p, c, scaleId) {
    const x = m.cells.get(matrixKey(p, c.skill_id)), fact = x?.fact;
    const doc = fact?.standard_revision_id ? one(db, "SELECT document_id FROM document_revision WHERE id=?", [fact.standard_revision_id]) : null;
    const matches = !c.document_id || doc?.document_id === c.document_id;
    const value = x?.valid && x.revisionCurrent && fact.scale_id === scaleId && matches && [1, 2, 3, 4].includes(fact.level) ? fact.level : null;
    let reason = !fact ? "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E" : fact.observation_state === "not_applicable" ? "\u041D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E" : fact.observation_state === "not_observed" ? "\u041D\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u043B\u043E\u0441\u044C" : fact.scale_id !== scaleId ? "\u0414\u0440\u0443\u0433\u0430\u044F \u0448\u043A\u0430\u043B\u0430" : !matches ? "\u0414\u0440\u0443\u0433\u043E\u0439 \u0421\u041E\u041F" : !x.valid ? "\u0418\u0441\u0442\u0451\u043A \u0441\u0440\u043E\u043A \u043E\u0446\u0435\u043D\u043A\u0438" : !x.revisionCurrent ? "\u041F\u0440\u0435\u0436\u043D\u044F\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F \u0421\u041E\u041F" : value === null ? "\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0432\u043D\u0435 \u0448\u043A\u0430\u043B\u044B" : "";
    return { value, reason, fact, x };
  }
  function matrixBaseline(db, roster, columns, scaleId, day) {
    const m = matrixData(db, day);
    return roster.flatMap((r) => columns.map((c) => {
      const x = factValue(db, m, r.person_id, c, scaleId);
      return { person_id: r.person_id, skill_id: c.skill_id, value: x.value, assessment_id: x.value === null ? null : x.fact.session_id };
    }));
  }
  var empty = () => ({ base: 0, baseCount: 0, actual: 0, actualCount: 0, target: 0, targetCount: 0, need: 0, needCount: 0, unknown: 0, planned: 0 });
  function aggregate(a, x) {
    for (const [k, count] of [["base", "baseCount"], ["actual", "actualCount"], ["target", "targetCount"], ["need", "needCount"]]) if (x[k] !== null) {
      a[k] += x[k];
      a[count]++;
    }
    if (x.targetLevel !== null && x.actual === null) a.unknown++;
    if (x.explicit !== null) a.planned++;
  }
  function matrixProjection(db, config, day) {
    const { roster, columns, scale_id, target_on, baseline = [] } = config, m = matrixData(db, day), base = new Map(baseline.map((x) => [matrixKey(x.person_id, x.skill_id), x.value])), goals = /* @__PURE__ */ new Map();
    for (const g of personalTargets(db, day, target_on)) if (g.scale_id === scale_id && [1, 2, 3, 4].includes(g.target_level)) {
      const k = matrixKey(g.person_id, g.skill_id);
      goals.set(k, Math.max(goals.get(k) || 0, g.target_level));
    }
    const cells2 = /* @__PURE__ */ new Map(), byPerson = new Map(roster.map((r) => [r.person_id, empty()])), bySkill = new Map(columns.map((c) => [c.skill_id, empty()])), total = empty();
    for (const r of roster) for (const c of columns) {
      const k = matrixKey(r.person_id, c.skill_id), v = factValue(db, m, r.person_id, c, scale_id), actual = v.value;
      const explicit = goals.get(k) ?? null, required2 = v.x?.goal?.scale_id === scale_id && [1, 2, 3, 4].includes(v.x.goal.required_level) ? v.x.goal.required_level : null;
      const targetLevel = explicit === null ? required2 : required2 === null ? explicit : Math.max(explicit, required2);
      const target = actual === null ? targetLevel : targetLevel === null ? actual : Math.max(actual, targetLevel), need = actual === null ? null : Math.max(0, (targetLevel ?? actual) - actual);
      const x = { base: base.get(k) ?? null, actual, target, need, explicit, required: required2, targetLevel, reason: v.reason, admission: v.x?.admission?.status || "", fact: v.fact };
      cells2.set(k, x);
      aggregate(byPerson.get(r.person_id), x);
      aggregate(bySkill.get(c.skill_id), x);
      aggregate(total, x);
    }
    return { cells: cells2, byPerson, bySkill, total };
  }
  function matrixFromRecord(row) {
    return { ...row, roster: JSON.parse(row.roster_json), columns: JSON.parse(row.columns_json), baseline: JSON.parse(row.baseline_json) };
  }
  function matrixWorkbook(ExcelJS2, config, projection, day) {
    const { roster, columns } = config, n = columns.length, right = n + 4, last = right + 3;
    const w = new ExcelJS2.Workbook(), s = w.addWorksheet("\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", { pageSetup: { paperSize: 8, orientation: "landscape", fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
    s.columns = [{ width: 6 }, { width: 30 }, { width: 26 }, ...columns.map(() => ({ width: 8 })), ...Array.from({ length: 4 }, () => ({ width: 14 }))];
    const set = (sheet2, r, c, value, fill = null, bold = false) => {
      const x = sheet2.getCell(r, c);
      x.value = value ?? null;
      x.font = { name: "Arial", size: 10, bold };
      x.alignment = { vertical: "middle", horizontal: "center", wrapText: true };
      const b = { style: "thin", color: { argb: "FFB4B4B4" } };
      x.border = { top: b, bottom: b, left: b, right: b };
      if (fill) x.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF" + fill } };
      return x;
    };
    const merge2 = (r, a, b, v) => {
      s.mergeCells(r, a, r, b);
      set(s, r, a, v, "E7E9EC", true);
    };
    merge2(1, 1, last, config.title || "\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439");
    merge2(2, 1, last, "\u0412\u0435\u0440\u0441\u0438\u044F " + (config.version_no || "\u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440") + " \xB7 \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0440\u0435\u0437 " + config.base_on + " \xB7 \u0424\u0430\u043A\u0442 " + day + " \xB7 \u0426\u0435\u043B\u044C " + config.target_on);
    merge2(3, 1, last, "\u0423\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E: ____________________     \u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u043B: " + (config.author_name || "____________________") + "     \u041F\u043E\u0434\u043F\u0438\u0441\u0438: ____________________");
    merge2(4, 1, last, "\u041E\u0446\u0435\u043D\u043A\u0438 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0435, \u043F\u0443\u0441\u0442\u0430\u044F \u044F\u0447\u0435\u0439\u043A\u0430 \u2014 \u043D\u0435\u0442 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u0438\u043C\u043E\u0433\u043E \u0444\u0430\u043A\u0442\u0430. \u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C \u2014 \u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u043F\u0440\u0438\u0440\u043E\u0441\u0442 \u0431\u0430\u043B\u043B\u043E\u0432, \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E \u043E\u0442\u043C\u0435\u0447\u0435\u043D\u044B \u0446\u0435\u043B\u0438 \u0431\u0435\u0437 \u0444\u0430\u043A\u0442\u0430.");
    for (const [i, h] of ["\u2116", "\u0424\u0418\u041E", "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C"].entries()) {
      s.mergeCells(5, i + 1, 6, i + 1);
      set(s, 5, i + 1, h, "E7E9EC", true);
    }
    columns.forEach((c, i) => {
      s.mergeCells(5, i + 4, 6, i + 4);
      const x = set(s, 5, i + 4, c.title, "F2F2F2", true);
      x.alignment = { vertical: "middle", horizontal: "center", textRotation: 90, wrapText: true };
    });
    merge2(5, right, right + 2, "\u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
    s.mergeCells(5, last, 6, last);
    set(s, 5, last, "\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430", "FFCCFF", true);
    [config.base_on, day, config.target_on].forEach((d, i) => set(s, 6, right + i, d, "FFCCCC", true));
    s.getRow(5).height = 125;
    s.getRow(6).height = 27;
    const sheets = { base: w.addWorksheet("\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0440\u0435\u0437"), target: w.addWorksheet("\u0426\u0435\u043B\u0435\u0432\u044B\u0435 \u0443\u0440\u043E\u0432\u043D\u0438"), need: w.addWorksheet("\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438"), details: w.addWorksheet("\u0420\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043A\u0430") };
    for (const [k, a] of Object.entries(sheets).filter(([k2]) => k2 !== "details")) {
      a.columns = [{ width: 30 }, ...columns.map(() => ({ width: 18 }))];
      a.addRow(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ...columns.map((c) => c.title)]);
      a.views = [{ state: "frozen", xSplit: 1, ySplit: 1 }];
    }
    sheets.details.columns = [{ width: 28 }, { width: 45 }, { width: 14 }, { width: 14 }, { width: 14 }, { width: 18 }, { width: 28 }, { width: 30 }];
    sheets.details.addRow(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0421\u041E\u041F / \u043D\u0430\u0432\u044B\u043A", "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439", "\u0424\u0430\u043A\u0442", "\u0426\u0435\u043B\u044C", "\u0418\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u043F\u0440\u0438\u0440\u043E\u0441\u0442", "\u041F\u0440\u0438\u0447\u0438\u043D\u0430 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u044F \u0444\u0430\u043A\u0442\u0430", "\u0414\u043E\u043F\u0443\u0441\u043A"]);
    function sumCell(row, col, range, summary, k, fill = null) {
      const count = summary[k === "base" ? "baseCount" : k === "actual" ? "actualCount" : k === "target" ? "targetCount" : "needCount"];
      return set(s, row, col, { formula: "IF(COUNT(" + range + ')=0,"",SUM(' + range + "))", result: count ? summary[k] : "" }, fill, true);
    }
    const start = 7, end = start + roster.length - 1;
    roster.forEach((r, i) => {
      const rr = start + i, aux = i + 2, a = projection.byPerson.get(r.person_id);
      set(s, rr, 1, i + 1);
      set(s, rr, 2, r.name, null, r.instructor).alignment = { vertical: "middle", horizontal: "left", wrapText: true };
      set(s, rr, 3, r.position).alignment = { vertical: "middle", horizontal: "left", wrapText: true };
      for (const sh of [sheets.base, sheets.target, sheets.need]) set(sh, aux, 1, r.name);
      columns.forEach((c2, j) => {
        const x = projection.cells.get(matrixKey(r.person_id, c2.skill_id));
        const cell = set(s, rr, j + 4, x.actual, x.actual === null ? null : LEVEL_COLORS[x.actual]);
        if (x.targetLevel !== null && (x.need > 0 || x.actual === null)) {
          cell.border = { top: { style: "medium", color: { argb: "FFD02020" } }, bottom: { style: "medium", color: { argb: "FFD02020" } }, left: { style: "medium", color: { argb: "FFD02020" } }, right: { style: "medium", color: { argb: "FFD02020" } } };
          cell.note = "\u0426\u0435\u043B\u0435\u0432\u043E\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C: " + x.targetLevel;
        }
        set(sheets.base, aux, j + 2, x.base);
        set(sheets.target, aux, j + 2, x.target);
        set(sheets.need, aux, j + 2, x.need);
        sheets.details.addRow([r.name, c2.title, x.base, x.actual, x.targetLevel, x.need, x.reason, x.admission]);
      });
      const aa = (sh) => "'" + sh.name + "'!" + sh.getCell(aux, 2).address + ":" + sh.getCell(aux, n + 1).address;
      sumCell(rr, right, aa(sheets.base), a, "base");
      sumCell(rr, right + 1, s.getCell(rr, 4).address + ":" + s.getCell(rr, n + 3).address, a, "actual");
      sumCell(rr, right + 2, aa(sheets.target), a, "target");
      const c = sumCell(rr, last, aa(sheets.need), a, "need", "FFCCFF");
      if (a.unknown) c.note = "\u0426\u0435\u043B\u0435\u0439 \u0431\u0435\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0433\u043E \u0444\u0430\u043A\u0442\u0430: " + a.unknown;
      s.getRow(rr).height = 32;
    });
    const footer = [["\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F \xB7 " + config.base_on, "base", sheets.base], ["\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F \xB7 " + day, "actual", null], ["\u0426\u0435\u043B\u0435\u0432\u043E\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \xB7 " + config.target_on, "target", sheets.target], ["\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430 (\u0431\u0430\u043B\u043B\u044B)", "need", sheets.need]];
    footer.forEach(([label, k, sh], i) => {
      const rr = end + i + 1;
      s.mergeCells(rr, 1, rr, 3);
      set(s, rr, 1, label, i === 3 ? "FFCCFF" : "E7E9EC", true);
      columns.forEach((c, j) => {
        const a = projection.bySkill.get(c.skill_id), range = sh ? "'" + sh.name + "'!" + sh.getCell(2, j + 2).address + ":" + sh.getCell(roster.length + 1, j + 2).address : s.getCell(start, j + 4).address + ":" + s.getCell(end, j + 4).address;
        const cell = sumCell(rr, j + 4, range, a, k, i === 3 ? "FFCCFF" : "E7E9EC");
        if (i === 3 && a.unknown) cell.note = "\u0426\u0435\u043B\u0435\u0439 \u0431\u0435\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0433\u043E \u0444\u0430\u043A\u0442\u0430: " + a.unknown;
      });
      sumCell(rr, right + Math.min(i, 3), s.getCell(rr, 4).address + ":" + s.getCell(rr, n + 3).address, projection.total, k, i === 3 ? "FFCCFF" : "E7E9EC");
    });
    const legend = end + 6;
    Object.entries(LEVEL_TEXT).forEach(([v, label], i) => {
      set(s, legend + i, 1, Number(v), LEVEL_COLORS[v]);
      s.mergeCells(legend + i, 2, legend + i, Math.min(last, 8));
      set(s, legend + i, 2, label);
    });
    merge2(legend + 4, 1, last, "\u041A\u0440\u0430\u0441\u043D\u0430\u044F \u0440\u0430\u043C\u043A\u0430 \u2014 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435. \u0426\u0435\u043B\u0435\u0439 \u0431\u0435\u0437 \u0444\u0430\u043A\u0442\u0430: " + projection.total.unknown + ". \u0411\u0430\u043B\u043B\u044B \u043D\u0435 \u0440\u0430\u0432\u043D\u044B \u0447\u0438\u0441\u043B\u0443 \u0434\u043E\u043F\u0443\u0449\u0435\u043D\u043D\u044B\u0445 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432.");
    s.views = [{ state: "frozen", xSplit: 3, ySplit: 6 }];
    s.pageSetup.printTitlesRow = "5:6";
    s.pageSetup.printArea = "A1:" + s.getCell(legend + 4, last).address;
    return w;
  }

  // src/modules/training/matrix-assistant.js
  var normalizeMatrixText = (v) => String(v ?? "").normalize("NFKC").toLocaleLowerCase("ru-RU").replaceAll("\u0451", "\u0435").replace(/\s+/g, " ").trim();
  var columnIdentity = (c) => c.document_id ? c.skill_id + ":" + c.document_id : c.skill_id;
  function matrixCatalog(db, unit = "", workplace = "", category = "") {
    const ops = new Map(rows(db, "SELECT o.id,o.workplace_id,o.equipment_id,w.name workplace,e.name equipment FROM operation o LEFT JOIN workplace w ON w.id=o.workplace_id LEFT JOIN equipment e ON e.id=o.equipment_id").map((x) => [x.id, x]));
    const skills = new Map(rows(db, "SELECT s.id,c.name category FROM skill s JOIN skill_category c ON c.id=s.category_id").map((x) => [x.id, x.category]));
    const docs = new Map(rows(db, "SELECT id,code,title FROM document").map((x) => [x.id, x]));
    return columnChoices(db, unit, workplace, category).map((c) => ({ ...c, workplace: ops.get(c.operation_id)?.workplace || "\u0411\u0435\u0437 \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430", equipment: ops.get(c.operation_id)?.equipment || "\u0411\u0435\u0437 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F", category: skills.get(c.skill_id) || "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043F\u043E \u0421\u041E\u041F", code: docs.get(c.document_id)?.code || "", documentTitle: docs.get(c.document_id)?.title || "" }));
  }
  function profileRequirements(db, day, scaleId) {
    return rows(db, "SELECT * FROM role_requirement WHERE valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? AND scale_id=? ORDER BY profession_id,skill_id", [day, day, scaleId]);
  }
  function autoMatrix(db, roster, catalog, day, scaleId, { allSops = false } = {}) {
    const ids = new Set(roster.map((x) => x.person_id)), people = rows(db, "SELECT a.person_id,a.profession_id FROM person_assignment a WHERE a.id=(SELECT id FROM person_assignment b WHERE b.person_id=a.person_id AND b.valid_from<=? AND coalesce(b.valid_to,'9999-12-31')>=? ORDER BY valid_from DESC,id LIMIT 1)", [day, day]).filter((x) => ids.has(x.person_id));
    const professions = new Set(people.map((p) => p.profession_id)), req = profileRequirements(db, day, scaleId).filter((x) => professions.has(x.profession_id));
    const requiredSkills = new Set(req.map((x) => x.skill_id)), selected = [], seen = /* @__PURE__ */ new Set(), ambiguous = [], missing = [];
    for (const id of requiredSkills) {
      const choices = catalog.filter((x) => x.skill_id === id);
      if (choices.length === 1) {
        selected.push(choices[0]);
        seen.add(id);
      } else if (choices.length > 1) ambiguous.push({ skill_id: id, choices: choices.map((c) => c.key) });
      else missing.push(id);
    }
    if (allSops) for (const x of catalog.filter((x2) => x2.document_id)) {
      if (x.skill_id && seen.has(x.skill_id) || !x.skill_id && selected.some((y) => y.operation_id === x.operation_id)) continue;
      if (x.skill_id && catalog.filter((y) => y.skill_id === x.skill_id).length > 1) {
        if (!ambiguous.some((y) => y.skill_id === x.skill_id)) ambiguous.push({ skill_id: x.skill_id, choices: catalog.filter((y) => y.skill_id === x.skill_id).map((y) => y.key) });
        continue;
      }
      selected.push(x);
      if (x.skill_id) seen.add(x.skill_id);
    }
    return { keys: selected.map((x) => x.key), missing, ambiguous, unprofiled: [...professions].filter((p) => !req.some((x) => x.profession_id === p)), requirements: req.length };
  }
  function profileEdits(db, { professionId, scaleId, effective: effective2, entries }) {
    invariant(professionId && scaleId && /^\d{4}-\d{2}-\d{2}$/.test(effective2), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E, \u0448\u043A\u0430\u043B\u0443 \u0438 \u0434\u0430\u0442\u0443 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F");
    const result = [], seen = /* @__PURE__ */ new Set(), previous = /* @__PURE__ */ new Date(effective2 + "T00:00:00Z");
    invariant(!isNaN(previous), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0434\u0430\u0442\u0430");
    previous.setUTCDate(previous.getUTCDate() - 1);
    const end = previous.toISOString().slice(0, 10);
    for (const x of entries) {
      invariant(x.skill_id && !seen.has(x.skill_id) && (x.level === null || [1, 2, 3, 4].includes(x.level)) && ["normal", "important", "critical"].includes(x.criticality), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430 \u043F\u0440\u043E\u0444\u0438\u043B\u044F");
      seen.add(x.skill_id);
      const old = one(db, "SELECT * FROM role_requirement WHERE profession_id=? AND skill_id=? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=?", [professionId, x.skill_id, effective2, effective2]);
      if (old && old.scale_id === scaleId && old.required_level === x.level && old.criticality === x.criticality) continue;
      if (!old && x.level === null) continue;
      invariant(!one(db, "SELECT id FROM role_requirement WHERE profession_id=? AND skill_id=? AND valid_from>?", [professionId, x.skill_id, effective2]), "\u0415\u0441\u0442\u044C \u0431\u0443\u0434\u0443\u0449\u0430\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439.");
      if (old) {
        invariant(!old.valid_to && old.valid_from < effective2, "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435 \u0443\u0436\u0435 \u043D\u0430\u0447\u0430\u043B\u043E\u0441\u044C \u0432 \u044D\u0442\u0443 \u0434\u0430\u0442\u0443 \u0438\u043B\u0438 \u0438\u043C\u0435\u0435\u0442 \u0437\u0430\u043A\u0440\u044B\u0442\u044B\u0439 \u043F\u0435\u0440\u0438\u043E\u0434. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0443\u044E \u0434\u0430\u0442\u0443 \u043B\u0438\u0431\u043E \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u044E.");
        result.push({ old, payload: { command: "close", valid_to: end } });
      }
      if (x.level !== null) result.push({ old: null, payload: { profession_id: professionId, skill_id: x.skill_id, scale_id: scaleId, required_level: x.level, criticality: x.criticality, valid_from: effective2, valid_to: null } });
    }
    return result;
  }
  function matrixActivity(db, cfg) {
    const people = new Set(cfg.roster.map((x) => x.person_id)), skills = new Map(cfg.columns.map((x) => [x.skill_id, x])), map = /* @__PURE__ */ new Map();
    for (const a of rows(db, "SELECT a.*,r.document_id,r.state revision_state FROM training_assignment a LEFT JOIN document_revision r ON r.id=a.sop_revision_id WHERE a.source_sha256 IS NOT NULL AND a.state IN('planned','in_progress') ORDER BY a.due_on,a.id")) {
      const s = skills.get(a.skill_id);
      if (!people.has(a.trainee_id) || !s || a.scale_id !== cfg.scale_id || s.document_id && s.document_id !== a.document_id) continue;
      const k = matrixKey(a.trainee_id, a.skill_id);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(a);
    }
    return map;
  }
  function matrixComparison(cfg, other) {
    invariant(cfg.scale_id === other.scale_id, "\u041D\u0435\u043B\u044C\u0437\u044F \u0441\u0440\u0430\u0432\u043D\u0438\u0432\u0430\u0442\u044C \u0440\u0430\u0437\u043D\u044B\u0435 \u0432\u0435\u0440\u0441\u0438\u0438 \u0448\u043A\u0430\u043B\u044B");
    const identities = new Map(other.columns.map((c) => [c.skill_id, columnIdentity(c)])), values = new Map(other.baseline.map((x) => [matrixKey(x.person_id, x.skill_id), x.value]));
    const out = /* @__PURE__ */ new Map();
    for (const p of cfg.roster) for (const c of cfg.columns) if (identities.get(c.skill_id) === columnIdentity(c) && values.has(matrixKey(p.person_id, c.skill_id))) out.set(matrixKey(p.person_id, c.skill_id), values.get(matrixKey(p.person_id, c.skill_id)));
    return out;
  }
  function uniqueMatrixMatch(value, choices, aliases2) {
    const key3 = normalizeMatrixText(value);
    if (!key3) return null;
    const hits = choices.filter((x) => aliases2(x).some((v) => normalizeMatrixText(v) === key3));
    return hits.length === 1 ? hits[0] : null;
  }
  function readMatrixRange(sheet2, { headerRow, firstRow, lastRow, personCol, firstSkill, lastSkill }) {
    invariant([headerRow, firstRow, lastRow, personCol, firstSkill, lastSkill].every(Number.isInteger) && headerRow > 0 && firstRow > headerRow && lastRow >= firstRow && lastRow - firstRow < 300 && lastRow <= sheet2.rowCount && personCol > 0 && firstSkill > personCol && lastSkill >= firstSkill && lastSkill - firstSkill < 150 && lastSkill <= sheet2.columnCount, "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D: \u0434\u043E 300 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432, 150 \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432, \u0431\u0435\u0437 \u0438\u0442\u043E\u0433\u043E\u0432\u044B\u0445 \u0441\u0442\u0440\u043E\u043A");
    const cols = [], people = [];
    for (let col = firstSkill; col <= lastSkill; col++) {
      const label = sheet2.getCell(headerRow, col).text.trim();
      if (label) cols.push({ col, label });
    }
    for (let row = firstRow; row <= lastRow; row++) {
      const label = sheet2.getCell(row, personCol).text.trim();
      if (!label) continue;
      const values = cols.map((c) => {
        const cell = sheet2.getCell(row, c.col), raw = cell.text.trim();
        return { col: c.col, raw, value: /^[1-4]$/.test(raw) ? Number(raw) : null, invalid: raw !== "" && !/^[1-4]$/.test(raw) };
      });
      people.push({ row, label, values });
    }
    invariant(people.length && cols.length && people.length * cols.length <= 12e3, "\u041D\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0445 \u0438\u043B\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 12000 \u044F\u0447\u0435\u0435\u043A");
    return { people, cols };
  }
  function suggestMatrixRange(sheet2) {
    let headerRow = 5, personCol = 2, found = false;
    const isName = (v) => ["\u0444\u0438\u043E", "\u0444 \u0438 \u043E", "\u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0444\u0430\u043C\u0438\u043B\u0438\u044F \u0438\u043C\u044F \u043E\u0442\u0447\u0435\u0441\u0442\u0432\u043E"].includes(normalizeMatrixText(v).replace(/\./g, ""));
    for (let r = 1; r <= Math.min(25, sheet2.rowCount) && !found; r++) for (let c = 1; c <= Math.min(12, sheet2.columnCount); c++) if (isName(sheet2.getCell(r, c).text)) {
      headerRow = r;
      personCol = c;
      found = true;
      break;
    }
    const firstSkill = personCol + (/должност|професси/.test(normalizeMatrixText(sheet2.getCell(headerRow, personCol + 1).text)) ? 2 : 1);
    let lastSkill = firstSkill - 1;
    for (let c = firstSkill; c <= Math.min(sheet2.columnCount, firstSkill + 149); c++) {
      const label = normalizeMatrixText(sheet2.getCell(headerRow, c).text);
      if (!label || /компетенци[ияй].*сотрудник|потребност|суммарн|^итого|^состояние/.test(label)) break;
      lastSkill = c;
    }
    if (lastSkill < firstSkill) lastSkill = Math.max(firstSkill, Math.min(sheet2.columnCount, firstSkill + 149));
    let firstRow = headerRow + 1;
    for (; firstRow <= Math.min(sheet2.rowCount, headerRow + 8); firstRow++) {
      const name = sheet2.getCell(firstRow, personCol).text.trim();
      if (name && !isName(name) && !/^должност|^дата|^инструкторы$/i.test(name)) break;
    }
    let lastRow = firstRow - 1;
    for (let r = firstRow; r <= Math.min(sheet2.rowCount, firstRow + 299); r++) {
      const name = normalizeMatrixText(sheet2.getCell(r, personCol).text), left = Array.from({ length: personCol }, (_, i) => normalizeMatrixText(sheet2.getCell(r, i + 1).text)).join(" ");
      if (!name || /состояние подразделения|состояние процесса|потребности|^итого|^целевое состояние|^легенда/.test(left.trim())) break;
      lastRow = r;
    }
    return { headerRow, personCol, firstRow, lastRow: Math.max(firstRow, lastRow), firstSkill, lastSkill };
  }
  function reconcileMatrix(source, personMap, columnMap, projection) {
    const people = source.people.filter((p) => personMap.get(p.row)), cols = source.cols.filter((c) => columnMap.get(c.col));
    invariant(people.length && cols.length, "\u0421\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0438 \u043D\u0430\u0432\u044B\u043A\u0438");
    invariant(new Set(people.map((p) => personMap.get(p.row))).size === people.length && new Set(cols.map((c) => columnMap.get(c.col))).size === cols.length, "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0438\u043B\u0438 \u0441\u0442\u043E\u043B\u0431\u0446\u0430");
    return people.flatMap((p) => cols.map((c) => {
      const src = p.values.find((v) => v.col === c.col), personId = personMap.get(p.row), skillId = columnMap.get(c.col), actual = projection?.cells.get(matrixKey(personId, skillId))?.actual ?? null;
      return { personId, skillId, person: p.label, skill: c.label, raw: src.raw, imported: src.value, actual, status: src.invalid ? "\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435" : src.value === null ? "\u041F\u0443\u0441\u0442\u043E" : actual === src.value ? "\u0421\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442" : actual === null ? "\u041D\u0435\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F" : "\u0420\u0430\u0441\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u0435" };
    }));
  }
  function matrixGroupLabels(db, columns) {
    const entries = new Map(rows(db, "SELECT s.id,c.name category,w.name workplace,e.name equipment FROM skill s JOIN skill_category c ON c.id=s.category_id LEFT JOIN operation o ON o.id=s.operation_id LEFT JOIN workplace w ON w.id=o.workplace_id LEFT JOIN equipment e ON e.id=o.equipment_id").map((x) => [x.id, x]));
    return new Map(columns.map((c) => {
      const x = entries.get(c.skill_id || c.id);
      return [c.skill_id || c.id, { workplace: x?.workplace || "\u0411\u0435\u0437 \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430", equipment: x?.equipment || "\u0411\u0435\u0437 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F", category: x?.category || "\u0411\u0435\u0437 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438" }];
    }));
  }

  // src/ui/people-picker.js
  var key = (x) => String(x ?? "").normalize("NFKC").toLocaleLowerCase("ru-RU").replaceAll("\u0451", "\u0435").trim();
  var ROLE_LABELS = { instructor: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", mentor: "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", trainee: "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", evaluator: "\u041E\u0446\u0435\u043D\u0449\u0438\u043A" };
  var tokens = (x) => key(x).split(/[\s,;]+/u).filter(Boolean);
  function matchesPerson(p, query2) {
    const words = tokens([p.display_name, p.employee_code, p.position, p.unit].join(" "));
    return tokens(query2).every((q) => words.some((w) => w.startsWith(q)));
  }
  function filterPeople(people, query2 = "", allowed = null, role = "") {
    return people.filter((p) => (!allowed || p.roles?.some((x) => allowed.includes(x.kind))) && (!role || p.roles?.some((x) => x.kind === role)) && matchesPerson(p, query2));
  }
  var active3 = null;
  var serial = 0;
  var node = (tag, text4, cls) => {
    const e = document.createElement(tag);
    if (text4 !== void 0) e.textContent = text4;
    if (cls) e.className = cls;
    return e;
  };
  function closePeopleDropdown() {
    active3?.close();
  }
  function openPeopleDropdown(trigger, { people, onChoose, allowed = null, roleOptions = ["instructor", "mentor", "trainee", "evaluator"], optional: optional2 = true, selectedId = "", label = "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A" }) {
    if (active3?.trigger === trigger) {
      active3.close();
      return;
    }
    closePeopleDropdown();
    if (trigger.disabled || !trigger.isConnected) return;
    const popup = node("div", void 0, "lc-picker-popup");
    popup.id = "lc-picker-" + ++serial;
    popup.setAttribute("role", "dialog");
    popup.setAttribute("aria-label", "\u0412\u044B\u0431\u043E\u0440: " + label);
    const header2 = node("div", label, "lc-picker-heading"), search = node("input"), role = node("select"), results = node("div", void 0, "lc-picker-results");
    search.type = "search";
    search.placeholder = "\u041F\u0435\u0440\u0432\u044B\u0435 \u0431\u0443\u043A\u0432\u044B \u0424\u0418\u041E \u0438\u043B\u0438 \u0442\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440";
    search.setAttribute("aria-label", "\u041F\u043E\u0438\u0441\u043A \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
    search.autocomplete = "off";
    search.setAttribute("aria-controls", popup.id + "-results");
    role.setAttribute("aria-label", "\u0420\u043E\u043B\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
    results.id = popup.id + "-results";
    const roles3 = allowed || roleOptions;
    const option = (value, label2) => {
      const o = node("option", label2);
      o.value = value;
      role.append(o);
    };
    if (roles3.length !== 1) option("", allowed ? "\u0412\u0441\u0435 \u043F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0440\u043E\u043B\u0438" : "\u0412\u0441\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438");
    roles3.forEach((r) => option(r, ROLE_LABELS[r] || r));
    if (roles3.length === 1) role.value = roles3[0];
    popup.append(header2);
    if (roles3.length > 1 || !allowed) popup.append(role);
    popup.append(search);
    const footer = node("div", void 0, "lc-picker-footer");
    const cancel = node("button", "\u0417\u0430\u043A\u0440\u044B\u0442\u044C");
    cancel.type = "button";
    cancel.onclick = () => close(true);
    if (optional2) {
      const clear = node("button", "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0432\u044B\u0431\u043E\u0440");
      clear.type = "button";
      clear.onclick = () => {
        close(true);
        onChoose(null);
      };
      footer.append(clear);
    }
    footer.append(cancel);
    popup.append(results, footer);
    document.body.append(popup);
    trigger.setAttribute("aria-haspopup", "dialog");
    trigger.setAttribute("aria-expanded", "true");
    trigger.setAttribute("aria-controls", popup.id);
    function options() {
      return Array.from(results.querySelectorAll("button.lc-person-option"));
    }
    function draw() {
      const list2 = filterPeople(people(), search.value, allowed, role.value);
      results.replaceChildren();
      if (!list2.length) {
        results.append(node("p", search.value ? "\u041D\u0435\u0442 \u0441\u043E\u0432\u043F\u0430\u0434\u0435\u043D\u0438\u0439 \u043F\u043E \u043F\u0435\u0440\u0432\u044B\u043C \u0431\u0443\u043A\u0432\u0430\u043C." : allowed || role.value ? "\u041D\u0435\u0442 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0441 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\u043C \u044D\u0442\u043E\u0439 \u0440\u043E\u043B\u0438. \u041D\u0430\u0437\u043D\u0430\u0447\u044C\u0442\u0435 \u0440\u043E\u043B\u044C \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0435 \u0446\u0435\u043D\u0442\u0440\u0430." : "\u041D\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432. \u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0438\u0445 \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0446\u0435\u043D\u0442\u0440\u0430.", "lc-picker-empty"));
        return;
      }
      for (const p of list2.slice(0, 100)) {
        const btn2 = node("button", void 0, "lc-person-option");
        btn2.type = "button";
        btn2.dataset.personId = p.id;
        btn2.setAttribute("aria-label", p.display_name + " \xB7 " + p.employee_code);
        if (p.id === selectedId) btn2.classList.add("lc-person-current");
        btn2.append(node("strong", p.display_name), node("span", [p.employee_code, p.position, p.unit, ...(p.roles || []).map((x) => x.name)].filter(Boolean).join(" \xB7 "), "lc-picker-meta"));
        btn2.onclick = () => {
          close(true);
          onChoose(p, role.value || null);
        };
        results.append(btn2);
      }
      if (list2.length > 100) results.append(node("p", "\u041F\u0435\u0440\u0432\u044B\u0435 100 \u0438\u0437 " + list2.length + ". \u0423\u0442\u043E\u0447\u043D\u0438\u0442\u0435 \u043F\u043E\u0438\u0441\u043A.", "lc-picker-empty"));
    }
    function place() {
      if (!trigger.isConnected || trigger.getBoundingClientRect().height === 0) {
        close();
        return;
      }
      const a = trigger.getBoundingClientRect(), w = Math.min(Math.max(a.width, 360), window.innerWidth - 16), below = window.innerHeight - a.bottom - 12, above = a.top - 12;
      popup.style.width = w + "px";
      popup.style.left = Math.max(8, Math.min(a.left, window.innerWidth - w - 8)) + "px";
      const height = Math.min(390, Math.max(150, Math.max(below, above)));
      popup.style.maxHeight = Math.min(window.innerHeight - 16, height) + "px";
      const actual = popup.getBoundingClientRect().height;
      popup.style.top = Math.max(8, Math.min(window.innerHeight - actual - 8, below >= Math.min(actual, 220) || below >= above ? a.bottom + 4 : a.top - actual - 4)) + "px";
    }
    function outside(e) {
      if (!popup.contains(e.target) && !trigger.contains(e.target)) close();
    }
    function keyboard(e) {
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        close(true);
        return;
      }
      if (!popup.contains(e.target)) return;
      const opts = options(), i = opts.indexOf(document.activeElement);
      if (e.key === "ArrowDown" && e.target !== role) {
        e.preventDefault();
        opts[Math.min(i + 1, opts.length - 1)]?.focus();
      } else if (e.key === "ArrowUp" && e.target !== role) {
        e.preventDefault();
        if (i <= 0) search.focus();
        else opts[i - 1]?.focus();
      } else if (e.key === "Enter" && e.target === search && opts.length) {
        e.preventDefault();
        opts[0].click();
      }
    }
    function close(focus = false) {
      if (active3?.popup !== popup) return;
      active3 = null;
      popup.remove();
      trigger.setAttribute("aria-expanded", "false");
      trigger.removeAttribute("aria-controls");
      document.removeEventListener("pointerdown", outside, true);
      document.removeEventListener("keydown", keyboard, true);
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
      observer.disconnect();
      if (focus && trigger.isConnected) trigger.focus({ preventScroll: true });
    }
    search.oninput = () => {
      draw();
      place();
    };
    role.onchange = () => {
      draw();
      place();
      search.focus();
    };
    const observer = new MutationObserver(() => {
      if (!trigger.isConnected) close();
    });
    observer.observe(document.body, { childList: true, subtree: true });
    active3 = { trigger, popup, close, refresh: () => {
      draw();
      place();
    } };
    document.addEventListener("pointerdown", outside, true);
    document.addEventListener("keydown", keyboard, true);
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    draw();
    place();
    search.focus({ preventScroll: true });
  }

  // src/modules/training/screens.js
  var TRAINING_PAGES = ["twi", "programs", "internship", "instruction", "retraining", "journal", "skills", "practical", "development", "mentoring", "certification", "appointments", "my_plan", "forms", "audit", "self_eval"];
  var route = {};
  function resetTrainingRoute() {
    route = {};
  }
  function setTrainingRoute(page2, options = {}) {
    route = { page: page2, ...options };
  }
  var statuses = { planned: "\u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043E", in_progress: "\u0412 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435", completed: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E", cancelled: "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E", active: "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442", retired: "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F" };
  var credentialRoles = { instructor: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", mentor: "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", internal_trainer: "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440" };
  var observationLabels = { rated: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D", not_observed: "\u041D\u0435 \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u043B\u043E\u0441\u044C", not_applicable: "\u041D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E" };
  var decisionLabels = { granted: "\u0414\u043E\u043F\u0443\u0441\u043A \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D", denied: "\u041D\u0435 \u0434\u043E\u043F\u0443\u0449\u0435\u043D" };
  var resultLabels = { completed: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E", incomplete: "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u044F", pass: "\u041F\u0440\u043E\u0439\u0434\u0435\u043D\u043E", fail: "\u041D\u0435 \u043F\u0440\u043E\u0439\u0434\u0435\u043D\u043E" };
  var safe = (x) => String(x ?? "");
  var nullable = (x) => x || null;
  var dateTime = () => {
    const d = /* @__PURE__ */ new Date(), local = new Date(d.getTime() - d.getTimezoneOffset() * 6e4);
    return local.toISOString().slice(0, 16);
  };
  function trainingScreen(main, page2, c) {
    if (route.page !== page2) route = { page: page2 };
    const { ws: ws2, el: el2, add: add2, btn: btn2, pane: pane2, tableOf: tableOf2, inputField: inputField2, fieldInput: fieldInput2, refName: refName2, refOption: refOption2, today: today2, run: run2, render: render2, go, goDocument: goDocument2, readContent: readContent3, pick: pick2, downloadBytes: downloadBytes2 } = c, db = ws2.working;
    const blocked = !!ws2.conflicts.length, day = today2(), n = (type, id) => refName2(type, id), stack = (...x) => add2(el2("div", void 0, "stack"), ...x), row = (...x) => add2(el2("div", void 0, "row"), ...x), grid = (...x) => add2(el2("div", void 0, "formgrid"), ...x);
    const msg = (s, cls = "muted") => el2("p", s, cls);
    const action = (label, fn, kind = "primary", disabled = false) => btn2(label, fn, kind, disabled || blocked);
    const goLocal = (options = {}) => {
      route = { page: page2, ...options };
      render2();
    };
    const back = () => btn2("\u041A \u0441\u043F\u0438\u0441\u043A\u0443", () => goLocal());
    const select = (name, options, value = "", emptyLabel = "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014") => {
      const s = el2("select");
      s.name = name;
      if (emptyLabel !== null) {
        const o = el2("option", emptyLabel);
        o.value = "";
        s.append(o);
      }
      for (const [id, label] of options) {
        const o = el2("option", safe(label));
        o.value = safe(id);
        s.append(o);
      }
      s.value = safe(value);
      if (s.selectedIndex < 0 && emptyLabel === null) s.selectedIndex = 0;
      return s;
    };
    const simple = (name, values, value = "", empty3 = null) => select(name, Object.entries(values), value, empty3);
    const ref = (type, name, value = "", emptyLabel = "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", filter = () => true) => select(name, list(db, type).filter((x) => !x.archived && filter(x)).map((x) => [x.id, refOption2(type, x)]), value, emptyLabel);
    const date3 = (name, value = day) => fieldInput2(name, value, "date");
    const num2 = (name, value = "", min = 0, max2 = 1e4, step = 1) => {
      const i = fieldInput2(name, value, "number");
      i.min = String(min);
      i.max = String(max2);
      i.step = String(step);
      return i;
    };
    const note = (name, value = "", placeholder = "") => {
      const i = el2("textarea");
      i.name = name;
      i.rows = 2;
      i.maxLength = 2e3;
      i.value = value;
      i.placeholder = placeholder;
      return i;
    };
    const check = (name, label) => {
      const i = el2("input");
      i.type = "checkbox";
      i.name = name;
      return { input: i, element: add2(el2("label", void 0, "row lc4-check"), i, el2("span", label)) };
    };
    const f = (label, input) => inputField2(label, input);
    function person2(name, label, initial = "", { allowed = null, optional: optional2 = false, filter = () => true, onChange = () => {
    }, at = () => day } = {}) {
      let id = initial;
      const button = btn2("", () => openPeopleDropdown(button, { people: () => directoryPeople(db, at() || day).filter(filter), allowed, optional: optional2, label, selectedId: id, onChoose: (p) => {
        id = p?.id || "";
        refresh2();
        onChange(id);
      } }), "lc-directory-trigger");
      button.name = name;
      button.setAttribute("aria-label", "\u0412\u044B\u0431\u0440\u0430\u0442\u044C: " + label);
      button.setAttribute("aria-haspopup", "dialog");
      button.setAttribute("aria-expanded", "false");
      function refresh2() {
        button.textContent = (id ? n("person", id) : "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430") + " \u25BE";
      }
      refresh2();
      return { get value() {
        return id;
      }, element: add2(el2("div", void 0, "field"), el2("span", label), button), button, set(v) {
        id = v;
        refresh2();
      } };
    }
    function event(type, payload, old = null) {
      return { id: uuid(), entity_type: type, entity_id: old?.id || uuid(), operation: old ? "update" : "create", expected_revision: old?.rev || 0, payload, occurred_at: (/* @__PURE__ */ new Date()).toISOString() };
    }
    async function write(type, payload, old = null) {
      const e = event(type, payload, old);
      await ws2.applyContentEvents([e], readContent3);
      return e.entity_id;
    }
    function save2(label, type, payload, old = null, done = () => {
    }, disabled = false) {
      return action(label, () => run2(async () => {
        const id = await write(type, typeof payload === "function" ? payload() : payload, old);
        done(id);
        return "\u0417\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
      }), "primary", disabled);
    }
    const reasonInput = () => note("reason", "", "\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F");
    function closeRecord(label, type, old, command) {
      const reason = reasonInput(), d = el2("details");
      d.append(el2("summary", label), f("\u041F\u0440\u0438\u0447\u0438\u043D\u0430", reason), save2(label, type, () => ({ command, reason: reason.value }), old));
      return d;
    }
    const revs = () => rows(db, "SELECT r.id,r.version_no,r.payload_json,d.id document_id,d.code,d.title,d.operation_id FROM document_revision r JOIN document d ON d.id=r.document_id JOIN operation o ON o.id=d.operation_id WHERE d.kind='sop' AND d.archived=0 AND r.state='effective' AND o.archived=0 ORDER BY d.code");
    const revLabel = (id) => {
      const x = currentStandard(db, id);
      return x ? x.code + " \xB7 " + x.title + " \xB7 v" + x.version_no : "\u2014";
    };
    const revPicker = (name, id = "") => select(name, revs().map((x) => [x.id, x.code + " \xB7 " + x.title + " \xB7 v" + x.version_no]), id);
    const scalePicker = (name, id = "") => ref("rating_scale", name, id);
    function levelPicker(name, scaleId, initial = "") {
      return select(name, rows(db, "SELECT value,label FROM rating_level WHERE scale_id=? ORDER BY value", [scaleId]).map((x) => [x.value, x.value + " \u2014 " + x.label]), initial);
    }
    function replaceOptions(dest, source) {
      const value = source.value;
      dest.replaceChildren(...Array.from(source.children));
      dest.value = value;
    }
    function scaleFields(prefix, scaleId = "", target = null) {
      const scale = scalePicker(prefix + "_scale", scaleId), level2 = levelPicker(prefix + "_level", scale.value, target ?? "");
      scale.onchange = () => replaceOptions(level2, levelPicker(level2.name, scale.value));
      return { scale, level: level2, element: grid(f("\u0428\u043A\u0430\u043B\u0430", scale), f("\u0426\u0435\u043B\u0435\u0432\u043E\u0439 / \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u043C\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C", level2)), set(s, l) {
        scale.value = s || "";
        replaceOptions(level2, levelPicker(level2.name, scale.value, l ?? ""));
      } };
    }
    function currentAuths(op, at = day) {
      return activeAuthorizations(db, op, at);
    }
    function asgns() {
      return rows(db, "SELECT * FROM training_assignment WHERE source_sha256 IS NOT NULL ORDER BY due_on,assigned_on,id");
    }
    function enrollmentList() {
      return rows(db, "SELECT * FROM training_enrollment ORDER BY due_on,start_on,id");
    }
    const assignmentName = (a) => (JSON.parse(a.recorded_names_json || "{}").trainee || n("person", a.trainee_id)) + " \xB7 " + revLabel(a.sop_revision_id);
    const enrollmentPage = (id) => one(db, "SELECT p.kind FROM training_enrollment e JOIN training_program p ON p.id=e.program_id WHERE e.id=?", [id])?.kind === "internship" ? "internship" : "programs";
    const stateLabel = (a) => a.state === "planned" ? a.approval_json ? "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043E" : "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F" : statuses[a.state] || a.state;
    const sameRevision = (a) => isCurrentStandard(db, a.sop_revision_id);
    const activePlan = (a) => ["planned", "in_progress"].includes(a.state);
    const expired = (a) => activePlan(a) && a.due_on < day;
    const table2 = (headers, data, empty3 = "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439.") => data.length ? tableOf2(headers, data) : msg(empty3);
    async function exportTable(name, headers, data) {
      const w = new ExcelJS.Workbook(), s = w.addWorksheet("\u041E\u0442\u0447\u0451\u0442", { pageSetup: { orientation: "landscape", fitToPage: true, fitToWidth: 1, fitToHeight: 0, paperSize: 9 } });
      s.columns = headers.map((h) => ({ width: Math.max(14, Math.min(52, safe(h).length + 14)) }));
      s.addRow(headers);
      s.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
      s.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242E40" } };
      for (const line of data) {
        const r = s.addRow(line.map((x) => x ?? ""));
        r.alignment = { vertical: "top", wrapText: true };
        r.height = Math.max(22, Math.min(90, 15 * Math.ceil(Math.max(1, ...line.map((x) => safe(x).length / 38)))));
      }
      s.views = [{ state: "frozen", ySplit: 1 }];
      s.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: headers.length } };
      downloadBytes2(name + ".xlsx", await w.xlsx.writeBuffer());
    }
    const saveWorkbook = async (name, w) => {
      downloadBytes2(name + ".xlsx", await w.xlsx.writeBuffer());
      return "\u041E\u0442\u0447\u0451\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    };
    const localDocx = (label, handler) => {
      const trigger = btn2(label, () => {
        const input = el2("input");
        input.type = "file";
        input.accept = ".docx";
        input.hidden = true;
        input.addEventListener("cancel", () => input.remove(), { once: true });
        input.onchange = async () => {
          const file = input.files?.[0];
          input.remove();
          if (!file) return;
          trigger.disabled = true;
          c.notify("\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0438 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u0448\u0430\u0431\u043B\u043E\u043D\u0430 DOCX\u2026");
          try {
            invariant(file.size <= 32 * 1024 * 1024, "\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
            c.notify(await handler(new Uint8Array(await file.arrayBuffer())));
          } catch (e) {
            c.notify(e.message || String(e), true);
          } finally {
            trigger.disabled = false;
          }
        };
        document.body.append(input);
        input.click();
      });
      return trigger;
    };
    const exportButton = (name, headers, items) => btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C XLSX", () => run2(async () => {
      await exportTable(name, headers, items);
      return "\u041E\u0442\u0447\u0451\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false }));
    function filterList(out, input, items, searchText, draw) {
      const update2 = () => {
        const q = input.value.trim().toLocaleLowerCase("ru-RU");
        out.replaceChildren(draw(items.filter((x) => searchText(x).toLocaleLowerCase("ru-RU").includes(q))));
      };
      input.oninput = update2;
      update2();
    }
    function searchInput(name = "lc4_search") {
      const i = fieldInput2(name, "", "search");
      i.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0443, \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u043D\u043E\u043C\u0435\u0440\u0443";
      return i;
    }
    function evidenceSummary(a) {
      const p = latestAssessment(db, a.id, "practical"), q = latestAssessment(db, a.id, "qualification"), s = latestVerification(db, a.id, "safety"), t = latestVerification(db, a.id, "theory");
      return { p, q, s, t, ad: admissionStatus(db, a.trainee_id, a.operation_id, day) };
    }
    function assignmentRows(items) {
      return table2(["\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0421\u041E\u041F / \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u0426\u0435\u043B\u044C", "\u0421\u0440\u043E\u043A", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436", ""], items.map((a) => {
        const p = progressFor(db, a), e = el2("span", stateLabel(a) + (expired(a) ? " \xB7 \u043F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043E" : "") + (!sameRevision(a) ? " \xB7 \u0421\u041E\u041F \u0438\u0437\u043C\u0435\u043D\u0451\u043D" : ""), expired(a) || !sameRevision(a) ? "warn" : "");
        return [n("person", a.trainee_id), revLabel(a.sop_revision_id), n("person", a.mentor_id), a.target_level + " \xB7 " + n("skill", a.skill_id), a.due_on, e, p.completed + "/" + p.stages.length, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => go(page2 === "instruction" ? "instruction" : "twi", { id: a.id, tab: page2 === "instruction" ? "instruction" : "overview" }), "primary")];
      }));
    }
    function productionData(items) {
      const ids = new Set(items.map((a) => a.id)), facts = rows(db, "SELECT * FROM training_session WHERE stage_code IS NOT NULL ORDER BY held_at,recorded_at,id").filter((x) => ids.has(x.assignment_id));
      return productionRows(items, facts, { unit: (a) => one(db, "SELECT u.name FROM person_assignment p JOIN org_unit u ON u.id=p.unit_id WHERE p.person_id=? AND p.valid_from<=? AND coalesce(p.valid_to,'9999-12-31')>=? ORDER BY p.valid_from DESC LIMIT 1", [a.trainee_id, a.assigned_on, a.assigned_on])?.name || "", person: (id) => n("person", id), revision: revLabel });
    }
    function productionExport(items, title) {
      return btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043F\u043B\u0430\u043D / \u0444\u0430\u043A\u0442 XLSX", () => run2(async () => saveWorkbook(title, productionWorkbook(ExcelJS, productionData(items()), { title, date: day })), { save: false }));
    }
    function assignmentList() {
      const items = asgns(), q = searchInput(), out = el2("div"), filter = select("training_filter", [["all", "\u0412\u0441\u0435"], ["open", "\u041E\u0442\u043A\u0440\u044B\u0442\u044B\u0435"], ["overdue", "\u041F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043D\u044B\u0435"], ["completed", "\u0417\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u044B\u0435"], ["changed", "\u0418\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F \u0421\u041E\u041F"]], route.filter || "all", null);
      let filtered = [];
      const display = () => {
        const text4 = q.value.toLocaleLowerCase("ru-RU").trim();
        filtered = items.filter((a) => (filter.value === "all" || filter.value === "open" && activePlan(a) || filter.value === "overdue" && expired(a) || filter.value === "completed" && a.state === "completed" || filter.value === "changed" && !sameRevision(a)) && assignmentName(a).toLocaleLowerCase("ru-RU").includes(text4));
        out.replaceChildren(assignmentRows(filtered));
        route.filter = filter.value;
      };
      q.oninput = display;
      filter.onchange = display;
      display();
      const controls = row(action("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { mode: "new" })), btn2("\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0438", () => go("programs")), btn2("\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0438 TWI", () => go("instruction")), q, filter);
      return pane2(page2 === "instruction" ? "\u0420\u0435\u0435\u0441\u0442\u0440 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439 TWI" : "\u041F\u043B\u0430\u043D \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", msg("\u041E\u0434\u0438\u043D \u0441\u043F\u0438\u0441\u043E\u043A \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439. \u0424\u0430\u043A\u0442 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430, \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430, \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F \u0438 \u0434\u043E\u043F\u0443\u0441\u043A \u0443\u0447\u0438\u0442\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E."), controls, out, productionExport(() => filtered, "\u041F\u043B\u0430\u043D \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432"), exportButton("\u041F\u043B\u0430\u043D-\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", ["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0421\u041E\u041F", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u041D\u0430\u0432\u044B\u043A", "\u0426\u0435\u043B\u044C", "\u041D\u0430\u0447\u0430\u043B\u043E", "\u0421\u0440\u043E\u043A", "\u0421\u0442\u0430\u0442\u0443\u0441"], items.map((a) => [n("person", a.trainee_id), revLabel(a.sop_revision_id), n("person", a.mentor_id), n("skill", a.skill_id), a.target_level, a.assigned_on, a.due_on, stateLabel(a)])));
    }
    function assignmentForm() {
      const preset = route, rev = revPicker("training_revision", preset.revisionId || ""), assigned = date3("assigned_on", preset.startOn || day), due = date3("due_on", preset.dueOn || day);
      const trainee = person2("training_trainee", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", preset.traineeId || "", { allowed: ["trainee"], at: () => assigned.value });
      const instructor = person2("training_instructor", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", preset.instructorId || "", { allowed: ["instructor", "mentor"], at: () => assigned.value, filter: (p) => currentAuths(currentStandard(db, rev.value)?.operation_id, assigned.value).some((a) => a.person_id === p.id) });
      const supervisor = person2("training_supervisor", "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", preset.supervisorId || "", { allowed: ["mentor", "instructor"], optional: true, at: () => assigned.value });
      const actor = person2("training_assigner", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0437\u0430 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"), skill = ref("skill", "training_skill", preset.skillId || "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", (s) => s.operation_id === currentStandard(db, rev.value)?.operation_id);
      const target = scaleFields("training_target", preset.scaleId || "", preset.targetLevel ?? null), shift = ref("work_shift", "training_shift", preset.shiftId || "", "\u2014 \u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430 \u2014");
      const reason = note("training_reason", preset.reason || ""), variant = simple("training_variant", variants, preset.variant || "classic"), review = check("plan_reviewed", "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u043B \u043F\u043B\u0430\u043D TWI \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0421\u041E\u041F \u0438 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F");
      const sourceInfo = el2("div");
      let epoch = 0;
      async function refreshSource() {
        const seq = ++epoch, r = currentStandard(db, rev.value);
        sourceInfo.replaceChildren(msg(r ? "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043F\u043B\u0430\u043D\u0430 TWI\u2026" : "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0421\u041E\u041F \u0441 \u043F\u043B\u0430\u043D\u043E\u043C TWI."));
        review.input.checked = false;
        review.input.disabled = true;
        if (!r) return;
        try {
          const raw = JSON.parse(await readContent3(r.source)), x = linkedTwi(raw.constructor);
          if (seq !== epoch || !sourceInfo.isConnected) return;
          sourceInfo.replaceChildren(msg("\u041F\u043B\u0430\u043D TWI: " + x.status + " \xB7 " + x.filled + "/15 \u043F\u043E\u043B\u0435\u0439", x.outdated || !x.exists ? "warn" : "muted"), btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u0421\u041E\u041F", () => goDocument2(r.document_id, r.id)));
          review.input.disabled = !x.exists || x.outdated;
        } catch (e) {
          if (seq === epoch) sourceInfo.replaceChildren(msg(e.message, "bad"));
        }
      }
      rev.onchange = () => {
        replaceOptions(skill, ref("skill", "training_skill", "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", (s) => s.operation_id === currentStandard(db, rev.value)?.operation_id));
        instructor.set("");
        void refreshSource();
      };
      assigned.onchange = () => {
        instructor.set("");
        if (!preset.programTaskId) {
          trainee.set("");
          supervisor.set("");
        }
      };
      if (preset.programTaskId) {
        rev.disabled = true;
        skill.disabled = true;
        target.scale.disabled = true;
        target.level.disabled = true;
        trainee.button.disabled = true;
      }
      const form2 = pane2("\u041D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", row(back()), msg("\u0414\u043B\u044F \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0421\u041E\u041F, \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 TWI, \u0446\u0435\u043B\u044C \u043F\u043E \u043D\u0430\u0432\u044B\u043A\u0443 \u0438 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u043F\u0440\u0430\u0432\u043E \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u044D\u0442\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438."), f("\u0421\u041E\u041F \u0438 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F", rev), sourceInfo, review.element, grid(trainee.element, instructor.element, supervisor.element, actor.element), grid(f("\u041D\u0430\u0432\u044B\u043A", skill), f("\u0421\u043C\u0435\u043D\u0430", shift), f("\u0412\u0438\u0434 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", variant), f("\u041D\u0430\u0447\u0430\u043B\u043E", assigned), f("\u0421\u0440\u043E\u043A", due)), target.element, f("\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", reason), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", "training_assignment", () => {
        const r = currentStandard(db, rev.value), auth = currentAuths(r?.operation_id, assigned.value).find((x) => x.person_id === instructor.value);
        invariant(r && auth, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0421\u041E\u041F \u0438 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0441 \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0435\u043C");
        return { trainee_id: trainee.value, mentor_id: instructor.value, supervisor_id: nullable(supervisor.value), authorization_id: auth.id, revision_id: r.id, source: r.source, skill_id: skill.value, scale_id: target.scale.value, target_level: target.level.value === "" ? null : Number(target.level.value), assigned_by: actor.value, assigned_on: assigned.value, due_on: due.value, reason: reason.value, variant: variant.value, shift_id: nullable(shift.value), enrollment_id: preset.enrollmentId || null, program_task_id: preset.programTaskId || null, plan_reviewed: review.input.checked };
      }, null, (id) => {
        route = { page: page2, id, tab: "overview" };
      }));
      void Promise.resolve().then(refreshSource);
      return form2;
    }
    function overview(a) {
      const s = currentStandard(db, a.sop_revision_id), p = progressFor(db, a), e = evidenceSummary(a), name = JSON.parse(a.recorded_names_json || "{}");
      const panel = pane2("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", tableOf2(["\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442", "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435"], [["\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", name.trainee || n("person", a.trainee_id)], ["\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", name.instructor || n("person", a.mentor_id)], ["\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", name.supervisor || n("person", a.supervisor_id)], ["\u0421\u041E\u041F", revLabel(a.sop_revision_id)], ["\u041D\u0430\u0432\u044B\u043A \u0438 \u0446\u0435\u043B\u044C", n("skill", a.skill_id) + " \xB7 " + a.target_level + " \xB7 " + n("rating_scale", a.scale_id)], ["\u0412\u0438\u0434 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", variants[a.method_variant]], ["\u0421\u043C\u0435\u043D\u0430", n("work_shift", a.shift_id)], ["\u041F\u0435\u0440\u0438\u043E\u0434", a.assigned_on + " \u2014 " + a.due_on], ["\u041F\u0440\u0438\u0447\u0438\u043D\u0430", a.reason], ["\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", stateLabel(a)], ["\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436", p.completed + " / " + p.stages.length], ["\u0414\u043E\u043F\u0443\u0441\u043A", e.ad.status]]), row(btn2("\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0421\u041E\u041F", () => goDocument2(s.document_id, s.id)), ...a.enrollment_id ? [btn2("\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", () => go(enrollmentPage(a.enrollment_id), { enrollmentId: a.enrollment_id }))] : []));
      if (!sameRevision(a)) panel.append(msg("\u0420\u0435\u0434\u0430\u043A\u0446\u0438\u044F \u0421\u041E\u041F \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442. \u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u043F\u0435\u0440\u0435\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0438.", "warn"), btn2("\u041F\u0435\u0440\u0435\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("retraining")));
      if (a.approval_json) {
        const x = JSON.parse(a.approval_json);
        panel.append(msg("\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043E " + x.approved_on + " \xB7 \u041D\u0420: " + x.names.responsible + " \xB7 \u0440\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C: " + x.names.head + (x.note ? " \xB7 " + x.note : "")));
      }
      if (activePlan(a) && sameRevision(a) && !a.approval_json) {
        const responsible = person2("plan_responsible", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0437\u0430 \u0421\u041E\u041F (\u041D\u0420)"), head = person2("plan_head", "\u0420\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F"), approved = date3("approved_on"), comment = note("approval_note");
        panel.append(pane2("\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u043B\u0430\u043D\u0430", msg("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F, \u043D\u0435 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0434\u043F\u0438\u0441\u044C."), grid(responsible.element, head.element, f("\u0414\u0430\u0442\u0430", approved)), f("\u041F\u0440\u0438\u043C\u0435\u0447\u0430\u043D\u0438\u0435", comment), save2("\u0417\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435", "training_assignment", () => ({ command: "approve", responsible_id: responsible.value, head_id: head.value, approved_on: approved.value, note: comment.value }), a)));
      }
      if (activePlan(a)) {
        const due = date3("reschedule_due", a.due_on), why = reasonInput(), d = el2("details");
        d.append(el2("summary", "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u0440\u043E\u043A"), grid(f("\u041D\u043E\u0432\u044B\u0439 \u0441\u0440\u043E\u043A", due), f("\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", why)), msg("\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0441\u0440\u043E\u043A\u0430 \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0433\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F; \u043F\u0440\u0435\u0436\u043D\u0438\u0435 \u0444\u0430\u043A\u0442\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F."), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u043E\u0432\u044B\u0439 \u0441\u0440\u043E\u043A", "training_assignment", () => ({ command: "reschedule", due_on: due.value, reason: why.value }), a));
        panel.append(d, closeRecord("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", "training_assignment", a, "cancel"));
      }
      if (a.change_reason) panel.append(msg("\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435: " + a.change_reason));
      return panel;
    }
    function planMaterial(a) {
      const out = el2("div"), button = btn2("\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043B\u0430\u043D TWI \u0438 \u0448\u0430\u0433\u0438 \u0421\u041E\u041F", async () => {
        button.disabled = true;
        try {
          const r = currentStandard(db, a.sop_revision_id);
          const raw = JSON.parse(await readContent3(r.source));
          const t = linkedTwi(raw.constructor);
          out.replaceChildren(msg("\u0418\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F: " + revLabel(a.sop_revision_id) + " \xB7 " + t.status), tableOf2(["\u0420\u0430\u0437\u0434\u0435\u043B", "\u041F\u043E\u043B\u0435", "\u0421\u043E\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u0435"], t.fields.map((x) => [x.section, x.label, x.value || "\u2014"])), tableOf2(["\u2116", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435", "\u041A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B", "\u041F\u0440\u0438\u0447\u0438\u043D\u044B"], raw.constructor.steps.map((x, i) => [i + 1, x.action, (x.keyMoments || []).join("\n"), x.reason])));
        } catch (e) {
          out.replaceChildren(msg(e.message, "bad"));
          button.disabled = false;
        }
      });
      return pane2("\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", button, out);
    }
    function instruction(a) {
      const pr = progressFor(db, a), can = a.state !== "cancelled" && a.approval_json && sameRevision(a);
      const panel = pane2("\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", msg("\u0412\u0432\u043E\u0434\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C: " + (pr.intro ? "\u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430" : "\u0432 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435") + " \xB7 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438: " + pr.followup + "/5" + (pr.followupDue ? " \xB7 \u0441\u0440\u043E\u043A \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0438 " + pr.followupDue : ""), pr.followupDue && day > pr.followupDue && pr.followup < 5 ? "warn" : "muted"));
      const bar = el2("progress");
      bar.max = pr.stages.length;
      bar.value = pr.completed;
      bar.setAttribute("aria-label", "\u041F\u0440\u043E\u0433\u0440\u0435\u0441\u0441 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430");
      panel.append(bar, tableOf2(["\u042D\u0442\u0430\u043F", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", "\u041F\u043E\u043F\u044B\u0442\u043E\u043A"], pr.stages.map((s) => [s.label, pr.done.has(s.code) ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D" : s.code === pr.next?.code ? "\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439" : "\u041E\u0436\u0438\u0434\u0430\u0435\u0442", pr.facts.filter((x) => x.stage_code === s.code).length])));
      if (can) {
        const stage = select("session_stage", pr.stages.filter((x) => pr.done.has(x.code) || x.code === pr.next?.code).map((x) => [x.code, x.label + (pr.done.has(x.code) ? " \xB7 \u043F\u043E\u0432\u0442\u043E\u0440" : "")]), pr.next?.code || pr.stages[0].code, null);
        const when = fieldInput2("session_when", dateTime(), "datetime-local"), duration = num2("session_minutes", 15, 1, 1440), result = simple("session_result", { completed: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E", incomplete: "\u041D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E, \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C" }, "completed");
        const witness = person2("session_witness", "\u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0442\u043E\u0440 / \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C", "", { optional: true }), notes = note("session_notes", "", "\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435, \u0437\u0430\u0434\u0430\u043D\u0438\u0435, \u0443\u0441\u043B\u043E\u0432\u0438\u044F, \u043E\u0448\u0438\u0431\u043A\u0438 \u0438\u043B\u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442");
        const ack1 = check("mentor_ack", "\u0424\u0430\u043A\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u043C"), ack2 = check("trainee_ack", "\u0424\u0430\u043A\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u043C");
        panel.append(pane2("\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u0444\u0430\u043A\u0442", grid(f("\u042D\u0442\u0430\u043F / \u043F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u0435", stage), f("\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F", when), f("\u041C\u0438\u043D\u0443\u0442", duration), f("\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", result), witness.element), f("\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435 \u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", notes), ack1.element, ack2.element, msg("\u041E\u0442\u043C\u0435\u0442\u043A\u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0442 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u043A\u0442, \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u044E\u0442 \u043F\u043E\u0434\u043F\u0438\u0441\u0438 \u0432 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u0445."), save2("\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u044D\u0442\u0430\u043F", "training_session", () => ({ assignment_id: a.id, assignment_rev: a.rev, stage_code: stage.value, held_at: when.value, duration_minutes: Number(duration.value), result: result.value, notes: notes.value, witness_id: nullable(witness.value), mentor_ack: ack1.input.checked, trainee_ack: ack2.input.checked }))));
      } else panel.append(msg("\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u043E\u0432\u044B\u0445 \u044D\u0442\u0430\u043F\u043E\u0432 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u043F\u043E\u0441\u043B\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F.", "warn"));
      const facts = pr.facts.map((x) => [x.held_at, JSON.parse(x.steps_json).label, resultLabels[x.result] || x.result, x.duration_minutes, x.notes, x.witness_name || "\u2014"]);
      panel.append(pane2("\u0416\u0443\u0440\u043D\u0430\u043B \u0444\u0430\u043A\u0442\u043E\u0432", table2(["\u0414\u0430\u0442\u0430 / \u0432\u0440\u0435\u043C\u044F", "\u042D\u0442\u0430\u043F", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", "\u041C\u0438\u043D\u0443\u0442", "\u0417\u0430\u043F\u0438\u0441\u044C", "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C"], facts), exportButton("\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436-" + a.id.slice(0, 8), ["\u0414\u0430\u0442\u0430 / \u0432\u0440\u0435\u043C\u044F", "\u042D\u0442\u0430\u043F", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", "\u041C\u0438\u043D\u0443\u0442", "\u0417\u0430\u043F\u0438\u0441\u044C", "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C"], facts)));
      return stack(planMaterial(a), panel);
    }
    function methodsPanel() {
      const methods = practicalMethods(db), out = pane2("\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043E\u0446\u0435\u043D\u043A\u0438", msg("\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 8 \u0432\u0441\u0442\u0440\u043E\u0435\u043D\u043E. \u041D\u043E\u0432\u0430\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F: \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u0439 XLSX, JSON v2 \u0438\u043B\u0438 \u043B\u0438\u0441\u0442 \xAB\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438\xBB (\u2116, \u0420\u0430\u0437\u0434\u0435\u043B, \u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439; 1\u2013100 \u0441\u0442\u0440\u043E\u043A). \u041F\u043E\u0440\u043E\u0433 \u0434\u043E\u043F\u0443\u0441\u043A\u0430 \u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u0430\u0432\u043B\u0438\u0432\u0430\u0435\u0442\u0441\u044F."), row(action("\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 JSON", () => pick2(".json", async (p) => {
        validatePracticalMethod(p);
        await write("checklist_version", p);
        return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
      }, 128e3)), action("\u0418\u043C\u043F\u043E\u0440\u0442 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u043E\u0433\u043E XLSX", () => {
        const input = el2("input");
        input.type = "file";
        input.accept = ".xlsx";
        input.onchange = () => {
          if (!input.files?.[0]) return;
          const file = input.files[0];
          run2(async () => {
            invariant(file.size <= 12 * 1024 * 1024, "\u0424\u0430\u0439\u043B \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
            const bytes = new Uint8Array(await file.arrayBuffer()), book = new ExcelJS.Workbook();
            await book.xlsx.load(bytes);
            const generic = book.getWorksheet("\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438"), sheet2 = book.worksheets.find((s) => s.name.trim().toLocaleLowerCase("ru-RU") === "\u0447\u0435\u043A \u043B\u0438\u0441\u0442");
            const criteria = generic ? criteriaFromTabularSheet(generic) : practicalCriteriaFromSheet(sheet2);
            const p = validatePracticalMethod({ format: criteria.length === 11 ? "lean-practical-checklist-v1" : "lean-practical-checklist-v2", title: "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \xB7 " + file.name.slice(0, 150), source_sha256: await sha256(bytes), criteria });
            invariant(new Set(criteria.map((x) => x.question)).size === criteria.length, "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u0442\u0440\u043E\u043A\u0438 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u044B");
            if (!confirm("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 \u0438\u0437 " + criteria.length + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432?\n\n" + criteria.map((x) => x.code + ". " + x.question).join("\n"))) return "\u0418\u043C\u043F\u043E\u0440\u0442 \u043E\u0442\u043C\u0435\u043D\u0451\u043D";
            await write("checklist_version", p);
            return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
          });
        };
        input.click();
      })));
      if (!methods.length) out.append(tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439"], BUILTIN_PRACTICAL.criteria.map((q) => [q.code, q.section, q.question])));
      for (const m of methods) {
        const d = el2("details"), p = JSON.parse(m.methodology_json);
        d.append(el2("summary", "v" + m.version_no + " \xB7 " + p.title + " \xB7 " + (m.state === "active" ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u0418\u0441\u0442\u043E\u0440\u0438\u044F")), tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439"], practicalCriteria(db, m.id).map((q) => [q.position, q.section_code, q.question])));
        out.append(d);
      }
      return out;
    }
    function verificationForm(a, kind) {
      const who = person2("verify_" + kind + "_actor", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "", { filter: (x) => x.id !== a.trainee_id }), when = date3("verify_" + kind + "_date"), result = simple("verify_" + kind + "_result", { pass: "\u041F\u0440\u043E\u0439\u0434\u0435\u043D\u043E", fail: "\u041D\u0435 \u043F\u0440\u043E\u0439\u0434\u0435\u043D\u043E" }, "pass"), evidence = note("verify_" + kind + "_evidence"), feedback = note("verify_" + kind + "_feedback");
      const d = el2("details");
      d.append(el2("summary", kind === "safety" ? "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u041E\u0422" : "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u0442\u0435\u043E\u0440\u0438\u0438"), grid(who.element, f("\u0414\u0430\u0442\u0430", when), f("\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", result)), f("\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 / \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438", evidence), f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C", feedback), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 " + (kind === "safety" ? "\u041E\u0422" : "\u0442\u0435\u043E\u0440\u0438\u0438"), "training_verification", () => ({ assignment_id: a.id, assignment_rev: a.rev, kind, evaluator_id: who.value, evaluated_on: when.value, result: result.value, evidence: evidence.value, feedback: feedback.value })));
      return d;
    }
    function practicalForm(a) {
      const methods = practicalMethods(db).filter((x) => x.state === "active"), builtin = methods.length ? null : event("checklist_version", BUILTIN_PRACTICAL);
      const m = methods[0] || { id: builtin.entity_id, version_no: 1 }, criteria = builtin ? previewCriteria(BUILTIN_PRACTICAL, m.id) : practicalCriteria(db, m.id), total = criteria.length, who = person2("practical_actor", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "", { filter: (x) => x.id !== a.trainee_id }), when = date3("practical_date"), conclusion = simple("practical_conclusion", conclusions, "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u2014"), feedback = note("practical_feedback");
      const controls = criteria.map((x) => ({ x, value: select("practical_value_" + x.position, [[0, "0 \u2014 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E"], [1, "1 \u2014 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E"]], "", "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E"), note: fieldInput2("practical_note_" + x.position) }));
      const result = msg("\u041E\u0446\u0435\u043D\u0435\u043D\u043E 0/" + total), value = () => controls.map((q) => ({ criterion_id: q.x.id, value: q.value.value === "" ? null : Number(q.value.value), note: q.note.value }));
      function refresh2() {
        const x = practicalResult(value(), total);
        result.textContent = "\u041E\u0446\u0435\u043D\u0435\u043D\u043E " + x.rated + "/" + total + " \xB7 " + (x.fraction === null ? "\u0438\u0442\u043E\u0433 \u043D\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D" : x.yes + "/" + total + " \xB7 " + (x.fraction * 100).toFixed(1) + "%");
      }
      controls.forEach((q) => q.value.onchange = refresh2);
      const d = el2("details");
      d.append(el2("summary", "\u041D\u043E\u0432\u0430\u044F \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430"), grid(who.element, f("\u0414\u0430\u0442\u0430", when), f("\u0417\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044E", conclusion)), msg((builtin ? "\u0412\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0430 \xB7 \u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 8" : "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 v" + m.version_no) + " \xB7 \u043F\u0440\u043E\u0446\u0435\u043D\u0442 \u043F\u043E\u0441\u043B\u0435 \u0432\u0441\u0435\u0445 " + total + " \u043E\u0442\u0432\u0435\u0442\u043E\u0432; \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0432\u044B\u0431\u0438\u0440\u0430\u0435\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E."), tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], controls.map((q) => [q.x.position, q.x.section_code, q.x.question, q.value, q.note])), result, f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u043E\u043C\u0443 / \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0443", feedback), action("\u0417\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u043E\u0446\u0435\u043D\u043A\u0443", () => run2(async () => {
        await ws2.applyContentEvents([...builtin ? [builtin] : [], event("assessment_session", { command: "practical", assignment_id: a.id, assignment_rev: a.rev, evaluator_id: who.value, assessed_on: when.value, method_id: m.id, responses: value(), conclusion: conclusion.value, feedback: feedback.value })], readContent3);
        return "\u0417\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
      })));
      return d;
    }
    function qualificationForm(a, p) {
      const actor = person2("qualification_actor", "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C", "", { filter: (x) => x.id !== a.trainee_id }), when = date3("qualification_date"), state = simple("qualification_state", observationLabels, "rated"), level2 = levelPicker("qualification_level", a.scale_id), until = date3("qualification_until", ""), evidence = note("qualification_evidence"), feedback = note("qualification_feedback");
      state.onchange = () => {
        level2.disabled = state.value !== "rated";
        until.disabled = level2.disabled;
        if (level2.disabled) {
          level2.value = "";
          until.value = "";
        }
      };
      const d = el2("details");
      d.append(el2("summary", "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044E"), msg("\u041D\u0430\u0432\u044B\u043A: " + n("skill", a.skill_id) + " \xB7 \u0448\u043A\u0430\u043B\u0430 " + n("rating_scale", a.scale_id) + " \xB7 \u0446\u0435\u043B\u044C " + a.target_level + ". \u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0432\u044B\u0431\u0438\u0440\u0430\u0435\u0442\u0441\u044F \u043F\u043E \u0444\u0430\u043A\u0442\u0443, \u043D\u0435 \u0438\u0437 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u0430."), grid(actor.element, f("\u0414\u0430\u0442\u0430", when), f("\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435", state), f("\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C", level2), f("\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u0435\u043D \u0434\u043E (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E)", until)), f("\u0414\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u0438 \u043E\u0431\u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", evidence), f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C", feedback), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u044F", "assessment_session", () => ({ command: "qualification", assignment_id: a.id, assignment_rev: a.rev, evaluator_id: actor.value, assessed_on: when.value, practical_id: p.id, observation_state: state.value, level: state.value === "rated" && level2.value !== "" ? Number(level2.value) : null, valid_until: nullable(until.value), evidence: evidence.value, feedback: feedback.value })));
      return d;
    }
    function admissionForm(a) {
      const actor = person2("admission_actor", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0437\u0430 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435", "", { filter: (x) => x.id !== a.trainee_id }), when = date3("admission_date"), decision = simple("admission_decision", decisionLabels, "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u2014"), until = date3("admission_until", ""), evidence = note("admission_evidence"), feedback = note("admission_feedback");
      decision.onchange = () => {
        until.disabled = decision.value !== "granted";
        if (until.disabled) until.value = "";
      };
      const d = el2("details");
      d.append(el2("summary", "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435"), msg("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u0443\u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0435\u043D\u043D\u043E\u0433\u043E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430. \u041E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0432\u043D\u0435\u0448\u043D\u0438\u0435 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B, \u043D\u0430\u0440\u044F\u0434\u044B \u0438 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u0442."), grid(actor.element, f("\u0414\u0430\u0442\u0430 \u0440\u0435\u0448\u0435\u043D\u0438\u044F", when), f("\u0420\u0435\u0448\u0435\u043D\u0438\u0435", decision), f("\u0421\u0440\u043E\u043A (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D)", until)), f("\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 / \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430", evidence), f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C", feedback), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435", "admission_decision", () => ({ assignment_id: a.id, assignment_rev: a.rev, actor_id: actor.value, decided_on: when.value, valid_until: nullable(until.value), decision: decision.value, evidence: evidence.value, feedback: feedback.value })));
      return d;
    }
    function practice2(a) {
      const pr = progressFor(db, a), x = evidenceSummary(a), can = a.state !== "cancelled" && a.approval_json && sameRevision(a);
      const panel = pane2("\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430, \u0437\u043D\u0430\u043D\u0438\u044F \u0438 \u0434\u043E\u043F\u0443\u0441\u043A", tableOf2(["\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435"], [["\u0412\u0432\u043E\u0434\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", pr.intro ? "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430" : "\u041D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430"], ["\u041E\u0422", x.s ? resultLabels[x.s.result] : "\u041D\u0435\u0442 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430"], ["\u0422\u0435\u043E\u0440\u0438\u044F", x.t ? resultLabels[x.t.result] : "\u041D\u0435\u0442 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430"], ["\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430", x.p ? conclusions[x.p.conclusion] : "\u041D\u0435\u0442 \u043E\u0446\u0435\u043D\u043A\u0438"], ["\u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F", x.q ? "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043E" : "\u041D\u0435\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F"], ["\u0414\u043E\u043F\u0443\u0441\u043A", x.ad.status]]), msg("\u041F\u043E\u043B\u043E\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0438 \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u043D\u0435 \u0432\u044B\u0434\u0430\u044E\u0442 \u0434\u043E\u043F\u0443\u0441\u043A \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438."));
      if (can) {
        panel.append(verificationForm(a, "safety"), verificationForm(a, "theory"));
        if (pr.intro) panel.append(practicalForm(a));
        else panel.append(msg("\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u043F\u043E\u0441\u043B\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0432\u0432\u043E\u0434\u043D\u044B\u0445 \u043F\u0440\u043E\u0431.", "muted"));
        if (x.p) panel.append(qualificationForm(a, x.p));
        panel.append(admissionForm(a));
      }
      const verifications = rows(db, "SELECT * FROM training_verification WHERE assignment_id=? ORDER BY evaluated_on DESC,recorded_at DESC", [a.id]);
      panel.append(pane2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043E\u043A \u0437\u043D\u0430\u043D\u0438\u0439", table2(["\u0414\u0430\u0442\u0430", "\u0412\u0438\u0434", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C"], verifications.map((v) => [v.evaluated_on, v.kind === "safety" ? "\u041E\u0422" : "\u0422\u0435\u043E\u0440\u0438\u044F", resultLabels[v.result], n("person", v.evaluator_id), v.evidence, v.feedback]))));
      const history = rows(db, "SELECT * FROM assessment_session WHERE assignment_id=? AND state='confirmed' ORDER BY assessed_at DESC,recorded_at DESC", [a.id]);
      const assessed = pane2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0438 \u0438 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438");
      for (const h of history) {
        const detail = el2("details");
        if (h.assessment_kind === "practical") {
          const values = JSON.parse(h.responses_json), criteria = practicalCriteria(db, h.method_id), result = practicalResult(values, criteria.length), lines = values.map((v, i) => [i + 1, criteria[i]?.section_code, criteria[i]?.question, v.value, v.note]);
          detail.append(el2("summary", h.assessed_at + " \xB7 \u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \xB7 " + result.yes + "/" + result.total + " \xB7 " + (result.fraction * 100).toFixed(1) + "% \xB7 " + conclusions[h.conclusion]), msg("\u041E\u0446\u0435\u043D\u0449\u0438\u043A: " + n("person", h.evaluator_id) + " \xB7 " + h.feedback), tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], lines), btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0447\u0435\u043A-\u043B\u0438\u0441\u0442 \u0441\u0442\u0430\u0436\u0451\u0440\u0430 XLSX", () => run2(async () => {
            const method = JSON.parse(one(db, "SELECT methodology_json FROM checklist_version WHERE id=?", [h.method_id]).methodology_json);
            return saveWorkbook("\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F-\u043E\u0446\u0435\u043D\u043A\u0430-" + h.id.slice(0, 8), practicalWorkbook(ExcelJS, method, [{ operation: revLabel(a.sop_revision_id), responses: values, feedback: h.feedback, conclusion: conclusions[h.conclusion], date: h.assessed_at, evaluator: n("person", h.evaluator_id) }], { trainee: n("person", a.trainee_id) }));
          }, { save: false })));
        } else {
          const i = one(db, "SELECT * FROM assessment_item WHERE session_id=?", [h.id]);
          detail.append(el2("summary", h.assessed_at + " \xB7 \u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F \xB7 " + (i?.observation_state === "rated" ? "\u0443\u0440\u043E\u0432\u0435\u043D\u044C " + i.level : observationLabels[i?.observation_state] || "\u2014")), msg("\u0428\u043A\u0430\u043B\u0430: " + n("rating_scale", i?.scale_id) + " \xB7 \u0434\u043E " + (i?.valid_until || "\u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E") + " \xB7 " + n("person", h.evaluator_id)), msg(i?.evidence_note || ""), msg(h.feedback));
        }
        assessed.append(detail);
      }
      if (!history.length) assessed.append(msg("\u041E\u0446\u0435\u043D\u043E\u043A \u043F\u043E\u043A\u0430 \u043D\u0435\u0442."));
      panel.append(assessed);
      const ads = rows(db, "SELECT * FROM admission_decision WHERE assignment_id=? ORDER BY decided_on DESC,recorded_at DESC", [a.id]);
      const decisions = pane2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u0439 \u043E \u0434\u043E\u043F\u0443\u0441\u043A\u0435");
      for (const d of ads) {
        decisions.append(pane2(d.decided_on + " \xB7 " + decisionLabels[d.decision] + (d.revoked_at ? " \xB7 \u041E\u0442\u043E\u0437\u0432\u0430\u043D" : ""), msg("\u0420\u0435\u0448\u0435\u043D\u0438\u0435: " + n("person", d.actor_id) + " \xB7 \u0441\u0440\u043E\u043A: " + (d.valid_until || "\u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D")), msg(d.evidence), msg(d.feedback), ...d.revoked_at ? [msg("\u041F\u0440\u0438\u0447\u0438\u043D\u0430 \u043E\u0442\u0437\u044B\u0432\u0430: " + d.revoke_reason)] : d.decision === "granted" ? [closeRecord("\u041E\u0442\u043E\u0437\u0432\u0430\u0442\u044C \u0434\u043E\u043F\u0443\u0441\u043A", "admission_decision", d, "revoke")] : []));
      }
      if (!ads.length) decisions.append(msg("\u041D\u0435\u0442 \u0440\u0435\u0448\u0435\u043D\u0438\u0439."));
      panel.append(decisions);
      return panel;
    }
    function assignmentCard(a) {
      const root2 = pane2("\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \xB7 " + assignmentName(a), row(back(), btn2("\u041A \u043F\u043B\u0430\u043D\u0443 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", () => go("twi")), btn2("\u041A \u0436\u0443\u0440\u043D\u0430\u043B\u0443", () => go("journal")), btn2("\u0410\u0443\u0434\u0438\u0442 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F", () => go("audit", { mode: "new", assignmentId: a.id })))), tabs = el2("div", void 0, "library-tabs");
      const selected = route.tab || (page2 === "instruction" ? "instruction" : page2 === "practical" ? "practice" : "overview"), content2 = el2("div");
      for (const [id, label, fn] of [["overview", "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", () => overview(a)], ["instruction", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436", () => instruction(a)], ["practice", "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \u0438 \u0434\u043E\u043F\u0443\u0441\u043A", () => practice2(a)]]) {
        const button = btn2(label, () => {
          route.tab = id;
          for (const x of tabs.children) x.classList.remove("selected");
          button.classList.add("selected");
          content2.replaceChildren(fn());
        }, "library-tab" + (selected === id ? " selected" : ""));
        tabs.append(button);
        if (selected === id) content2.append(fn());
      }
      root2.append(tabs, content2);
      return root2;
    }
    function registryPrograms() {
      const items = rows(db, "SELECT * FROM training_program ORDER BY code,version_no DESC").filter((p) => page2 === "internship" ? p.kind === "internship" : p.kind !== "internship"), enrollments = enrollmentList().filter((x) => items.some((p) => p.id === x.program_id));
      return stack(
        pane2(page2 === "internship" ? "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438" : "\u0428\u0430\u0431\u043B\u043E\u043D\u044B \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0438 \u0438 \u0432\u0432\u043E\u0434\u0430 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E", msg("\u0412\u0435\u0440\u0441\u0438\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u044B. \u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u0445\u0440\u0430\u043D\u0438\u0442 \u0441\u0432\u043E\u044E \u0432\u0435\u0440\u0441\u0438\u044E, \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044B\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B."), action("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", () => goLocal({ mode: "program" })), table2(["\u041A\u043E\u0434", "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", "\u0412\u0438\u0434", "\u0412\u0435\u0440\u0441\u0438\u044F", "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F / \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], items.map((p) => [p.code, p.title, programKinds[p.kind], p.version_no, n("profession", p.profession_id) + " / " + n("position", p.position_id), statuses[p.state], btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ programId: p.id }), "primary")]))),
        pane2("\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", table2(["\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", "\u0421\u0440\u043E\u043A", "\u0417\u0430\u0434\u0430\u043D\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], enrollments.map((x) => {
          const p = items.find((v) => v.id === x.program_id), t = enrollmentTasks(db, x);
          return [n("person", x.trainee_id), p.title + " \xB7 v" + p.version_no, n("person", x.mentor_id), x.due_on, t.filter((y) => y.done).length + "/" + t.length, statuses[x.state], btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ enrollmentId: x.id }), "primary")];
        })))
      );
    }
    function programForm() {
      const prev = route.copyId ? one(db, "SELECT * FROM training_program WHERE id=?", [route.copyId]) : null;
      const code = fieldInput2("program_code", prev?.code || ""), title = fieldInput2("program_title", prev?.title || ""), kind = select("program_kind", Object.entries(programKinds).filter(([k]) => page2 === "internship" ? k === "internship" : k !== "internship"), prev?.kind || (page2 === "internship" ? "internship" : "entry"), null);
      const profession = ref("profession", "program_profession", prev?.profession_id || "", "\u2014 \u041B\u044E\u0431\u0430\u044F \u2014"), position = ref("position", "program_position", prev?.position_id || "", "\u2014 \u041B\u044E\u0431\u0430\u044F \u2014"), author = person2("program_author", "\u0421\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u0435\u043B\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B"), tasks = el2("div", void 0, "stack"), controls = [];
      function taskLine(x = {}) {
        const part2 = simple("task_part", parts, x.part || "general"), name = fieldInput2("task_title", x.title || ""), hours = num2("task_hours", x.hours ?? 0, 0, 1e3, 0.25), offset = num2("task_day", x.day_offset ?? 0, 0, 3660), rev = revPicker("task_revision", x.sop_revision_id || "");
        const skill = ref("skill", "task_skill", x.skill_id || "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", (v) => v.operation_id === currentStandard(db, rev.value)?.operation_id), target = scaleFields("task_target", x.scale_id || "", x.target_level ?? null), line = el2("div", void 0, "lc4-task");
        const item2 = { part: part2, name, hours, offset, rev, skill, target, line };
        controls.push(item2);
        function sync() {
          const on = !!rev.value;
          skill.disabled = !on;
          target.scale.disabled = !on;
          target.level.disabled = !on;
          if (!on) {
            skill.value = "";
            target.set("", null);
          }
        }
        rev.onchange = () => {
          replaceOptions(skill, ref("skill", "task_skill", "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014", (v) => v.operation_id === currentStandard(db, rev.value)?.operation_id));
          sync();
        };
        line.append(row(el2("strong", "\u0417\u0430\u0434\u0430\u043D\u0438\u0435"), btn2("\u0423\u0434\u0430\u043B\u0438\u0442\u044C", () => {
          const i = controls.indexOf(item2);
          if (i >= 0) controls.splice(i, 1);
          line.remove();
        })), grid(f("\u0427\u0430\u0441\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", part2), f("\u0417\u0430\u0434\u0430\u043D\u0438\u0435 / \u0444\u0443\u043D\u043A\u0446\u0438\u044F", name), f("\u0427\u0430\u0441\u044B", hours), f("\u0414\u0435\u043D\u044C \u043E\u0442 \u043D\u0430\u0447\u0430\u043B\u0430 (0 = \u043F\u0435\u0440\u0432\u044B\u0439)", offset)), f("\u0421\u041E\u041F (\u0435\u0441\u043B\u0438 \u043E\u0431\u0443\u0447\u0430\u0435\u043C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438)", rev), f("\u041D\u0430\u0432\u044B\u043A", skill), target.element);
        tasks.append(line);
        sync();
      }
      if (prev) rows(db, "SELECT * FROM training_program_task WHERE program_id=? ORDER BY position", [prev.id]).forEach(taskLine);
      else if (page2 === "internship") Object.keys(parts).forEach((part2) => taskLine({ part: part2 }));
      else taskLine();
      return pane2(prev ? "\u041D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B" : "\u041D\u043E\u0432\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", row(back()), grid(f("\u041A\u043E\u0434", code), f("\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", title), f("\u0412\u0438\u0434", kind), f("\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", profession), f("\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", position), author.element), msg("\u0417\u0430\u0434\u0430\u043D\u0438\u044F \u0441 \u0421\u041E\u041F \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u044E\u0442\u0441\u044F \u0447\u0435\u0440\u0435\u0437 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F; \u043E\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u043E\u0442\u043C\u0435\u0447\u0430\u044E\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u043C \u0444\u0430\u043A\u0442\u043E\u043C. \u041F\u0440\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0438 \u0442\u043E\u0433\u043E \u0436\u0435 \u043A\u043E\u0434\u0430 \u0441\u043E\u0437\u0434\u0430\u0451\u0442\u0441\u044F \u043D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F."), tasks, ...page2 === "internship" ? [btn2("\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0438\u0437 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F 2", () => {
        if (!confirm("\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u043D\u0435\u0437\u0430\u043F\u0438\u0441\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043E\u0431\u0440\u0430\u0437\u0446\u043E\u043C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B? \u0427\u0430\u0441\u044B, \u0434\u0430\u0442\u044B \u0438 \u0421\u041E\u041F \u0437\u0430\u0442\u0435\u043C \u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0432\u0440\u0443\u0447\u043D\u0443\u044E.")) return;
        controls.splice(0);
        tasks.replaceChildren();
        INITIAL_PROGRAM_TASKS.forEach(taskLine);
      })] : [], btn2("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u0435", () => taskLine()), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0432\u0435\u0440\u0441\u0438\u044E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", "training_program", () => ({ code: code.value, kind: kind.value, title: title.value, profession_id: nullable(profession.value), position_id: nullable(position.value), created_by: author.value, tasks: controls.map((v) => ({ part: v.part.value, title: v.name.value, hours: Number(v.hours.value), day_offset: Number(v.offset.value), sop_revision_id: nullable(v.rev.value), skill_id: v.rev.value ? nullable(v.skill.value) : null, scale_id: v.rev.value ? nullable(v.target.scale.value) : null, target_level: v.rev.value && v.target.level.value !== "" ? Number(v.target.level.value) : null })) }), null, (id) => {
        route = { page: page2, programId: id };
      }));
    }
    function programCard(p) {
      const tasks = rows(db, "SELECT * FROM training_program_task WHERE program_id=? ORDER BY position", [p.id]), lines = tasks.map((x) => [x.position, parts[x.part], x.title, x.day_offset, x.hours, x.sop_revision_id ? revLabel(x.sop_revision_id) : "\u2014", x.target_level ?? "\u2014"]);
      const root2 = pane2(p.code + " \xB7 " + p.title + " \xB7 v" + p.version_no, row(back(), action("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E", () => goLocal({ mode: "program", copyId: p.id }))), msg(programKinds[p.kind] + " \xB7 " + statuses[p.state] + " \xB7 \u0447\u0430\u0441\u043E\u0432 " + tasks.reduce((s, x) => s + x.hours, 0)), tableOf2(["\u2116", "\u0427\u0430\u0441\u0442\u044C", "\u0417\u0430\u0434\u0430\u043D\u0438\u0435", "\u0414\u0435\u043D\u044C", "\u0427\u0430\u0441\u044B", "\u0421\u041E\u041F", "\u0426\u0435\u043B\u044C"], lines), exportButton("\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430-" + p.code, ["\u2116", "\u0427\u0430\u0441\u0442\u044C", "\u0417\u0430\u0434\u0430\u043D\u0438\u0435", "\u0414\u0435\u043D\u044C", "\u0427\u0430\u0441\u044B", "\u0421\u041E\u041F", "\u0426\u0435\u043B\u044C"], lines));
      if (p.state === "active") {
        const start = date3("enroll_start"), due = date3("enroll_due"), internStart = date3("internship_start", ""), internEnd = date3("internship_end", ""), entryStart = date3("entry_start", ""), entryEnd = date3("entry_end", ""), learner = person2("enroll_trainee", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "", { allowed: ["trainee"], at: () => start.value }), mentor = person2("enroll_mentor", "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", "", { allowed: ["mentor", "instructor"], at: () => start.value }), manager = person2("enroll_manager", "\u0420\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C"), reason = note("enroll_reason");
        const d = el2("details");
        d.append(el2("summary", "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0443\u044E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443"), grid(learner.element, mentor.element, manager.element, f("\u041D\u0430\u0447\u0430\u043B\u043E", start), f("\u0421\u0440\u043E\u043A \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F", due)), ...p.kind === "internship" ? [grid(f("\u0421\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0430 \u0441", internStart), f("\u0421\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0430 \u043F\u043E", internEnd), f("\u0412\u0432\u043E\u0434 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E \u0441", entryStart), f("\u0412\u0432\u043E\u0434 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E \u043F\u043E", entryEnd))] : [], f("\u041F\u0440\u0438\u0447\u0438\u043D\u0430 / \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", reason), save2("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", "training_enrollment", () => ({ program_id: p.id, trainee_id: learner.value, mentor_id: mentor.value, manager_id: manager.value, start_on: start.value, due_on: due.value, reason: reason.value, ...p.kind === "internship" ? { internship_start: nullable(internStart.value), internship_end: nullable(internEnd.value), entry_start: nullable(entryStart.value), entry_end: nullable(entryEnd.value) } : {} }), null, (id) => {
          route = { page: page2, enrollmentId: id };
        }));
        root2.append(d, closeRecord("\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0448\u0430\u0431\u043B\u043E\u043D\u0430", "training_program", p, "retire"));
      }
      return root2;
    }
    function plusDays3(d, days) {
      const v = /* @__PURE__ */ new Date(d + "T00:00:00Z");
      v.setUTCDate(v.getUTCDate() + days);
      return v.toISOString().slice(0, 10);
    }
    function enrollmentCard(x) {
      const p = one(db, "SELECT * FROM training_program WHERE id=?", [x.program_id]), tasks = enrollmentTasks(db, x), panel = pane2("\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \xB7 " + n("person", x.trainee_id), row(back(), btn2("\u0428\u0430\u0431\u043B\u043E\u043D \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", () => goLocal({ programId: p.id }))), msg(p.title + " \xB7 v" + p.version_no + " \xB7 " + statuses[x.state] + " \xB7 " + x.start_on + " \u2014 " + x.due_on), msg("\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A: " + n("person", x.mentor_id) + " \xB7 \u0440\u0443\u043A\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C: " + n("person", x.manager_id) + " \xB7 " + x.reason), tableOf2(["\u0427\u0430\u0441\u0442\u044C", "\u0417\u0430\u0434\u0430\u043D\u0438\u0435", "\u0421\u0440\u043E\u043A", "\u0427\u0430\u0441\u044B", "\u0424\u0430\u043A\u0442", ""], tasks.map((t2) => {
        const due = plusDays3(x.start_on, t2.day_offset), controls = row();
        if (t2.assignment) controls.append(btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", () => go("twi", { id: t2.assignment.id })));
        else if (x.state === "active" && t2.sop_revision_id) controls.append(action("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436", () => go("twi", { mode: "new", revisionId: t2.sop_revision_id, skillId: t2.skill_id, scaleId: t2.scale_id, targetLevel: t2.target_level, traineeId: x.trainee_id, supervisorId: x.mentor_id, enrollmentId: x.id, programTaskId: t2.id, startOn: x.start_on, dueOn: due, reason: "\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B: " + t2.title })));
        else if (x.state === "active") controls.append(action("\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", () => goLocal({ enrollmentId: x.id, taskId: t2.id })));
        return [parts[t2.part], t2.title, due, t2.hours, t2.done ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E" : t2.assignment ? stateLabel(t2.assignment) : t2.result ? resultLabels[t2.result.result] : "\u041D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E", controls];
      })));
      const facts = tasks.flatMap((t2) => t2.sop_revision_id ? rows(db, "SELECT s.held_at,s.duration_minutes FROM training_session s JOIN training_assignment a ON a.id=s.assignment_id WHERE a.enrollment_id=? AND a.program_task_id=? AND s.stage_code IS NOT NULL", [x.id, t2.id]).map((v) => ({ date: v.held_at.slice(0, 10), minutes: v.duration_minutes, title: t2.title })) : rows(db, "SELECT held_on,minutes FROM training_task_result WHERE enrollment_id=? AND task_id=?", [x.id, t2.id]).map((v) => ({ date: v.held_on, minutes: v.minutes, title: t2.title })));
      const cal = calendarData(x.start_on, tasks), dates = calendarFacts(x.start_on, tasks, facts), calendar = pane2("\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u043D\u044B\u0439 \u043F\u043B\u0430\u043D", msg("\u041F\u043B\u0430\u043D\u043E\u0432\u044B\u0435 \u0434\u0430\u0442\u044B \u0431\u0435\u0440\u0443\u0442\u0441\u044F \u0438\u0437 \u0432\u0435\u0440\u0441\u0438\u0438 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B, \u0444\u0430\u043A\u0442\u044B \u2014 \u0438\u0437 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0434\u0430\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439. \u041F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u044F \u0443\u0447\u0438\u0442\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E."), tableOf2(["\u0414\u0430\u0442\u0430", "\u041F\u043B\u0430\u043D\u043E\u0432\u044B\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F", "\u041F\u043B\u0430\u043D, \u0447", "\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u044F", "\u0424\u0430\u043A\u0442, \u0447"], dates.map((d) => [d.date, d.plannedTasks.join(" \xB7 "), d.planned, d.actualTasks.join(" \xB7 "), Math.round(d.actual * 100) / 100])), msg("\u0412\u0441\u0435\u0433\u043E \u043F\u043B\u0430\u043D\u043E\u0432\u044B\u0445 \u0447\u0430\u0441\u043E\u0432: " + cal.total));
      if (p.kind === "internship") calendar.append(msg(x.internship_start ? "\u0421\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0430: " + x.internship_start + " \u2014 " + x.internship_end + " \xB7 \u0412\u0432\u043E\u0434: " + x.entry_start + " \u2014 " + x.entry_end : "\u041F\u0435\u0440\u0438\u043E\u0434\u044B \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438 \u0438 \u0432\u0432\u043E\u0434\u0430 \u0432 \u0441\u0442\u0430\u0440\u043E\u0439 \u0437\u0430\u043F\u0438\u0441\u0438 \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u044B."));
      const scope = directoryPeople(db, x.start_on).find((v) => v.id === x.trainee_id);
      calendar.append(btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u043D\u044B\u0439 \u043F\u043B\u0430\u043D XLSX", () => run2(async () => saveWorkbook("\u041F\u043B\u0430\u043D-\u0432\u0432\u043E\u0434\u0430-" + p.code, entryWorkbook(ExcelJS, p, x, tasks, { scope: scope?.unit || "", trainee: n("person", x.trainee_id), mentor: n("person", x.mentor_id), manager: n("person", x.manager_id), revision: revLabel, facts, responsible: (t2) => t2.assignment ? n("person", t2.assignment.mentor_id) : t2.result ? n("person", t2.result.actor_id) : "" })), { save: false })));
      panel.append(calendar);
      const t = tasks.find((q) => q.id === route.taskId);
      if (t && !t.sop_revision_id && x.state === "active") {
        const actor = person2("task_actor", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439"), when = date3("task_held"), minutes = num2("task_minutes", 0, 0, 1440), result = simple("task_result", { completed: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E", incomplete: "\u041D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E" }, "completed"), evidence = note("task_evidence");
        panel.append(pane2("\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \xB7 " + t.title, grid(actor.element, f("\u0414\u0430\u0442\u0430", when), f("\u041C\u0438\u043D\u0443\u0442", minutes), f("\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", result)), f("\u0424\u0430\u043A\u0442 \u0438 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", evidence), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0437\u0430\u0434\u0430\u043D\u0438\u044F", "training_task_result", () => ({ enrollment_id: x.id, task_id: t.id, actor_id: actor.value, held_on: when.value, result: result.value, minutes: Number(minutes.value), evidence: evidence.value, enrollment_rev: x.rev }), null, () => {
          route = { page: page2, enrollmentId: x.id };
        })));
      }
      if (x.state === "active") {
        const actor = person2("enroll_finish_actor", "\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0437\u0430 \u0438\u0442\u043E\u0433"), conclusion = simple("enroll_conclusion", conclusions, "", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014"), feedback = note("enroll_feedback"), d = el2("details");
        d.append(el2("summary", "\u0418\u0442\u043E\u0433 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B"), grid(actor.element, f("\u0417\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435", conclusion)), f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C / \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435", feedback), save2("\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", "training_enrollment", () => ({ command: "finish", actor_id: actor.value, conclusion: conclusion.value, feedback: feedback.value }), x, () => {
        }, !tasks.every((t2) => t2.done)), save2("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", "training_enrollment", () => ({ command: "cancel", actor_id: actor.value, conclusion: null, feedback: feedback.value }), x));
        panel.append(d);
      } else panel.append(msg("\u0417\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435: " + (conclusions[x.conclusion] || "\u2014") + " \xB7 " + (x.feedback || "")));
      return panel;
    }
    function certificatePage() {
      const items = rows(db, "SELECT * FROM mentor_credential ORDER BY issued_on DESC,id"), out = pane2("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B \u0438 \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0430", msg("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u044E\u0442\u0441\u044F \u0432\u044B\u0434\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B. \u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u043E \u043F\u0440\u043E\u0441\u043B\u0443\u0448\u0438\u0432\u0430\u043D\u0438\u0438 \u043D\u0435 \u0434\u0430\u0451\u0442 \u043F\u0440\u0430\u0432\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C. \u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F \u043F\u043E \u0431\u0430\u043B\u043B\u0430\u043C \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F."), action("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442", () => goLocal({ mode: "new" })), table2(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0412\u0438\u0434", "\u0420\u043E\u043B\u044C", "\u041D\u043E\u043C\u0435\u0440", "\u0412\u044B\u0434\u0430\u043D", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u0434\u043E", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], items.map((x2) => [n("person", x2.person_id), x2.kind === "certificate" ? "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442" : "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E", credentialRoles[x2.role], x2.number, x2.issued_on, x2.valid_until || "\u041D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D", x2.revoked_at ? "\u041E\u0442\u043E\u0437\u0432\u0430\u043D" : x2.valid_until && x2.valid_until < day ? "\u0418\u0441\u0442\u0451\u043A" : "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D", btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: x2.id }), "primary")])));
      if (route.mode === "new") {
        const who = person2("credential_person", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A"), actor = person2("credential_actor", "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043B"), role = simple("credential_role", credentialRoles, "instructor"), kind = simple("credential_kind", { certificate: "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442", attendance: "\u0421\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u043E \u043F\u0440\u043E\u0441\u043B\u0443\u0448\u0438\u0432\u0430\u043D\u0438\u0438" }, "certificate"), number = fieldInput2("credential_number"), issuer = fieldInput2("credential_issuer"), issued = date3("credential_issued"), valid = date3("credential_valid", ""), evidence = note("credential_evidence");
        return pane2("\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u043E \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0435", back(), grid(who.element, actor.element, f("\u0412\u0438\u0434", kind), f("\u0420\u043E\u043B\u044C", role), f("\u041D\u043E\u043C\u0435\u0440", number), f("\u041A\u0435\u043C \u0432\u044B\u0434\u0430\u043D", issuer), f("\u0412\u044B\u0434\u0430\u043D", issued), f("\u0421\u0440\u043E\u043A (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D)", valid)), f("\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B / \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0439 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442", evidence), save2("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442", "mentor_credential", () => ({ person_id: who.value, registered_by: actor.value, kind: kind.value, role: role.value, number: number.value, issuer: issuer.value, issued_on: issued.value, valid_until: nullable(valid.value), evidence: evidence.value }), null, (id) => {
          route = { page: page2, id };
        }));
      }
      const x = items.find((v) => v.id === route.id);
      if (x) return pane2(n("person", x.person_id) + " \xB7 " + x.number, back(), msg(credentialRoles[x.role] + " \xB7 " + x.issuer + " \xB7 " + x.issued_on + " \xB7 " + (x.revoked_at ? "\u041E\u0442\u043E\u0437\u0432\u0430\u043D" : "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D")), msg(x.evidence), ...x.kind === "certificate" ? [btn2("\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u0430 DOCX", () => run2(async () => {
        const info = directoryPeople(db, x.issued_on).find((v) => v.id === x.person_id);
        const label = x.role === "internal_trainer" ? "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u043E\u0432 TWI" : "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A TWI";
        downloadBytes2("\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B-\u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u0430-" + x.id.slice(0, 8) + ".docx", draftDocx([{ text: "\u0420\u0415\u041A\u0412\u0418\u0417\u0418\u0422\u042B \u0421\u0415\u0420\u0422\u0418\u0424\u0418\u041A\u0410\u0422\u0410", bold: true, size: 32, center: true }, { text: "\u041D\u0435 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u0430 \xB7 \u0431\u0435\u0437 \u043F\u043E\u0434\u043F\u0438\u0441\u0438", center: true }, n("person", x.person_id), info?.position || "", label, "\u041D\u043E\u043C\u0435\u0440: " + x.number, "\u0412\u044B\u0434\u0430\u043D: " + x.issued_on, "\u041E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F: " + x.issuer, "\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435: " + x.evidence, "\u041F\u043E\u0434\u043F\u0438\u0441\u044C: __________________"]));
        return "\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u044B; \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0431\u043B\u0430\u043D\u043A";
      }, { save: false }))] : [], ...!x.revoked_at ? [closeRecord("\u041E\u0442\u043E\u0437\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442", "mentor_credential", x, "revoke")] : []);
      return out;
    }
    function groupOrderForm() {
      const organization = fieldInput2("order_organization"), city = fieldInput2("order_city"), number = fieldInput2("order_number"), order = date3("order_on"), start = date3("order_start"), end = date3("order_end", ""), payFrom = date3("order_pay_from", ""), payI = num2("order_pay_instructor", "", 0, 1e7), payT = num2("order_pay_trainer", "", 0, 1e7), actor = person2("group_order_actor", "\u0414\u0438\u0440\u0435\u043A\u0442\u043E\u0440 / \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0439"), evidence = note("group_order_evidence"), confirmed = check("group_order_confirm", "\u041F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u044B\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 \u043F\u043E\u043B\u0443\u0447\u0435\u043D, \u043E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E"), members = [], listEl = el2("div", void 0, "stack");
      const roleLabel = (x) => x.role === "internal_trainer" ? "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440" : "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A";
      function candidates() {
        return rows(db, "SELECT * FROM mentor_credential WHERE kind='certificate' ORDER BY issued_on DESC").filter((x) => certificateValid(db, x.id, start.value));
      }
      function addMember() {
        const role = select("group_member_role", [["", "\u0412\u0441\u0435 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435"], ["instructor", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u044B-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438"], ["internal_trainer", "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0435 \u0442\u0440\u0435\u043D\u0435\u0440\u044B"]], "", null), cert = select("group_member_cert", []), ack = date3("group_member_ack", day), description = msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442"), block = el2("div", void 0, "lc4-task");
        const matching = () => candidates().filter((x) => !role.value || (role.value === "internal_trainer" ? x.role === "internal_trainer" : x.role !== "internal_trainer"));
        const who = person2("group_member_person", "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "", { at: () => start.value, filter: (p) => matching().some((x) => x.person_id === p.id), onChange: refresh2 });
        const selected = () => matching().find((x) => x.id === cert.value && x.person_id === who.value);
        function show2() {
          const x = selected(), p = x && directoryPeople(db, start.value).find((y) => y.id === x.person_id);
          description.textContent = x ? n("person", x.person_id) + " \xB7 " + (orderPosition(db, x.person_id, start.value) || "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C \u043D\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0430") + " \xB7 " + roleLabel(x) : "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442";
        }
        function refresh2() {
          if (who.value && !matching().some((x) => x.person_id === who.value)) who.set("");
          const before = cert.value, available = matching().filter((x) => x.person_id === who.value);
          replaceOptions(cert, select(cert.name, available.map((x) => [x.id, roleLabel(x) + " \xB7 " + x.number]), available.some((x) => x.id === before) ? before : available.length === 1 ? available[0].id : ""));
          show2();
        }
        role.onchange = refresh2;
        cert.onchange = show2;
        const item2 = { cert, ack, block, selected, refresh: refresh2 };
        members.push(item2);
        block.append(grid(f("\u0413\u0440\u0443\u043F\u043F\u0430 \u043F\u0440\u0438\u043A\u0430\u0437\u0430", role), who.element, f("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442", cert), f("\u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D", ack)), description, btn2("\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430", () => {
          members.splice(members.indexOf(item2), 1);
          block.remove();
        }));
        listEl.append(block);
        refresh2();
      }
      start.onchange = () => members.forEach((m) => m.refresh());
      addMember();
      function collect(registered) {
        const header2 = { order_number: number.value.trim(), order_on: order.value, organization: organization.value.trim(), city: city.value.trim(), approved_by: actor.value, valid_from: start.value, valid_to: nullable(end.value), supplement_from: nullable(payFrom.value), instructor_amount: payI.value === "" ? null : Number(payI.value), trainer_amount: payT.value === "" ? null : Number(payT.value), evidence: evidence.value, members: [] };
        invariant(header2.order_number && header2.organization && header2.city && actor.value && members.length && header2.order_on && header2.valid_from, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0448\u0430\u043F\u043A\u0443 \u043F\u0440\u0438\u043A\u0430\u0437\u0430 \u0438 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432");
        if (registered) invariant(confirmed.input.checked, "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044E \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043A\u0430\u0437\u0430 \u0438 \u043E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0439");
        const snapshots = [], seen = /* @__PURE__ */ new Set();
        for (const m of members) {
          const cert = m.selected(), p = cert && directoryPeople(db, start.value).find((x) => x.id === cert.person_id);
          const position = p ? orderPosition(db, p.id, start.value) : "";
          invariant(cert && p && position, "\u041D\u0443\u0436\u043D\u044B \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u0438 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
          const k = p.id + ":" + (cert.role === "internal_trainer" ? "vt" : "instructor");
          invariant(!seen.has(k), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0432 \u0433\u0440\u0443\u043F\u043F\u0435");
          seen.add(k);
          header2.members.push({ id: uuid(), credential_id: cert.id, acknowledged_on: m.ack.value });
          snapshots.push({ role: cert.role, person_name: p.display_name, position_name: position });
        }
        invariant([header2.instructor_amount, header2.trainer_amount].every((x) => x === null || Number.isInteger(x) && x >= 0), "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043D\u0435\u043E\u0442\u0440\u0438\u0446\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0446\u0435\u043B\u044B\u0435 \u0441\u0443\u043C\u043C\u044B");
        invariant(header2.instructor_amount === null && header2.trainer_amount === null ? !header2.supplement_from : !!header2.supplement_from, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0430\u0442\u0443 \u0434\u043E\u043F\u043B\u0430\u0442\u044B \u0438\u043B\u0438 \u043E\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F \u0434\u043E\u043F\u043B\u0430\u0442 \u043F\u0443\u0441\u0442\u044B\u043C\u0438");
        return { header: header2, snapshots, order: { ...header2, approved_name: n("person", actor.value) } };
      }
      return pane2("\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 \u043E \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0438", back(), msg("\u041F\u0440\u043E\u0435\u043A\u0442 \u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0438\u0437 \u0432\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u043E\u0433\u043E \u0431\u043B\u0430\u043D\u043A\u0430; \u043C\u043E\u0436\u043D\u043E \u0442\u0430\u043A\u0436\u0435 \u0432\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u0432\u043E\u0439 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u0439 DOCX. \u0414\u043B\u044F \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043D\u0443\u0436\u043D\u044B \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u044B\u0439 \u043F\u0440\u0438\u043A\u0430\u0437, \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B \u0438 \u043E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430. \u0421\u0443\u043C\u043C\u044B \u0432\u0432\u043E\u0434\u044F\u0442\u0441\u044F \u043F\u043E \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u043C\u0443 \u0440\u0435\u0448\u0435\u043D\u0438\u044E, \u0440\u0430\u0441\u0447\u0451\u0442 \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u044B \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F."), grid(f("\u041E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F", organization), f("\u0413\u043E\u0440\u043E\u0434", city), f("\u041D\u043E\u043C\u0435\u0440 \u043F\u0440\u0438\u043A\u0430\u0437\u0430", number), f("\u0414\u0430\u0442\u0430 \u043F\u0440\u0438\u043A\u0430\u0437\u0430", order), f("\u041D\u0430\u0447\u0430\u043B\u043E \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0439", start), f("\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 (\u0435\u0441\u043B\u0438 \u0435\u0441\u0442\u044C)", end), actor.element), grid(f("\u0414\u043E\u043F\u043B\u0430\u0442\u0430 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430\u043C, \u0440\u0443\u0431. \u043D\u0430 \u0440\u0443\u043A\u0438", payI), f("\u0414\u043E\u043F\u043B\u0430\u0442\u0430 \u0412\u0422, \u0440\u0443\u0431. \u043D\u0430 \u0440\u0443\u043A\u0438", payT), f("\u0414\u0430\u0442\u0430 \u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u043E\u043F\u043B\u0430\u0442\u044B", payFrom)), listEl, btn2("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430", addMember), f("\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 / \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043A\u0430\u0437\u0430", evidence), confirmed.element, row(btn2("\u0421\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442 DOCX", () => {
        try {
          const x = collect(false);
          downloadBytes2("\u041F\u0440\u043E\u0435\u043A\u0442-\u043F\u0440\u0438\u043A\u0430\u0437\u0430.docx", builtinOrderDocx(x.order, x.snapshots));
          c.notify("\u041F\u0440\u043E\u0435\u043A\u0442 \u043F\u0440\u0438\u043A\u0430\u0437\u0430 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D \u0431\u0435\u0437 \u043F\u043E\u0434\u043F\u0438\u0441\u0438");
        } catch (e) {
          c.notify(e.message, true);
        }
      }), localDocx("\u0421\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442 \u043F\u043E \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0443 DOCX", async (bytes) => {
        const x = collect(false);
        downloadBytes2("\u041F\u0440\u043E\u0435\u043A\u0442-\u043F\u0440\u0438\u043A\u0430\u0437\u0430.docx", await fillOrderTemplate(bytes, x.order, x.snapshots));
        return "\u041F\u0440\u043E\u0435\u043A\u0442 \u043F\u0440\u0438\u043A\u0430\u0437\u0430 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D \u0431\u0435\u0437 \u043F\u043E\u0434\u043F\u0438\u0441\u0438";
      }), save2("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0439 \u043F\u0440\u0438\u043A\u0430\u0437", "mentor_order", () => collect(true).header, null, (id) => {
        route = { page: page2, groupId: id };
      })));
    }
    function appointmentPage() {
      const items = rows(db, "SELECT * FROM mentor_appointment ORDER BY valid_from DESC,id"), groups = rows(db, "SELECT * FROM mentor_order ORDER BY order_on DESC,id");
      if (route.mode === "group") return groupOrderForm();
      const group = groups.find((g) => g.id === route.groupId);
      if (group) {
        const members = items.filter((x2) => x2.order_id === group.id);
        return pane2("\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 " + group.order_number, back(), msg(group.organization + " \xB7 " + group.city + " \xB7 " + group.order_on), msg("\u0423\u0442\u0432\u0435\u0440\u0434\u0438\u043B: " + group.approved_name + " \xB7 " + group.valid_from + " \u2014 " + (group.valid_to || "\u2014")), msg(orderPayment(group)), msg(group.evidence), tableOf2(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", "\u0420\u043E\u043B\u044C", "\u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", ""], members.map((x2) => [x2.person_name, x2.position_name, credentialRoles[x2.role], x2.acknowledged_on, x2.revoked_at ? "\u041F\u0440\u0435\u043A\u0440\u0430\u0449\u0435\u043D\u043E" : "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043E", btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: x2.id }))])), btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043F\u0440\u0438\u043A\u0430\u0437 DOCX", () => {
          try {
            downloadBytes2("\u041F\u0440\u0438\u043A\u0430\u0437-" + group.id.slice(0, 8) + ".docx", builtinOrderDocx(group, members, { registered: true }));
            c.notify("\u041A\u043E\u043F\u0438\u044F \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u043E\u0432 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0431\u0435\u0437 \u043F\u043E\u0434\u043F\u0438\u0441\u0438");
          } catch (e) {
            c.notify(e.message, true);
          }
        }), localDocx("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043A\u043E\u043F\u0438\u044E \u043F\u043E \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0443 DOCX", async (bytes) => {
          downloadBytes2("\u041F\u0440\u0438\u043A\u0430\u0437-" + group.id.slice(0, 8) + ".docx", await fillOrderTemplate(bytes, group, members, { registered: true }));
          return "\u041A\u043E\u043F\u0438\u044F \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u043E\u0432 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0431\u0435\u0437 \u043F\u043E\u0434\u043F\u0438\u0441\u0438";
        }));
      }
      if (route.mode === "new") {
        const cert = select("appointment_certificate", rows(db, "SELECT * FROM mentor_credential WHERE kind='certificate' AND revoked_at IS NULL ORDER BY issued_on DESC").map((x2) => [x2.id, n("person", x2.person_id) + " \xB7 " + credentialRoles[x2.role] + " \xB7 " + x2.number])), actor = person2("appointment_actor", "\u0423\u0442\u0432\u0435\u0440\u0434\u0438\u0432\u0448\u0438\u0439 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"), number = fieldInput2("appointment_number"), order = date3("appointment_order_date"), start = date3("appointment_start"), end = date3("appointment_end", ""), ack = date3("appointment_ack"), evidence = note("appointment_evidence");
        return pane2("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043F\u0440\u0438\u043A\u0430\u0437\u0430", back(), f("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0438 \u0440\u043E\u043B\u044C", cert), grid(actor.element, f("\u041D\u043E\u043C\u0435\u0440 \u043F\u0440\u0438\u043A\u0430\u0437\u0430", number), f("\u0414\u0430\u0442\u0430 \u043F\u0440\u0438\u043A\u0430\u0437\u0430", order), f("\u041D\u0430\u0447\u0430\u043B\u043E \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0439", start), f("\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E)", end), f("\u0414\u0430\u0442\u0430 \u043E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u044F", ack)), f("\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 / \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043A\u0430\u0437\u0430", evidence), save2("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u0438\u043A\u0430\u0437", "mentor_appointment", () => {
          const c2 = one(db, "SELECT * FROM mentor_credential WHERE id=?", [cert.value]);
          invariant(c2, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442");
          return { person_id: c2.person_id, credential_id: c2.id, role: c2.role, order_number: number.value, order_on: order.value, approved_by: actor.value, valid_from: start.value, valid_to: nullable(end.value), acknowledged_on: ack.value, evidence: evidence.value };
        }, null, (id) => {
          route = { page: page2, id };
        }));
      }
      const x = items.find((v) => v.id === route.id);
      if (x) return pane2("\u041F\u0440\u0438\u043A\u0430\u0437 " + x.order_number, back(), msg(n("person", x.person_id) + " \xB7 " + credentialRoles[x.role] + " \xB7 " + x.valid_from + " \u2014 " + (x.valid_to || "\u0431\u0435\u0437 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F")), msg(x.evidence), ...!x.revoked_at ? [closeRecord("\u041F\u0440\u0435\u043A\u0440\u0430\u0442\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043F\u0440\u0438\u043A\u0430\u0437\u0430", "mentor_appointment", x, "revoke")] : [msg("\u041F\u0440\u0435\u043A\u0440\u0430\u0449\u0435\u043D\u043E: " + x.revoked_at)]);
      return pane2("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E \u043F\u0440\u0438\u043A\u0430\u0437\u0430\u043C", msg("\u0420\u043E\u043B\u0438 \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0435, \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u0438 \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u044B\u0439 \u043F\u0440\u0438\u043A\u0430\u0437 \u2014 \u0440\u0430\u0437\u043D\u044B\u0435 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u044F. \u041F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0432 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435 \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430."), row(action("\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0439 \u043F\u0440\u0438\u043A\u0430\u0437", () => goLocal({ mode: "group" })), action("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u0438\u043A\u0430\u0437", () => goLocal({ mode: "new" })), btn2("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B", () => go("certification"))), pane2("\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u044B\u0435 \u043F\u0440\u0438\u043A\u0430\u0437\u044B", table2(["\u041D\u043E\u043C\u0435\u0440", "\u0414\u0430\u0442\u0430", "\u041E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", ""], groups.map((g) => [g.order_number, g.order_on, g.organization, items.filter((x2) => x2.order_id === g.id).length, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ groupId: g.id }), "primary")]))), table2(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0420\u043E\u043B\u044C", "\u041F\u0440\u0438\u043A\u0430\u0437", "\u041D\u0430\u0447\u0430\u043B\u043E", "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", "\u041E\u0437\u043D\u0430\u043A\u043E\u043C\u043B\u0435\u043D\u0438\u0435", ""], items.filter((x2) => !x2.order_id).map((x2) => [n("person", x2.person_id), credentialRoles[x2.role], x2.order_number, x2.valid_from, x2.valid_to || "\u2014", x2.acknowledged_on + (x2.revoked_at ? " \xB7 \u043F\u0440\u0435\u043A\u0440\u0430\u0449\u0451\u043D" : ""), btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: x2.id }), "primary")])));
    }
    function mentorPage() {
      const persons = directoryPeople(db, day).filter((p) => p.roles.some((x) => ["mentor", "instructor"].includes(x.kind))), auths = rows(db, "SELECT * FROM mentor_authorization WHERE credential_id IS NOT NULL ORDER BY valid_from DESC,id");
      if (route.mode === "auth") {
        let refresh2 = function() {
          replaceOptions(appointment, select("auth_appointment", rows(db, "SELECT * FROM mentor_appointment WHERE person_id=? AND revoked_at IS NULL ORDER BY valid_from DESC", [who.value]).map((x) => [x.id, x.order_number + " \xB7 " + credentialRoles[x.role] + " \xB7 " + x.valid_from])));
        };
        const who = person2("auth_person", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 / \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", route.personId || "", { allowed: ["mentor", "instructor"], onChange: refresh2 }), actor = person2("auth_actor", "\u0423\u0442\u0432\u0435\u0440\u0434\u0438\u0432\u0448\u0438\u0439 \u043F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C"), op = ref("operation", "auth_operation"), start = date3("auth_start"), end = date3("auth_end", ""), appointment = select("auth_appointment", []);
        refresh2();
        return pane2("\u041F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438", back(), grid(who.element, actor.element, f("\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", op), f("\u041F\u0440\u0438\u043A\u0430\u0437", appointment), f("\u041D\u0430\u0447\u0430\u043B\u043E", start), f("\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 (\u0435\u0441\u043B\u0438 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E)", end)), msg("\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0440\u043E\u043B\u0438, \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442 \u0438 \u043F\u0440\u0438\u043A\u0430\u0437. \u0412\u0441\u0435 \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0442\u0441\u044F \u044F\u0434\u0440\u043E\u043C \u043D\u0430 \u0434\u0430\u0442\u0443 \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u044F."), save2("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0435", "mentor_authorization", () => {
          const o = one(db, "SELECT * FROM mentor_appointment WHERE id=?", [appointment.value]);
          invariant(o, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0440\u0438\u043A\u0430\u0437 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
          return { person_id: who.value, operation_id: op.value, approved_by: actor.value, valid_from: start.value, valid_to: nullable(end.value), credential_id: o.credential_id, appointment_id: o.id };
        }, null, () => {
          route = { page: page2, personId: who.value };
        }));
      }
      const selected = persons.find((p) => p.id === route.personId);
      if (selected) {
        const rowsAuth = auths.filter((x) => x.person_id === selected.id), root2 = pane2("\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A \xB7 " + selected.display_name, back(), msg(selected.roles.map((x) => x.name).join(" \xB7 ")), row(action("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C", () => goLocal({ mode: "auth", personId: selected.id })), btn2("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B", () => go("certification")), btn2("\u041F\u0440\u0438\u043A\u0430\u0437\u044B", () => go("appointments"))), table2(["\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", "\u041D\u0430\u0447\u0430\u043B\u043E", "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", ""], rowsAuth.map((a) => [n("operation", a.operation_id), a.valid_from, a.valid_to || "\u2014", authorizationValid(db, a.id, day) ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u041D\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442", a.revoked_at ? "\u041E\u0442\u043E\u0437\u0432\u0430\u043D" : closeRecord("\u041E\u0442\u043E\u0437\u0432\u0430\u0442\u044C", "mentor_authorization", a, "revoke")])), pane2("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438 \u0438\u0441\u0442\u043E\u0440\u0438\u044F", assignmentRows(asgns().filter((a) => a.mentor_id === selected.id || a.supervisor_id === selected.id))));
        return root2;
      }
      const search = searchInput("mentor_search"), out = el2("div");
      filterList(out, search, persons, (p) => p.display_name + " " + p.employee_code + " " + p.unit, (items) => table2(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0440\u043E\u043B\u0438", "\u041F\u0440\u0430\u0432 \u043D\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438", "\u041E\u0442\u043A\u0440\u044B\u0442\u044B\u0445 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0439", ""], items.map((p) => [p.display_name, p.unit || "\u2014", p.roles.map((x) => x.name).join(", "), auths.filter((x) => x.person_id === p.id && authorizationValid(db, x.id, day)).length, asgns().filter((a) => a.mentor_id === p.id && activePlan(a)).length, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ personId: p.id }), "primary")])));
      return pane2("\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438 \u0438 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0435 \u0442\u0440\u0435\u043D\u0435\u0440\u044B", msg("\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u0440\u043E\u043B\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432, \u0437\u0430\u0442\u0435\u043C \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B, \u043F\u0440\u0438\u043A\u0430\u0437\u044B \u0438 \u043F\u0440\u0430\u0432\u0430 \u043E\u0431\u0443\u0447\u0430\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C."), row(action("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u0440\u0430\u0432\u043E \u043E\u0431\u0443\u0447\u0430\u0442\u044C", () => goLocal({ mode: "auth" })), btn2("\u0420\u043E\u043B\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", () => go("business_role")), btn2("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0440\u043E\u043B\u0435\u0439", () => go("role_assignment")), btn2("\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B", () => go("certification")), btn2("\u041F\u0440\u0438\u043A\u0430\u0437\u044B", () => go("appointments"))), search, out);
    }
    function requirementsPanel() {
      const profession = ref("profession", "requirement_profession"), skill = ref("skill", "requirement_skill"), target = scaleFields("requirement_target"), critical = simple("requirement_critical", { normal: "\u041E\u0431\u044B\u0447\u043D\u0430\u044F", important: "\u0412\u0430\u0436\u043D\u0430\u044F", critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" }, "normal"), start = date3("requirement_start"), end = date3("requirement_end", "");
      const existing = rows(db, "SELECT * FROM role_requirement ORDER BY valid_from DESC"), d = el2("details");
      d.append(el2("summary", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u043A \u043D\u0430\u0432\u044B\u043A\u0430\u043C \u043F\u043E \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F\u043C"), grid(f("\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", profession), f("\u041D\u0430\u0432\u044B\u043A", skill), f("\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u043E\u0441\u0442\u044C", critical), f("\u041D\u0430\u0447\u0430\u043B\u043E", start), f("\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 (\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)", end)), target.element, save2("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "role_requirement", () => ({ profession_id: profession.value, skill_id: skill.value, scale_id: target.scale.value, required_level: target.level.value === "" ? null : Number(target.level.value), criticality: critical.value, valid_from: start.value, valid_to: nullable(end.value) })), table2(["\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", "\u041D\u0430\u0432\u044B\u043A", "\u0428\u043A\u0430\u043B\u0430", "\u0426\u0435\u043B\u044C", "\u041F\u0435\u0440\u0438\u043E\u0434", ""], existing.map((v) => {
        const end2 = date3("close_requirement");
        const closure = el2("details");
        closure.append(el2("summary", "\u0417\u0430\u043A\u0440\u044B\u0442\u044C"), f("\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u0434\u0435\u043D\u044C", end2), save2("\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "role_requirement", () => ({ command: "close", valid_to: end2.value }), v));
        return [n("profession", v.profession_id), n("skill", v.skill_id), n("rating_scale", v.scale_id), v.required_level, v.valid_from + " \u2014 " + (v.valid_to || "\u2014"), v.valid_to ? "\u0417\u0430\u043A\u0440\u044B\u0442\u043E" : closure];
      })));
      return d;
    }
    function coveragePanel(matrix) {
      const unit = ref("org_unit", "coverage_unit"), skill = ref("skill", "coverage_skill"), shift = select("coverage_shift", list(db, "work_shift").filter((x) => !x.archived).map((x) => [x.code, x.name]), "", "\u0412\u0441\u0435 \u0441\u043C\u0435\u043D\u044B"), target = scaleFields("coverage_target"), minimum = num2("coverage_min", 1, 0, 1e5), data = coverageData(db, day, matrix);
      const d = el2("details");
      d.append(el2("summary", "\u041F\u043E\u043A\u0440\u044B\u0442\u0438\u0435 \u043F\u043E \u0443\u0447\u0430\u0441\u0442\u043A\u0430\u043C \u0438 \u0441\u043C\u0435\u043D\u0430\u043C"), msg("\u041F\u043E\u043A\u0440\u044B\u0442\u0438\u0435 \u2014 \u0447\u0438\u0441\u043B\u043E \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u043E\u0432 \u0441 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u043C \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u044B\u043C \u0443\u0440\u043E\u0432\u043D\u0435\u043C \u0438, \u0434\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u043C \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u043C \u0434\u043E\u043F\u0443\u0441\u043A\u043E\u043C. \u041D\u0443\u043B\u0435\u0432\u043E\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435 \u043D\u0435 \u0434\u0430\u0451\u0442 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u0430."), grid(f("\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", unit), f("\u041D\u0430\u0432\u044B\u043A", skill), f("\u0421\u043C\u0435\u043D\u0430", shift), f("\u0422\u0440\u0435\u0431\u0443\u0435\u043C\u043E\u0435 \u0447\u0438\u0441\u043B\u043E", minimum)), target.element, action("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C", () => run2(async () => {
        const payload = { unit_id: unit.value, skill_id: skill.value, shift_code: shift.value, min_people: Number(minimum.value), scale_id: target.scale.value, required_level: target.level.value === "" ? null : Number(target.level.value) }, old = one(db, "SELECT * FROM coverage_requirement WHERE unit_id=? AND skill_id=? AND shift_code=?", [payload.unit_id, payload.skill_id, payload.shift_code]);
        await write("coverage_requirement", payload, old);
        return "\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430";
      })), table2(["\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", "\u041D\u0430\u0432\u044B\u043A", "\u0421\u043C\u0435\u043D\u0430", "\u041D\u0443\u0436\u043D\u043E", "\u0415\u0441\u0442\u044C", "\u0414\u0435\u0444\u0438\u0446\u0438\u0442"], data.map((x) => [n("org_unit", x.unit_id), n("skill", x.skill_id), x.shift_code || "\u0412\u0441\u0435", x.min_people, x.actual, x.deficit])));
      return d;
    }
    function matrixBuilder(previous = null) {
      const name = fieldInput2("matrix_title", previous?.title || ""), code = fieldInput2("matrix_code", previous?.code || ""), author = person2("matrix_author", "\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u043B", previous?.author_id || ""), scope = ref("org_unit", "matrix_scope", previous?.unit_id || "", "\u0412\u0441\u0435 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F"), shift = ref("work_shift", "matrix_roster_shift", previous?.shift_id || "", "\u0412\u0441\u0435 \u0441\u043C\u0435\u043D\u044B"), profession = ref("profession", "matrix_roster_profession", "", "\u0412\u0441\u0435 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438"), workplace = ref("workplace", "matrix_column_workplace", "", "\u0412\u0441\u0435 \u0440\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u0435\u0441\u0442\u0430"), category = ref("skill_category", "matrix_column_category", "", "\u0412\u0441\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438"), horizon = date3("matrix_target_date", previous?.target_on >= day ? previous.target_on : plusDays3(day, 30));
      const scales = list(db, "rating_scale").filter((x) => !x.archived && x.name === SCALE_NAME && x.levels === CORPORATE_LEVELS), scale = select("matrix_scale", scales.map((x) => [x.id, x.name + " \xB7 v" + x.version_no]), previous?.scale_id || scales[0]?.id || "", "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0443\u044E \u0448\u043A\u0430\u043B\u0443");
      const mode = select("matrix_create_mode", [["auto", "\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u043F\u043E \u043F\u0440\u043E\u0444\u0438\u043B\u044F\u043C"], ["template", "\u041F\u043E \u0433\u043E\u0442\u043E\u0432\u043E\u0439 \u043C\u0430\u0442\u0440\u0438\u0446\u0435"], ["manual", "\u0412\u0440\u0443\u0447\u043D\u0443\u044E"]], previous || route.personId ? "manual" : "auto", null), templates = rows(db, "SELECT * FROM competency_matrix WHERE state='active' ORDER BY title"), template = select("matrix_template", templates.map((x) => [x.id, x.title + " \xB7 v" + x.version_no]), "", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043E\u0431\u0440\u0430\u0437\u0435\u0446"), allSops = check("matrix_all_sops", "\u0412\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0442\u0430\u043A\u0436\u0435 \u0421\u041E\u041F \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u0443\u0447\u0430\u0441\u0442\u043A\u0430 \u0431\u0435\u0437 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439"), autoGoals = check("matrix_profile_goals", "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0446\u0435\u043B\u0438 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F \u043F\u043E \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F\u043C \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0439"), bulkLevel = select("matrix_bulk_target", Object.entries(LEVEL_TEXT).map(([v, t]) => [v, v + " \u2014 " + t]), "", "\u0411\u0435\u0437 \u043D\u043E\u0432\u043E\u0439 \u0446\u0435\u043B\u0438");
      const chosenPeople = new Set(previous?.roster.map((x) => x.person_id) || (route.personId ? [route.personId] : [])), chosenColumns = previous?.columns.map(columnIdentity) || [];
      const pSearch = searchInput("matrix_roster_search"), sSearch = searchInput("matrix_column_search"), pBox = el2("div"), sBox = el2("div"), ordered = el2("div"), preview = el2("div"), counts = msg(""), autoStatus = msg(""), targets = /* @__PURE__ */ new Map(), importOut = el2("div"), importReview = el2("div");
      const groupBy = select("matrix_builder_group", [["workplace", "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E"], ["equipment", "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435"], ["category", "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F \u043D\u0430\u0432\u044B\u043A\u0430"], ["none", "\u0411\u0435\u0437 \u0433\u0440\u0443\u043F\u043F\u0438\u0440\u043E\u0432\u043A\u0438"]], "workplace", null);
      pSearch.placeholder = "\u0424\u0430\u043C\u0438\u043B\u0438\u044F, \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C";
      sSearch.placeholder = "\u041A\u043E\u0434 \u0438\u043B\u0438 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0421\u041E\u041F / \u043D\u0430\u0432\u044B\u043A\u0430";
      const match = (q, ...values) => values.join(" ").toLocaleLowerCase("ru-RU").includes(q.value.trim().toLocaleLowerCase("ru-RU"));
      let people = [], options = [];
      const find = (k) => options.find((x) => x.key === k), selection = () => ({ roster: people.filter((x) => chosenPeople.has(x.person_id)), columns: chosenColumns.map(find).filter(Boolean) });
      function count() {
        const x = selection();
        counts.textContent = "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432: " + x.roster.length + " \xB7 \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432: " + x.columns.length + " \xB7 \u044F\u0447\u0435\u0435\u043A: " + x.roster.length * x.columns.length;
        showPreview(true);
      }
      function drawPeople() {
        const shown = people.filter((x) => match(pSearch, x.name, x.position));
        pBox.replaceChildren(...shown.map((p) => {
          const v = check("matrix_person_" + p.person_id, p.name + (p.position ? " \xB7 " + p.position : ""));
          v.input.checked = chosenPeople.has(p.person_id);
          v.input.onchange = () => {
            if (v.input.checked) chosenPeople.add(p.person_id);
            else chosenPeople.delete(p.person_id);
            count();
          };
          return v.element;
        }));
        if (!shown.length) pBox.append(msg("\u041D\u0435\u0442 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u043F\u043E \u0444\u0438\u043B\u044C\u0442\u0440\u0443"));
      }
      function chooseColumn(x) {
        if (!x || chosenColumns.includes(x.key) || x.skill_id && chosenColumns.some((k) => find(k)?.skill_id === x.skill_id) || !x.skill_id && chosenColumns.some((k) => !find(k)?.skill_id && find(k)?.operation_id === x.operation_id)) return;
        chosenColumns.push(x.key);
      }
      function drawColumns() {
        const shown = options.filter((x) => match(sSearch, x.title, x.skill, x.workplace, x.equipment, x.category)), groups = /* @__PURE__ */ new Map();
        for (const v of shown) {
          const key3 = groupBy.value === "none" ? "\u0412\u0441\u0435 \u043D\u0430\u0432\u044B\u043A\u0438" : v[groupBy.value];
          if (!groups.has(key3)) groups.set(key3, []);
          groups.get(key3).push(v);
        }
        sBox.replaceChildren(...[...groups].map(([label, items]) => {
          const detail = el2("details");
          detail.open = true;
          detail.append(el2("summary", label + " \xB7 " + items.length), btn2("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0433\u0440\u0443\u043F\u043F\u0443", () => {
            items.forEach(chooseColumn);
            drawColumns();
            drawOrder();
            count();
          }), ...items.map((s) => {
            const v = check("matrix_column_" + s.key, s.title + " \xB7 " + s.skill);
            v.input.checked = chosenColumns.includes(s.key);
            v.input.onchange = () => {
              if (v.input.checked) {
                chooseColumn(s);
                v.input.checked = chosenColumns.includes(s.key);
              } else {
                chosenColumns.splice(chosenColumns.indexOf(s.key), 1);
                targets.delete(s.key);
              }
              drawOrder();
              count();
            };
            return v.element;
          }));
          return detail;
        }));
        if (!shown.length) sBox.append(msg("\u041D\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0421\u041E\u041F \u0438\u043B\u0438 \u043D\u0430\u0432\u044B\u043A\u043E\u0432"));
      }
      function drawOrder() {
        ordered.replaceChildren(...chosenColumns.map((k, i) => {
          const x = find(k), target = select("matrix_target_" + i, Object.entries(LEVEL_TEXT).map(([v, t]) => [v, v + " \u2014 " + t]), targets.get(k) || "", "\u0411\u0435\u0437 \u043D\u043E\u0432\u043E\u0439 \u0446\u0435\u043B\u0438");
          target.onchange = () => {
            targets.set(k, target.value);
            count();
          };
          const line = row(el2("span", i + 1 + ". " + x.title), target, btn2("\u2191", () => {
            [chosenColumns[i - 1], chosenColumns[i]] = [chosenColumns[i], chosenColumns[i - 1]];
            drawOrder();
            count();
          }, "", i === 0), btn2("\u2193", () => {
            [chosenColumns[i], chosenColumns[i + 1]] = [chosenColumns[i + 1], chosenColumns[i]];
            drawOrder();
            count();
          }, "", i === chosenColumns.length - 1), btn2("\u0423\u0431\u0440\u0430\u0442\u044C", () => {
            chosenColumns.splice(i, 1);
            targets.delete(k);
            drawColumns();
            drawOrder();
            count();
          }));
          const handle = btn2("\u283F", () => {
          }, "matrix-drag-handle");
          handle.title = "\u041F\u0435\u0440\u0435\u0442\u0430\u0449\u0438\u0442\u0435 \u0441\u0442\u043E\u043B\u0431\u0435\u0446; \u0434\u043B\u044F \u043A\u043B\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u044B \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0441\u0442\u0440\u0435\u043B\u043A\u0438";
          handle.draggable = true;
          handle.ondragstart = (e) => {
            e.dataTransfer.setData("text/plain", k);
            e.dataTransfer.effectAllowed = "move";
          };
          line.ondragover = (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = "move";
          };
          line.ondrop = (e) => {
            e.preventDefault();
            const from = chosenColumns.indexOf(e.dataTransfer.getData("text/plain")), to = chosenColumns.indexOf(k);
            if (from < 0 || to < 0 || from === to) return;
            const [moved] = chosenColumns.splice(from, 1);
            chosenColumns.splice(to, 0, moved);
            drawOrder();
            count();
          };
          line.prepend(handle);
          return line;
        }));
        if (!chosenColumns.length) ordered.append(msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0421\u041E\u041F, \u0437\u0430\u0442\u0435\u043C \u0437\u0430\u0434\u0430\u0439\u0442\u0435 \u043F\u043E\u0440\u044F\u0434\u043E\u043A \u043E\u0442 \u043F\u0440\u043E\u0441\u0442\u044B\u0445 \u043A \u0441\u043B\u043E\u0436\u043D\u044B\u043C."));
      }
      function selectAutomatically() {
        chosenPeople.clear();
        people.forEach((p) => chosenPeople.add(p.person_id));
        const result = autoMatrix(db, people, options, day, scale.value, { allSops: allSops.input.checked });
        chosenColumns.splice(0);
        targets.clear();
        result.keys.forEach((k) => chooseColumn(find(k)));
        autoStatus.textContent = "\u041F\u043E\u0434\u043E\u0431\u0440\u0430\u043D\u043E \u043F\u043E " + result.requirements + " \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F\u043C. \u0411\u0435\u0437 \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0433\u043E \u043F\u0440\u043E\u0444\u0438\u043B\u044F: " + result.unprofiled.length + " \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0439; \u0432\u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0439 \u043E\u0431\u043B\u0430\u0441\u0442\u0438: " + result.missing.length + " \u043D\u0430\u0432\u044B\u043A\u043E\u0432; \u043D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0445 \u0421\u041E\u041F: " + result.ambiguous.length + "." + (result.ambiguous.length ? " \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043D\u0443\u0436\u043D\u044B\u0439 \u0421\u041E\u041F \u0432\u0440\u0443\u0447\u043D\u0443\u044E." : "") + (!result.keys.length ? " \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u043E\u0444\u0438\u043B\u0438, \u0432\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0421\u041E\u041F \u0443\u0447\u0430\u0441\u0442\u043A\u0430 \u0438\u043B\u0438 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0442\u043E\u043B\u0431\u0446\u044B \u0432\u0440\u0443\u0447\u043D\u0443\u044E." : "");
      }
      function refresh2() {
        people = matrixRoster(db, day, scope.value, shift.value, profession.value);
        options = matrixCatalog(db, scope.value, workplace.value, category.value);
        for (const p of [...chosenPeople]) if (!people.some((x) => x.person_id === p)) chosenPeople.delete(p);
        for (let i = chosenColumns.length - 1; i >= 0; i--) if (!find(chosenColumns[i])) {
          targets.delete(chosenColumns[i]);
          chosenColumns.splice(i, 1);
        }
        if (mode.value === "auto") selectAutomatically();
        drawPeople();
        drawColumns();
        drawOrder();
        count();
      }
      function copyTemplate() {
        const source = templates.find((t) => t.id === template.value);
        if (!source) {
          c.notify("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043C\u0430\u0442\u0440\u0438\u0446\u0443-\u043E\u0431\u0440\u0430\u0437\u0435\u0446", true);
          return;
        }
        if (chosenColumns.length && !confirm("\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u043E\u0441\u0442\u0430\u0432 \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432 \u043E\u0431\u0440\u0430\u0437\u0446\u043E\u043C?")) return;
        const x = matrixFromRecord(source);
        mode.value = "template";
        scope.value = x.unit_id || "";
        shift.value = x.shift_id || "";
        profession.value = "";
        workplace.value = "";
        category.value = "";
        if (scales.some((v) => v.id === x.scale_id)) scale.value = x.scale_id;
        people = matrixRoster(db, day, scope.value, shift.value, profession.value);
        options = matrixCatalog(db, scope.value);
        chosenPeople.clear();
        people.forEach((p) => chosenPeople.add(p.person_id));
        chosenColumns.splice(0);
        targets.clear();
        for (const col of x.columns) {
          const v = find(columnIdentity(col));
          if (v) chooseColumn(v);
        }
        autoStatus.textContent = "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D \u043F\u043E\u0440\u044F\u0434\u043E\u043A " + chosenColumns.length + " \u0438\u0437 " + x.columns.length + " \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432; \u0441\u043E\u0441\u0442\u0430\u0432 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0439. \u041F\u0440\u0435\u0436\u043D\u0438\u0435 \u043E\u0446\u0435\u043D\u043A\u0438 \u0438 \u0446\u0435\u043B\u0438 \u043D\u0435 \u043A\u043E\u043F\u0438\u0440\u0443\u044E\u0442\u0441\u044F.";
        drawPeople();
        drawColumns();
        drawOrder();
        count();
      }
      for (const ctl of [scope, shift, profession, workplace, category]) ctl.onchange = () => {
        if (mode.value === "auto" && (chosenColumns.length || chosenPeople.size)) autoStatus.textContent = "\u0421\u043E\u0441\u0442\u0430\u0432 \u043E\u0431\u043D\u043E\u0432\u043B\u0451\u043D \u043F\u043E \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u043C";
        refresh2();
      };
      mode.onchange = () => {
        if (mode.value === "auto") refresh2();
        else {
          autoStatus.textContent = mode.value === "template" ? "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043E\u0431\u0440\u0430\u0437\u0435\u0446 \u0438 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u0435 \u0435\u0433\u043E." : "\u0421\u043E\u0441\u0442\u0430\u0432 \u0438 \u043F\u043E\u0440\u044F\u0434\u043E\u043A \u0437\u0430\u0434\u0430\u044E\u0442\u0441\u044F \u0432\u0440\u0443\u0447\u043D\u0443\u044E.";
          count();
        }
      };
      allSops.input.onchange = () => {
        if (mode.value === "auto") refresh2();
      };
      autoGoals.input.onchange = count;
      horizon.onchange = count;
      scale.onchange = () => {
        if (mode.value === "auto") refresh2();
        else count();
      };
      groupBy.onchange = drawColumns;
      pSearch.oninput = drawPeople;
      sSearch.oninput = drawColumns;
      refresh2();
      const pAll = btn2("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0432\u0441\u0435\u0445 \u043F\u043E \u043F\u043E\u0438\u0441\u043A\u0443", () => {
        for (const p of people.filter((x) => match(pSearch, x.name, x.position))) chosenPeople.add(p.person_id);
        drawPeople();
        count();
      }), pClear = btn2("\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", () => {
        chosenPeople.clear();
        drawPeople();
        count();
      }), sAll = btn2("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0421\u041E\u041F \u043F\u043E \u043F\u043E\u0438\u0441\u043A\u0443", () => {
        for (const x of options.filter((x2) => match(sSearch, x2.title, x2.skill))) chooseColumn(x);
        drawColumns();
        drawOrder();
        count();
      }), sClear = btn2("\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0441\u0442\u043E\u043B\u0431\u0446\u044B", () => {
        chosenColumns.splice(0);
        targets.clear();
        drawColumns();
        drawOrder();
        count();
      });
      function checked() {
        const x = selection();
        invariant(x.roster.length && x.columns.length && x.roster.length <= 300 && x.columns.length <= 150 && x.roster.length * x.columns.length <= 12e3, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 1\u2013300 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432, 1\u2013150 \u043D\u0430\u0432\u044B\u043A\u043E\u0432 \u0438 \u0434\u043E 12000 \u044F\u0447\u0435\u0435\u043A");
        invariant(horizon.value && horizon.value >= day, "\u0426\u0435\u043B\u044C \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u0440\u0430\u043D\u044C\u0448\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0441\u0440\u0435\u0437\u0430");
        return x;
      }
      function showPreview(silent = false) {
        try {
          const x = checked(), roster = x.roster.slice(0, 12), columns = x.columns.slice(0, 16).map((v) => ({ ...v, skill_id: v.skill_id || v.key })), baseline = matrixBaseline(db, roster, columns, scale.value, day), p = matrixProjection(db, { roster, columns, scale_id: scale.value, target_on: horizon.value, baseline }, day);
          preview.replaceChildren(msg("\u0416\u0438\u0432\u043E\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440: " + roster.length + " \u0438\u0437 " + x.roster.length + " \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432, " + columns.length + " \u0438\u0437 " + x.columns.length + " \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432. \u041F\u0443\u0441\u0442\u0430\u044F \u044F\u0447\u0435\u0439\u043A\u0430 \u2014 \u043D\u0435\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0439 \u043E\u0446\u0435\u043D\u043A\u0438."), tableOf2(["\u0424\u0418\u041E", "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", ...columns.map((v) => v.title)], roster.map((r) => [r.name, r.position, ...columns.map((v) => {
            const cell = p.cells.get(matrixKey(r.person_id, v.skill_id)), target = Math.max(Number(targets.get(v.key) || 0), cell.targetLevel || 0) || null, elv = el2("span", (cell.actual ?? "\u2014") + (target ? " \u2192 " + target : ""), "matrix-preview-value" + (cell.actual !== null ? " matrix-level-" + cell.actual : "") + (target && (cell.actual === null || cell.actual < target) ? " matrix-preview-gap" : ""));
            return elv;
          })])), msg("\u0426\u0435\u043B\u0438 \u0441\u043E\u0437\u0434\u0430\u044E\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E \u043E\u0442 \u0444\u0430\u043A\u0442\u043E\u0432. \u0412\u044B\u0431\u0440\u0430\u043D\u043E " + x.roster.length * x.columns.length + " \u044F\u0447\u0435\u0435\u043A."));
        } catch (e) {
          preview.replaceChildren(msg(e.message));
          if (!silent) c.notify(e.message, true);
        }
      }
      function openImport2() {
        const input = el2("input");
        input.type = "file";
        input.accept = ".xlsx";
        input.hidden = true;
        document.body.append(input);
        input.addEventListener("cancel", () => input.remove(), { once: true });
        input.onchange = async () => {
          const file = input.files?.[0];
          input.remove();
          if (!file) return;
          try {
            let defaults = function() {
              const d = suggestMatrixRange(sheet2());
              for (const k of Object.keys(fields)) fields[k].value = d[k];
              mapOut.replaceChildren();
            }, mapping = function() {
              try {
                const source = readMatrixRange(sheet2(), Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, Number(v.value)]))), directory = new Map(rows(db, "SELECT id,employee_code FROM person").map((p) => [p.id, p.employee_code]));
                const pp = source.people.map((p) => {
                  const match2 = uniqueMatrixMatch(p.label, people, (x) => [x.name, directory.get(x.person_id)]);
                  return { p, ctl: select("matrix_import_p_" + p.row, people.map((x) => [x.person_id, x.name + " \xB7 " + (directory.get(x.person_id) || "")]), match2?.person_id || "", "\u041D\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E / \u0438\u0441\u043A\u043B\u044E\u0447\u0438\u0442\u044C") };
                });
                const cc = source.cols.map((col) => {
                  const match2 = uniqueMatrixMatch(col.label, options, (x) => [x.title, x.skill, x.documentTitle, x.code]);
                  return { col, ctl: select("matrix_import_c_" + col.col, options.map((x) => [x.key, x.title + " \xB7 " + x.skill]), match2?.key || "", "\u041D\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E / \u0438\u0441\u043A\u043B\u044E\u0447\u0438\u0442\u044C") };
                });
                mapOut.replaceChildren(msg("\u0421\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0442\u043E\u0447\u043D\u043E\u0435, \u043D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u044B \u043F\u0443\u0441\u0442\u044B\u043C\u0438. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043A\u0430\u0436\u0434\u044B\u0439 \u0432\u044B\u0431\u043E\u0440. \u0424\u0430\u043A\u0442\u044B \u0438\u0437 Excel \u043D\u0435 \u043F\u0440\u0438\u0441\u0432\u0430\u0438\u0432\u0430\u044E\u0442 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438 \u0438\u043B\u0438 \u0434\u043E\u043F\u0443\u0441\u043A\u0438."), tableOf2(["\u0421\u0442\u0440\u043E\u043A\u0430", "\u0424\u0418\u041E / \u043D\u043E\u043C\u0435\u0440 \u0432 Excel", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A \u0446\u0435\u043D\u0442\u0440\u0430"], pp.map((x) => [x.p.row, x.p.label, x.ctl])), tableOf2(["\u0421\u0442\u043E\u043B\u0431\u0435\u0446", "\u0421\u041E\u041F \u0432 Excel", "\u041D\u0430\u0432\u044B\u043A / \u0421\u041E\u041F \u0446\u0435\u043D\u0442\u0440\u0430"], cc.map((x) => [x.col.col, x.col.label, x.ctl])), btn2("\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u043E\u0441\u0442\u0430\u0432 \u0438 \u0441\u0432\u0435\u0440\u0438\u0442\u044C \u043E\u0446\u0435\u043D\u043A\u0438", () => {
                  try {
                    const peopleMap = new Map(pp.filter((x) => x.ctl.value).map((x) => [x.p.row, x.ctl.value])), columnMap = new Map(cc.filter((x) => x.ctl.value).map((x) => [x.col.col, find(x.ctl.value)?.skill_id || x.ctl.value])), keys = cc.map((x) => x.ctl.value).filter(Boolean);
                    const pickedPeople = people.filter((x) => [...peopleMap.values()].includes(x.person_id)), pickedColumns = keys.map(find).map((x) => ({ ...x, skill_id: x.skill_id || x.key })), base2 = matrixBaseline(db, pickedPeople, pickedColumns, scale.value, day), pr = matrixProjection(db, { roster: pickedPeople, columns: pickedColumns, scale_id: scale.value, target_on: horizon.value, baseline: base2 }, day), result = reconcileMatrix(source, peopleMap, columnMap, pr), omitted = pp.length - peopleMap.size + cc.length - columnMap.size;
                    invariant(!pickedColumns.some((v, i) => pickedColumns.some((w, j) => i !== j && v.operation_id && v.operation_id === w.operation_id && !find(keys[i]).skill_id && !find(keys[j]).skill_id)), "\u041D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0421\u041E\u041F \u043E\u0434\u043D\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0431\u0435\u0437 \u043D\u0430\u0432\u044B\u043A\u0430: \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043E\u0434\u0438\u043D");
                    if (!confirm("\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C " + pickedPeople.length + " \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0438 " + keys.length + " \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432? \u0418\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u043E \u043D\u0435\u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u0445 \u0441\u0442\u0440\u043E\u043A/\u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432: " + omitted + ". \u041E\u0446\u0435\u043D\u043A\u0438 \u0431\u0430\u0437\u044B \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u0442\u0441\u044F.")) return;
                    mode.value = "manual";
                    chosenPeople.clear();
                    pickedPeople.forEach((x) => chosenPeople.add(x.person_id));
                    chosenColumns.splice(0);
                    targets.clear();
                    keys.forEach((k) => chooseColumn(find(k)));
                    drawPeople();
                    drawColumns();
                    drawOrder();
                    count();
                    const diff = result.filter((x) => !["\u041F\u0443\u0441\u0442\u043E", "\u0421\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442"].includes(x.status)), heads = ["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A Excel", "\u0421\u041E\u041F Excel", "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 Excel", "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u0432 \u0446\u0435\u043D\u0442\u0440\u0435", "\u0421\u0442\u0430\u0442\u0443\u0441"];
                    const values = (x) => [x.person, x.skill, x.raw, x.actual ?? "\u2014", x.status];
                    importReview.replaceChildren(msg("\u0421\u0432\u0435\u0440\u043A\u0430 " + file.name + ": " + result.length + " \u044F\u0447\u0435\u0435\u043A; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 " + diff.length + ". \u0418\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0441\u043E\u0441\u0442\u0430\u0432, \u043D\u0435 \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F."), tableOf2(heads, diff.slice(0, 100).map(values)), btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043F\u043E\u043B\u043D\u0443\u044E \u0441\u0432\u0435\u0440\u043A\u0443 XLSX", async () => {
                      try {
                        await exportTable("\u0421\u0432\u0435\u0440\u043A\u0430-\u0438\u043C\u043F\u043E\u0440\u0442\u0430-\u043C\u0430\u0442\u0440\u0438\u0446\u044B", heads, result.map(values));
                        c.notify("\u0421\u0432\u0435\u0440\u043A\u0430 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0430");
                      } catch (e) {
                        c.notify(e.message, true);
                      }
                    }));
                  } catch (e) {
                    c.notify(e.message, true);
                  }
                }));
              } catch (e) {
                mapOut.replaceChildren(msg(e.message, "warn"));
              }
            };
            invariant(file.size <= 12 * 1024 * 1024, "\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
            const book = new ExcelJS.Workbook();
            await book.xlsx.load(await file.arrayBuffer());
            const sh = select("matrix_import_sheet", book.worksheets.map((v) => [String(v.id), v.name]), String(book.worksheets[0]?.id), null), fields = {}, labels3 = { headerRow: "\u0421\u0442\u0440\u043E\u043A\u0430 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0439 \u0421\u041E\u041F", firstRow: "\u041F\u0435\u0440\u0432\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", lastRow: "\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u0441\u0442\u0440\u043E\u043A\u0430 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", personCol: "\u0421\u0442\u043E\u043B\u0431\u0435\u0446 \u0424\u0418\u041E / \u0442\u0430\u0431\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043D\u043E\u043C\u0435\u0440\u0430", firstSkill: "\u041F\u0435\u0440\u0432\u044B\u0439 \u0441\u0442\u043E\u043B\u0431\u0435\u0446 \u0421\u041E\u041F", lastSkill: "\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u0441\u0442\u043E\u043B\u0431\u0435\u0446 \u0421\u041E\u041F" };
            for (const k of Object.keys(labels3)) fields[k] = num2("matrix_import_" + k, 1, 1, 1e4);
            const mapOut = el2("div");
            const sheet2 = () => book.getWorksheet(Number(sh.value));
            sh.onchange = defaults;
            defaults();
            importOut.replaceChildren(msg(file.name + " \xB7 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0441\u0442\u0440\u043E\u043A\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0438 \u0441\u0442\u043E\u043B\u0431\u0446\u044B \u0421\u041E\u041F, \u0431\u0435\u0437 \u0438\u0442\u043E\u0433\u043E\u0432 \u0438 \u043B\u0435\u0433\u0435\u043D\u0434\u044B."), f("\u041B\u0438\u0441\u0442", sh), grid(...Object.entries(labels3).map(([k, label]) => f(label, fields[k]))), btn2("\u0421\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0438 \u0438 \u0441\u0442\u043E\u043B\u0431\u0446\u044B", mapping), mapOut);
          } catch (e) {
            c.notify(e.message, true);
          }
        };
        input.click();
      }
      async function saveMatrix() {
        const x = checked();
        invariant(name.value.trim() && code.value.trim() && author.value, "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043A\u043E\u0434, \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0438 \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A\u0430");
        const existing = one(db, "SELECT id,rev FROM competency_matrix WHERE code=? AND state='active'", [code.value.trim()]);
        if (existing && !confirm("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u043C\u0430\u0442\u0440\u0438\u0446\u044B " + code.value.trim() + "? \u0421\u0442\u0430\u0440\u044B\u0439 \u0441\u043E\u0441\u0442\u0430\u0432 \u0438 \u0441\u0440\u0435\u0437 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0442\u0441\u044F.")) return "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
        const events = [];
        let scaleId = scale.value;
        if (!scaleId) {
          const version = Math.max(0, ...list(db, "rating_scale").filter((x2) => x2.name === SCALE_NAME).map((x2) => Number(x2.version_no))) + 1;
          const e2 = event("rating_scale", { name: SCALE_NAME, version_no: String(version), levels: CORPORATE_LEVELS });
          scaleId = e2.entity_id;
          events.push(e2);
        }
        let cat = one(db, "SELECT id FROM skill_category WHERE name=? AND archived=0", ["\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043F\u043E \u0421\u041E\u041F"])?.id;
        const columns = x.columns.map((v) => {
          let id = v.skill_id;
          if (!id) {
            if (!cat) {
              const e3 = event("skill_category", { name: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043F\u043E \u0421\u041E\u041F" });
              cat = e3.entity_id;
              events.push(e3);
            }
            const doc = one(db, "SELECT title FROM document WHERE id=?", [v.document_id]), e2 = event("skill", { category_id: cat, operation_id: v.operation_id, name: doc.title });
            events.push(e2);
            id = e2.entity_id;
          }
          return { skill_id: id, document_id: v.document_id, title: v.title };
        });
        const baseline = matrixBaseline(db, x.roster, columns, scaleId, day), e = event("competency_matrix", { code: code.value.trim(), title: name.value.trim(), author_id: author.value, unit_id: nullable(scope.value), shift_id: nullable(shift.value), scale_id: scaleId, base_on: day, target_on: horizon.value, roster: x.roster, columns, baseline, previous_id: existing?.id || null, previous_rev: existing?.rev || 0 });
        events.push(e);
        const projection = matrixProjection(db, { roster: x.roster, columns, scale_id: scaleId, target_on: horizon.value, baseline }, day);
        let goalCount = 0;
        for (const p of x.roster) {
          const planned2 = columns.map((v, i) => ({ v, level: Math.max(Number(targets.get(x.columns[i].key) || 0), autoGoals.input.checked ? projection.cells.get(matrixKey(p.person_id, v.skill_id))?.required || 0 : 0), cell: projection.cells.get(matrixKey(p.person_id, v.skill_id)) })).filter((g) => g.level > 0 && (g.cell.actual ?? 0) < g.level && (g.cell.explicit ?? 0) < g.level);
          if (!planned2.length) continue;
          const plan = event("development_plan", { person_id: p.person_id, title: "\u0420\u0430\u0437\u0432\u0438\u0442\u0438\u0435 \u043F\u043E \u043C\u0430\u0442\u0440\u0438\u0446\u0435 " + name.value.trim(), start_on: day, due_on: horizon.value });
          events.push(plan);
          for (const g of planned2) {
            events.push(event("development_goal", { plan_id: plan.entity_id, skill_id: g.v.skill_id, scale_id: scaleId, target_level: g.level, title: "\u041E\u0441\u0432\u043E\u0438\u0442\u044C: " + g.v.title, due_on: horizon.value }));
            goalCount++;
          }
        }
        invariant(events.length + ws2.pending.length <= 2e3, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u043D\u043E\u0433\u043E \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 \u0437\u0430 \u043E\u0434\u0438\u043D \u0440\u0430\u0437. \u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u0435 \u0432\u044B\u0431\u043E\u0440\u043A\u0443 \u0438\u043B\u0438 \u0441\u043D\u0430\u0447\u0430\u043B\u0430 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u0443\u0439\u0442\u0435 \u043E\u0447\u0435\u0440\u0435\u0434\u044C.");
        if (goalCount && !confirm("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043C\u0430\u0442\u0440\u0438\u0446\u0443 \u0438 " + goalCount + " \u0446\u0435\u043B\u0435\u0439 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F? \u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043E\u0446\u0435\u043D\u043A\u0438 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u0442\u0441\u044F.")) return "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
        await ws2.applyContentEvents(events, readContent3);
        route = { page: page2, matrixId: e.entity_id };
        return "\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430. \u0426\u0435\u043B\u0435\u0439 \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F \u0441\u043E\u0437\u0434\u0430\u043D\u043E: " + goalCount + ". \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
      }
      const base = date3("matrix_base_date", day);
      base.readOnly = true;
      const settings = pane2(previous ? "\u041D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u043C\u0430\u0442\u0440\u0438\u0446\u044B" : "\u041A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 \u043C\u0430\u0442\u0440\u0438\u0446\u044B \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", back(), msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043F\u043E\u0441\u043E\u0431 \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F. \u0412 \u043B\u044E\u0431\u043E\u043C \u0440\u0435\u0436\u0438\u043C\u0435 \u043C\u043E\u0436\u043D\u043E \u0443\u0442\u043E\u0447\u043D\u0438\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0438 \u0441\u0442\u043E\u043B\u0431\u0446\u044B. \u041F\u0440\u043E\u0444\u0438\u043B\u0438 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u044E\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u043A \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F\u043C; \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0434\u0443\u0431\u043B\u0438\u0440\u0443\u044E\u0442\u0441\u044F."), grid(f("\u0421\u043F\u043E\u0441\u043E\u0431", mode), f("\u041E\u0431\u0440\u0430\u0437\u0435\u0446", template)), row(btn2("\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u043E\u0431\u0440\u0430\u0437\u0435\u0446", copyTemplate), btn2("\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0430\u0432\u0442\u043E\u043F\u043E\u0434\u0431\u043E\u0440", () => {
        mode.value = "auto";
        refresh2();
      }), btn2("\u041F\u0440\u043E\u0444\u0438\u043B\u0438 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0439", () => {
        if (confirm("\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u043A \u043F\u0440\u043E\u0444\u0438\u043B\u044F\u043C? \u041D\u0435\u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0439 \u0441\u043E\u0441\u0442\u0430\u0432 \u043C\u0430\u0442\u0440\u0438\u0446\u044B \u0431\u0443\u0434\u0435\u0442 \u0441\u0431\u0440\u043E\u0448\u0435\u043D.")) goLocal({ mode: "profiles" });
      })), row(allSops.element, autoGoals.element), autoStatus, grid(f("\u041A\u043E\u0434 \u043C\u0430\u0442\u0440\u0438\u0446\u044B", code), f("\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", name), author.element, f("\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", scope), f("\u0421\u043C\u0435\u043D\u0430", shift), f("\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", profession), f("\u0428\u043A\u0430\u043B\u0430", scale), f("\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0440\u0435\u0437", base), f("\u0426\u0435\u043B\u0435\u0432\u043E\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", horizon)), row(...[[30, "\u041C\u0435\u0441\u044F\u0446"], [90, "\u041A\u0432\u0430\u0440\u0442\u0430\u043B"], [180, "\u041F\u043E\u043B\u0433\u043E\u0434\u0430"], [365, "\u0413\u043E\u0434"]].map(([d, label]) => btn2(label, () => {
        horizon.value = plusDays3(day, d);
        count();
      }))));
      const selectionPane = add2(el2("div", void 0, "matrix-builder-columns"), pane2("\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438", pSearch, row(pAll, pClear), add2(el2("div", void 0, "matrix-choice-list"), pBox)), pane2("\u0421\u041E\u041F \u0438 \u043D\u0430\u0432\u044B\u043A\u0438", grid(f("\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E", workplace), f("\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F", category), f("\u0413\u0440\u0443\u043F\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C", groupBy)), sSearch, row(sAll, sClear), add2(el2("div", void 0, "matrix-choice-list"), sBox)));
      const tools = pane2("\u041F\u043E\u0440\u044F\u0434\u043E\u043A \u0438 \u0446\u0435\u043B\u0438", msg("\u041F\u0435\u0440\u0435\u0442\u0430\u0441\u043A\u0438\u0432\u0430\u0439\u0442\u0435 \u0441\u0442\u043E\u043B\u0431\u0446\u044B \u0438\u043B\u0438 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0441\u0442\u0440\u0435\u043B\u043A\u0438. \u041C\u0430\u0441\u0441\u043E\u0432\u0430\u044F \u0446\u0435\u043B\u044C \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0438 \u0434\u0435\u0444\u0438\u0446\u0438\u0442\u0435."), row(f("\u0426\u0435\u043B\u0435\u0432\u043E\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u0434\u043B\u044F \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0445 \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432", bulkLevel), btn2("\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u043E \u0432\u0441\u0435\u043C \u0441\u0442\u043E\u043B\u0431\u0446\u0430\u043C", () => {
        chosenColumns.forEach((k) => targets.set(k, bulkLevel.value));
        drawOrder();
        count();
      })), ordered);
      const importing = el2("details");
      importing.append(el2("summary", "\u0418\u043C\u043F\u043E\u0440\u0442 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0439 \u043C\u0430\u0442\u0440\u0438\u0446\u044B XLSX"), msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u0430\u0439\u043B, \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D \u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435. \u0418\u043C\u043F\u043E\u0440\u0442 \u043E\u0446\u0435\u043D\u043E\u043A \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F \u0441\u0432\u0435\u0440\u043A\u0438: \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0443\u0440\u043E\u0432\u043D\u0438 \u0431\u0435\u0440\u0443\u0442\u0441\u044F \u0438\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439."), btn2("\u0412\u044B\u0431\u0440\u0430\u0442\u044C XLSX", openImport2), importOut, importReview);
      return stack(settings, selectionPane, tools, importing, pane2("\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435", counts, row(btn2("\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440", () => showPreview()), action("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043C\u0430\u0442\u0440\u0438\u0446\u0443", () => run2(saveMatrix))), preview));
    }
    function matrixDetail(record) {
      const cfg = matrixFromRecord(record), projection = matrixProjection(db, cfg, day), filter = check("matrix_only_employee", "\u0422\u043E\u043B\u044C\u043A\u043E \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A"), focus = route.personId || "", search = searchInput("matrix_saved_search"), out = el2("div");
      const saved = route.matrixFilters || {}, activity = matrixActivity(db, cfg), labels3 = matrixGroupLabels(db, cfg.columns), drawer = el2("aside", void 0, "matrix-cell-drawer");
      filter.input.checked = saved.only ?? !!focus;
      drawer.hidden = true;
      search.value = saved.search || "";
      const gaps = check("matrix_saved_gaps", "\u0422\u043E\u043B\u044C\u043A\u043E \u0442\u0440\u0435\u0431\u0443\u044E\u0449\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"), transpose = check("matrix_saved_transpose", "\u041D\u0430\u0432\u044B\u043A\u0438 \u0441\u0442\u0440\u043E\u043A\u0430\u043C\u0438");
      gaps.input.checked = !!saved.gaps;
      transpose.input.checked = !!saved.transpose;
      const grouping = select("matrix_saved_group", [["none", "\u0411\u0435\u0437 \u0433\u0440\u0443\u043F\u043F\u0438\u0440\u043E\u0432\u043A\u0438"], ["workplace", "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E"], ["equipment", "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435"], ["category", "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F"]], saved.grouping || "none", null);
      const group = select("matrix_saved_group_value", [], "", "\u0412\u0441\u0435 \u0433\u0440\u0443\u043F\u043F\u044B");
      const metric = select("matrix_saved_metric", [["actual", "\u0422\u0435\u043A\u0443\u0449\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u0438"], ["target", "\u0426\u0435\u043B\u0435\u0432\u044B\u0435 \u0443\u0440\u043E\u0432\u043D\u0438"], ["base", "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0440\u0435\u0437"], ["delta", "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043A \u0441\u0440\u0435\u0437\u0443"]], saved.metric || "actual", null);
      const versions = rows(db, "SELECT * FROM competency_matrix WHERE code=? AND scale_id=? AND id<>? ORDER BY version_no DESC", [cfg.code, cfg.scale_id, cfg.id]);
      const compare = select("matrix_compare_snapshot", versions.map((x) => [x.id, x.base_on + " \xB7 v" + x.version_no]), saved.compare || "", "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0440\u0435\u0437 \u044D\u0442\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438");
      const needs = (x) => x.targetLevel !== null && (x.actual === null || x.need > 0);
      function comparison() {
        const v = versions.find((x) => x.id === compare.value);
        return v ? matrixComparison(cfg, matrixFromRecord(v)) : new Map(cfg.baseline.map((x) => [matrixKey(x.person_id, x.skill_id), x.value]));
      }
      function refreshGroups(prior = "") {
        const values = grouping.value === "none" ? [] : [...new Set(cfg.columns.map((c2) => labels3.get(c2.skill_id)?.[grouping.value] || "\u0411\u0435\u0437 \u0433\u0440\u0443\u043F\u043F\u044B"))].sort((a, b) => a.localeCompare(b, "ru"));
        replaceOptions(group, select("matrix_saved_group_value", values.map((v) => [v, v]), values.includes(prior) ? prior : "", "\u0412\u0441\u0435 \u0433\u0440\u0443\u043F\u043F\u044B"));
        group.disabled = grouping.value === "none";
      }
      const total = (a, k) => a[k + "Count"] ? String(a[k]) : "\u2014";
      const personLink = (r) => btn2(r.name, () => c.openEmployee(r.person_id), "matrix-person-link");
      const backMatrix = () => {
        delete route.cellPersonId;
        delete route.cellSkillId;
        delete route.skillId;
        drawer.hidden = true;
        drawer.replaceChildren();
      };
      function openCell(who2, col2) {
        route.cellPersonId = who2.person_id;
        route.cellSkillId = col2.skill_id;
        const x = projection.cells.get(matrixKey(who2.person_id, col2.skill_id)), goal = select("matrix_cell_target", Object.entries(LEVEL_TEXT).map(([v, t]) => [v, v + " \u2014 " + t]), String(x.targetLevel || "")), due = date3("matrix_cell_due", cfg.target_on >= day ? cfg.target_on : plusDays3(day, 30));
        const root2 = pane2(who2.name + " \xB7 " + col2.title, row(btn2("\u0417\u0430\u043A\u0440\u044B\u0442\u044C", backMatrix), personLink(who2)), msg("\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439: " + (x.base ?? "\u2014") + " \xB7 \u0422\u0435\u043A\u0443\u0449\u0438\u0439: " + (x.actual ?? "\u2014") + " \xB7 \u0426\u0435\u043B\u044C: " + (x.targetLevel ?? "\u2014") + " \xB7 " + x.reason + " \xB7 " + x.admission));
        const active4 = activity.get(matrixKey(who2.person_id, col2.skill_id)) || [];
        const history = rows(db, "SELECT i.*,a.assessed_at,a.evaluator_id,a.standard_revision_id,a.assignment_id FROM assessment_item i JOIN assessment_session a ON a.id=i.session_id WHERE a.person_id=? AND i.skill_id=? AND a.state='confirmed' ORDER BY a.assessed_at DESC,a.recorded_at DESC", [who2.person_id, col2.skill_id]);
        const plans = rows(db, "SELECT p.id,p.title,g.due_on,g.target_json FROM development_plan p JOIN development_goal g ON g.plan_id=p.id WHERE p.person_id=? AND p.state='active' AND g.skill_id=? AND g.state='open' ORDER BY g.due_on", [who2.person_id, col2.skill_id]);
        root2.append(msg("\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438: " + (x.required ?? "\u2014") + " \xB7 \u0418\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u0430\u044F \u0446\u0435\u043B\u044C: " + (x.explicit ?? "\u2014")));
        if (col2.document_id) root2.append(btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0421\u041E\u041F", () => goDocument2(col2.document_id)));
        const trainingLines = active4.map((v) => [v.due_on, n("person", v.mentor_id), (statuses[v.state] || v.state) + (v.revision_state !== "effective" ? " \xB7 \u043F\u0440\u0435\u0436\u043D\u044F\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F" : ""), btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { id: v.id }))]);
        root2.append(pane2("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", trainingLines.length ? tableOf2(["\u0421\u0440\u043E\u043A", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", ""], trainingLines) : msg("\u041E\u0442\u043A\u0440\u044B\u0442\u044B\u0445 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043D\u0435\u0442.")));
        const historyLines = history.map((v) => [v.assessed_at, n("rating_scale", v.scale_id), v.observation_state === "rated" ? v.level : observationLabels[v.observation_state], n("person", v.evaluator_id), revLabel(v.standard_revision_id), v.assignment_id ? btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => go("twi", { id: v.assignment_id, tab: "practice" })) : "\u2014"]);
        root2.append(pane2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0439", historyLines.length ? tableOf2(["\u0414\u0430\u0442\u0430", "\u0428\u043A\u0430\u043B\u0430", "\u0423\u0440\u043E\u0432\u0435\u043D\u044C", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "\u0421\u041E\u041F", ""], historyLines) : msg("\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0445 \u043E\u0446\u0435\u043D\u043E\u043A \u043D\u0435\u0442.")));
        const planLines = plans.map((v) => [v.title, JSON.parse(v.target_json).target_level, v.due_on, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u043B\u0430\u043D", () => go("development", { id: v.id }))]);
        root2.append(pane2("\u041E\u0442\u043A\u0440\u044B\u0442\u044B\u0435 \u0446\u0435\u043B\u0438", planLines.length ? tableOf2(["\u041F\u043B\u0430\u043D", "\u0423\u0440\u043E\u0432\u0435\u043D\u044C", "\u0421\u0440\u043E\u043A", ""], planLines) : msg("\u041D\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0442\u044B\u0445 \u0438\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0446\u0435\u043B\u0435\u0439.")));
        const rev = col2.document_id && one(db, "SELECT id FROM document_revision WHERE document_id=? AND state='effective'", [col2.document_id]);
        if (record.state === "active" && !one(db, "SELECT archived FROM person WHERE id=?", [who2.person_id])?.archived) root2.append(row(btn2("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { mode: "new", traineeId: who2.person_id, skillId: col2.skill_id, scaleId: cfg.scale_id, targetLevel: x.targetLevel ?? 2, revisionId: rev?.id, reason: "\u0420\u0430\u0437\u0432\u0438\u0442\u0438\u0435 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438 \u043F\u043E \u043C\u0430\u0442\u0440\u0438\u0446\u0435 " + cfg.code }), "primary", !rev || active4.some((v) => v.revision_state === "effective")), btn2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438", () => goLocal({ mode: "overview", personId: who2.person_id, skillId: col2.skill_id })), btn2("\u041F\u043B\u0430\u043D\u044B \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", () => go("development", { mode: "new", personId: who2.person_id }))), grid(f("\u0426\u0435\u043B\u0435\u0432\u043E\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C", goal), f("\u0421\u0440\u043E\u043A", due)), action("\u041F\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0446\u0435\u043B\u044C \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", () => run2(async () => {
          const level2 = Number(goal.value);
          invariant(level2 >= 1 && level2 <= 4 && due.value >= day, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u0438 \u0441\u0440\u043E\u043A");
          invariant((x.actual ?? 0) < level2, "\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0443\u0436\u0435 \u0434\u043E\u0441\u0442\u0438\u0433\u043D\u0443\u0442");
          invariant(!personalTargets(db, day, due.value).some((g2) => g2.person_id === who2.person_id && g2.skill_id === col2.skill_id && g2.scale_id === cfg.scale_id && g2.target_level >= level2), "\u0415\u0441\u0442\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u0430\u044F \u0446\u0435\u043B\u044C \u043D\u0435 \u043D\u0438\u0436\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0439");
          const p = event("development_plan", { person_id: who2.person_id, title: "\u0420\u0430\u0437\u0432\u0438\u0442\u0438\u0435 \u043F\u043E \u043C\u0430\u0442\u0440\u0438\u0446\u0435 " + cfg.title, start_on: day, due_on: due.value }), g = event("development_goal", { plan_id: p.entity_id, skill_id: col2.skill_id, scale_id: cfg.scale_id, target_level: level2, title: "\u041E\u0441\u0432\u043E\u0438\u0442\u044C: " + col2.title, due_on: due.value });
          await ws2.applyContentEvents([p, g], readContent3);
          return "\u0426\u0435\u043B\u044C \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0430 \u0432 \u043F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F.";
        })));
        drawer.hidden = false;
        drawer.replaceChildren(root2);
      }
      function cellButton(r, v, ri, ci, prior) {
        const k = matrixKey(r.person_id, v.skill_id), x = projection.cells.get(k), old = prior.get(k), pending = activity.get(k) || [], mode = metric.value;
        const value = mode === "base" ? x.base : mode === "target" ? x.targetLevel : mode === "delta" ? x.actual === null || old == null ? null : x.actual - old : x.actual;
        const b = btn2(value === null ? "\u2014" : mode === "delta" && value > 0 ? "+" + value : String(value), () => openCell(r, v), "matrix-value" + (mode !== "delta" && value !== null ? " matrix-level-" + value : "") + (needs(x) ? " matrix-deficit" : "") + (pending.length ? " matrix-training-pending" : ""));
        b.dataset.matrixR = ri;
        b.dataset.matrixC = ci;
        b.title = [v.title, "\u0424\u0430\u043A\u0442: " + (x.actual ?? "\u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D"), "\u0426\u0435\u043B\u044C: " + (x.targetLevel ?? "\u2014"), x.reason, x.admission, pending.length ? "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F: " + pending.length : "", mode === "delta" ? "\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435 \u0441\u043E \u0441\u0440\u0435\u0437\u043E\u043C: " + (old ?? "\u2014") : ""].filter(Boolean).join(" \xB7 ");
        b.setAttribute("aria-label", r.name + " \xB7 " + v.title + " \xB7 " + b.title);
        b.onkeydown = (e) => {
          const d = { ArrowLeft: [0, -1], ArrowRight: [0, 1], ArrowUp: [-1, 0], ArrowDown: [1, 0] }[e.key];
          if (d) {
            const next = out.querySelector('[data-matrix-r="' + (ri + d[0]) + '"][data-matrix-c="' + (ci + d[1]) + '"]');
            if (next) {
              e.preventDefault();
              next.focus();
            }
          } else if (e.key === "Escape") backMatrix();
        };
        return add2(el2("td", void 0, "matrix-value-cell"), b);
      }
      function draw() {
        route.matrixFilters = { only: filter.input.checked, gaps: gaps.input.checked, transpose: transpose.input.checked, search: search.value, grouping: grouping.value, group: group.value, metric: metric.value, compare: compare.value };
        const columns = cfg.columns.filter((v) => !group.value || grouping.value === "none" || labels3.get(v.skill_id)?.[grouping.value] === group.value), prior = comparison();
        const selected = cfg.roster.filter((r) => (!filter.input.checked || !focus || r.person_id === focus) && normalizeMatrixText(r.name + " " + r.position).includes(normalizeMatrixText(search.value)) && (!gaps.input.checked || columns.some((v) => needs(projection.cells.get(matrixKey(r.person_id, v.skill_id))))));
        if (!selected.length || !columns.length) {
          out.replaceChildren(msg("\u041D\u0435\u0442 \u0441\u0442\u0440\u043E\u043A \u0438\u043B\u0438 \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432 \u043F\u043E \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u043C \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u043C."));
          return;
        }
        const t = el2("table", void 0, "corporate-matrix"), head = el2("thead"), tr = el2("tr");
        if (transpose.input.checked) {
          t.classList.add("matrix-transposed");
          tr.append(el2("th", "\u0421\u041E\u041F / \u043D\u0430\u0432\u044B\u043A", "matrix-fixed matrix-transposed-skill"));
          selected.forEach((r) => tr.append(add2(el2("th", void 0, "matrix-transposed-person"), personLink(r))));
          tr.append(el2("th", "\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430"));
          head.append(tr);
          const body2 = el2("tbody");
          let prev = null;
          columns.forEach((v, i) => {
            const g = labels3.get(v.skill_id)?.[grouping.value];
            if (grouping.value !== "none" && g !== prev) {
              const line2 = el2("tr", void 0, "matrix-group-row"), label = el2("th", g || "\u0411\u0435\u0437 \u0433\u0440\u0443\u043F\u043F\u044B");
              label.colSpan = selected.length + 2;
              line2.append(label);
              body2.append(line2);
              prev = g;
            }
            const line = el2("tr");
            line.append(el2("th", v.title, "matrix-fixed matrix-transposed-skill"));
            selected.forEach((r, j) => line.append(cellButton(r, v, i, j, prior)));
            const a = projection.bySkill.get(v.skill_id);
            line.append(el2("td", total(a, "need") + (a.unknown ? " + ?" + a.unknown : ""), "matrix-need"));
            body2.append(line);
          });
          t.append(head, body2);
          out.replaceChildren(msg("\u041D\u0430\u0432\u044B\u043A\u0438 \u0441\u0442\u0440\u043E\u043A\u0430\u043C\u0438. \u0418\u0442\u043E\u0433\u0438 \u043E\u0442\u043D\u043E\u0441\u044F\u0442\u0441\u044F \u043A\u043E \u0432\u0441\u0435\u0439 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0439 \u043C\u0430\u0442\u0440\u0438\u0446\u0435."), add2(el2("div", void 0, "tablewrap corporate-matrix-wrap"), t));
          return;
        }
        for (const [i, label] of ["\u2116", "\u0424\u0418\u041E", "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C"].entries()) {
          const th = el2("th", label, "matrix-fixed matrix-fixed-" + i);
          th.rowSpan = 2;
          tr.append(th);
        }
        for (const v of columns) {
          const th = add2(el2("th", void 0, "matrix-skill-head"), el2("span", v.title));
          th.rowSpan = 2;
          th.title = v.title + (grouping.value === "none" ? "" : " \xB7 " + labels3.get(v.skill_id)?.[grouping.value]);
          tr.append(th);
        }
        const grouped = el2("th", "\u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430");
        grouped.colSpan = 3;
        const need = el2("th", "\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C", "matrix-need");
        need.rowSpan = 2;
        tr.append(grouped, need);
        const dates = el2("tr");
        for (const d of [cfg.base_on, day, cfg.target_on]) dates.append(el2("th", d));
        head.append(tr, dates);
        t.append(head);
        const body = el2("tbody");
        for (const [i, r] of selected.entries()) {
          const line = el2("tr"), a = projection.byPerson.get(r.person_id);
          line.append(el2("td", String(i + 1), "matrix-fixed matrix-fixed-0"), add2(el2("td", void 0, "matrix-fixed matrix-fixed-1" + (r.instructor ? " matrix-instructor" : "")), personLink(r)), el2("td", r.position || "\u2014", "matrix-fixed matrix-fixed-2"));
          columns.forEach((v, j) => line.append(cellButton(r, v, i, j, prior)));
          for (const k of ["base", "actual", "target"]) line.append(el2("td", total(a, k), "matrix-total"));
          line.append(el2("td", total(a, "need") + (a.unknown ? " + ?" + a.unknown : ""), "matrix-need"));
          body.append(line);
        }
        t.append(body);
        const footer = el2("tfoot");
        for (const [label, k] of [["\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043D\u0430 " + cfg.base_on, "base"], ["\u0422\u0435\u043A\u0443\u0449\u0435\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 " + day, "actual"], ["\u0426\u0435\u043B\u0435\u0432\u043E\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 " + cfg.target_on, "target"], ["\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430", "need"]]) {
          const tr2 = el2("tr", void 0, k === "need" ? "matrix-need" : "");
          const labelCell = el2("th", label);
          labelCell.colSpan = 3;
          tr2.append(labelCell);
          for (const v of columns) {
            const a = projection.bySkill.get(v.skill_id);
            tr2.append(el2("td", total(a, k) + (k === "need" && a.unknown ? " + ?" + a.unknown : "")));
          }
          const sum = el2("td", total(projection.total, k));
          sum.colSpan = 4;
          tr2.append(sum);
          footer.append(tr2);
        }
        t.append(footer);
        out.replaceChildren(msg("\u041F\u043E\u043A\u0430\u0437\u0430\u043D\u043E " + selected.length + " \u0438\u0437 " + cfg.roster.length + " \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432. \u041D\u0438\u0436\u043D\u0438\u0435 \u0438\u0442\u043E\u0433\u0438 \u043E\u0442\u043D\u043E\u0441\u044F\u0442\u0441\u044F \u043A\u043E \u0432\u0441\u0435\u0439 \u043C\u0430\u0442\u0440\u0438\u0446\u0435."), add2(el2("div", void 0, "tablewrap corporate-matrix-wrap"), t));
      }
      refreshGroups(saved.group);
      grouping.onchange = () => {
        refreshGroups();
        draw();
      };
      for (const ctl of [group, metric, compare]) ctl.onchange = draw;
      search.oninput = draw;
      filter.input.onchange = gaps.input.onchange = transpose.input.onchange = draw;
      draw();
      const who = cfg.roster.find((r) => r.person_id === (route.cellPersonId || route.personId)), col = cfg.columns.find((v) => v.skill_id === (route.cellSkillId || route.skillId));
      if (who && col) openCell(who, col);
      const legend = row(...Object.entries(LEVEL_TEXT).map(([v, label]) => add2(el2("span", void 0, "matrix-legend"), el2("span", v, "matrix-level-" + v), el2("span", label))), el2("span", "\u041A\u0440\u0430\u0441\u043D\u0430\u044F \u0440\u0430\u043C\u043A\u0430 \u2014 \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C; ? \u2014 \u0446\u0435\u043B\u044C \u0431\u0435\u0437 \u0444\u0430\u043A\u0442\u0430; \u0441\u0438\u043D\u044F\u044F \u0442\u043E\u0447\u043A\u0430 \u2014 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", "muted"));
      const coverage = coverageData(db, day, matrixData(db, day)).filter((x) => cfg.columns.some((c2) => c2.skill_id === x.skill_id) && (!cfg.unit_id || x.unit_id === cfg.unit_id || one(db, "WITH RECURSIVE u(id) AS (SELECT ? UNION SELECT o.id FROM org_unit o JOIN u ON o.parent_id=u.id) SELECT id FROM u WHERE id=?", [cfg.unit_id, x.unit_id])) && (!cfg.shift_id || !x.shift_code || one(db, "SELECT code FROM work_shift WHERE id=?", [cfg.shift_id])?.code === x.shift_code));
      const coverageSection = pane2("\u041F\u043E\u043A\u0440\u044B\u0442\u0438\u0435 \u043F\u043E \u0441\u043C\u0435\u043D\u0430\u043C", coverage.length ? tableOf2(["\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", "\u0421\u043C\u0435\u043D\u0430", "\u041D\u0430\u0432\u044B\u043A", "\u041D\u0443\u0436\u043D\u043E", "\u0415\u0441\u0442\u044C", "\u0414\u0435\u0444\u0438\u0446\u0438\u0442"], coverage.map((x) => [n("org_unit", x.unit_id), x.shift_code || "\u0412\u0441\u0435", n("skill", x.skill_id), x.min_people, x.actual, x.deficit])) : msg("\u0414\u043B\u044F \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0445 \u043D\u0430\u0432\u044B\u043A\u043E\u0432 \u043D\u0435\u0442 \u043D\u043E\u0440\u043C\u044B \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u044F. \u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u0435 \u043D\u043E\u0440\u043C\u044B \u043D\u0435 \u0441\u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044F \u0434\u0435\u0444\u0438\u0446\u0438\u0442\u043E\u043C."));
      return stack(pane2(cfg.title, row(btn2("\u041A \u0441\u043F\u0438\u0441\u043A\u0443 \u043C\u0430\u0442\u0440\u0438\u0446", () => goLocal()), action("\u041D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F", () => goLocal({ mode: "builder", copyId: record.id })), btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043C\u0430\u0442\u0440\u0438\u0446\u0443 XLSX", () => run2(async () => saveWorkbook("\u041C\u0430\u0442\u0440\u0438\u0446\u0430-" + cfg.code, matrixWorkbook(ExcelJS, { ...cfg, author_name: n("person", cfg.author_id) }, projection, day)), { save: false }))), msg(cfg.code + " \xB7 v" + cfg.version_no + " \xB7 " + statuses[cfg.state] + " \xB7 " + n("org_unit", cfg.unit_id) + " \xB7 " + n("work_shift", cfg.shift_id) + " \xB7 \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u043B: " + n("person", cfg.author_id)), legend, grid(f("\u041F\u043E\u0438\u0441\u043A", search), f("\u0413\u0440\u0443\u043F\u043F\u0438\u0440\u043E\u0432\u043A\u0430", grouping), f("\u0413\u0440\u0443\u043F\u043F\u0430", group), f("\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u044C", metric), f("\u0421\u0440\u0435\u0437 \u0434\u043B\u044F \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044F", compare)), row(...focus ? [filter.element] : [], gaps.element, transpose.element), add2(el2("div", void 0, "matrix-workspace"), out, drawer), msg("\u041E\u0446\u0435\u043D\u043A\u0438 \u2014 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0435 \u0444\u0430\u043A\u0442\u044B \u0432 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u043E\u0439 \u0448\u043A\u0430\u043B\u0435. \u0414\u043B\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0441\u0440\u0435\u0437\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u044E\u0442\u0441\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F. \u0422\u0435\u043A\u0443\u0449\u0430\u044F \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F \u043D\u0435 \u0440\u0430\u0432\u043D\u0430 \u0434\u043E\u043F\u0443\u0441\u043A\u0443. \u041F\u0440\u0435\u0436\u043D\u044F\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u043C\u0430\u0442\u0440\u0438\u0446\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u0442 \u0441\u043E\u0441\u0442\u0430\u0432 \u0438 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0440\u0435\u0437, \u043D\u043E \u0442\u0435\u043A\u0443\u0449\u0438\u0435 \u043F\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u0438 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u043D\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F. \u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0440\u0435\u0437 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438. \u042D\u043A\u0441\u043F\u043E\u0440\u0442 \u2014 \u043F\u043E\u043B\u043D\u0430\u044F \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043C\u0430\u0442\u0440\u0438\u0446\u0430.")), coverageSection, pane2("\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u0435", requirementsPanel(), coveragePanel(matrixData(db, day))));
    }
    function matrixProfiles() {
      const profession = ref("profession", "matrix_profile_profession"), effective2 = date3("matrix_profile_date");
      const scales = list(db, "rating_scale").filter((x) => !x.archived && x.name === SCALE_NAME && x.levels === CORPORATE_LEVELS);
      const scale = select("matrix_profile_scale", scales.map((x) => [x.id, x.name + " \xB7 v" + x.version_no]), scales[0]?.id || "", "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0443\u044E \u0448\u043A\u0430\u043B\u0443");
      const search = searchInput("matrix_profile_search"), group = select("matrix_profile_group", [["category", "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F"], ["workplace", "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E"], ["equipment", "\u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435"]], "category", null);
      const bulk = select("matrix_profile_bulk", Object.entries(LEVEL_TEXT).map(([v, t]) => [v, v + " \u2014 " + t]), "", "\u0411\u0435\u0437 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F"), out = el2("div"), head = el2("div"), status2 = msg(""), dirty = /* @__PURE__ */ new Set(), values = /* @__PURE__ */ new Map();
      let loaded = null, choices = [];
      search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u0421\u041E\u041F / \u043D\u0430\u0432\u044B\u043A\u0430";
      function load2() {
        try {
          invariant(profession.value && effective2.value >= day, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E \u0438 \u0434\u0430\u0442\u0443 \u043D\u0435 \u0440\u0430\u043D\u044C\u0448\u0435 \u0441\u0435\u0433\u043E\u0434\u043D\u044F");
          if (dirty.size && !confirm("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043D\u0435\u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0444\u0438\u043B\u044F?")) return;
          loaded = { professionId: profession.value, effective: effective2.value, scaleId: scale.value };
          dirty.clear();
          values.clear();
          const labels3 = matrixGroupLabels(db, list(db, "skill")), catalog = matrixCatalog(db);
          choices = list(db, "skill").filter((x) => !x.archived).map((x) => ({ key: x.id, skill_id: x.id, operation_id: x.operation_id, title: [x.name, ...catalog.filter((v) => v.skill_id === x.id).map((v) => v.title)].join(" \xB7 "), ...labels3.get(x.id) }));
          choices.push(...catalog.filter((x) => !x.skill_id));
          const current = new Map(rows(db, "SELECT * FROM role_requirement WHERE profession_id=? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=?", [loaded.professionId, loaded.effective, loaded.effective]).map((x) => [x.skill_id, x]));
          for (const x of choices) {
            const old = current.get(x.skill_id);
            values.set(x.key, { level: old && old.scale_id === loaded.scaleId ? String(old.required_level) : "", criticality: old?.criticality || "normal", old });
          }
          head.replaceChildren(msg("\u041F\u0440\u043E\u0444\u0438\u043B\u044C: " + n("profession", loaded.professionId) + " \xB7 \u0441 " + loaded.effective + ". \u0418\u0437\u043C\u0435\u043D\u044F\u044E\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0435 \u0441\u0442\u0440\u043E\u043A\u0438. \u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0438\u043D\u043E\u0439 \u0448\u043A\u0430\u043B\u044B \u043D\u0435 \u043F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u0443\u044E\u0442\u0441\u044F \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438."));
          draw();
        } catch (e) {
          c.notify(e.message, true);
        }
      }
      const shown = () => choices.filter((x) => normalizeMatrixText([x.title, x.category, x.workplace, x.equipment].join(" ")).includes(normalizeMatrixText(search.value)));
      function updateStatus() {
        status2.textContent = "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u043E \u0441\u0442\u0440\u043E\u043A: " + dirty.size + " \xB7 \u043D\u0430\u0439\u0434\u0435\u043D\u043E " + shown().length;
      }
      function draw() {
        if (!loaded) return;
        const groups = /* @__PURE__ */ new Map();
        for (const x of shown()) {
          const label = x[group.value] || "\u0411\u0435\u0437 \u0433\u0440\u0443\u043F\u043F\u044B";
          if (!groups.has(label)) groups.set(label, []);
          groups.get(label).push(x);
        }
        out.replaceChildren();
        for (const [label, items] of groups) {
          const d = el2("details");
          d.open = true;
          d.append(el2("summary", label + " \xB7 " + items.length));
          const lines = items.map((x) => {
            const v = values.get(x.key), target = select("profile_level_" + x.key, Object.entries(LEVEL_TEXT).map(([k, t]) => [k, k + " \u2014 " + t]), v.level, "\u041D\u0435 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F");
            const critical = simple("profile_critical_" + x.key, { normal: "\u041E\u0431\u044B\u0447\u043D\u0430\u044F", important: "\u0412\u0430\u0436\u043D\u0430\u044F", critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" }, v.criticality);
            target.onchange = () => {
              v.level = target.value;
              dirty.add(x.key);
              updateStatus();
            };
            critical.onchange = () => {
              if (v.old && v.old.scale_id !== loaded.scaleId && !v.level) {
                critical.value = v.criticality;
                c.notify("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043D\u043E\u0432\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u0432 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u043E\u0439 \u0448\u043A\u0430\u043B\u0435", true);
                return;
              }
              v.criticality = critical.value;
              dirty.add(x.key);
              updateStatus();
            };
            return [x.title, target, critical, v.old ? v.old.required_level + " \xB7 " + n("rating_scale", v.old.scale_id) + " \xB7 \u0441 " + v.old.valid_from : "\u041D\u0435\u0442"];
          });
          d.append(tableOf2(["\u0421\u041E\u041F / \u043D\u0430\u0432\u044B\u043A", "\u0422\u0440\u0435\u0431\u0443\u0435\u043C\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C", "\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u043E\u0441\u0442\u044C", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435"], lines));
          out.append(d);
        }
        updateStatus();
      }
      search.oninput = draw;
      group.onchange = draw;
      function bulkApply() {
        if (!loaded) return;
        const items = shown();
        if (!items.length || !confirm("\u0423\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C " + (bulk.value ? "\u0443\u0440\u043E\u0432\u0435\u043D\u044C " + bulk.value : "\u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F") + " \u0434\u043B\u044F " + items.length + " \u0432\u0438\u0434\u0438\u043C\u044B\u0445 \u043D\u0430\u0432\u044B\u043A\u043E\u0432?")) return;
        for (const x of items) {
          values.get(x.key).level = bulk.value;
          dirty.add(x.key);
        }
        draw();
      }
      async function saveProfile() {
        invariant(loaded && dirty.size, "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u043E\u0444\u0438\u043B\u044C \u0438 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F");
        invariant(profession.value === loaded.professionId && effective2.value === loaded.effective && scale.value === loaded.scaleId, "\u0418\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0440\u043E\u0444\u0438\u043B\u044F: \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0435\u0433\u043E \u0437\u0430\u043D\u043E\u0432\u043E");
        const events = [], entries = [], seenOps = /* @__PURE__ */ new Set();
        let scaleId = loaded.scaleId, categoryId = one(db, "SELECT id FROM skill_category WHERE name='\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043F\u043E \u0421\u041E\u041F' AND archived=0")?.id;
        if (!scaleId) {
          const version = Math.max(0, ...list(db, "rating_scale").filter((x) => x.name === SCALE_NAME).map((x) => Number(x.version_no))) + 1;
          const e = event("rating_scale", { name: SCALE_NAME, version_no: String(version), levels: CORPORATE_LEVELS });
          events.push(e);
          scaleId = e.entity_id;
        }
        for (const key3 of dirty) {
          const x = choices.find((v2) => v2.key === key3), v = values.get(key3);
          let skillId = x.skill_id;
          if (!skillId) {
            if (!v.level) continue;
            invariant(!seenOps.has(x.operation_id), "\u0414\u043B\u044F \u043D\u043E\u0432\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043E\u0434\u0438\u043D \u0421\u041E\u041F");
            seenOps.add(x.operation_id);
            if (!categoryId) {
              const cat = event("skill_category", { name: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043F\u043E \u0421\u041E\u041F" });
              events.push(cat);
              categoryId = cat.entity_id;
            }
            const doc = one(db, "SELECT title FROM document WHERE id=?", [x.document_id]), e = event("skill", { category_id: categoryId, operation_id: x.operation_id, name: doc.title });
            events.push(e);
            skillId = e.entity_id;
          }
          entries.push({ skill_id: skillId, level: v.level ? Number(v.level) : null, criticality: v.criticality });
        }
        const changes = profileEdits(db, { professionId: loaded.professionId, scaleId, effective: loaded.effective, entries });
        invariant(changes.length, "\u041D\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439");
        events.push(...changes.map((x) => event("role_requirement", x.payload, x.old)));
        if (!confirm("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C " + changes.length + " \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439? \u0421\u0442\u0430\u0440\u044B\u0435 \u043F\u0435\u0440\u0438\u043E\u0434\u044B \u0438 \u043E\u0446\u0435\u043D\u043A\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F.")) return "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
        await ws2.applyContentEvents(events, readContent3);
        return "\u041F\u0440\u043E\u0444\u0438\u043B\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
      }
      const top = pane2("\u041F\u0440\u043E\u0444\u0438\u043B\u0438 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0439", row(btn2("\u041A \u0441\u043F\u0438\u0441\u043A\u0443 \u043C\u0430\u0442\u0440\u0438\u0446", () => goLocal()), btn2("\u041A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 \u043C\u0430\u0442\u0440\u0438\u0446\u044B", () => goLocal({ mode: "builder" }))), msg("\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0440\u0435\u0435\u0441\u0442\u0440 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439. \u0421\u043E\u0437\u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u043D\u0430\u0431\u043E\u0440\u044B \u043F\u043E \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F\u043C. \u0418\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u044B\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0437\u0430\u043A\u0440\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u043F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0438\u043C \u0434\u043D\u0451\u043C; \u0434\u043B\u044F \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F, \u043D\u0430\u0447\u0430\u0442\u043E\u0433\u043E \u0441\u0435\u0433\u043E\u0434\u043D\u044F, \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0443\u044E \u0434\u0430\u0442\u0443."), grid(f("\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", profession), f("\u0428\u043A\u0430\u043B\u0430", scale), f("\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u0441", effective2)), btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u043E\u0444\u0438\u043B\u044C", load2, "primary"), head);
      return stack(top, pane2("\u041D\u0430\u0432\u044B\u043A\u0438 \u0438 \u043C\u0430\u0441\u0441\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", grid(f("\u0413\u0440\u0443\u043F\u043F\u0438\u0440\u043E\u0432\u043A\u0430", group), f("\u041F\u043E\u0438\u0441\u043A", search), f("\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0434\u043B\u044F \u0432\u0438\u0434\u0438\u043C\u044B\u0445 \u043D\u0430\u0432\u044B\u043A\u043E\u0432", bulk)), row(btn2("\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0443\u0440\u043E\u0432\u0435\u043D\u044C", bulkApply), action("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u0440\u043E\u0444\u0438\u043B\u044C", () => run2(saveProfile))), status2, out), pane2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439", requirementsPanel()));
    }
    function matrixPage() {
      const records = rows(db, "SELECT * FROM competency_matrix ORDER BY code,version_no DESC");
      if (route.mode === "overview") return legacyMatrixPage();
      if (route.mode === "profiles") return matrixProfiles();
      if (route.mode === "builder") return matrixBuilder(records.find((x) => x.id === route.copyId) ? matrixFromRecord(records.find((x) => x.id === route.copyId)) : null);
      const record = records.find((x) => x.id === route.matrixId);
      if (record) return matrixDetail(record);
      const items = route.personId ? records.filter((x) => matrixFromRecord(x).roster.some((r) => r.person_id === route.personId)) : records;
      const root2 = pane2("\u041C\u0430\u0442\u0440\u0438\u0446\u044B \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", msg("\u0424\u043E\u0440\u043C\u0430 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F 6. \u0421\u043E\u0441\u0442\u0430\u0432 \u0438 \u043F\u043E\u0440\u044F\u0434\u043E\u043A \u0421\u041E\u041F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u043F\u043E \u0432\u0435\u0440\u0441\u0438\u044F\u043C, \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u0438 \u0438 \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u043E\u0431\u043D\u043E\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0438\u0437 \u043E\u0431\u0449\u0435\u0439 \u0431\u0430\u0437\u044B."), row(action("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043C\u0430\u0442\u0440\u0438\u0446\u0443", () => goLocal({ mode: "builder", personId: route.personId })), btn2("\u041E\u0431\u0449\u0430\u044F \u043C\u0430\u0442\u0440\u0438\u0446\u0430 \u0432\u0441\u0435\u0445 \u043D\u0430\u0432\u044B\u043A\u043E\u0432", () => goLocal({ mode: "overview" })), btn2("\u041F\u0440\u043E\u0444\u0438\u043B\u0438 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0439", () => goLocal({ mode: "profiles" }))), tableOf2(["\u041A\u043E\u0434", "\u041C\u0430\u0442\u0440\u0438\u0446\u0430", "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", "\u0421\u043C\u0435\u043D\u0430", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", "\u0421\u041E\u041F / \u043D\u0430\u0432\u044B\u043A\u043E\u0432", "\u0426\u0435\u043B\u0435\u0432\u0430\u044F \u0434\u0430\u0442\u0430", "\u0412\u0435\u0440\u0441\u0438\u044F / \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", ""], items.map((v) => {
        const x = matrixFromRecord(v);
        return [v.code, v.title, n("org_unit", v.unit_id), n("work_shift", v.shift_id), x.roster.length, x.columns.length, v.target_on, "v" + v.version_no + " \xB7 " + statuses[v.state], btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043C\u0430\u0442\u0440\u0438\u0446\u0443", () => goLocal({ matrixId: v.id, personId: route.personId }), "primary")];
      })));
      if (!items.length) root2.append(msg("\u041D\u0435\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0445 \u043C\u0430\u0442\u0440\u0438\u0446. \u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043F\u0435\u0440\u0432\u0443\u044E \u0438\u043B\u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043E\u0431\u0449\u0438\u0439 \u043E\u0431\u0437\u043E\u0440 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u043E\u0446\u0435\u043D\u043E\u043A."));
      return root2;
    }
    function legacyMatrixPage() {
      const m = matrixData(db, day), q = searchInput("matrix_search"), unit = ref("org_unit", "matrix_unit", "", "\u0412\u0441\u0435 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F"), profession = ref("profession", "matrix_profession", "", "\u0412\u0441\u0435 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438"), shift = ref("work_shift", "matrix_shift", "", "\u0412\u0441\u0435 \u0441\u043C\u0435\u043D\u044B"), workplace = ref("workplace", "matrix_workplace", "", "\u0412\u0441\u0435 \u0440\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u0435\u0441\u0442\u0430"), category = ref("skill_category", "matrix_category", "", "\u0412\u0441\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438"), transpose = check("matrix_transpose", "\u041D\u0430\u0432\u044B\u043A\u0438 \u0441\u0442\u0440\u043E\u043A\u0430\u043C\u0438"), gaps = check("matrix_gaps", "\u0422\u043E\u043B\u044C\u043A\u043E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438 \u0441 \u0440\u0430\u0437\u0440\u044B\u0432\u0430\u043C\u0438"), out = el2("div");
      const operations = new Map(rows(db, "SELECT id,workplace_id FROM operation").map((o) => [o.id, o.workplace_id]));
      let personPage = 0, skillPage = 0;
      const scales = list(db, "rating_scale").filter((x) => !x.archived && x.name === SCALE_NAME && x.levels === CORPORATE_LEVELS), pointScale = select("matrix_points_scale", scales.map((x) => [x.id, x.name + " \xB7 v" + x.version_no]), scales[0]?.id || "", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0443\u044E \u0448\u043A\u0430\u043B\u0443"), horizon = date3("matrix_horizon", plusDays3(day, 30)), totals = el2("div");
      function cell(p, s, forExport = false) {
        const x = m.cells.get(p.id + ":" + s.id), fact = x.fact, actual = !fact ? "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E" : fact.observation_state === "rated" ? String(fact.level) : observationLabels[fact.observation_state], target = x.goal ? " / \u0446\u0435\u043B\u044C " + x.goal.required_level : "";
        const label = actual + target + (fact?.observation_state === "rated" && !x.valid ? " \xB7 \u0441\u0440\u043E\u043A \u0438\u0441\u0442\u0451\u043A" : "") + (!x.same && fact ? " \xB7 \u0434\u0440\u0443\u0433\u0430\u044F \u0448\u043A\u0430\u043B\u0430" : "") + (fact && !x.revisionCurrent ? " \xB7 \u043F\u0440\u0435\u0436\u043D\u044F\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F" : "") + (x.admission ? " \xB7 " + x.admission.status : "");
        if (forExport) return label;
        const b = btn2(label, () => goLocal({ mode: "overview", personId: p.id, skillId: s.id }), "lc4-matrix-cell" + (x.gap ? " lc4-gap" : x.qualified ? " lc4-met" : ""));
        b.title = label;
        return b;
      }
      function subset() {
        let people = m.people.filter((p) => (!unit.value || p.unit_id === unit.value) && (!profession.value || p.profession_id === profession.value) && (!shift.value || p.shift_id === shift.value) && [p.display_name, p.employee_code].join(" ").toLocaleLowerCase("ru-RU").includes(q.value.trim().toLocaleLowerCase("ru-RU"))), skills = m.skills.filter((s) => (!category.value || s.category_id === category.value) && (!workplace.value || operations.get(s.operation_id) === workplace.value));
        if (gaps.input.checked) people = people.filter((p) => skills.some((s) => m.cells.get(p.id + ":" + s.id).gap));
        return { people, skills };
      }
      function draw() {
        const all = subset();
        if (!all.people.length || !all.skills.length) {
          out.replaceChildren(msg("\u041D\u0435\u0442 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0438\u043B\u0438 \u043D\u0430\u0432\u044B\u043A\u043E\u0432 \u043F\u043E \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u043C \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u043C. \u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430\u0445."));
          totals.replaceChildren(msg("\u041D\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0445 \u0444\u0438\u043B\u044C\u0442\u0440\u043E\u0432."));
          return;
        }
        personPage = Math.min(personPage, Math.floor((all.people.length - 1) / 40));
        skillPage = Math.min(skillPage, Math.floor((all.skills.length - 1) / 20));
        const people = all.people.slice(personPage * 40, personPage * 40 + 40), skills = all.skills.slice(skillPage * 20, skillPage * 20 + 20);
        const transposeOn = transpose.input.checked, heads = transposeOn ? ["\u041D\u0430\u0432\u044B\u043A", ...people.map((p) => p.display_name)] : ["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ...skills.map((s) => s.name)], data = transposeOn ? skills.map((s) => [s.name, ...people.map((p) => cell(p, s))]) : people.map((p) => [btn2(p.display_name, () => c.openEmployee(p.id), "matrix-person-link"), ...skills.map((s) => cell(p, s))]);
        const table3 = tableOf2(heads, data);
        table3.classList.add("lc4-matrix");
        const pager = row(msg("\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438 " + (personPage * 40 + 1) + "\u2013" + (personPage * 40 + people.length) + " \u0438\u0437 " + all.people.length), btn2("\u2039", () => {
          personPage--;
          draw();
        }, "", personPage === 0), btn2("\u203A", () => {
          personPage++;
          draw();
        }, "", personPage * 40 + people.length >= all.people.length), msg("\u041D\u0430\u0432\u044B\u043A\u0438 " + (skillPage * 20 + 1) + "\u2013" + (skillPage * 20 + skills.length) + " \u0438\u0437 " + all.skills.length), btn2("\u2039", () => {
          skillPage--;
          draw();
        }, "", skillPage === 0), btn2("\u203A", () => {
          skillPage++;
          draw();
        }, "", skillPage * 20 + skills.length >= all.skills.length));
        const download2 = btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0432\u0441\u044E \u0432\u044B\u0431\u043E\u0440\u043A\u0443 XLSX", () => run2(async () => {
          invariant(all.people.length * all.skills.length <= 2e5, "\u0423\u0442\u043E\u0447\u043D\u0438\u0442\u0435 \u0444\u0438\u043B\u044C\u0442\u0440\u044B \u0434\u043B\u044F \u044D\u043A\u0441\u043F\u043E\u0440\u0442\u0430");
          const headers = transposeOn ? ["\u041D\u0430\u0432\u044B\u043A", ...all.people.map((p) => p.display_name)] : ["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", ...all.skills.map((s) => s.name)];
          await exportTable("\u041C\u0430\u0442\u0440\u0438\u0446\u0430-\u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", headers, transposeOn ? all.skills.map((s) => [s.name, ...all.people.map((p) => cell(p, s, true))]) : all.people.map((p) => [p.display_name, ...all.skills.map((s) => cell(p, s, true))]));
          return "\u041E\u0442\u0447\u0451\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
        }, { save: false }));
        out.replaceChildren(pager, table3, download2);
        drawTotals(all);
      }
      function drawTotals(all) {
        if (!pointScale.value) {
          totals.replaceChildren(msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0438\u043B\u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0442\u043E\u0447\u043D\u0443\u044E \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0443\u044E \u0448\u043A\u0430\u043B\u0443 1\u20134 \u0434\u043B\u044F \u0441\u0443\u043C\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F. \u0414\u0440\u0443\u0433\u0438\u0435 \u0448\u043A\u0430\u043B\u044B \u043D\u0435 \u0441\u043C\u0435\u0448\u0438\u0432\u0430\u044E\u0442\u0441\u044F."));
          return;
        }
        if (!horizon.value || horizon.value < day) {
          totals.replaceChildren(msg("\u0426\u0435\u043B\u0435\u0432\u0430\u044F \u0434\u0430\u0442\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043D\u0435 \u0440\u0430\u043D\u044C\u0448\u0435 \u0442\u0435\u043A\u0443\u0449\u0435\u0439.", "warn"));
          return;
        }
        const p = matrixPoints(m, all.people, all.skills, pointScale.value, personalTargets(db, day, horizon.value)), labels3 = ["\u041E\u0431\u044A\u0435\u043A\u0442", "\u0424\u0430\u043A\u0442, \u0431\u0430\u043B\u043B\u044B", "\u041E\u0446\u0435\u043D\u0435\u043D\u043E", "\u0426\u0435\u043B\u044C, \u0431\u0430\u043B\u043B\u044B", "\u0426\u0435\u043B\u0435\u0439", "\u0418\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0440\u0430\u0437\u0440\u044B\u0432", "\u0426\u0435\u043B\u0435\u0439 \u0431\u0435\u0437 \u0444\u0430\u043A\u0442\u0430"];
        const line = (name, x) => [name, x.rated ? x.actual : "\u2014", x.rated, x.targeted ? x.target : "\u2014", x.targeted, x.targeted ? x.need : "\u2014", x.unknown];
        const persons = all.people.map((x) => line(x.display_name, p.byPerson.get(x.id))), skills = all.skills.map((x) => line(x.name, p.bySkill.get(x.id) || { actual: 0, rated: 0, target: 0, targeted: 0, need: 0, unknown: 0 }));
        totals.replaceChildren(msg("\u0421\u0443\u043C\u043C\u044B \u043F\u043E \u0432\u0441\u0435\u0439 \u043E\u0442\u0444\u0438\u043B\u044C\u0442\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0432\u044B\u0431\u043E\u0440\u043A\u0435. \u0426\u0435\u043B\u044C \u0432\u043A\u043B\u044E\u0447\u0430\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u043E\u0442\u043A\u0440\u044B\u0442\u044B\u0435 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u0446\u0435\u043B\u0438 \u0434\u043E " + horizon.value + ". \u041D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0435/\u043D\u0435\u043E\u0446\u0435\u043D\u0451\u043D\u043D\u043E\u0435 \u043D\u0435 \u0440\u0430\u0432\u043D\u043E \u043D\u0443\u043B\u044E. \u0421\u0443\u043C\u043C\u0430 \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u0442 \u0447\u0438\u0441\u043B\u043E \u0434\u043E\u043F\u0443\u0449\u0435\u043D\u043D\u044B\u0445 \u0440\u0430\u0431\u043E\u0442\u043D\u0438\u043A\u043E\u0432."), pane2("\u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438 \u0438 \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", tableOf2(labels3, persons), exportButton("\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438-\u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", labels3, persons)), pane2("\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439 \u0438 \u043F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430", tableOf2(labels3, skills), exportButton("\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u0438-\u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430", labels3, skills)));
      }
      pointScale.onchange = horizon.onchange = () => drawTotals(subset());
      const reset = () => {
        personPage = 0;
        skillPage = 0;
        draw();
      };
      for (const control of [unit, profession, shift, workplace, category, transpose.input, gaps.input]) control.onchange = reset;
      q.oninput = reset;
      draw();
      if (route.personId && route.skillId) {
        const p = m.people.find((x) => x.id === route.personId), s = m.skills.find((x) => x.id === route.skillId);
        if (p && s) {
          const x = m.cells.get(p.id + ":" + s.id), history = rows(db, "SELECT i.*,a.assessed_at,a.evaluator_id,a.standard_revision_id,a.assignment_id FROM assessment_item i JOIN assessment_session a ON a.id=i.session_id WHERE a.person_id=? AND i.skill_id=? AND a.state='confirmed' ORDER BY a.assessed_at DESC,a.recorded_at DESC", [p.id, s.id]);
          return pane2(p.display_name + " \xB7 " + s.name, row(back(), btn2("\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430", () => c.openEmployee(p.id))), msg(cell(p, s, true)), table2(["\u0414\u0430\u0442\u0430", "\u0428\u043A\u0430\u043B\u0430", "\u0423\u0440\u043E\u0432\u0435\u043D\u044C / \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "\u0421\u041E\u041F", ""], history.map((h) => [h.assessed_at, n("rating_scale", h.scale_id), h.observation_state === "rated" ? h.level : observationLabels[h.observation_state], n("person", h.evaluator_id), revLabel(h.standard_revision_id), h.assignment_id ? btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { id: h.assignment_id, tab: "practice" })) : "\u2014"])), row(btn2("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { mode: "new", traineeId: p.id, skillId: s.id, scaleId: x.goal?.scale_id, targetLevel: x.goal?.required_level, revisionId: revs().find((r) => r.operation_id === s.operation_id)?.id, reason: "\u0420\u0430\u0437\u0432\u0438\u0442\u0438\u0435 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438" })), btn2("\u041F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", () => go("development", { mode: "new", personId: p.id }))));
        }
      }
      const scaleSetup = action("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0448\u043A\u0430\u043B\u0443 1\u20134", () => run2(async () => {
        invariant(!scales.length, "\u0422\u043E\u0447\u043D\u0430\u044F \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u0448\u043A\u0430\u043B\u0430 \u0443\u0436\u0435 \u0441\u043E\u0437\u0434\u0430\u043D\u0430");
        const previous = list(db, "rating_scale").filter((x) => x.name === SCALE_NAME);
        const version = Math.max(0, ...previous.map((x) => Number(x.version_no))) + 1;
        ws2.edit("rating_scale", null, { name: SCALE_NAME, version_no: String(version), levels: CORPORATE_LEVELS });
        return "\u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u0448\u043A\u0430\u043B\u0430 1\u20134 \u0441\u043E\u0437\u0434\u0430\u043D\u0430 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0435\u0439. \u041F\u0440\u0435\u0436\u043D\u0438\u0435 \u043E\u0446\u0435\u043D\u043A\u0438 \u043D\u0435 \u043F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u044B.";
      }), "", scales.length > 0);
      return stack(pane2("\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", msg("\u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u0438 \u0446\u0435\u043B\u0435\u0432\u043E\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u044B \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E. \u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E, \u043D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E, \u0434\u0440\u0443\u0433\u0430\u044F \u0448\u043A\u0430\u043B\u0430, \u0441\u0440\u043E\u043A \u0438 \u0434\u043E\u043F\u0443\u0441\u043A \u043D\u0435 \u0441\u043C\u0435\u0448\u0438\u0432\u0430\u044E\u0442\u0441\u044F."), row(btn2("\u041D\u0430\u0432\u044B\u043A\u0438", () => go("skill")), btn2("\u0428\u043A\u0430\u043B\u044B", () => go("rating_scale")), scaleSetup), grid(f("\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", unit), f("\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044F", profession), f("\u0421\u043C\u0435\u043D\u0430", shift), f("\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E", workplace), f("\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F \u043D\u0430\u0432\u044B\u043A\u043E\u0432", category), f("\u041F\u043E\u0438\u0441\u043A \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430", q)), row(transpose.element, gaps.element), out), pane2("\u0421\u0443\u043C\u043C\u0430\u0440\u043D\u044B\u0435 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438", grid(f("\u0412\u0435\u0440\u0441\u0438\u044F \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u043E\u0439 \u0448\u043A\u0430\u043B\u044B", pointScale), f("\u0426\u0435\u043B\u0435\u0432\u043E\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043D\u0430 \u0434\u0430\u0442\u0443", horizon)), totals), pane2("\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u0435", requirementsPanel(), coveragePanel(m)));
    }
    function journalPage() {
      const a = asgns(), facts = rows(db, "SELECT * FROM training_session WHERE stage_code IS NOT NULL ORDER BY held_at DESC,recorded_at DESC"), q = searchInput("journal_search"), out = el2("div"), heads = ["\u0414\u0430\u0442\u0430 / \u0432\u0440\u0435\u043C\u044F", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0421\u041E\u041F", "\u042D\u0442\u0430\u043F", "\u041C\u0438\u043D\u0443\u0442", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442"];
      const line = (x) => {
        const t = a.find((y) => y.id === x.assignment_id), names3 = JSON.parse(t?.recorded_names_json || "{}");
        return [x.held_at, names3.instructor || n("person", x.mentor_id), names3.trainee || n("person", t?.trainee_id), revLabel(t?.sop_revision_id), JSON.parse(x.steps_json).label, x.duration_minutes, resultLabels[x.result]];
      };
      filterList(out, q, facts, (x) => line(x).join(" "), (items) => table2([...heads, ""], items.map((x) => [...line(x), btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => go("instruction", { id: x.assignment_id, tab: "instruction" }), "primary")])));
      return pane2("\u0416\u0443\u0440\u043D\u0430\u043B \u0437\u0430\u0434\u0430\u043D\u0438\u0439 \u0438 \u043F\u0440\u043E\u0432\u0435\u0434\u0451\u043D\u043D\u044B\u0445 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", msg("\u042D\u0442\u043E \u0444\u0430\u043A\u0442\u044B \u0438\u0437 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439, \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u0432\u0432\u043E\u0434 \u043D\u0435 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F. \u041F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u044F \u044F\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u044B\u043C\u0438 \u0437\u0430\u043F\u0438\u0441\u044F\u043C\u0438."), q, out, productionExport(() => a.filter((x) => {
        const text4 = q.value.trim().toLocaleLowerCase("ru-RU");
        return !text4 || assignmentName(x).toLocaleLowerCase("ru-RU").includes(text4) || facts.some((y) => y.assignment_id === x.id && line(y).join(" ").toLocaleLowerCase("ru-RU").includes(text4));
      }), "\u0416\u0443\u0440\u043D\u0430\u043B-\u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u0440\u0430\u0431\u043E\u0442\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432 TWI"), exportButton("\u0416\u0443\u0440\u043D\u0430\u043B-\u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", heads, facts.map(line)));
    }
    function retrainingPage() {
      const old = asgns().filter((a) => a.state !== "cancelled" && !sameRevision(a)), m = matrixData(db, day);
      const gaps = [];
      for (const p of m.people) for (const s of m.skills) {
        const x = m.cells.get(p.id + ":" + s.id);
        if (x.gap) gaps.push({ p, s, x });
      }
      return stack(
        pane2("\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0421\u041E\u041F \u2014 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0430\u043D\u0430\u043B\u0438\u0437 \u0432\u043B\u0438\u044F\u043D\u0438\u044F", msg("\u041F\u0440\u0435\u0436\u043D\u0438\u0435 \u0444\u0430\u043A\u0442\u044B, \u0443\u0440\u043E\u0432\u043D\u0438 \u0438 \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F. \u041D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0441\u043E\u0437\u0434\u0430\u0451\u0442\u0441\u044F \u043F\u043E \u044F\u0432\u043D\u043E\u043C\u0443 \u0440\u0435\u0448\u0435\u043D\u0438\u044E, \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0441\u0442\u0430\u0440\u044B\u0439 \u0434\u043E\u043F\u0443\u0441\u043A \u043D\u0435 \u0430\u043D\u043D\u0443\u043B\u0438\u0440\u0443\u0435\u0442\u0441\u044F."), table2(["\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u041F\u0440\u0435\u0436\u043D\u0438\u0439 \u0421\u041E\u041F", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0430\u044F \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F", ""], old.map((a) => {
          const r = revs().find((x) => x.document_id === currentStandard(db, a.sop_revision_id)?.document_id);
          return [n("person", a.trainee_id), revLabel(a.sop_revision_id), stateLabel(a), r ? revLabel(r.id) : "\u041D\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0433\u043E \u0421\u041E\u041F", row(btn2("\u0418\u0441\u0442\u043E\u0440\u0438\u044F", () => go("twi", { id: a.id })), ...r ? [action("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043F\u0435\u0440\u0435\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => go("twi", { mode: "new", traineeId: a.trainee_id, revisionId: r.id, skillId: a.skill_id, scaleId: a.scale_id, targetLevel: a.target_level, reason: "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0438 \u0421\u041E\u041F: " + revLabel(a.sop_revision_id) }))] : [])];
        }))),
        pane2("\u0420\u0430\u0437\u0440\u044B\u0432\u044B \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", table2(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u041D\u0430\u0432\u044B\u043A", "\u0426\u0435\u043B\u044C", "\u0424\u0430\u043A\u0442", ""], gaps.map(({ p, s, x }) => [p.display_name, s.name, x.goal.required_level, x.fact?.level ?? "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E", action("\u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u0435", () => go("development", { mode: "new", personId: p.id }))])))
      );
    }
    function developmentPage() {
      const items = rows(db, "SELECT * FROM development_plan ORDER BY due_on,id");
      if (route.mode === "new") {
        const who = person2("development_person", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", route.personId || ""), title = fieldInput2("development_title"), start = date3("development_start"), due = date3("development_due");
        return pane2("\u041D\u043E\u0432\u044B\u0439 \u043F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", back(), grid(who.element, f("\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 / \u0446\u0435\u043B\u044C", title), f("\u041D\u0430\u0447\u0430\u043B\u043E", start), f("\u0421\u0440\u043E\u043A", due)), save2("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", "development_plan", () => ({ person_id: who.value, title: title.value, start_on: start.value, due_on: due.value }), null, (id) => {
          route = { page: page2, id };
        }));
      }
      const plan = items.find((x) => x.id === route.id);
      if (plan) {
        const goals = rows(db, "SELECT * FROM development_goal WHERE plan_id=? ORDER BY due_on,id", [plan.id]), root2 = pane2(plan.title + " \xB7 " + n("person", plan.person_id), back(), msg(statuses[plan.state] + " \xB7 " + plan.start_on + " \u2014 " + plan.due_on), table2(["\u0426\u0435\u043B\u044C", "\u041D\u0430\u0432\u044B\u043A", "\u0423\u0440\u043E\u0432\u0435\u043D\u044C", "\u0421\u0440\u043E\u043A", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", ""], goals.map((g) => {
          const t = JSON.parse(g.target_json);
          return [g.title, n("skill", g.skill_id), t.target_level ?? "\u2014", g.due_on, g.state === "open" ? "\u041E\u0442\u043A\u0440\u044B\u0442\u0430" : statuses[g.state] || g.state, g.state === "open" ? row(closeRecord("\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C", "development_goal", g, "finish"), closeRecord("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C", "development_goal", g, "cancel")) : "\u2014"];
        })));
        if (plan.state === "active") {
          const title = fieldInput2("goal_title"), skill = ref("skill", "goal_skill", "", "\u2014 \u0411\u0435\u0437 \u043D\u0430\u0432\u044B\u043A\u0430 \u2014"), target = scaleFields("goal_target"), due = date3("goal_due", plan.due_on);
          root2.append(pane2("\u041D\u043E\u0432\u0430\u044F \u0446\u0435\u043B\u044C", grid(f("\u0426\u0435\u043B\u044C", title), f("\u041D\u0430\u0432\u044B\u043A", skill), f("\u0421\u0440\u043E\u043A", due)), target.element, save2("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0446\u0435\u043B\u044C", "development_goal", () => ({ plan_id: plan.id, skill_id: nullable(skill.value), scale_id: skill.value ? nullable(target.scale.value) : null, target_level: skill.value && target.level.value !== "" ? Number(target.level.value) : null, title: title.value, due_on: due.value }))), closeRecord("\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u043F\u043B\u0430\u043D", "development_plan", plan, "finish"), closeRecord("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u043B\u0430\u043D", "development_plan", plan, "cancel"));
        }
        return root2;
      }
      return pane2("\u041F\u043B\u0430\u043D\u044B \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", action("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", () => goLocal({ mode: "new" })), table2(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0426\u0435\u043B\u044C", "\u0421\u0440\u043E\u043A", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], items.map((x) => [n("person", x.person_id), x.title, x.due_on, statuses[x.state], btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: x.id }), "primary")])));
    }
    function myPlan() {
      const actor = person2("my_plan_person", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", route.personId || "", { onChange: (id2) => {
        route.personId = id2;
        render2();
      } }), id = actor.value, items = id ? asgns().filter((a) => [a.trainee_id, a.mentor_id, a.supervisor_id, a.assigned_by].includes(id)) : [], programs = id ? enrollmentList().filter((x) => [x.trainee_id, x.mentor_id, x.manager_id].includes(id)) : [];
      return stack(pane2("\u041C\u043E\u0439 \u043F\u043B\u0430\u043D", msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430. \u042D\u0442\u043E \u0444\u0438\u043B\u044C\u0442\u0440 \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439, \u043D\u0435 \u0432\u0445\u043E\u0434 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0443 \u0438 \u043D\u0435 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u043F\u0440\u0430\u0432 \u0434\u043E\u0441\u0442\u0443\u043F\u0430."), actor.element, id ? assignmentRows(items) : msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u0434\u043B\u044F \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439.")), pane2("\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", table2(["\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0421\u0440\u043E\u043A", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], programs.map((x) => [one(db, "SELECT title FROM training_program WHERE id=?", [x.program_id])?.title, n("person", x.trainee_id), x.due_on, statuses[x.state], btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => go(enrollmentPage(x.id), { enrollmentId: x.id }), "primary")]))));
    }
    function methodView(code, method) {
      const existing = trainingMethods(db, code), out = pane2("\u0412\u0435\u0440\u0441\u0438\u0438 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438", msg("\u0412\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0434\u043E \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F. \u0418\u043C\u043F\u043E\u0440\u0442 \u043D\u043E\u0432\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u0435\u0442 \u0441\u0442\u0430\u0440\u044B\u0435 \u043E\u0446\u0435\u043D\u043A\u0438. \u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E 1\u2013100 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432. \u0428\u043A\u0430\u043B\u0430 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u044F\u0435\u0442\u0441\u044F \u0432\u0438\u0434\u043E\u043C \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438."));
      const sample = existing.find((m) => m.state === "active");
      const data = sample ? JSON.parse(sample.methodology_json) : method;
      out.append(tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439"], data.criteria.map((q) => [q.code, q.section, q.question])));
      const importMethod = async (p) => {
        validateMentorMethod(p, method.format);
        if (!confirm(p.title + " \xB7 " + p.criteria.length + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432. \u0410\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E?\n\n" + p.criteria.map((q) => q.code + ". " + q.question).join("\n"))) return "\u0418\u043C\u043F\u043E\u0440\u0442 \u043E\u0442\u043C\u0435\u043D\u0451\u043D";
        await write("checklist_version", p);
        return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
      };
      out.append(row(action("\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 JSON", () => pick2(".json", importMethod, 128e3)), action("\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 XLSX", () => {
        const input = el2("input");
        input.type = "file";
        input.accept = ".xlsx";
        input.onchange = () => {
          const file = input.files?.[0];
          if (file) run2(async () => {
            invariant(file.size <= 12 * 1024 * 1024, "\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
            const bytes = new Uint8Array(await file.arrayBuffer()), book = new ExcelJS.Workbook();
            await book.xlsx.load(bytes);
            const generic = book.getWorksheet("\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438"), original = code === SELF_CODE ? book.getWorksheet("\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430") : null;
            let criteria;
            if (generic) criteria = criteriaFromTabularSheet(generic);
            else if (original) {
              criteria = Array.from({ length: 20 }, (_, i) => ({ code: Number(original.getCell(i + 5, 1).text), section: "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430", question: original.getCell(i + 5, 2).text.trim() }));
            } else throw Error("\u041D\u0443\u0436\u0435\u043D \u043B\u0438\u0441\u0442 \xAB\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438\xBB: \u2116, \u0420\u0430\u0437\u0434\u0435\u043B, \u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439");
            return importMethod({ format: method.format, title: file.name.slice(0, 200), source_sha256: await sha256(bytes), criteria });
          });
        };
        input.click();
      }), btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C JSON \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0439 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438", () => run2(async () => {
        const payload = { ...data };
        if (!sample && code === AUDIT_CODE) payload.source_sha256 = await sha256(canonical(payload.criteria));
        downloadBytes2("\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430-" + code + ".json", new TextEncoder().encode(JSON.stringify(payload, null, 2)));
        return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
      }, { save: false }))));
      for (const m of existing) {
        const p = JSON.parse(m.methodology_json);
        const d = el2("details");
        d.append(el2("summary", "v" + m.version_no + " \xB7 " + p.title + " \xB7 " + p.criteria.length + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \xB7 " + (m.state === "active" ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u0418\u0441\u0442\u043E\u0440\u0438\u044F")), tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439"], p.criteria.map((q) => [q.code, q.section, q.question])));
        out.append(d);
      }
      return out;
    }
    function answerControls(criteria, levels, prefix) {
      const values = criteria.map((q) => ({ q, input: select(prefix + "_" + q.position, Object.entries(levels).map(([k, v]) => [k, k + " \u2014 " + v]), "", "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E"), note: fieldInput2(prefix + "_note_" + q.position) }));
      const progress = msg("\u041E\u0446\u0435\u043D\u0435\u043D\u043E 0 / " + criteria.length);
      for (const x of values) x.input.onchange = () => {
        progress.textContent = "\u041E\u0446\u0435\u043D\u0435\u043D\u043E " + values.filter((v) => v.input.value !== "").length + " / " + criteria.length;
      };
      return { values, table: stack(tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], values.map((x) => [x.q.position, x.q.section_code, x.q.question, x.input, x.note])), progress), responses: () => values.map((x) => ({ criterion_id: x.q.id, value: x.input.value === "" ? null : Number(x.input.value), note: x.note.value })) };
    }
    function methodDraft(code, builtin) {
      const m = trainingMethods(db, code).find((x) => x.state === "active"), created = m ? null : event("checklist_version", builtin), id = m?.id || created.entity_id;
      return { id, created, criteria: m ? practicalCriteria(db, id) : previewCriteria(builtin, id), label: m ? "v" + m.version_no : "\u0412\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0430" };
    }
    function saveWithMethod(label, draft, type, payload, done) {
      return action(label, () => run2(async () => {
        const e = event(type, payload());
        await ws2.applyContentEvents([...draft.created ? [draft.created] : [], e], readContent3);
        done?.(e.entity_id);
        return "\u0417\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
      }));
    }
    function selfPage() {
      const items = rows(db, "SELECT * FROM mentor_self_evaluation ORDER BY evaluated_on DESC,recorded_at DESC");
      const detail = items.find((x) => x.id === route.id);
      if (detail) {
        const criteria = practicalCriteria(db, detail.method_id), answers = JSON.parse(detail.responses_json), lines = criteria.map((q, i) => [q.position, q.question, answers[i]?.value ?? "\u2014", answers[i]?.note || ""]);
        return pane2("\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430 \xB7 " + detail.person_name, back(), msg(detail.evaluated_on + " \xB7 " + detail.place), tableOf2(["\u2116", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u0423\u0440\u043E\u0432\u0435\u043D\u044C", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], lines), msg(detail.feedback), exportButton("\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430-" + detail.id.slice(0, 8), ["\u2116", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u0423\u0440\u043E\u0432\u0435\u043D\u044C", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], lines));
      }
      if (route.mode === "new") {
        const draft = methodDraft(SELF_CODE, BUILTIN_SELF), when = date3("self_date"), who = person2("self_person", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 / \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A", "", { allowed: ["instructor", "mentor"], at: () => when.value }), place = fieldInput2("self_place"), feedback = note("self_feedback"), answers = answerControls(draft.criteria, SELF_LEVELS, "self_value");
        return pane2("\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430", back(), msg(draft.label + " \xB7 " + draft.criteria.length + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432. \u0428\u043A\u0430\u043B\u0430 1\u20135; \u043D\u0435 \u0441\u043C\u0435\u0448\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u0441 \u043C\u0430\u0442\u0440\u0438\u0446\u0435\u0439 1\u20134."), grid(who.element, f("\u0414\u0430\u0442\u0430", when), f("\u041C\u0435\u0441\u0442\u043E", place)), answers.table, f("\u0410\u043D\u0430\u043B\u0438\u0437 \u0438 \u043E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C", feedback), saveWithMethod("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0441\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0443", draft, "mentor_self_evaluation", () => ({ person_id: who.value, method_id: draft.id, evaluated_on: when.value, place: place.value, responses: answers.responses(), feedback: feedback.value }), (id) => {
          route = { page: page2, id };
        }));
      }
      return stack(pane2("\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u043E\u0432 \u0438 \u0412\u0422", action("\u041D\u043E\u0432\u0430\u044F \u0441\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430", () => goLocal({ mode: "new" })), table2(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0414\u0430\u0442\u0430", "\u041C\u0435\u0441\u0442\u043E", "\u0418\u0442\u043E\u0433\u043E", ""], items.map((x) => {
        const v = JSON.parse(x.responses_json);
        return [x.person_name, x.evaluated_on, x.place, v.reduce((n2, q) => n2 + q.value, 0) + " / " + v.length * 5, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: x.id }), "primary")];
      }))), methodView(SELF_CODE, BUILTIN_SELF));
    }
    function auditPayload() {
      return { format: "lean-audit-checklist-v1", title: "\u0410\u0443\u0434\u0438\u0442 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F \xB7 RC1", source_sha256: "0".repeat(64), criteria: RC1_CRITERIA.map(({ rc1_id, ...q }) => q) };
    }
    function auditPage() {
      const method = auditPayload(), items = rows(db, "SELECT * FROM audit_session WHERE assignment_id IS NOT NULL ORDER BY observed_at DESC,recorded_at DESC"), detail = items.find((x) => x.id === route.auditId);
      if (detail) {
        const criteria = practicalCriteria(db, detail.version_id), answers = rows(db, "SELECT * FROM audit_response WHERE audit_id=?", [detail.id]), byId = new Map(answers.map((x) => [x.criterion_id, x])), lines = criteria.map((q) => [q.position, q.section_code, q.question, byId.get(q.id)?.response === "yes" ? 1 : 0, byId.get(q.id)?.note || ""]);
        const source = JSON.parse(one(db, "SELECT methodology_json FROM checklist_version WHERE id=?", [detail.version_id]).methodology_json), recommendations = source.criteria.filter((q, i) => lines[i][3] === 0 && q.recommendation).map((q) => q.recommendation);
        const names3 = JSON.parse(detail.recorded_names_json);
        return pane2("\u0410\u0443\u0434\u0438\u0442 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F \xB7 " + (names3.mentor || n("person", detail.mentor_id)), back(), msg(detail.observed_at + " \xB7 " + revLabel(detail.standard_revision_id) + " \xB7 " + (detail.state === "void" ? "\u0410\u043D\u043D\u0443\u043B\u0438\u0440\u043E\u0432\u0430\u043D" : "\u0417\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u043D")), msg("\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440: " + names3.auditor + " \xB7 \u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439: " + names3.trainee), msg("\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: " + lines.reduce((n2, x) => n2 + x[3], 0) + " / " + lines.length), tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], lines), msg(detail.summary || ""), ...recommendations.map((x) => msg(x)), btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", () => go("twi", { id: detail.assignment_id })), exportButton("\u0410\u0443\u0434\u0438\u0442-L1-" + detail.id.slice(0, 8), ["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], lines), ...detail.state === "final" ? [closeRecord("\u0410\u043D\u043D\u0443\u043B\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0430\u0443\u0434\u0438\u0442", "audit_session", detail, "void")] : [msg(detail.void_reason || "")]);
      }
      if (route.mode === "new") {
        const available = asgns().filter((a) => a.state !== "cancelled" && a.approval_json && progressFor(db, a).facts.length), as = select("audit_assignment", available.map((a) => [a.id, assignmentName(a)]), route.assignmentId || ""), session = select("audit_fact", []), when = date3("audit_date");
        const auditor = person2("audit_actor", "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440", "", { at: () => when.value, allowed: ["instructor"], filter: (p) => {
          const a = available.find((x) => x.id === as.value);
          return p.id !== a?.mentor_id && p.id !== a?.trainee_id && p.roles.some((r) => [r.name, r.code].some((v) => ["internal_trainer", "internal trainer", "\u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0442\u0440\u0435\u043D\u0435\u0440", "\u0432\u0442"].includes(String(v).toLocaleLowerCase("ru-RU").trim().replaceAll("-", "_"))));
        } });
        const feedback = note("audit_feedback"), draft = methodDraft(AUDIT_CODE, method), answers = answerControls(draft.criteria, { 0: "\u041D\u0435\u0442", 1: "\u0414\u0430" }, "audit_value");
        const info = msg("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"), refresh2 = () => {
          const a = available.find((x) => x.id === as.value);
          replaceOptions(session, select("audit_fact", a ? progressFor(db, a).facts.map((v) => [v.id, v.held_at + " \xB7 " + JSON.parse(v.steps_json).label]) : []));
          info.textContent = a ? "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440: " + n("person", a.mentor_id) + " \xB7 \u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439: " + n("person", a.trainee_id) + " \xB7 " + revLabel(a.sop_revision_id) : "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435";
        };
        as.onchange = () => {
          auditor.set("");
          refresh2();
        };
        refresh2();
        return pane2("\u0410\u0443\u0434\u0438\u0442 \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F", back(), msg("\u041E\u0446\u0435\u043D\u043A\u0430 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430. \u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u0441\u0442\u0430\u0436\u0451\u0440\u0430 \u043E\u0441\u0442\u0430\u0451\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u043C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u043C."), f("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", as), info, grid(f("\u041D\u0430\u0431\u043B\u044E\u0434\u0430\u0432\u0448\u0438\u0439\u0441\u044F \u0444\u0430\u043A\u0442", session), auditor.element, f("\u0414\u0430\u0442\u0430 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F", when)), answers.table, f("\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0443", feedback), action("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0430\u0443\u0434\u0438\u0442", () => run2(async () => {
          const a = available.find((x) => x.id === as.value);
          invariant(a, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435");
          if (draft.created) draft.created.payload = { ...method, source_sha256: await sha256(canonical(method.criteria)) };
          const e = event("audit_session", { assignment_id: a.id, assignment_rev: a.rev, method_id: draft.id, auditor_id: auditor.value, session_id: session.value, observed_on: when.value, responses: answers.responses(), feedback: feedback.value });
          await ws2.applyContentEvents([...draft.created ? [draft.created] : [], e], readContent3);
          route = { page: page2, auditId: e.entity_id };
          return "\u0417\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
        })));
      }
      return stack(pane2("\u0410\u0443\u0434\u0438\u0442\u044B 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F", msg("\u0412\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u0430\u044F RC1: 7+4+4+5 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432. \u0417\u0430\u043F\u0438\u0441\u044C \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u0430 \u043A \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044E \u0438 \u0444\u0430\u043A\u0442\u0443 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430. \u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u043D\u0430\u044F \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 \u0438 \u043C\u043E\u0431\u0438\u043B\u044C\u043D\u044B\u0439 \u043E\u0431\u043C\u0435\u043D RC1 \u2014 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u0437\u0430\u0434\u0430\u0447\u0430 LC5."), action("\u041D\u043E\u0432\u044B\u0439 \u0430\u0443\u0434\u0438\u0442", () => goLocal({ mode: "new" })), table2(["\u0414\u0430\u0442\u0430", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", "\u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439", "\u0421\u041E\u041F", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", ""], items.map((x) => [x.observed_at, n("person", x.mentor_id), n("person", x.trainee_id), revLabel(x.standard_revision_id), x.state === "void" ? "\u0410\u043D\u043D\u0443\u043B\u0438\u0440\u043E\u0432\u0430\u043D" : "\u0417\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u043D", btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ auditId: x.id }), "primary")]))), methodView(AUDIT_CODE, method));
    }
    function formsPage() {
      const routes = FORM_CATALOG.map(([i, name, p, notes]) => [i, name, notes, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => go(p), "primary")]);
      return stack(pane2("\u0411\u043B\u0430\u043D\u043A\u0438 \u0438 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438", msg("13 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0439 \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u0430 \u0441\u0432\u044F\u0437\u0430\u043D\u044B \u0441 \u0440\u0430\u0431\u043E\u0447\u0438\u043C\u0438 \u0440\u0430\u0437\u0434\u0435\u043B\u0430\u043C\u0438. \u041E\u0446\u0435\u043D\u043A\u0438 \u0438 \u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0437 \u043F\u0440\u0438\u043C\u0435\u0440\u043E\u0432 \u043D\u0435 \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u044B. \u041D\u043E\u0432\u044B\u0435 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0438 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u043E\u0432 \u0437\u0430\u0433\u0440\u0443\u0436\u0430\u0439\u0442\u0435 \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0440\u0430\u0437\u0434\u0435\u043B\u0430\u0445."), tableOf2(["\u2116 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F", "\u0424\u043E\u0440\u043C\u0430", "\u041F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435", ""], routes)), pane2("\u0412\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u044B\u0435 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u044B", ...[["\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F", BUILTIN_SOP], ["\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \u0441\u0442\u0430\u0436\u0451\u0440\u0430", BUILTIN_PRACTICAL], ["\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430", BUILTIN_SELF], ["\u0410\u0443\u0434\u0438\u0442 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F", auditPayload()]].map(([label, p]) => {
        const d = el2("details");
        d.append(el2("summary", label + " \xB7 " + p.criteria.length + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432"), tableOf2(["\u2116", "\u0420\u0430\u0437\u0434\u0435\u043B", "\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0439"], p.criteria.map((q) => [q.code, q.section || "\u2014", q.question])), btn2("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u0443\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 JSON", () => run2(async () => {
          const payload = { ...p };
          if (p.format === "lean-audit-checklist-v1") payload.source_sha256 = await sha256(canonical(payload.criteria));
          downloadBytes2("\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430-" + p.format + ".json", new TextEncoder().encode(JSON.stringify(payload, null, 2)));
          return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
        }, { save: false })));
        return d;
      })));
    }
    let content;
    if (page2 === "twi" || page2 === "instruction" || page2 === "practical") {
      const a = route.id ? asgns().find((x) => x.id === route.id) : null;
      if (a) content = assignmentCard(a);
      else if (route.mode === "new" && page2 === "twi") content = assignmentForm();
      else if (page2 === "practical") content = stack(pane2("\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043E\u0446\u0435\u043D\u043A\u0438 \u0438 \u0434\u043E\u043F\u0443\u0441\u043A\u0438", msg("\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0434\u043B\u044F \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438, \u0443\u0440\u043E\u0432\u043D\u044F, \u041E\u0422, \u0442\u0435\u043E\u0440\u0438\u0438 \u0438 \u0440\u0435\u0448\u0435\u043D\u0438\u044F."), table2(["\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", "\u0421\u041E\u041F", "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430", "\u041A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u044F", "\u0414\u043E\u043F\u0443\u0441\u043A", ""], asgns().map((a2) => {
        const x = evidenceSummary(a2);
        return [n("person", a2.trainee_id), revLabel(a2.sop_revision_id), x.p ? conclusions[x.p.conclusion] : "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E", x.q ? "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430" : "\u041D\u0435\u0442", x.ad.status, btn2("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goLocal({ id: a2.id, tab: "practice" }), "primary")];
      }))), methodsPanel());
      else content = assignmentList();
    } else if (page2 === "programs" || page2 === "internship") {
      const n2 = route.enrollmentId && one(db, "SELECT * FROM training_enrollment WHERE id=?", [route.enrollmentId]), p = route.programId && one(db, "SELECT * FROM training_program WHERE id=?", [route.programId]);
      content = n2 ? enrollmentCard(n2) : p ? programCard(p) : route.mode === "program" ? programForm() : registryPrograms();
    } else if (page2 === "mentoring") content = mentorPage();
    else if (page2 === "certification") content = certificatePage();
    else if (page2 === "appointments") content = appointmentPage();
    else if (page2 === "skills") content = matrixPage();
    else if (page2 === "journal") content = journalPage();
    else if (page2 === "retraining") content = retrainingPage();
    else if (page2 === "development") content = developmentPage();
    else if (page2 === "my_plan") content = myPlan();
    else if (page2 === "forms") content = formsPage();
    else if (page2 === "self_eval") content = selfPage();
    else if (page2 === "audit") content = auditPage();
    if (content) {
      main.append(content);
      main.dataset.lc4Page = page2;
    }
  }

  // src/modules/library/frv-summary.js
  var positive = (v) => typeof v === "number" && Number.isFinite(v) && v > 0;
  var mean = (a) => a.length ? a.reduce((s, n) => s + n, 0) / a.length : null;
  var median = (a) => {
    const v = a.slice().sort((x, y) => x - y);
    return v.length % 2 ? v[v.length >> 1] : (v[v.length / 2 - 1] + v[v.length / 2]) / 2;
  };
  var clean = (x, max2 = 2e4) => typeof x === "string" ? x.trim().slice(0, max2) : "";
  function frvSummary(raw) {
    const totals = { VA: 0, NVA_Necessary: 0, NVA_Waste: 0, WAIT: 0, BREAK: 0, OTHER: 0 }, cycles = [];
    let missing = 0;
    for (const [i, c] of raw.cycles.entries()) {
      let seconds = 0, complete = c.observations.length > 0, measured = 0;
      for (const o of c.observations) {
        if (!positive(o.durationSec) || !clean(o.actionRaw)) {
          missing++;
          complete = false;
          continue;
        }
        seconds += o.durationSec;
        measured++;
        totals[Object.hasOwn(totals, o.valueType) ? o.valueType : "OTHER"] += o.durationSec;
      }
      cycles.push({ index: i + 1, phase: ["baseline", "improved"].includes(c.phase) ? c.phase : "unassigned", seconds: measured ? seconds : null, complete });
    }
    const a = cycles.filter((c) => c.complete && c.phase === "baseline").map((c) => c.seconds), b = cycles.filter((c) => c.complete && c.phase === "improved").map((c) => c.seconds);
    const before = mean(a), after = mean(b), comparable = raw.comparisonApproved === true && before !== null && after !== null;
    return { totals, cycles, missing, baselineCount: a.length, improvedCount: b.length, before, after, comparable, delta: comparable ? before - after : null, percent: comparable && before > 0 ? (before - after) / before * 100 : null };
  }
  async function draftFromFrv(text4) {
    const raw = JSON.parse(text4);
    await inspectSource(text4, "frv");
    const candidate = raw.standard;
    invariant(candidate && !candidate.outdated && Array.isArray(candidate.steps) && candidate.steps.length > 0 && candidate.steps.length <= 12, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u044C\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0439 \u043F\u0440\u043E\u0435\u043A\u0442 \u0421\u041E\u041F \u0438\u0437 \u0437\u0430\u043C\u0435\u0440\u043E\u0432 \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435 \u0424\u0420\u0412 (\u043D\u0435 \u0431\u043E\u043B\u0435\u0435 12 \u0448\u0430\u0433\u043E\u0432)");
    const ids = /* @__PURE__ */ new Map();
    for (const [i, c] of raw.cycles.entries()) for (const o of c.observations) ids.set(o.id, { o, cycle: c.cycleNo || i + 1 });
    const used = /* @__PURE__ */ new Set(), steps = candidate.steps.map((s, i) => {
      invariant(clean(s.action) && positive(s.plannedTimeSec) && Array.isArray(s.sourceObservationIds) && s.sourceObservationIds.length, "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435, \u043F\u0440\u043E\u0435\u043A\u0442\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u0438 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F \u0448\u0430\u0433\u0430 " + (i + 1));
      const found = s.sourceObservationIds.map((id) => {
        const x = ids.get(id);
        invariant(x && positive(x.o.durationSec) && clean(x.o.actionRaw) && x.o.standardCandidate === true && !used.has(id), "\u0428\u0430\u0433 " + (i + 1) + ": \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0437\u0430\u043C\u0435\u0440 \u0438\u043B\u0438 \u043E\u043D \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0435\u0442\u0441\u044F");
        used.add(id);
        return x;
      });
      const observed = median(found.map((x) => x.o.durationSec)), duration = Math.max(1, Math.round(s.plannedTimeSec)), km = [clean(s.keyMoment), s.safety ? "\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u044C: " + clean(s.safety) : ""].filter(Boolean);
      return { id: i + 1, action: clean(s.action), keyMoments: km.length ? km : [""], reason: clean(s.reason), durationSeconds: duration, hasPhoto: false, photoAnnotations: [], frv: { vdc: s.valueType === "VA", m2: s.valueType === "NVA_Necessary" ? duration : "", m1: s.valueType === "NVA_Waste" ? duration : "", move: s.distanceM ?? "", comment: clean(s.comment), autoFullStep: ["NVA_Necessary", "NVA_Waste"].includes(s.valueType) }, frvSource: { studyId: raw.study.studyId || "", libraryId: raw.study.libraryId || "", observationIds: s.sourceObservationIds.slice(), observationId: s.sourceObservationIds[0], cycleNos: found.map((x) => x.cycle), cycleNo: found[0].cycle, observedTimeSec: observed, projectTimeSec: s.plannedTimeSec } };
    });
    const payload = { schemaVersion: 2, document: { id: uuid(), status: "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A", number: "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A", version: 1 }, constructor: { schemaVersion: 4, meta: { branch: "", date: "", department: "", workplace: clean(raw.study.workplace), executor: clean(raw.study.operator), operation: clean(raw.study.operationId) || clean(raw.study.processDescription) || "\u041F\u0440\u043E\u0435\u043A\u0442 \u0421\u041E\u041F \u043F\u043E \u0424\u0420\u0412", sopNumber: "", safety: "", tools: "", material: "", approverPost: "", approverName: "" }, steps, description: clean(raw.study.processDescription), responsibles: [""], agreedList: [{ post: "", name: "" }], totalTimeSeconds: steps.reduce((s, x) => s + x.durationSeconds, 0), twi: { enabled: false } }, photoAssets: {} };
    const result = JSON.stringify({ ...payload, integrity: { algorithm: "SHA-256", sha256: await sha256(JSON.stringify(payload)) } }, null, 2);
    return { text: result, ...await inspectSource(result, "sop") };
  }

  // src/storage/local.js
  async function openCache() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open("lean-center-lc1", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("kv");
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  function load(cache2, key3) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readonly"), r = t.objectStore("kv").get(key3);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  function save(cache2, key3, value) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readwrite");
      t.objectStore("kv").put(value, key3);
      t.oncomplete = resolve;
      t.onabort = () => reject(t.error || new Error("\u0417\u0430\u043F\u0438\u0441\u044C \u043F\u0440\u0435\u0440\u0432\u0430\u043D\u0430"));
      t.onerror = () => reject(t.error);
    });
  }
  function saveWorkspace(cache2, expected, value) {
    return new Promise((resolve, reject) => {
      const t = cache2.transaction("kv", "readwrite"), s = t.objectStore("kv"), r = s.get("workspace");
      let reason;
      const next = expected + 1;
      r.onsuccess = () => {
        if ((r.result?.generation || 0) !== expected) {
          reason = new Error("\u0414\u0440\u0443\u0433\u0430\u044F \u0432\u043A\u043B\u0430\u0434\u043A\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430 \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E. \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443.");
          t.abort();
          return;
        }
        s.put({ generation: next, state: value }, "workspace");
      };
      t.oncomplete = () => resolve(next);
      t.onabort = () => reject(reason || t.error || new Error("\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430"));
      t.onerror = () => reject(t.error);
    });
  }

  // src/storage/network.js
  var textBytes = (s) => new TextEncoder().encode(s);
  async function chooseFolder() {
    invariant(window.showDirectoryPicker, "\u0412\u044B\u0431\u043E\u0440 \u043F\u0430\u043F\u043A\u0438 \u0437\u0430\u043F\u0440\u0435\u0449\u0451\u043D \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u043E\u043C. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0440\u0443\u0447\u043D\u043E\u0439 \u0438\u043C\u043F\u043E\u0440\u0442 \u0438 \u044D\u043A\u0441\u043F\u043E\u0440\u0442.");
    return window.showDirectoryPicker({ id: "lean-center-network", mode: "readwrite" });
  }
  async function permission(h, request = false) {
    if (!h) return false;
    let p = await h.queryPermission({ mode: "readwrite" });
    if (p !== "granted" && request) p = await h.requestPermission({ mode: "readwrite" });
    return p === "granted";
  }
  async function sub(h, name, create = false) {
    return h.getDirectoryHandle(name, { create });
  }
  async function readFile(dir, name, max2 = MAX_DB) {
    const f = await (await dir.getFileHandle(name)).getFile();
    invariant(f.size <= max2, "\u0424\u0430\u0439\u043B \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043B\u0438\u043C\u0438\u0442: " + name);
    return new Uint8Array(await f.arrayBuffer());
  }
  async function writeNew(dir, name, data) {
    try {
      await dir.getFileHandle(name);
      throw new Error("\u0424\u0430\u0439\u043B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442: " + name);
    } catch (e) {
      if (e.name !== "NotFoundError") throw e;
    }
    const f = await dir.getFileHandle(name, { create: true }), w = await f.createWritable();
    try {
      await w.write(data);
      await w.close();
    } catch (e) {
      try {
        await w.abort();
      } catch {
      }
      throw e;
    }
    const expected = typeof data === "string" ? textBytes(data) : data;
    const back = await readFile(dir, name, Math.max(MAX_DB, expected.length));
    invariant(await sha256(back) === await sha256(expected), "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u043F\u0440\u043E\u0448\u043B\u0430 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C SHA-256: " + name);
  }
  async function testFolder(h) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043D\u0430 \u0437\u0430\u043F\u0438\u0441\u044C");
    const name = ".lean-test-" + uuid() + ".txt";
    await writeNew(h, name, "LEAN CENTER / TEST");
    await h.removeEntry(name);
    return true;
  }
  async function readContent(h, ref) {
    validateRef(ref);
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u043C \u0444\u0430\u0439\u043B\u0430\u043C");
    const d = await sub(h, "Documents"), bytes = await readFile(d, ref.sha256 + ".json", ref.size);
    return checkContent(ref, new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  }
  async function ensureContent(h, ref, read) {
    validateRef(ref);
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const d = await sub(h, "Documents", true), name = ref.sha256 + ".json";
    let exists = true;
    try {
      await d.getFileHandle(name);
    } catch (e) {
      if (e.name !== "NotFoundError") throw e;
      exists = false;
    }
    if (exists) {
      await readContent(h, ref);
      return;
    }
    invariant(typeof read === "function", "\u041D\u0435\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 " + ref.sha256);
    const text4 = await checkContent(ref, await read(ref));
    try {
      await writeNew(d, name, text4);
    } catch (e) {
      if (!String(e.message).startsWith("\u0424\u0430\u0439\u043B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442:")) throw e;
    }
    await readContent(h, ref);
  }
  async function sendPackage(h, p, read) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    for (const ref of refsForEvents(p.events)) await ensureContent(h, ref, read);
    const d = await sub(h, "Exchange", true);
    await writeNew(d, "change-" + p.id + ".leanpkg", canonical(p));
  }
  async function listPackages(h) {
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    let d;
    try {
      d = await sub(h, "Exchange");
    } catch (e) {
      if (e.name === "NotFoundError") return [];
      throw e;
    }
    const result = [];
    for await (const [name, entry] of d.entries()) {
      if (entry.kind !== "file" || !/^change-[0-9a-f-]+\.leanpkg$/i.test(name)) continue;
      try {
        const p = JSON.parse(new TextDecoder().decode(await readFile(d, name, MAX_PACKAGE)));
        invariant(name === "change-" + p.id + ".leanpkg", "\u0418\u043C\u044F \u043F\u0430\u043A\u0435\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 ID");
        result.push({ name, p });
      } catch (e) {
        result.push({ name, error: e.message });
      }
    }
    return result.sort((a, b) => (a.p?.created_at || "").localeCompare(b.p?.created_at || ""));
  }
  async function latestSnapshot(h, SQL2, databaseId = null) {
    invariant(await permission(h, false), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    let d;
    try {
      d = await sub(h, "Database");
    } catch (e) {
      if (e.name === "NotFoundError") return null;
      throw e;
    }
    const manifests = [];
    for await (const [name, entry] of d.entries()) {
      if (entry.kind !== "file" || !/^publication-[0-9a-f-]+\.json$/i.test(name)) continue;
      const m = JSON.parse(new TextDecoder().decode(await readFile(d, name, 65536)));
      invariant(name === "publication-" + m.id + ".json", "\u0418\u043C\u044F \u043C\u0430\u043D\u0438\u0444\u0435\u0441\u0442\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442");
      if (!databaseId || m.database_id === databaseId) manifests.push(m);
    }
    if (!manifests.length) return null;
    invariant(new Set(manifests.map((m) => m.database_id)).size === 1, "\u0412 \u043F\u0430\u043F\u043A\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0431\u0430\u0437. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0439.");
    const ids = new Set(manifests.map((m) => m.id)), parents = new Set(manifests.map((m) => m.parent_id));
    const heads = manifests.filter((m) => !parents.has(m.id));
    invariant(heads.length === 1, "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u044B \u043F\u0430\u0440\u0430\u043B\u043B\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0430\u0437\u0431\u043E\u0440");
    const head = heads[0];
    const seen = /* @__PURE__ */ new Set();
    let node2 = head;
    while (node2) {
      invariant(!seen.has(node2.id), "\u0426\u0438\u043A\u043B \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
      seen.add(node2.id);
      node2 = node2.parent_id ? manifests.find((m) => m.id === node2.parent_id) : null;
    }
    invariant(seen.size === ids.size, "\u0420\u0430\u0437\u043E\u0440\u0432\u0430\u043D\u0430 \u0446\u0435\u043F\u043E\u0447\u043A\u0430 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439");
    const bytes = await readFile(d, "snapshot-" + head.id + ".sqlite");
    const db = await readSnapshot(SQL2, head, bytes);
    return { manifest: head, db, bytes };
  }
  async function publishSnapshot(h, SQL2, snapshot, read) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const current = await latestSnapshot(h, SQL2);
    try {
      invariant(!current ? snapshot.manifest.parent_id === null : current.manifest.database_id === snapshot.manifest.database_id && current.manifest.id === snapshot.manifest.parent_id, "\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u0431\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u044D\u0442\u043E \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0435\u0451.");
    } finally {
      current?.db.close();
    }
    const checked = await readSnapshot(SQL2, snapshot.manifest, snapshot.bytes);
    try {
      for (const ref of refsForDb(checked)) await ensureContent(h, ref, read);
    } finally {
      checked.close();
    }
    const d = await sub(h, "Database", true);
    await writeNew(d, "snapshot-" + snapshot.manifest.id + ".sqlite", snapshot.bytes);
    await writeNew(d, "publication-" + snapshot.manifest.id + ".json", canonical(snapshot.manifest));
    const verified = await latestSnapshot(h, SQL2, snapshot.manifest.database_id);
    try {
      invariant(verified?.manifest.id === snapshot.manifest.id, "\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430");
    } finally {
      verified?.db.close();
    }
  }
  async function saveBackup(h, obj2) {
    invariant(await permission(h, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0430\u043F\u043A\u0435");
    const d = await sub(h, "Backups", true);
    await writeNew(d, "backup-" + uuid() + ".leanbackup", canonical(obj2));
  }

  // src/modules/library/content.js
  var MAX_TRANSFER = 150 * 1024 * 1024;
  var key2 = (r) => "content:" + r.sha256;
  var ContentStore = class {
    constructor(getCache, getFolder) {
      this.getCache = getCache;
      this.getFolder = getFolder;
      this.memory = /* @__PURE__ */ new Map();
    }
    async put(ref, text4) {
      await checkContent(ref, text4);
      const cache2 = this.getCache();
      if (cache2) {
        const old = await load(cache2, key2(ref));
        if (old !== void 0) {
          await checkContent(ref, old);
          return old;
        }
        await save(cache2, key2(ref), text4);
        return text4;
      }
      const total = [...this.memory.values()].reduce((n, x) => n + x.length * 2, 0);
      invariant(this.memory.has(ref.sha256) || total + text4.length * 2 <= MAX_TRANSFER, "\u041B\u0438\u043C\u0438\u0442 \u043F\u0430\u043C\u044F\u0442\u0438 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432; \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u044D\u0448 \u0438\u043B\u0438 \u0441\u0435\u0442\u0435\u0432\u0443\u044E \u043F\u0430\u043F\u043A\u0443");
      this.memory.set(ref.sha256, text4);
      return text4;
    }
    async get(ref, { network = true } = {}) {
      validateRef(ref);
      const cache2 = this.getCache(), v = cache2 ? await load(cache2, key2(ref)) : this.memory.get(ref.sha256);
      if (v !== void 0) return checkContent(ref, v);
      const h = this.getFolder();
      invariant(network && h, "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043D\u0435 \u0432 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u043C \u043A\u044D\u0448\u0435. \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043E\u0431\u0449\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u043F\u043E\u043B\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.");
      const text4 = await readContent(h, ref);
      return this.put(ref, text4);
    }
  };
  async function makeTransfer(kind, payload, refs, read) {
    refs = unionRefs(refs);
    if (!refs.length) return payload;
    let size = new TextEncoder().encode(canonical(payload)).length;
    const contents = [];
    for (const ref of refs) {
      const text4 = await checkContent(ref, await read(ref));
      size += new TextEncoder().encode(JSON.stringify(text4)).length + 256;
      invariant(size <= MAX_TRANSFER - 65536, "\u041F\u043E\u043B\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 150 \u041C\u0411; \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0441\u0435\u0442\u0435\u0432\u043E\u0435 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u0441 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u043C \u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435\u043C");
      contents.push({ ref, text: text4 });
    }
    return { format: "lean-content-bundle-v1", kind, payload, contents };
  }
  function unpackTransfer(value, kind) {
    if (value?.format !== "lean-content-bundle-v1") return { payload: value, contents: [] };
    invariant(value.kind === kind && Array.isArray(value.contents) && value.contents.length <= 1e4 && Object.hasOwn(value, "payload"), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432");
    return { payload: value.payload, contents: value.contents };
  }
  async function restoreContents(contents, refs, put) {
    refs = unionRefs(refs);
    const expected = new Map(refs.map((r) => [r.sha256, r]));
    invariant(contents.length === expected.size, "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C " + expected.size + ", \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E " + contents.length);
    const seen = /* @__PURE__ */ new Set();
    for (const item2 of contents) {
      invariant(item2 && typeof item2 === "object" && Object.keys(item2).length === 2, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u044D\u043B\u0435\u043C\u0435\u043D\u0442 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442\u0430");
      const ref = validateRef(item2.ref), match = expected.get(ref.sha256);
      invariant(match && canonical(match) === canonical(ref) && !seen.has(ref.sha256), "\u041B\u0438\u0448\u043D\u0438\u0439, \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u044B\u0439 \u0438\u043B\u0438 \u043D\u0435\u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u0439\u043B");
      seen.add(ref.sha256);
      await checkContent(ref, item2.text);
    }
    for (const item2 of contents) await put(item2.ref, item2.text);
  }

  // src/modules/master-data/import-xlsx.js
  var MAX_ROWS = 1e3;
  var MAX_COLUMNS = 100;
  var MAX_XLSX = 20 * 1024 * 1024;
  var MAX_EXPANDED = 100 * 1024 * 1024;
  var normalized = (s) => foldKey(s).replace(/[^\p{L}\p{N}]+/gu, "");
  function fieldLabel(type, key3) {
    const f = definitions[type].fields[key3];
    if (f.ref) {
      if (f.ref === "person") return "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430";
      if (f.ref === "skill_category") return "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438";
      if (f.ref === "equipment") return "\u041A\u043E\u0434 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F";
      if (f.ref === "operation") return "\u041A\u043E\u0434 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 (\u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435/\u043A\u043E\u0434)";
      return "\u041A\u043E\u0434 " + { org_unit: key3 === "parent_id" ? "\u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u043E\u0433\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F" : "\u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F", profession: "\u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438", position: "\u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438", work_shift: "\u0441\u043C\u0435\u043D\u044B", business_role: "\u0440\u043E\u043B\u0438", workplace: "\u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u043C\u0435\u0441\u0442\u0430" }[f.ref];
    }
    return f.label;
  }
  function importFields(type) {
    return Object.entries(definitions[type].fields).filter(([, f]) => !f.legacy);
  }
  function autoMap(type, headers) {
    const result = {};
    const used = /* @__PURE__ */ new Set();
    for (const [key3, f] of importFields(type)) {
      const aliases2 = [key3, fieldLabel(type, key3), f.label];
      if (key3 === "display_name") aliases2.push("\u0424\u0418\u041E", "\u0424\u0430\u043C\u0438\u043B\u0438\u044F \u0418\u043C\u044F \u041E\u0442\u0447\u0435\u0441\u0442\u0432\u043E", "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A");
      if (key3 === "employee_code") aliases2.push("\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439", "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u2116", "\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440");
      if (key3 === "name") aliases2.push("\u041D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435");
      const exact5 = headers.filter((h) => !used.has(h.col) && aliases2.some((a) => normalized(a) === normalized(h.name)));
      if (exact5.length === 1) {
        result[key3] = exact5[0].col;
        used.add(exact5[0].col);
      }
    }
    return result;
  }
  function checkXlsxContainer(buffer) {
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    invariant(bytes.length >= 22 && bytes.length <= MAX_XLSX, "XLSX \u0434\u043E 20 \u041C\u0411");
    const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let end = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
      if (v.getUint32(i, true) === 101010256 && i + 22 + v.getUint16(i + 20, true) === bytes.length) {
        end = i;
        break;
      }
    }
    invariant(end >= 0, "\u0424\u0430\u0439\u043B \u043D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043E\u0431\u044B\u0447\u043D\u044B\u043C XLSX (ZIP)");
    invariant(v.getUint16(end + 4, true) === 0 && v.getUint16(end + 6, true) === 0, "\u041C\u043D\u043E\u0433\u043E\u0442\u043E\u043C\u043D\u044B\u0439 ZIP \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F");
    const n = v.getUint16(end + 10, true), size = v.getUint32(end + 12, true), start = v.getUint32(end + 16, true);
    invariant(n === v.getUint16(end + 8, true) && n > 0 && n <= 2e3 && start + size === end, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043A\u0430\u0442\u0430\u043B\u043E\u0433 XLSX");
    let p = start, total = 0;
    const names3 = /* @__PURE__ */ new Set();
    for (let i = 0; i < n; i++) {
      invariant(p + 46 <= end && v.getUint32(p, true) === 33639248, "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u043A\u0430\u0442\u0430\u043B\u043E\u0433 XLSX");
      const flags = v.getUint16(p + 8, true), method = v.getUint16(p + 10, true), uncompressed = v.getUint32(p + 24, true), len = v.getUint16(p + 28, true), extra = v.getUint16(p + 30, true), comment = v.getUint16(p + 32, true);
      invariant(!(flags & 1) && [0, 8].includes(method) && p + 46 + len + extra + comment <= end, "\u041D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0439 ZIP");
      const name = new TextDecoder().decode(bytes.subarray(p + 46, p + 46 + len));
      invariant(!names3.has(name) && !name.split("/").includes(".."), "\u041F\u043E\u0432\u0442\u043E\u0440 \u0438\u043B\u0438 \u043D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u043F\u0443\u0442\u044C \u0432 ZIP");
      names3.add(name);
      total += uncompressed;
      invariant(total <= MAX_EXPANDED, "\u0420\u0430\u0441\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0439 XLSX \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 100 \u041C\u0411");
      p += 46 + len + extra + comment;
    }
    invariant(p === end && names3.has("[Content_Types].xml") && names3.has("xl/workbook.xml"), "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 XLSX");
    invariant(![...names3].some((n2) => /vbaProject\.bin|externalLinks\//i.test(n2)), "\u0424\u0430\u0439\u043B\u044B \u0441 \u043C\u0430\u043A\u0440\u043E\u0441\u0430\u043C\u0438 \u0438\u043B\u0438 \u0432\u043D\u0435\u0448\u043D\u0438\u043C\u0438 \u0441\u0432\u044F\u0437\u044F\u043C\u0438 \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044E\u0442\u0441\u044F");
  }
  async function loadWorkbook(ExcelJS2, buffer) {
    invariant(ExcelJS2?.Workbook, "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 ExcelJS \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430");
    checkXlsxContainer(buffer);
    const book = new ExcelJS2.Workbook();
    await book.xlsx.load(buffer);
    invariant(book.worksheets.length > 0 && book.worksheets.length <= 50, "\u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u043E\u0442 1 \u0434\u043E 50 \u043B\u0438\u0441\u0442\u043E\u0432");
    return book;
  }
  function sheetHeaders(sheet2, row = 1) {
    invariant(Number.isInteger(row) && row >= 1 && row <= 20, "\u0421\u0442\u0440\u043E\u043A\u0430 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u043E\u0432: 1\u201320");
    invariant(sheet2.columnCount <= MAX_COLUMNS, "\u041B\u0438\u0441\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0431\u043E\u043B\u0435\u0435 100 \u043A\u043E\u043B\u043E\u043D\u043E\u043A");
    const r = sheet2.getRow(row), out = [];
    for (let col = 1; col <= sheet2.columnCount; col++) {
      const name = r.getCell(col).text.trim();
      out.push({ col, name: name || "\u041A\u043E\u043B\u043E\u043D\u043A\u0430 " + col });
    }
    return out;
  }
  function sheetRows(sheet2, headerRow, mapping) {
    invariant(sheet2.rowCount - headerRow <= MAX_ROWS, "\u0412 \u043E\u0434\u043D\u043E\u043C \u0438\u043C\u043F\u043E\u0440\u0442\u0435 \u043D\u0435 \u0431\u043E\u043B\u0435\u0435 " + MAX_ROWS + " \u0441\u0442\u0440\u043E\u043A; \u0440\u0430\u0437\u0434\u0435\u043B\u0438\u0442\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u0443");
    const out = [];
    for (let n = headerRow + 1; n <= sheet2.rowCount; n++) {
      const row = sheet2.getRow(n), values = {};
      for (const [key3, col] of Object.entries(mapping)) if (col) values[key3] = row.getCell(col).value;
      if (Object.values(values).some((v) => v !== null && v !== void 0 && v !== "")) out.push({ row: n, values });
    }
    return out;
  }
  function cellText(v, f, key3) {
    if (v === null || v === void 0 || v === "") return null;
    if (v instanceof Date) {
      invariant(f.date && !isNaN(v.getTime()), "\u0414\u0430\u0442\u0430 \u0432 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u043E\u0439 \u043A\u043E\u043B\u043E\u043D\u043A\u0435");
      return v.toISOString().slice(0, 10);
    }
    if (typeof v === "object") {
      if (Array.isArray(v.richText)) v = v.richText.map((t) => t.text).join("");
      else throw Error("\u0424\u043E\u0440\u043C\u0443\u043B\u044B, \u043E\u0448\u0438\u0431\u043A\u0438 \u0438 \u0441\u0441\u044B\u043B\u043A\u0438 \u043D\u0435 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u044E\u0442\u0441\u044F; \u0432\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F");
    }
    if (typeof v === "number") {
      invariant(f.integer, "\u041A\u043E\u0434\u044B \u0438 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0442\u0435\u043A\u0441\u0442\u043E\u043C \u0432 Excel (\u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0432\u0435\u0434\u0443\u0449\u0438\u0435 \u043D\u0443\u043B\u0438)");
      v = String(v);
    }
    invariant(typeof v === "string", "\u041D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0439 \u0442\u0438\u043F \u044F\u0447\u0435\u0439\u043A\u0438");
    v = v.trim();
    if (!v) return null;
    if (key3 === "criticality") v = { "\u043E\u0431\u044B\u0447\u043D\u0430\u044F": "normal", "\u0432\u0430\u0436\u043D\u0430\u044F": "important", "\u043A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F": "critical" }[foldKey(v)] || v;
    if (f.date) {
      const m = v.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
      if (m) v = m[3] + "-" + m[2] + "-" + m[1];
    }
    return v;
  }
  function findRef(db, ref, value, unitId) {
    if (!value) return null;
    let matches = list(db, ref).filter((x) => !x.archived);
    if (["equipment", "operation", "workplace"].includes(ref)) {
      let code = value, unit = unitId;
      const split = value.indexOf("/");
      if (split >= 0) {
        const u = value.slice(0, split);
        const found = list(db, "org_unit").filter((x) => !x.archived && foldKey(x.code) === foldKey(u));
        invariant(found.length === 1, "\u041D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0439/\u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u043A\u043E\u0434 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F: " + u);
        unit = found[0].id;
        code = value.slice(split + 1);
      }
      matches = matches.filter((x) => (!unit || x.unit_id === unit) && foldKey(x.code) === foldKey(code));
    } else matches = matches.filter((x) => foldKey(ref === "person" ? x.employee_code : ref === "skill_category" ? x.name : x.code) === foldKey(value));
    invariant(matches.length === 1, "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430 \u0438\u043B\u0438 \u043D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u0430 \u0441\u0441\u044B\u043B\u043A\u0430: " + definitions[ref].label + " / " + value);
    return matches[0].id;
  }
  function workspaceToken(ws2) {
    return canonical({ database: meta(ws2.base, "database_id"), publication: meta(ws2.base, "publication_id"), count: one(ws2.base, "SELECT count(*) n FROM change_event").n, pending: ws2.pending.map((e) => e.id), dirty: ws2.dirty });
  }
  function previewValue(db, f, value) {
    if (value == null) return null;
    if (!f.ref) return value;
    const v = one(db, "SELECT * FROM " + f.ref + " WHERE id=?", [value]);
    if (!v) return value;
    return (v.employee_code || v.code ? (v.employee_code || v.code) + " \u2014 " : "") + (v.display_name || v.name || value);
  }
  var statusLabels = { create: "\u0421\u043E\u0437\u0434\u0430\u0442\u044C", update: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C", same: "\u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", error: "\u041E\u0448\u0438\u0431\u043A\u0430" };
  function planImport(ws2, type, source, { allowUpdates = false } = {}) {
    invariant(Object.hasOwn(definitions, type), "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A");
    invariant(!ws2.conflicts.length, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B");
    invariant(Array.isArray(source) && source.length > 0 && source.length <= MAX_ROWS, "\u041D\u0435\u0442 \u0441\u0442\u0440\u043E\u043A \u0438\u043B\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 1000");
    const d = definitions[type], db = openDb(ws2.SQL, bytesOf(ws2.working)), results = [], events = [], seen = /* @__PURE__ */ new Map();
    try {
      const parsed = source.map((item2) => {
        try {
          const v = {};
          for (const [k, raw] of Object.entries(item2.values)) {
            invariant(Object.hasOwn(d.fields, k) && !d.fields[k].legacy, "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u043A\u043E\u043B\u043E\u043D\u043A\u0430 " + k);
            v[k] = cellText(raw, d.fields[k], k);
          }
          return { row: item2.row, v };
        } catch (e) {
          return { row: item2.row, error: e.message };
        }
      });
      if (type === "org_unit") {
        const remaining = parsed.slice(), ordered = [], known = new Set(list(db, type).map((x) => foldKey(x.code)));
        while (remaining.length) {
          const i = remaining.findIndex((x2) => x2.error || !x2.v.parent_id || known.has(foldKey(x2.v.parent_id)) || !remaining.some((y) => y.v && foldKey(y.v.code) === foldKey(x2.v.parent_id)));
          if (i < 0) {
            for (const x2 of remaining) ordered.push({ ...x2, error: "\u0426\u0438\u043A\u043B \u0438\u043B\u0438 \u043D\u0435\u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u0430\u044F \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u044C \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0439" });
            break;
          }
          const [x] = remaining.splice(i, 1);
          ordered.push(x);
          if (x.v?.code) known.add(foldKey(x.v.code));
        }
        parsed.splice(0, parsed.length, ...ordered);
      }
      for (const item2 of parsed) {
        const result = { row: item2.row, status: "error", message: "", changes: [] };
        results.push(result);
        if (item2.error) {
          result.message = item2.error;
          continue;
        }
        try {
          const p = {};
          for (const [k, f] of Object.entries(d.fields)) {
            if (!Object.hasOwn(item2.v, k)) {
              p[k] = null;
              continue;
            }
            p[k] = f.ref ? findRef(db, f.ref, item2.v[k], p.unit_id) : item2.v[k];
          }
          const keys = type === "person" ? ["employee_code"] : type === "person_assignment" ? ["person_id", "valid_from"] : type === "role_assignment" ? ["person_id", "role_id", "valid_from"] : type === "skill_category" ? ["name"] : type === "skill" ? ["category_id", "name"] : type === "rating_scale" ? ["name", "version_no"] : ["equipment", "operation", "workplace"].includes(type) ? ["unit_id", "code"] : ["code"];
          invariant(keys.every((k) => p[k] != null), "\u041D\u0435 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D \u043A\u043B\u044E\u0447: " + keys.map((k) => fieldLabel(type, k)).join(", "));
          const key3 = identityKey(type, p);
          if (seen.has(key3)) {
            const previous = seen.get(key3);
            previous.status = "error";
            previous.message = "\u0414\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u043A\u043B\u044E\u0447\u0430 \u0432 \u0444\u0430\u0439\u043B\u0435 (\u0441\u0442\u0440\u043E\u043A\u0430 " + item2.row + ")";
            throw Error("\u0414\u0443\u0431\u043B\u0438\u043A\u0430\u0442 \u043A\u043B\u044E\u0447\u0430 \u0432 \u0444\u0430\u0439\u043B\u0435 (\u0441\u0442\u0440\u043E\u043A\u0430 " + previous.row + ")");
          }
          seen.set(key3, result);
          const matches = list(db, type).filter((v) => identityKey(type, v) === key3);
          invariant(matches.length <= 1, "\u041D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 \u0431\u0430\u0437\u0435");
          const old = matches[0];
          invariant(!old?.archived, "\u041A\u043B\u044E\u0447 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0438\u0442 \u0430\u0440\u0445\u0438\u0432\u043D\u043E\u0439 \u0437\u0430\u043F\u0438\u0441\u0438; \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u043E");
          const oldPayload = old ? recordPayload(type, old) : null;
          if (old) {
            for (const k of Object.keys(d.fields)) if (!Object.hasOwn(item2.v, k)) p[k] = oldPayload[k];
          }
          if (type === "rating_scale" && p.levels) {
            p.levels = p.levels.split(/\r?\n/).filter((x) => x.trim()).map((x) => x.trim()).join("\n");
          }
          if (old && canonical(p) === canonical(oldPayload)) {
            result.status = "same";
            result.message = "\u0421\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0437\u0430\u043F\u0438\u0441\u044C\u044E \u0431\u0430\u0437\u044B";
            continue;
          }
          result.changes = Object.entries(p).filter(([k, v]) => !old || oldPayload[k] !== v).map(([k, v]) => ({ field: fieldLabel(type, k), before: previewValue(db, d.fields[k], oldPayload?.[k] ?? null), after: previewValue(db, d.fields[k], v) }));
          invariant(!old || allowUpdates, "\u041A\u043B\u044E\u0447 \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442, \u0434\u0430\u043D\u043D\u044B\u0435 \u043E\u0442\u043B\u0438\u0447\u0430\u044E\u0442\u0441\u044F. \u0412\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438.");
          const e = { id: uuid(), entity_type: type, entity_id: old?.id || uuid(), operation: old ? "update" : "create", expected_revision: old?.rev || 0, payload: p, occurred_at: now() };
          tx(db, () => applyEvent(db, e));
          events.push(e);
          result.status = e.operation;
          result.message = old ? "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0439 \u0437\u0430\u043F\u0438\u0441\u0438" : "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430 \u043D\u043E\u0432\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C";
        } catch (e) {
          result.message = e.message;
        }
      }
      results.sort((a, b) => a.row - b.row);
      const counts = Object.fromEntries(Object.keys(statusLabels).map((k) => [k, results.filter((x) => x.status === k).length]));
      return { type, token: workspaceToken(ws2), results, counts, events: counts.error ? [] : events };
    } finally {
      db.close();
    }
  }
  function commitImport(ws2, plan) {
    invariant(plan && plan.counts.error === 0 && plan.events.length > 0, "\u041D\u0435\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 \u0434\u043B\u044F \u0438\u043C\u043F\u043E\u0440\u0442\u0430");
    invariant(plan.token === workspaceToken(ws2), "\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C; \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u0441\u043D\u043E\u0432\u0430");
    return ws2.applyBatch(plan.events);
  }
  async function makeTemplate(ExcelJS2, type) {
    const book = new ExcelJS2.Workbook(), sheet2 = book.addWorksheet(definitions[type].label.slice(0, 31));
    sheet2.columns = importFields(type).map(([k, f]) => ({ header: fieldLabel(type, k), key: k, width: f.multiline ? 55 : f.ref ? 26 : 28, style: { numFmt: "@" } }));
    sheet2.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
    sheet2.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242E40" } };
    sheet2.views = [{ state: "frozen", ySplit: 1 }];
    const guide = book.addWorksheet("\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F");
    guide.getColumn(1).width = 100;
    for (const t of ["\u0417\u0430\u043F\u043E\u043B\u043D\u044F\u0439\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0435\u0440\u0432\u044B\u0439 \u043B\u0438\u0441\u0442. \u041D\u0435 \u043C\u0435\u043D\u044F\u0439\u0442\u0435 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u0438 \u0431\u0435\u0437 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F.", "\u041A\u043E\u0434\u044B \u0438 \u0442\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0435 \u043D\u043E\u043C\u0435\u0440\u0430 \u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u043A\u0430\u043A \u0442\u0435\u043A\u0441\u0442, \u0434\u0430\u0442\u044B \u2014 YYYY-MM-DD \u0438\u043B\u0438 \u0434\u0430\u0442\u044B Excel.", "\u0421\u0441\u044B\u043B\u043A\u0438: \u043A\u043E\u0434\u044B \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432. \u0414\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043C\u043E\u0436\u043D\u043E \u0443\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435/\u043A\u043E\u0434.", "\u0428\u043A\u0430\u043B\u0430: \u0443\u0440\u043E\u0432\u043D\u0438 \u0432 \u043E\u0434\u043D\u043E\u0439 \u044F\u0447\u0435\u0439\u043A\u0435, \u043A\u0430\u0436\u0434\u044B\u0439 \u0441 \u043D\u043E\u0432\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0438: 0: \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435.", "\u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043A\u043B\u044E\u0447\u0438 \u043D\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0431\u0435\u0437 \u044F\u0432\u043D\u043E\u0433\u043E \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F. \u0412\u0441\u0435 \u043E\u0448\u0438\u0431\u043A\u0438 \u0431\u043B\u043E\u043A\u0438\u0440\u0443\u044E\u0442 \u0438\u043C\u043F\u043E\u0440\u0442."]) guide.addRow([t]);
    return book.xlsx.writeBuffer();
  }

  // src/analytics/palette.js
  var labels = Object.freeze({
    actual: "\u0424\u0430\u043A\u0442",
    comparison: "\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435",
    compliant: "\u0421\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442",
    attention: "\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044F",
    risk: "\u0420\u0438\u0441\u043A / \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435",
    critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435",
    plan: "\u041F\u043B\u0430\u043D",
    not_assessed: "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E",
    not_applicable: "\u041D\u0435\u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E"
  });
  var palettes = {
    light: {
      surface: "#FFFFFF",
      text: "#5B626E",
      grid: "#DADDDF",
      actual: "#242E40",
      comparison: "#2563EB",
      compliant: "#27965A",
      attention: "#A17600",
      risk: "#C46708",
      critical: "#E30613",
      plan: "#85878C",
      unavailable: "#BFC0C0",
      unavailableOutline: "#686B71",
      categorical: ["#242E40", "#2563EB", "#687B98", "#79649A", "#476F83", "#65749E"]
    },
    dark: {
      surface: "#232B39",
      text: "#BDC6D3",
      grid: "#424E60",
      actual: "#A9BCD4",
      comparison: "#74A8FF",
      compliant: "#69CA90",
      attention: "#F0CE57",
      risk: "#FFAB62",
      critical: "#FF777F",
      plan: "#A6ADB8",
      unavailable: "#626E80",
      unavailableOutline: "#C0CAD7",
      categorical: ["#A9BCD4", "#74A8FF", "#91A7C7", "#C3A6E0", "#80C3D4", "#A5B4E8"]
    }
  };
  for (const p of Object.values(palettes)) {
    Object.freeze(p.categorical);
    Object.freeze(p);
  }
  Object.freeze(palettes);
  function analyticsPalette(dark = false) {
    return palettes[dark ? "dark" : "light"];
  }
  function registryCountChart(categories, counts, dark = false) {
    if (!Array.isArray(categories) || !Array.isArray(counts) || categories.length !== counts.length || counts.some((n) => !Number.isSafeInteger(n) || n < 0)) throw new TypeError("Invalid registry counts");
    const p = analyticsPalette(dark);
    return {
      backgroundColor: "transparent",
      animation: false,
      color: p.categorical.slice(),
      textStyle: { fontFamily: "Proxima Nova, Proxima Nova Rg, Arial, sans-serif" },
      aria: { enabled: true, description: "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439: " + categories.map((n, i) => n + " \u2014 " + counts[i]).join("; ") },
      tooltip: { trigger: "axis" },
      grid: { left: 24, right: 36, bottom: 8, top: 8, containLabel: true },
      xAxis: { type: "value", minInterval: 1, axisLabel: { color: p.text }, splitLine: { lineStyle: { color: p.grid } } },
      yAxis: { type: "category", inverse: true, data: categories.slice(), axisLabel: { color: p.text, fontSize: 11, width: 144, overflow: "truncate" }, axisLine: { show: false }, axisTick: { show: false } },
      series: [{ name: "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438", type: "bar", barMaxWidth: 20, data: counts.slice(), label: { show: true, position: "right", color: p.text }, itemStyle: { color: p.actual, borderRadius: [0, 2, 2, 0] } }]
    };
  }

  // src/app.js
  var root = document.getElementById("app");
  var SQL;
  var ws;
  var cache;
  var folder;
  var generation = 0;
  var busy = false;
  var master = false;
  var page = "home";
  var theme = false;
  var status = "\u0413\u043E\u0442\u043E\u0432\u043E";
  var error = false;
  var chart = null;
  var edit = null;
  var query = "";
  var incoming = [];
  var importState = null;
  var historyPerson = null;
  var archiveFilter = "active";
  var libraryDraft = null;
  var editorSession = null;
  var libraryFilter = "all";
  var contentStore = new ContentStore(() => cache, () => folder);
  var readContent2 = (ref) => contentStore.get(ref);
  var sourceRefs = () => unionRefs(refsForDb(ws.base), refsForEvents(ws.pending));
  var planned = { forms: "\u0411\u043B\u0430\u043D\u043A\u0438 \u0438 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438", sop: "\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u0421\u041E\u041F", sop_constructor: "\u041A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 \u0421\u041E\u041F", frv: "\u0424\u0420\u0412", twi_plans: "\u041F\u043B\u0430\u043D\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 TWI", sop_evaluation: "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F", my_plan: "\u041C\u043E\u0439 \u043F\u043B\u0430\u043D", twi: "\u041F\u043B\u0430\u043D \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F", programs: "\u0412\u0432\u043E\u0434 \u0432 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u044E", internship: "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0441\u0442\u0430\u0436\u0438\u0440\u043E\u0432\u043A\u0438", instruction: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0438 TWI", retraining: "\u041F\u0435\u0440\u0435\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", journal: "\u0416\u0443\u0440\u043D\u0430\u043B \u0437\u0430\u0434\u0430\u043D\u0438\u0439", skills: "\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439", practical: "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043E\u0446\u0435\u043D\u043A\u0438", development: "\u041F\u043B\u0430\u043D\u044B \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", mentoring: "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438 \u0438 \u0412\u0422", self_eval: "\u0421\u0430\u043C\u043E\u043E\u0446\u0435\u043D\u043A\u0430", certification: "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F", appointments: "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F", audit: "\u0410\u0443\u0434\u0438\u0442\u044B 1-\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F", calendar: "\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u044C", actions: "\u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u044F", analytics: "\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 \u0446\u0435\u043D\u0442\u0440\u0430", metrics: "\u0414\u0435\u0440\u0435\u0432\u043E \u043C\u0435\u0442\u0440\u0438\u043A", roi: "ROI-\u043C\u043E\u0434\u0435\u043B\u044C", ai: "\u0418\u0418-\u043F\u043E\u043C\u043E\u0449\u043D\u0438\u043A" };
  var labels2 = { home: "\u0414\u0430\u0448\u0431\u043E\u0440\u0434", ...Object.fromEntries(Object.entries(definitions).map(([k, v]) => [k, v.label])), ...planned, org_unit: "\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F", import_xlsx: "\u0418\u043C\u043F\u043E\u0440\u0442 \u0434\u0430\u043D\u043D\u044B\u0445", storage: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0438 \u043E\u0431\u043C\u0435\u043D" };
  var navGroups = [
    ["\u0415\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0442\u0430", ["home", "my_plan", "calendar", "actions"]],
    ["\u0421\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u0438\u0437\u0430\u0446\u0438\u044F \u0438 \u0443\u043B\u0443\u0447\u0448\u0435\u043D\u0438\u044F", ["sop", "sop_constructor", "frv", "sop_evaluation"]],
    ["\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", ["twi_plans", "twi", "programs", "internship", "instruction", "retraining", "journal"]],
    ["\u041B\u044E\u0434\u0438 \u0438 \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438", ["person", "workplace", "skills", "practical", "development"]],
    ["\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438 \u0438 \u0412\u0422", ["mentoring", "self_eval", "certification", "appointments", "audit"]],
    ["\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430", ["analytics", "metrics", "roi"]],
    ["\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0446\u0435\u043D\u0442\u0440\u043E\u043C", ["org_unit", "forms", "import_xlsx", "storage"]],
    ["\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438", ["profession", "position", "work_shift", "equipment", "operation", "person_assignment", "business_role", "role_assignment", "skill_category", "skill", "rating_scale"]]
  ];
  var implemented = /* @__PURE__ */ new Set(["home", "sop", "sop_constructor", "frv", "twi_plans", "sop_evaluation", "storage", "import_xlsx", ...TRAINING_PAGES, ...Object.keys(definitions)]);
  var collapsedNav = /* @__PURE__ */ new Set(["\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438 \u0438 \u0412\u0422", "\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430", "\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438"]);
  var librarySelected = null;
  var libraryRevisionSelected = null;
  var evaluationSelected = null;
  var evaluationTab = "weighted";
  var evaluationSearch = "";
  var employeeSelected = null;
  var employeeTab = "overview";
  var employeeReturn = null;
  var employeeSources = null;
  function el(tag, text4, cls) {
    const n = document.createElement(tag);
    if (text4 !== void 0) n.textContent = text4;
    if (cls) n.className = cls;
    return n;
  }
  function add(parent, ...children) {
    parent.append(...children);
    return parent;
  }
  function btn(label, fn, cls = "", disabled = false) {
    const n = el("button", label, cls);
    n.type = "button";
    n.disabled = disabled || busy;
    n.addEventListener("click", fn);
    return n;
  }
  function pane(title, ...children) {
    return add(el("section", void 0, "panel"), el("h2", title), ...children);
  }
  function message(s, bad = false) {
    status = s;
    error = bad;
    const n = document.getElementById("status");
    if (n) {
      n.textContent = s;
      n.className = "status" + (bad ? " error" : "");
    }
  }
  function navigate(p, { retainEmployee = false } = {}) {
    if (busy) return;
    if (editorSession && !editorSession.host.hidden) hideEditor(editorSession);
    closePeopleDropdown();
    resetTrainingRoute();
    if (!retainEmployee) {
      employeeSelected = null;
      employeeReturn = null;
      employeeTab = "overview";
      employeeSources = null;
    }
    page = p;
    edit = null;
    query = "";
    historyPerson = null;
    archiveFilter = "active";
    libraryFilter = "all";
    librarySelected = null;
    libraryRevisionSelected = null;
    if (p === "sop_evaluation") {
      evaluationSelected = null;
      evaluationTab = "weighted";
      evaluationSearch = "";
    }
    render();
  }
  function goTraining(p, options = {}) {
    navigate(p, { retainEmployee: !!employeeReturn });
    setTrainingRoute(p, options);
    render();
  }
  function openImport(type) {
    importState = { type, book: null, sheet: 0, header: 1, mapping: {}, allowUpdates: false, plan: null, file: "" };
    navigate("import_xlsx");
  }
  async function persist() {
    if (cache) generation = await saveWorkspace(cache, generation, ws.state());
  }
  function replace(newWs) {
    ws?.close();
    ws = newWs;
  }
  async function run(fn, { save: save2 = true } = {}) {
    if (busy) return;
    const prev = ws.state();
    busy = true;
    root.querySelectorAll("button").forEach((b) => b.disabled = true);
    message("\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F\u2026");
    try {
      const m = await fn();
      if (save2) await persist();
      message(m || "\u0413\u043E\u0442\u043E\u0432\u043E");
    } catch (e) {
      console.error(e);
      replace(new Workspace(SQL, openDb(SQL, prev.base), prev));
      message(e.message, true);
    } finally {
      busy = false;
      render();
    }
  }
  function download(name, body) {
    const url = URL.createObjectURL(new Blob([canonical(body)], { type: "application/json" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function pick(accept, fn, max2 = 150 * 1024 * 1024) {
    const i = el("input");
    i.type = "file";
    i.accept = accept;
    i.onchange = () => {
      const f = i.files?.[0];
      if (f) run(async () => {
        invariant(f.size <= max2, "\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
        return await fn(JSON.parse(await f.text()));
      });
    };
    i.click();
  }
  var empty2 = () => !ws.pending.length && !ws.dirty && !meta(ws.base, "publication_id") && Object.keys(definitions).every((t) => list(ws.base, t).length === 0) && !one(ws.base, "SELECT id FROM document LIMIT 1") && !one(ws.base, "SELECT id FROM frv_study LIMIT 1");
  function refName(type, id) {
    if (!id) return "\u2014";
    const v = one(ws.working, "SELECT * FROM " + type + " WHERE id=?", [id]);
    return v?.display_name || v?.name || id;
  }
  function refOption(type, v) {
    return (v.employee_code || v.code ? (v.employee_code || v.code) + " \u2014 " : "") + (v.display_name || v.name || v.id) + (v.unit_id ? " \xB7 " + refName("org_unit", v.unit_id) : "") + (v.archived ? " (\u0430\u0440\u0445\u0438\u0432)" : "");
  }
  var today = () => {
    const d = /* @__PURE__ */ new Date();
    return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
  };
  function activeRecord(d, v) {
    return !v.archived && (!d.history || v.valid_from <= today() && (!v.valid_to || v.valid_to >= today()));
  }
  function showVal(k, f, v) {
    if (f.ref) return k === "shift_id" && !v[k] && v.shift_code ? v.shift_code + " (LC1)" : refName(f.ref, v[k]);
    if (k === "criticality") return { normal: "\u041E\u0431\u044B\u0447\u043D\u0430\u044F", important: "\u0412\u0430\u0436\u043D\u0430\u044F", critical: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" }[v[k]] || v[k];
    return v[k] ?? "\u2014";
  }
  var ICON_PATHS = {
    home: ["M3 10 12 3l9 7v10H3z", "M9 20v-6h6v6"],
    sop: ["M6 3h9l4 4v14H6z", "M14 3v5h5", "M9 12h7M9 16h7"],
    frv: ["M12 5a7 7 0 1 0 7 7 7 7 0 0 0-7-7z", "M12 8v4l3 2M9 2h6"],
    twi: ["M3 5h7l2 2 2-2h7v15h-7l-2 1-2-1H3z", "M12 7v14"],
    skills: ["M3 4h18v16H3z", "M3 9h18M3 14h18M9 4v16M15 4v16"],
    mentoring: ["M9 4a3 3 0 1 0 0 6 3 3 0 0 0 0-6z", "M3 20v-3c0-3 12-3 12 0v3", "M16 6h5M18.5 3.5v5"],
    audit: ["M5 4h14v17H5z", "M9 4V2h6v2", "m8 10 2 2 4-4", "M8 16h8"],
    calendar: ["M3 6h18v15H3z", "M7 3v6M17 3v6M3 10h18", "M7 14h3M14 14h3"],
    actions: ["M4 5h16v15H4z", "m7 11 3 3 6-6"],
    analytics: ["M4 3v17h17", "M8 16v-5M13 16V7M18 16V4"],
    ai: ["m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"],
    org_unit: ["M8 3h8v5H8z", "M12 8v5M4 13h16M4 13v3M20 13v3", "M2 16h5v5H2zM17 16h5v5h-5z"],
    person: ["M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z", "M4 21v-3c0-6 16-6 16 0v3"],
    profession: ["M3 7h18v13H3z", "M8 7V4h8v3M3 12h18M10 12v3h4v-3"],
    equipment: ["M3 21V9l6 4V8l6 5V4h5v17z", "M6 17h2M11 17h2M16 17h2"],
    operation: ["M4 3h16v5H4zM4 16h16v5H4z", "M12 8v8m-3-3 3 3 3-3"],
    person_assignment: ["M3 4h18v16H3z", "M7 8h4M7 12h4M7 16h4", "m14 13 2 2 4-5"],
    storage: ["M4 7c0-4 16-4 16 0v10c0 4-16 4-16 0z", "M4 7c0 4 16 4 16 0M4 12c0 4 16 4 16 0"]
  };
  function icon(key3, cls = "nav-icon") {
    if (key3 === "sop_constructor") key3 = "sop";
    if (key3 === "twi_plans") key3 = "twi";
    const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
    for (const [k, v] of Object.entries({ viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.65", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", class: cls })) svg.setAttribute(k, v);
    for (const d of ICON_PATHS[key3] || ICON_PATHS.home) {
      const p = document.createElementNS(ns, "path");
      p.setAttribute("d", d);
      svg.append(p);
    }
    return svg;
  }
  function navButton(k) {
    const n = btn("", () => navigate(k), "nav" + (page === k ? " active" : "") + (!implemented.has(k) ? " nav-planned" : ""));
    n.append(icon(k), el("span", labels2[k]));
    if (page === k) n.setAttribute("aria-current", "page");
    if (!implemented.has(k)) {
      n.title = "\u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u043D\u0430 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0435 \u044D\u0442\u0430\u043F\u044B";
      const dot = el("span", "", "planned-dot");
      dot.setAttribute("aria-hidden", "true");
      n.append(dot);
    }
    return n;
  }
  function sectionHeading(title, caption) {
    return add(el("div", void 0, "section-heading"), el("h2", title), el("span", caption, "muted"));
  }
  function home(main) {
    const todayIso = today(), overdue = one(ws.working, "SELECT count(*) n FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.state='effective' AND d.archived=0 AND r.review_due<?", [todayIso]).n;
    const without = one(ws.working, "SELECT count(*) n FROM document_revision r JOIN document d ON d.id=r.document_id WHERE r.state='draft' AND d.archived=0 AND (r.print_format IS NULL OR r.workplace_id IS NULL)").n;
    const needs = pane("\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044F", add(el("div", void 0, "attention-row"), el("strong", String(overdue), overdue ? "bad" : "muted"), el("span", "\u041F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0421\u041E\u041F"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
      navigate("sop");
      libraryFilter = "overdue";
      render();
    })), add(el("div", void 0, "attention-row"), el("strong", String(without), without ? "warn" : "muted"), el("span", "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438 \u0431\u0435\u0437 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0433\u043E \u043F\u0430\u0441\u043F\u043E\u0440\u0442\u0430"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
      navigate("sop");
      libraryFilter = "missing_passport";
      render();
    })));
    const overdueTraining = one(ws.working, "SELECT count(*) n FROM training_assignment WHERE source_sha256 IS NOT NULL AND state IN('planned','in_progress') AND due_on<?", [todayIso]).n;
    const revisedTraining = one(ws.working, "SELECT count(*) n FROM training_assignment a JOIN document_revision r ON r.id=a.sop_revision_id JOIN document d ON d.id=r.document_id WHERE a.source_sha256 IS NOT NULL AND a.state<>'cancelled' AND (r.state<>'effective' OR d.archived=1)").n;
    needs.append(add(el("div", void 0, "attention-row"), el("strong", String(overdueTraining), overdueTraining ? "warn" : "muted"), el("span", "\u041F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043D\u044B\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goTraining("twi", { filter: "overdue" }))), add(el("div", void 0, "attention-row"), el("strong", String(revisedTraining), revisedTraining ? "warn" : "muted"), el("span", "\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u043F\u0440\u0435\u0436\u043D\u0438\u043C \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F\u043C \u0421\u041E\u041F"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => goTraining("retraining"))));
    main.append(needs);
    main.append(sectionHeading("\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F", "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"));
    const g = el("div", void 0, "kpi-grid");
    const counts = Object.fromEntries(Object.keys(definitions).map((k) => [k, list(ws.working, k).filter((x) => activeRecord(definitions[k], x)).length]));
    for (const k of ["org_unit", "person", "workplace", "equipment", "operation", "profession"]) {
      const d = definitions[k], n = btn("", () => navigate(k), "tile");
      n.setAttribute("aria-label", d.label + ": " + counts[k]);
      add(n, add(el("div", void 0, "tile-head"), el("span", d.label, "muted"), icon(k, "tile-icon")), el("b", String(counts[k])), el("span", "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u2192", "tile-link"));
      g.append(n);
    }
    main.append(g);
    main.append(add(el("div", void 0, "row registry-shortcuts"), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432 \u0438\u0437 Excel", () => openImport("person"), "primary"), btn("\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", () => navigate("person_assignment")), btn("\u0428\u043A\u0430\u043B\u044B \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u043D\u0438\u044F", () => navigate("rating_scale"))));
    const c = el("div", void 0, "chart");
    c.style.height = Math.max(290, Object.keys(definitions).length * 29) + "px";
    main.append(pane("\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u043E\u0432", c));
    if (window.echarts) {
      chart = echarts.init(c, theme ? "dark" : null);
      chart.setOption(registryCountChart(Object.values(definitions).map((x) => x.label), Object.keys(definitions).map((k) => counts[k]), theme));
    }
    const links = el("div", void 0, "workspace-grid");
    for (const [k, n] of Object.entries(planned).filter(([k2]) => implemented.has(k2))) {
      const b = btn("", () => navigate(k), "workspace-link");
      b.append(icon(k), el("span", n));
      links.append(b);
    }
    main.append(pane("\u0420\u0430\u0431\u043E\u0447\u0438\u0435 \u043C\u043E\u0434\u0443\u043B\u0438", el("p", "\u0421\u041E\u041F, \u0424\u0420\u0412, TWI, \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438, \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0438 \u0430\u0443\u0434\u0438\u0442 \u2014 \u0440\u0430\u0432\u043D\u043E\u043F\u0440\u0430\u0432\u043D\u044B\u0435 \u043C\u043E\u0434\u0443\u043B\u0438 \u0446\u0435\u043D\u0442\u0440\u0430. \u0414\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0431\u0430\u0437\u0430, \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438, \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0421\u041E\u041F, \u0424\u0420\u0412, \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435, \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0438 \u0438 \u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0438. \u0410\u0443\u0434\u0438\u0442 L1 \u0438 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u043D\u0430\u044F \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0430\u044E\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.", "muted"), links));
  }
  function form(type, v) {
    const d = definitions[type], f = el("form"), grid = el("div", void 0, "formgrid"), controls = {};
    for (const [k, x] of Object.entries(d.fields)) {
      let input;
      const initial = v?.[k] ?? (k === "criticality" ? "normal" : k === "kind" ? "\u0423\u0447\u0430\u0441\u0442\u043E\u043A" : k === "valid_from" ? today() : k === "version_no" ? "1" : "");
      if (x.legacy) {
        input = el("input");
        input.type = "hidden";
        input.name = k;
        input.value = initial;
        controls[k] = input;
        grid.append(input);
        if (initial) grid.append(add(el("div", void 0, "field"), el("span", x.label), el("p", initial, "muted")));
        continue;
      }
      if (x.ref || x.options) {
        input = el("select");
        const option = el("option", "\u2014");
        option.value = "";
        input.append(option);
        const opts = x.ref ? list(ws.working, x.ref).filter((y) => !y.archived || v?.[k] === y.id).map((y) => [y.id, refOption(x.ref, y)]) : x.options.map((y) => [y, y === "normal" ? "\u041E\u0431\u044B\u0447\u043D\u0430\u044F" : y === "important" ? "\u0412\u0430\u0436\u043D\u0430\u044F" : y === "critical" ? "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F" : y]);
        for (const [value, label] of opts) {
          const o = el("option", label);
          o.value = value;
          input.append(o);
        }
      } else if (x.multiline) {
        input = el("textarea");
        input.rows = 5;
        input.maxLength = 5e3;
        input.placeholder = "0: \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u044F\n1: \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u044F";
      } else {
        input = el("input");
        input.type = x.date ? "date" : x.integer ? "number" : "text";
        input.maxLength = 500;
        if (x.integer) {
          input.min = "1";
          input.step = "1";
        }
      }
      input.name = k;
      input.required = !!x.required;
      input.value = initial;
      controls[k] = input;
      if (d.history && v?.id && k !== "valid_to") input.disabled = true;
      if (d.history && v?.valid_to && k === "valid_to") input.disabled = true;
      grid.append(add(el("label", void 0, "field"), el("span", x.label), input));
    }
    const submit = el("button", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C", "primary");
    submit.type = "submit";
    submit.disabled = busy;
    f.onsubmit = (e) => {
      e.preventDefault();
      const payload = Object.fromEntries(Object.entries(controls).map(([k, n]) => [k, n.value || null]));
      run(async () => {
        ws.edit(type, v?.id || null, payload);
        edit = null;
        return "\u0417\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
      });
    };
    if (d.history && v?.id) f.append(el("p", "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430: \u043C\u043E\u0436\u043D\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u0437\u0430\u043A\u0440\u044B\u0442\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0434\u0430\u0442\u043E\u0439 \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F. \u0414\u043B\u044F \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E\u0441\u043B\u0435 \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u044F.", "muted"));
    if (type === "rating_scale") f.append(el("p", "\u041F\u043E\u0441\u043B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0448\u043A\u0430\u043B\u0430 \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0430. \u0414\u043B\u044F \u043D\u043E\u0432\u043E\u0439 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E. \u0423\u0440\u043E\u0432\u043D\u0438 \u0437\u0430\u0434\u0430\u044E\u0442\u0441\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u043C; \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0438\u0435 \u043F\u043E\u0440\u043E\u0433\u0438 \u043D\u0435 \u043F\u0440\u0435\u0434\u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u044B.", "muted"));
    return add(f, grid, add(el("div", void 0, "row"), submit, btn("\u041E\u0442\u043C\u0435\u043D\u0430", () => {
      edit = null;
      render();
    })));
  }
  function orgTree(panel, items) {
    const box = el("div", void 0, "org-tree"), children = /* @__PURE__ */ new Map();
    for (const v of items) {
      const k = v.parent_id || "";
      if (!children.has(k)) children.set(k, []);
      children.get(k).push(v);
    }
    const seen = /* @__PURE__ */ new Set();
    function walk(id, depth) {
      for (const v of children.get(id) || []) {
        if (seen.has(v.id)) continue;
        seen.add(v.id);
        const line = add(el("div", void 0, "org-node"), el("span", v.code, "pill"), el("span", v.name), el("span", v.kind + (v.archived ? " \xB7 \u0410\u0440\u0445\u0438\u0432" : ""), "muted"));
        line.style.paddingLeft = Math.min(depth, 8) * 17 + "px";
        box.append(line);
        walk(v.id, depth + 1);
      }
    }
    walk("", 0);
    for (const v of items.filter((x) => !seen.has(x.id))) box.append(el("p", v.code + " \u2014 " + v.name + " (\u043D\u0435\u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u0439 \u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044C)", "warn"));
    if (items.length) panel.append(pane("\u0418\u0435\u0440\u0430\u0440\u0445\u0438\u044F \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F", box));
  }
  var employeeTabs = [["overview", "\u041E\u0431\u0437\u043E\u0440"], ["matrices", "\u041C\u0430\u0442\u0440\u0438\u0446\u044B \u043A\u043E\u043C\u043F\u0435\u0442\u0435\u043D\u0446\u0438\u0439"], ["training", "\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435"], ["assessments", "\u041E\u0446\u0435\u043D\u043A\u0438 \u0438 \u0434\u043E\u043F\u0443\u0441\u043A\u0438"], ["mentoring", "\u041D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u0447\u0435\u0441\u0442\u0432\u043E"], ["documents", "\u0421\u041E\u041F \u0438 \u0424\u0420\u0412"], ["development", "\u041F\u043B\u0430\u043D\u044B \u0438 \u043C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u044F"], ["history", "\u041D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438 \u0440\u043E\u043B\u0438"]];
  var employeeStates = { active: "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442", retired: "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F", planned: "\u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043E", in_progress: "\u0412 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435", completed: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E", cancelled: "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E", confirmed: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E", void: "\u0410\u043D\u043D\u0443\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u043E", registered: "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043E", revoked: "\u041E\u0442\u043E\u0437\u0432\u0430\u043D\u043E", closed: "\u0417\u0430\u043A\u0440\u044B\u0442\u043E", granted: "\u0414\u043E\u043F\u0443\u0441\u043A \u0432\u044B\u0434\u0430\u043D", denied: "\u041D\u0435 \u0434\u043E\u043F\u0443\u0449\u0435\u043D", final: "\u0417\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u043E", draft: "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A", pass: "\u041F\u0440\u043E\u0439\u0434\u0435\u043D\u043E", fail: "\u041D\u0435 \u043F\u0440\u043E\u0439\u0434\u0435\u043D\u043E", incomplete: "\u041D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E", effective: "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442", superseded: "\u0417\u0430\u043C\u0435\u043D\u0435\u043D\u043E", withdrawn: "\u0412\u044B\u0432\u0435\u0434\u0435\u043D\u043E \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F", open: "\u041E\u0442\u043A\u0440\u044B\u0442\u043E", review: "\u041D\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0438", approved: "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043E", archived: "\u0410\u0440\u0445\u0438\u0432" };
  function openEmployee(id, { restore: restore2 = false } = {}) {
    if (!id || !one(ws.working, "SELECT id FROM person WHERE id=?", [id])) return;
    const keep = restore2 && employeeReturn === id, tab = keep ? employeeTab : "overview";
    navigate("person", { retainEmployee: keep });
    employeeSelected = id;
    employeeReturn = id;
    employeeTab = tab;
    employeeSources = null;
    render();
  }
  function employeeDestination(id, d) {
    if (!d) return;
    employeeReturn = id;
    const p = d.page, o = d.options || {};
    if (p === "sop") {
      goDocument(o.documentId, o.revisionId);
      return;
    }
    if (p === "frv") {
      goResearch(o.studyId);
      return;
    }
    if (p === "sop_evaluation") {
      navigate(p, { retainEmployee: true });
      evaluationSelected = o.revisionId;
      evaluationTab = o.tab || "corporate";
      render();
      return;
    }
    if (p === "person_assignment" || p === "role_assignment") {
      navigate(p, { retainEmployee: true });
      historyPerson = id;
      archiveFilter = "all";
      render();
      return;
    }
    goTraining(p, o);
  }
  function employeeCard(main, id) {
    const db = ws.working, p = one(db, "SELECT * FROM person WHERE id=?", [id]);
    if (!p) {
      employeeSelected = null;
      return registry(main, "person");
    }
    const cur = one(db, "SELECT * FROM person_assignment WHERE person_id=? AND valid_from<=? AND coalesce(valid_to,'9999-12-31')>=? ORDER BY valid_from DESC,id LIMIT 1", [id, today(), today()]);
    const roles3 = rows(db, "SELECT b.name FROM role_assignment a JOIN business_role b ON b.id=a.role_id WHERE a.person_id=? AND b.archived=0 AND a.valid_from<=? AND coalesce(a.valid_to,'9999-12-31')>=? ORDER BY b.name", [id, today(), today()]);
    const groups = employeeRelations(db, id);
    const top = pane(p.display_name, add(el("div", void 0, "row"), btn("\u2190 \u0421\u043F\u0438\u0441\u043E\u043A \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432", () => navigate("person")), btn("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439", () => employeeDestination(id, { page: "person_assignment" })), btn("\u0420\u043E\u043B\u0438", () => employeeDestination(id, { page: "role_assignment" }))), add(el("div", void 0, "employee-meta"), ...[
      ["\u0422\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440", p.employee_code],
      ["\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", refName("org_unit", cur?.unit_id)],
      ["\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", refName(cur?.position_id ? "position" : "profession", cur?.position_id || cur?.profession_id)],
      ["\u0421\u043C\u0435\u043D\u0430", cur?.shift_id ? refName("work_shift", cur.shift_id) : cur?.shift_code || "\u2014"],
      ["\u0420\u043E\u043B\u0438", roles3.map((r) => r.name).join(", ") || "\u2014"],
      ["\u0421\u0442\u0430\u0442\u0443\u0441", p.archived ? "\u0410\u0440\u0445\u0438\u0432" : "\u0410\u043A\u0442\u0438\u0432\u0435\u043D"]
    ].map(([key3, value]) => add(el("div"), el("span", key3, "muted"), el("strong", value)))));
    main.append(top);
    const nav = el("div", void 0, "library-tabs employee-tabs"), body = el("div");
    function show2(key3) {
      employeeTab = key3;
      for (const b of nav.children) b.classList.toggle("selected", b.dataset.tab === key3);
      body.replaceChildren();
      if (key3 === "overview") {
        body.append(pane("\u0421\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435", el("p", "\u0412\u0441\u0435 \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u0431\u0435\u0440\u0443\u0442\u0441\u044F \u0438\u0437 \u043E\u0431\u0449\u0435\u0439 \u0431\u0430\u0437\u044B \u043F\u043E \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0443 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430. \u0414\u043B\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0421\u041E\u041F \u0438 \u0424\u0420\u0412 \u043F\u0440\u0435\u0434\u0443\u0441\u043C\u043E\u0442\u0440\u0435\u043D \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u043F\u043E\u0438\u0441\u043A \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0445 \u0441\u0441\u044B\u043B\u043E\u043A.", "muted"), add(el("div", void 0, "employee-overview"), ...employeeTabs.slice(1).map(([k, label]) => btn(label + " \xB7 " + groups[k].length, () => show2(k), "employee-section-button")))));
        const open = groups.training.filter((x) => ["active", "planned", "in_progress"].includes(x.state));
        if (open.length) body.append(pane("\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", recordsTable(open.slice(0, 10))));
        const active4 = groups.matrices.filter((x) => x.state === "active");
        if (active4.length) body.append(pane("\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043C\u0430\u0442\u0440\u0438\u0446\u044B", recordsTable(active4)));
        return;
      }
      const title = employeeTabs.find((x) => x[0] === key3)?.[1] || key3, items = groups[key3], section = pane(title);
      const search = fieldInput("employee_related_search", "", "search");
      search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E, \u0440\u043E\u043B\u0438, \u0434\u0430\u0442\u0435";
      const out = el("div");
      const draw = () => {
        const q = search.value.trim().toLocaleLowerCase("ru-RU"), list2 = items.filter((r) => [r.title, r.role, r.date, employeeStates[r.state] || r.state, r.extra].join(" ").toLocaleLowerCase("ru-RU").includes(q));
        out.replaceChildren(list2.length ? recordsTable(list2) : el("p", "\u041D\u0435\u0442 \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u043F\u043E \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u043C \u0443\u0441\u043B\u043E\u0432\u0438\u044F\u043C.", "muted"));
      };
      search.oninput = draw;
      section.append(search, out);
      draw();
      if (key3 === "matrices" && !p.archived) section.append(btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043C\u0430\u0442\u0440\u0438\u0446\u0443 \u0441 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u043C", () => employeeDestination(id, { page: "skills", options: { mode: "builder", personId: id } }), "primary"));
      if (key3 === "training" && !p.archived) section.append(btn("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => employeeDestination(id, { page: "twi", options: { mode: "new", traineeId: id } }), "primary"));
      if (key3 === "development" && !p.archived) section.append(btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u043B\u0430\u043D \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F", () => employeeDestination(id, { page: "development", options: { mode: "new", personId: id } }), "primary"));
      if (key3 === "documents") {
        let drawSources = function(result) {
          sourceOut.replaceChildren(el("p", "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u043E\u0432: " + result.scanned + ". \u041D\u0430\u0439\u0434\u0435\u043D\u043E \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0445: " + result.items.length + ".", "muted"));
          if (result.items.length) sourceOut.append(recordsTable(result.items));
          if (result.errors.length) {
            const details = el("details");
            details.append(el("summary", "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C: " + result.errors.length), ...result.errors.map((e) => el("p", e, "warn")));
            sourceOut.append(details);
          }
        };
        const sourceOut = el("div"), searchSources = btn("\u041D\u0430\u0439\u0442\u0438 \u0441\u0432\u044F\u0437\u0438 \u0432 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0430\u0445 \u0421\u041E\u041F \u0438 \u0424\u0420\u0412", async () => {
          searchSources.disabled = true;
          sourceOut.replaceChildren(el("p", "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0442\u0441\u044F \u0441\u0441\u044B\u043B\u043A\u0438 \u0432 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u0430\u0445\u2026", "muted"));
          try {
            const result = await employeeSourceLinks(db, id, readContent2, (done, total) => {
              sourceOut.replaceChildren(el("p", "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E " + done + " \u0438\u0437 " + total, "muted"));
            });
            if (employeeSelected !== id) return;
            employeeSources = { id, result };
            drawSources(result);
          } catch (e) {
            sourceOut.replaceChildren(el("p", e.message, "bad"));
          } finally {
            searchSources.disabled = false;
          }
        });
        section.append(pane("\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A \u0432 \u043F\u043E\u043B\u044F\u0445 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432", el("p", "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u043C \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430\u043C: \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u0433\u0440\u0443\u043F\u043F\u0430, \u0441\u043E\u0433\u043B\u0430\u0441\u0443\u044E\u0449\u0438\u0435, \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0435, \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440, \u043E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439, \u0438\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C \u0438 \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u0435\u043B\u044C \u0424\u0420\u0412. \u0421\u0442\u0430\u0440\u044B\u0435 \u043F\u043E\u043B\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0441 \u0424\u0418\u041E \u043D\u0435 \u0441\u0432\u044F\u0437\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438.", "muted"), searchSources, sourceOut));
        if (employeeSources?.id === id) drawSources(employeeSources.result);
      }
      body.append(section);
    }
    function recordsTable(items) {
      return tableOf(["\u0417\u0430\u043F\u0438\u0441\u044C", "\u0420\u043E\u043B\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430", "\u0414\u0430\u0442\u0430", "\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", "\u0421\u0432\u0435\u0434\u0435\u043D\u0438\u044F", ""], items.map((r) => [r.title, r.role, r.date, employeeStates[r.state] || r.state || "\u2014", r.extra, r.dest ? btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => employeeDestination(id, r.dest), "primary") : "\u2014"]));
    }
    for (const [key3, title] of employeeTabs) {
      const b = btn(title + (key3 === "overview" ? "" : " (" + groups[key3].length + ")"), () => show2(key3), "library-tab");
      b.dataset.tab = key3;
      nav.append(b);
    }
    main.append(nav, body);
    show2(employeeTab);
  }
  function registry(main, type) {
    if (type === "person" && employeeSelected) {
      employeeCard(main, employeeSelected);
      return;
    }
    const d = definitions[type], items = list(ws.working, type), search = el("input");
    search.type = "search";
    search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0443";
    search.value = query;
    const filter = el("select");
    for (const [value, label] of [["active", d.history ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435" : "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435"], ["all", "\u0412\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"], ["inactive", d.history ? "\u0418\u0441\u0442\u043E\u0440\u0438\u044F / \u0431\u0443\u0434\u0443\u0449\u0438\u0435" : "\u0410\u0440\u0445\u0438\u0432"]]) {
      const o = el("option", label);
      o.value = value;
      filter.append(o);
    }
    filter.value = archiveFilter;
    const panel = pane(d.label, add(el("div", void 0, "row"), search, filter, btn("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C", () => {
      edit = historyPerson ? { person_id: historyPerson } : {};
      render();
    }, "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 Excel", () => openImport(type))));
    main.append(panel);
    if (historyPerson) panel.append(add(el("div", void 0, "row"), el("span", "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430: " + refName("person", historyPerson), "pill"), btn("\u0412\u0441\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438", () => {
      historyPerson = null;
      render();
    })));
    if (edit !== null) panel.append(pane(edit.id ? "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435" : "\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C", form(type, edit)));
    const wrap = el("div", void 0, "tablewrap");
    panel.append(wrap);
    function draw() {
      wrap.replaceChildren();
      const data = items.filter((v) => (!historyPerson || v.person_id === historyPerson) && (archiveFilter === "all" || (archiveFilter === "active" ? activeRecord(d, v) : !activeRecord(d, v))) && Object.entries(d.fields).some(([k, f]) => String(showVal(k, f, v)).toLowerCase().includes(query.toLowerCase())));
      if (!data.length) {
        wrap.append(el("p", "\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439", "empty"));
        return;
      }
      const fields = Object.entries(d.fields).filter(([, f]) => !f.legacy);
      const t = el("table"), head = el("tr");
      for (const [, f] of fields) head.append(el("th", f.label));
      if (type === "person") head.append(el("th", "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435"), el("th", "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C"));
      head.append(el("th", "\u0412\u0435\u0440\u0441\u0438\u044F / \u0441\u0442\u0430\u0442\u0443\u0441"), el("th", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F"));
      t.append(add(el("thead"), head));
      const body = el("tbody"), directory = type === "person" ? new Map(directoryPeople(ws.working, today()).map((p) => [p.id, p])) : null;
      for (const v of data) {
        const tr = el("tr", void 0, !activeRecord(d, v) ? "archive" : "");
        for (const [k, f] of fields) tr.append(type === "person" && k === "display_name" ? add(el("td"), btn(v.display_name, () => openEmployee(v.id), "employee-name-link")) : el("td", String(showVal(k, f, v)), f.multiline ? "multiline-cell" : ""));
        if (type === "person") {
          const p = directory.get(v.id);
          tr.append(el("td", p?.unit || "\u2014"), el("td", p?.position || "\u2014"));
        }
        const state = v.archived ? "\u0410\u0440\u0445\u0438\u0432" : d.history ? v.valid_from > today() ? "\u0411\u0443\u0434\u0443\u0449\u0435\u0435" : v.valid_to && v.valid_to < today() ? "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E" : "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u0410\u043A\u0442\u0438\u0432\u043D\u043E";
        tr.append(el("td", state + " \xB7 v" + v.rev));
        const a = el("td");
        if (type === "person") a.append(btn("\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430", () => openEmployee(v.id), "primary"));
        if (!v.archived) {
          if (!d.immutable && (!d.history || !v.valid_to)) a.append(btn(d.history ? "\u0417\u0430\u043A\u0440\u044B\u0442\u044C / \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C" : "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C", () => {
            edit = v;
            render();
          }, "", !!ws.conflicts.length));
          if (d.immutable) a.append(btn("\u041D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F", () => {
            edit = { name: v.name, version_no: String(Math.max(...items.filter((x) => x.name === v.name).map((x) => x.version_no)) + 1), levels: v.levels };
            render();
          }, "", !!ws.conflicts.length));
          if (!d.history) a.append(btn("\u0410\u0440\u0445\u0438\u0432", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C? \u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F.")) run(async () => {
              ws.edit(type, v.id, null, "archive");
              return "\u0417\u0430\u043F\u0438\u0441\u044C \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
            });
          }, "danger", !!ws.conflicts.length));
        }
        tr.append(a);
        body.append(tr);
      }
      t.append(body);
      wrap.append(t);
    }
    search.oninput = () => {
      query = search.value;
      draw();
    };
    filter.onchange = () => {
      archiveFilter = filter.value;
      draw();
    };
    draw();
    if (type === "org_unit") orgTree(panel, items);
  }
  function downloadBytes(name, bytes) {
    const url = URL.createObjectURL(new Blob([bytes], { type: name.endsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function updateMapping(s) {
    s.plan = null;
    s.mapping = s.book ? autoMap(s.type, sheetHeaders(s.book.worksheets[s.sheet], s.header)) : {};
  }
  function importScreen(main) {
    const s = importState || (importState = { type: "person", book: null, sheet: 0, header: 1, mapping: {}, allowUpdates: false, plan: null, file: "" });
    const kind = el("select");
    kind.name = "import_type";
    for (const [key3, d] of Object.entries(definitions)) {
      const o = el("option", d.label);
      o.value = key3;
      kind.append(o);
    }
    kind.value = s.type;
    kind.onchange = () => {
      s.type = kind.value;
      try {
        updateMapping(s);
      } catch (e) {
        message(e.message, true);
        s.mapping = {};
      }
      render();
    };
    const load2 = el("input");
    load2.type = "file";
    load2.accept = ".xlsx";
    load2.name = "import_file";
    load2.onchange = () => {
      const f = load2.files?.[0];
      if (!f) return;
      run(async () => {
        invariant(/\.xlsx$/i.test(f.name) && f.size <= MAX_XLSX, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 XLSX \u0434\u043E 20 \u041C\u0411");
        const book = await loadWorkbook(window.ExcelJS, await f.arrayBuffer());
        s.book = book;
        s.file = f.name;
        s.sheet = 0;
        s.header = 1;
        updateMapping(s);
        return "Excel \u043E\u0442\u043A\u0440\u044B\u0442. \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u043A\u043E\u043B\u043E\u043D\u043E\u043A.";
      }, { save: false });
    };
    const setup = pane("1. \u0412\u044B\u0431\u043E\u0440 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u0438 \u0444\u0430\u0439\u043B\u0430", add(el("div", void 0, "formgrid"), add(el("label", void 0, "field"), el("span", "\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A"), kind), add(el("label", void 0, "field"), el("span", "Excel (.xlsx)"), load2)), add(el("div", void 0, "row"), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D XLSX", () => run(async () => {
      downloadBytes("LeanCenter-" + s.type + ".xlsx", await makeTemplate(window.ExcelJS, s.type));
      return "\u0428\u0430\u0431\u043B\u043E\u043D \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false })), btn("\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0438\u043C\u043F\u043E\u0440\u0442", () => openImport(s.type))), el("p", s.file ? "\u041E\u0442\u043A\u0440\u044B\u0442 \u0444\u0430\u0439\u043B: " + s.file : "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u0430\u0439\u043B. \u0414\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u0442\u0441\u044F \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0438\u043C\u043F\u043E\u0440\u0442\u0430.", "muted"));
    main.append(setup);
    if (!s.book) return;
    const select = el("select");
    select.name = "import_sheet";
    for (const [i, sheet2] of s.book.worksheets.entries()) {
      const o = el("option", sheet2.name);
      o.value = String(i);
      select.append(o);
    }
    select.value = String(s.sheet);
    select.onchange = () => {
      s.sheet = Number(select.value);
      try {
        updateMapping(s);
      } catch (e) {
        message(e.message, true);
        s.mapping = {};
      }
      render();
    };
    const hdr = el("input");
    hdr.type = "number";
    hdr.name = "header_row";
    hdr.min = 1;
    hdr.max = 20;
    hdr.value = s.header;
    hdr.onchange = () => {
      const v = Number(hdr.value);
      if (Number.isInteger(v) && v >= 1 && v <= 20) {
        s.header = v;
        try {
          updateMapping(s);
        } catch (e) {
          message(e.message, true);
          s.mapping = {};
        }
        render();
      }
    };
    const updates = el("input");
    updates.type = "checkbox";
    updates.name = "allow_updates";
    updates.checked = s.allowUpdates;
    updates.onchange = () => {
      s.allowUpdates = updates.checked;
      s.plan = null;
      render();
    };
    const mapPanel = pane("2. \u041B\u0438\u0441\u0442 \u0438 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u043A\u043E\u043B\u043E\u043D\u043E\u043A", add(el("div", void 0, "formgrid"), add(el("label", void 0, "field"), el("span", "\u041B\u0438\u0441\u0442"), select), add(el("label", void 0, "field"), el("span", "\u0421\u0442\u0440\u043E\u043A\u0430 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u043E\u0432 (1\u201320)"), hdr)), el("p", "\u041A\u043E\u0434\u044B \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0442\u0435\u043A\u0441\u0442\u043E\u043C \u0432 Excel. \u0421\u0441\u044B\u043B\u043A\u0438 \u2014 \u043F\u043E \u043A\u043E\u0434\u0430\u043C, \u043D\u0435 \u043F\u043E \u0424\u0418\u041E. \u0414\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435/\u043A\u043E\u0434. \u041D\u0435\u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044B\u0435 \u043A\u043E\u043B\u043E\u043D\u043A\u0438 \u043F\u0440\u0438 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442 \u043F\u0440\u0435\u0436\u043D\u0435\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435. \u041F\u0443\u0441\u0442\u0430\u044F \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u0430\u044F \u043A\u043E\u043B\u043E\u043D\u043A\u0430 \u043E\u0447\u0438\u0449\u0430\u0435\u0442 \u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043F\u043E\u043B\u0435.", "muted"));
    main.append(mapPanel);
    let headers;
    try {
      headers = sheetHeaders(s.book.worksheets[s.sheet], s.header);
    } catch (e) {
      mapPanel.append(el("p", e.message, "bad"));
      return;
    }
    const grid = el("div", void 0, "formgrid");
    for (const [key3, f] of importFields(s.type)) {
      const input = el("select");
      input.name = "map_" + key3;
      const blank = el("option", "\u2014 \u041D\u0435 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u2014");
      blank.value = "";
      input.append(blank);
      for (const h of headers) {
        const o = el("option", h.col + " \xB7 " + h.name);
        o.value = String(h.col);
        input.append(o);
      }
      input.value = String(s.mapping[key3] || "");
      input.onchange = () => {
        s.mapping[key3] = Number(input.value) || null;
        s.plan = null;
        render();
      };
      grid.append(add(el("label", void 0, "field"), el("span", fieldLabel(s.type, key3) + (f.required ? " *" : "")), input));
    }
    mapPanel.append(grid, add(el("label", void 0, "row"), updates, el("span", "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u044C \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0449\u0438\u0445 \u043A\u043B\u044E\u0447\u0435\u0439 (\u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430)")), btn("\u041F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430", () => run(async () => {
      const cols = Object.values(s.mapping).filter(Boolean);
      invariant(cols.length > 0 && new Set(cols).size === cols.length, "\u041D\u0430\u0437\u043D\u0430\u0447\u044C\u0442\u0435 \u043A\u0430\u0436\u0434\u043E\u0439 \u043A\u043E\u043B\u043E\u043D\u043A\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043E\u0434\u043D\u043E \u043F\u043E\u043B\u0435");
      s.plan = planImport(ws, s.type, sheetRows(s.book.worksheets[s.sheet], s.header, s.mapping), { allowUpdates: s.allowUpdates });
      return "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0433\u043E\u0442\u043E\u0432. \u0417\u0430\u043F\u0438\u0441\u044C \u0432 \u0431\u0430\u0437\u0443 \u0435\u0449\u0451 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430.";
    }, { save: false }), "primary"));
    if (!s.plan) return;
    const p = s.plan, c = p.counts;
    const report = pane("3. \u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438", add(el("div", void 0, "row"), el("span", "\u0421\u043E\u0437\u0434\u0430\u0442\u044C: " + c.create, "pill"), el("span", "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C: " + c.update, "pill"), el("span", "\u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439: " + c.same, "pill"), el("span", "\u041E\u0448\u0438\u0431\u043A\u0438: " + c.error, c.error ? "bad" : "pill")));
    const t = el("table"), head = el("tr");
    for (const h of ["\u0421\u0442\u0440\u043E\u043A\u0430 Excel", "\u0420\u0435\u0448\u0435\u043D\u0438\u0435", "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 / \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F"]) head.append(el("th", h));
    t.append(add(el("thead"), head));
    const body = el("tbody");
    for (const v of p.results) {
      const details = el("div");
      details.append(el("div", v.message, v.status === "error" ? "bad" : "muted"));
      for (const ch of v.changes) {
        details.append(el("div", ch.field + ": " + (ch.before ?? "\u2014") + " \u2192 " + (ch.after ?? "\u2014"), "preview-detail"));
      }
      body.append(add(el("tr"), el("td", String(v.row)), el("td", { create: "\u0421\u043E\u0437\u0434\u0430\u0442\u044C", update: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C", same: "\u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", error: "\u041E\u0448\u0438\u0431\u043A\u0430" }[v.status]), add(el("td"), details)));
    }
    t.append(body);
    report.append(add(el("div", void 0, "tablewrap"), t), el("p", c.error ? "\u0418\u043C\u043F\u043E\u0440\u0442 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D. \u0418\u0441\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0432\u0441\u0435 \u043E\u0448\u0438\u0431\u043A\u0438 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443." : "\u0411\u0443\u0434\u0443\u0442 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F, \u043E\u0434\u043D\u043E\u0439 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0435\u0439.", "muted"), btn("\u0418\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C " + p.events.length + " \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", () => {
      if (confirm("\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0432 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u0443\u044E \u0431\u0430\u0437\u0443?")) run(async () => {
        const n = commitImport(ws, p);
        s.plan = null;
        return "\u0418\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439: " + n;
      });
    }, "primary", !!c.error || !p.events.length || !!ws.conflicts.length));
    main.append(report);
  }
  var revisionLabels = { draft: "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A", review: "\u041D\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0438", approved: "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D", effective: "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442", superseded: "\u0417\u0430\u043C\u0435\u043D\u0451\u043D", withdrawn: "\u0412\u044B\u0432\u0435\u0434\u0435\u043D \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F", final: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E", archived: "\u0410\u0440\u0445\u0438\u0432" };
  function inputField(label, input) {
    return add(el("label", void 0, "field"), el("span", label), input);
  }
  function fieldInput(name, value = "", type = "text") {
    const n = el("input");
    n.name = name;
    n.type = type;
    n.value = value ?? "";
    return n;
  }
  function selectRef(type, name, id = null, optional2 = true) {
    const s = el("select");
    s.name = name;
    if (optional2) {
      const o = el("option", "\u2014 \u041D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u043E \u2014");
      o.value = "";
      s.append(o);
    }
    for (const v of list(ws.working, type).filter((x) => !x.archived || x.id === id)) {
      const o = el("option", refOption(type, v));
      o.value = v.id;
      s.append(o);
    }
    s.value = id || "";
    return s;
  }
  function personPickerField(name, label, id = null, { optional: optional2 = true, historicalName = "", allowed = null } = {}) {
    const wrap = el("div"), trigger = btn("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430 \u25BE", () => openPeopleDropdown(trigger, { people: editorPeople, allowed, optional: optional2, selectedId: value, label, onChoose: (p) => {
      value = p?.id || "";
      selectedName = p?.display_name || "";
      update2();
    } }), "lc-directory-trigger");
    trigger.name = name;
    trigger.setAttribute("aria-label", "\u0412\u044B\u0431\u0440\u0430\u0442\u044C: " + label);
    trigger.setAttribute("aria-haspopup", "dialog");
    trigger.setAttribute("aria-expanded", "false");
    let value = id || "", selectedName = id ? one(ws.working, "SELECT display_name FROM person WHERE id=?", [id])?.display_name || historicalName : "";
    function update2() {
      trigger.textContent = (selectedName || "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430") + " \u25BE";
    }
    Object.defineProperties(wrap, { value: { get: () => value }, selectedName: { get: () => selectedName }, disabled: { get: () => trigger.disabled, set: (v) => {
      trigger.disabled = !!v;
    } } });
    wrap.append(trigger);
    update2();
    return wrap;
  }
  function personInputField(label, picker) {
    return add(el("div", void 0, "field"), el("span", label), picker);
  }
  function downloadRaw(name, text4) {
    const url = URL.createObjectURL(new Blob([text4], { type: "application/json;charset=utf-8" }));
    const a = el("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function contentEvent(type, payload) {
    return { id: uuid(), entity_type: type, entity_id: uuid(), operation: "create", expected_revision: 0, payload, occurred_at: (/* @__PURE__ */ new Date()).toISOString() };
  }
  function tableOf(headers, data) {
    const t = el("table"), h = el("tr");
    headers.forEach((v) => h.append(el("th", v)));
    t.append(add(el("thead"), h));
    const body = el("tbody");
    for (const r of data) {
      const tr = el("tr");
      for (const v of r) tr.append(v instanceof Node ? add(el("td"), v) : el("td", String(v ?? "\u2014")));
      body.append(tr);
    }
    t.append(body);
    return add(el("div", void 0, "tablewrap detail-table"), t);
  }
  function evaluationForm(revision2, source) {
    const methods = sopMethods(ws.working).filter((m) => m.state === "active"), builtin = methods.length ? null : contentEvent("checklist_version", BUILTIN_SOP);
    if (builtin) methods.push({ id: builtin.entity_id, version_no: 1, builtin: true });
    const panel = el("div"), select = el("select");
    for (const m of methods) {
      const o = el("option", m.builtin ? "\u0412\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0430 \xB7 \u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 4" : "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 v" + m.version_no);
      o.value = m.id;
      select.append(o);
    }
    const actor = personPickerField("eval_actor", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", null, { optional: false }), day = fieldInput("eval_date", today(), "date"), place = fieldInput("eval_place", revision2.workplace_name || ""), content = el("div");
    panel.append(add(el("div", void 0, "formgrid"), inputField("\u0412\u0435\u0440\u0441\u0438\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438", select), personInputField("\u041E\u0446\u0435\u043D\u0449\u0438\u043A", actor), inputField("\u0414\u0430\u0442\u0430", day), inputField("\u041C\u0435\u0441\u0442\u043E", place)), content);
    function draw() {
      content.replaceChildren();
      const criteria = builtin ? previewCriteria(BUILTIN_SOP, builtin.entity_id) : sopCriteria(ws.working, select.value), total = criteria.length, values = criteria.map((c) => {
        const choice = el("select");
        choice.name = "criterion_" + c.position;
        for (const [v, n] of [["", "\u041D\u0435 \u043E\u0446\u0435\u043D\u0435\u043D\u043E"], ["1", "1 \u2014 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E"], ["0", "0 \u2014 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E"]]) {
          const o = el("option", n);
          o.value = v;
          choice.append(o);
        }
        const note = fieldInput("note_" + c.position);
        note.maxLength = 2e3;
        return { c, choice, note };
      });
      const progress = el("p", "\u041E\u0446\u0435\u043D\u0435\u043D\u043E: 0 \u0438\u0437 " + total, "muted"), save2 = btn("\u0417\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043E\u0446\u0435\u043D\u043A\u0443", () => run(async () => {
        const payload = { revision_id: revision2.id, method_id: select.value, actor_id: actor.value, evaluated_on: day.value, place: place.value, source_sha256: source.sha256, responses: values.map((v) => ({ criterion_id: v.c.id, value: v.choice.value === "" ? null : Number(v.choice.value), note: v.note.value })) };
        await ws.applyContentEvents([...builtin ? [builtin] : [], contentEvent("sop_evaluation", payload)]);
        return "\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
      }), "primary", true);
      function update2() {
        const result = evaluationResult(values.map((x) => ({ value: x.choice.value === "" ? null : Number(x.choice.value) })), total);
        progress.textContent = "\u041E\u0446\u0435\u043D\u0435\u043D\u043E: " + result.rated + " \u0438\u0437 " + total + " \xB7 " + (result.fraction === null ? "\u0438\u0442\u043E\u0433 \u043F\u043E\u043A\u0430 \u043D\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D" : (result.fraction * 100).toFixed(0) + "%");
        save2.disabled = busy || result.rated !== total || !!ws.conflicts.length;
      }
      values.forEach((v) => v.choice.onchange = update2);
      content.append(tableOf(["\u2116", "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u043E\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], values.map((v) => [v.c.position, v.c.question, v.choice, v.note])), progress, el("p", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u2014 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u044B\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F / " + total + ". \u041F\u043E\u0440\u043E\u0433 \u0437\u0430\u0447\u0451\u0442\u0430 \u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D; \u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0435 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442 \u0421\u041E\u041F \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438.", "muted"), save2);
    }
    select.onchange = () => {
      if (!confirm("\u0421\u043C\u0435\u043D\u0438\u0442\u044C \u0432\u0435\u0440\u0441\u0438\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438? \u041D\u0435\u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u044B\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u0431\u0443\u0434\u0443\u0442 \u043E\u0447\u0438\u0449\u0435\u043D\u044B.")) {
        select.value = select.dataset.previous;
        return;
      }
      select.dataset.previous = select.value;
      draw();
    };
    select.dataset.previous = select.value;
    draw();
    return panel;
  }
  async function evaluationXlsx(id) {
    const e = one(ws.working, "SELECT * FROM sop_evaluation WHERE id=?", [id]), v = one(ws.working, "SELECT * FROM document_revision WHERE id=?", [e.revision_id]), doc = one(ws.working, "SELECT * FROM document WHERE id=?", [v.document_id]);
    const responses = rows(ws.working, "SELECT c.position,c.question,r.value,r.note FROM sop_evaluation_response r JOIN checklist_criterion c ON c.id=r.criterion_id WHERE r.evaluation_id=? ORDER BY c.position", [id]);
    const method = one(ws.working, "SELECT version_no FROM checklist_version WHERE id=?", [e.method_id]);
    const w = new ExcelJS.Workbook(), s = w.addWorksheet("\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F", { pageSetup: { paperSize: 9, orientation: "landscape", fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
    s.columns = [{ width: 7 }, { width: 105 }, { width: 13 }, { width: 48 }];
    s.mergeCells("A1:D1");
    s.getCell("A1").value = "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F";
    s.getCell("A1").font = { bold: true, size: 16 };
    s.mergeCells("A2:D2");
    s.getCell("A2").value = doc.code + " \xB7 " + doc.title + " \xB7 \u0432\u0435\u0440\u0441\u0438\u044F " + v.version_no;
    s.mergeCells("A3:D3");
    s.getCell("A3").value = "\u041C\u0435\u0441\u0442\u043E: " + e.place + "    \u0414\u0430\u0442\u0430: " + e.evaluated_on + "    \u041E\u0446\u0435\u043D\u0449\u0438\u043A: " + e.actor_name + "    \u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 v" + method.version_no;
    s.mergeCells("A4:D4");
    s.getCell("A4").value = "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 SHA-256: " + e.source_sha256;
    s.addRow(["\u2116 \u043F/\u043F", "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u044B\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"]);
    s.getRow(5).font = { bold: true, color: { argb: "FFFFFFFF" } };
    s.getRow(5).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242E40" } };
    for (const x of responses) {
      const row2 = s.addRow([x.position, x.question, x.value, x.note]);
      row2.alignment = { vertical: "top", wrapText: true };
      row2.height = Math.max(28, 15 * Math.ceil(Math.max(x.question.length / 100, (x.note || "").length / 43)));
    }
    const total = sopCriteria(ws.working, e.method_id).length, result = evaluationResult(responses, total), row = s.addRow(["", "\u0418\u0422\u041E\u0413\u041E", { formula: "SUM(C6:C" + (5 + total) + ")/" + total, result: result.fraction }, ""]);
    row.getCell(3).numFmt = "0%";
    s.pageSetup.printArea = "A1:D" + (6 + total);
    downloadBytes("\u041E\u0446\u0435\u043D\u043A\u0430-\u0421\u041E\u041F-" + doc.code + "-v" + v.version_no + ".xlsx", await w.xlsx.writeBuffer());
  }
  function evaluationHistory(revision2, source) {
    const data = rows(ws.working, "SELECT e.*,m.version_no AS method_version FROM sop_evaluation e JOIN checklist_version m ON m.id=e.method_id WHERE e.revision_id=? ORDER BY e.evaluated_on DESC,e.recorded_at DESC", [revision2.id]);
    const out = el("div");
    if (!data.length) out.append(el("p", "\u041E\u0446\u0435\u043D\u043E\u043A \u044D\u0442\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0435\u0449\u0451 \u043D\u0435\u0442.", "muted"));
    else out.append(tableOf(["\u0414\u0430\u0442\u0430", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A", "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", "\u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A", "\u041E\u0442\u0447\u0451\u0442"], data.map((e) => {
      const r = evaluationResult(rows(ws.working, "SELECT value FROM sop_evaluation_response WHERE evaluation_id=?", [e.id]), sopCriteria(ws.working, e.method_id).length);
      return [e.evaluated_on, e.actor_name, "v" + e.method_version, r.yes + "/" + r.total + " \xB7 " + (r.fraction * 100).toFixed(0) + "%", e.source_sha256 === source.sha256 ? "\u0422\u0435\u043A\u0443\u0449\u0438\u0439" : "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0438\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A", btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C XLSX", () => run(async () => {
        await evaluationXlsx(e.id);
        return "\u041E\u0442\u0447\u0451\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
      }, { save: false }))];
    })));
    return out;
  }
  function goEvaluation(id) {
    navigate("sop_evaluation");
    evaluationSelected = id;
    render();
  }
  var stage43SourceLabels = { seed: "\u0421\u0442\u0430\u0440\u0442\u043E\u0432\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", auto: "\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438", manual: "\u0412\u0440\u0443\u0447\u043D\u0443\u044E", legacy: "\u0418\u0437 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0430" };
  var weightedLabel = (data) => {
    const x = weightedResult(data);
    return "\u0412\u0437\u0432\u0435\u0448\u0435\u043D\u043D\u044B\u0439 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: " + (x.fraction === null ? "\u2014" : (x.fraction * 100).toFixed(1) + "%") + " (" + x.points.toFixed(2) + " / " + x.weight.toFixed(2) + ")" + (x.seed ? " \xB7 \u0421\u0442\u0430\u0440\u0442\u043E\u0432\u044B\u0445 \u043E\u0446\u0435\u043D\u043E\u043A: " + x.seed + "; \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439" : "");
  };
  async function stage43Xlsx(doc, revision2, source, data, actorName) {
    const w = new ExcelJS.Workbook(), s = w.addWorksheet("\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 Stage43", { pageSetup: { paperSize: 9, orientation: "landscape", fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
    s.columns = [{ width: 7 }, { width: 84 }, { width: 12 }, { width: 10 }, { width: 12 }, { width: 48 }, { width: 23 }];
    s.mergeCells("A1:G1");
    s.getCell("A1").value = "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F \u2014 Stage43 (13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432)";
    s.getCell("A1").font = { bold: true, size: 15 };
    s.mergeCells("A2:G2");
    s.getCell("A2").value = doc.code + " \xB7 " + doc.title + " \xB7 \u0432\u0435\u0440\u0441\u0438\u044F " + revision2.version_no;
    s.mergeCells("A3:G3");
    s.getCell("A3").value = "SHA-256: " + source.sha256 + " \xB7 " + (actorName || "\u041E\u0446\u0435\u043D\u0449\u0438\u043A \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D");
    s.addRow(["\u2116", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u0412\u0435\u0441", "\u0411\u0430\u043B\u043B", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439", "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A"]);
    s.getRow(4).font = { bold: true, color: { argb: "FFFFFFFF" } };
    s.getRow(4).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242E40" } };
    data.forEach((x, i) => {
      const n = i + 5, row = s.addRow([x.id, x.req, x.score, x.weight, { formula: "C" + n + "*D" + n, result: x.score * x.weight }, x.comment, stage43SourceLabels[x.scoreSource]]);
      row.alignment = { vertical: "top", wrapText: true };
      row.height = Math.max(28, 15 * Math.ceil(Math.max(x.req.length / 75, x.comment.length / 43)));
    });
    const r = weightedResult(data), total = s.addRow(["", "\u0418\u0422\u041E\u0413\u041E", "", { formula: "SUM(D5:D17)", result: r.weight }, { formula: "SUM(E5:E17)", result: r.points }, "", ""]);
    total.font = { bold: true };
    const result = s.addRow(["", "\u0412\u0437\u0432\u0435\u0448\u0435\u043D\u043D\u044B\u0439 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442", { formula: "E18/D18", result: r.fraction }, "", "", "", ""]);
    result.getCell(3).numFmt = "0.0%";
    s.mergeCells("A20:G20");
    s.getCell("A20").value = r.seed ? "\u0421\u0442\u0430\u0440\u0442\u043E\u0432\u044B\u0435 \u043E\u0446\u0435\u043D\u043A\u0438 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B: " + r.seed + "; \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439." : "\u041E\u0442\u0434\u0435\u043B\u044C\u043D\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 Stage43; \u043D\u0435 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u0431\u0438\u043D\u0430\u0440\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430.";
    s.pageSetup.printArea = "A1:G20";
    downloadBytes("\u0427\u0435\u043A-\u043B\u0438\u0441\u0442-Stage43-" + doc.code + "-v" + revision2.version_no + ".xlsx", await w.xlsx.writeBuffer());
  }
  function stage43Panel(doc, revision2, source) {
    const panel = pane("\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0421\u041E\u041F \xB7 13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432", el("p", "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0433\u043E \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430\u2026", "muted"));
    void (async () => {
      try {
        let refresh2 = function() {
          const value = current();
          value.forEach((x, i) => {
            items[i].cell.textContent = (x.score * x.weight).toFixed(2);
            items[i].origin.textContent = stage43SourceLabels[x.scoreSource];
          });
          progress.textContent = weightedLabel(value);
        }, appendHistory = function() {
          const previous = records.filter((x) => x.source_sha256 !== source.sha256);
          for (const x of previous) {
            const data2 = JSON.parse(x.rows_json), d = el("details");
            d.append(el("summary", "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \xB7 \u043F\u0440\u0435\u0436\u043D\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \xB7 " + x.updated_at.slice(0, 10)), el("p", weightedLabel(data2) + " \xB7 " + (x.actor_name || "\u043E\u0446\u0435\u043D\u0449\u0438\u043A \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D"), "muted"), el("p", "SHA-256: " + x.source_sha256, "source-hash"), tableOf(["\u2116", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u0412\u0435\u0441", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], data2.map((y) => [y.id, y.req, y.score, y.weight, y.comment])));
            panel.append(d);
          }
        };
        const raw = JSON.parse(await readContent2(source)), original = stage43Checklist(raw.constructor);
        if (!panel.isConnected) return;
        panel.replaceChildren(el("h2", "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0421\u041E\u041F \xB7 13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432"), el("p", "\u041F\u0440\u0438\u0432\u044F\u0437\u0430\u043D \u043A \u0442\u043E\u0447\u043D\u043E\u043C\u0443 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0443 \u0432\u0435\u0440\u0441\u0438\u0438 " + revision2.version_no + ". \u0428\u043A\u0430\u043B\u0430 0 / 0,3 / 0,7 / 1 \u0438 \u0432\u0435\u0441\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B. \u041D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F 20-\u043F\u0443\u043D\u043A\u0442\u043D\u043E\u0439 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u043E\u0439 \u043E\u0446\u0435\u043D\u043A\u043E\u0439.", "muted"));
        const records = stage43Checks(ws.working, revision2.id), old = records.find((x) => x.source_sha256 === source.sha256);
        if (!original.length) {
          panel.append(el("p", "\u0412 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u043C JSON \u043D\u0435\u0442 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0421\u041E\u041F \u0438\u0437 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0441 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u043E\u043C.", "muted"));
          appendHistory();
          return;
        }
        const data = old ? JSON.parse(old.rows_json) : original, items = [], progress = el("p", weightedLabel(data), "muted"), actor = personPickerField("stage43_actor", "\u041E\u0446\u0435\u043D\u0449\u0438\u043A \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430", old?.actor_id || null, { historicalName: old?.actor_name || "" }), editable = !doc.archived && !ws.conflicts.length;
        panel.append(el("p", old ? "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u0430\u044F \u043F\u0440\u0430\u0432\u043A\u0430 \u0446\u0435\u043D\u0442\u0440\u0430 \xB7 " + old.updated_at.slice(0, 10) + " \xB7 " + (old.actor_name || "\u043E\u0446\u0435\u043D\u0449\u0438\u043A \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") : "\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D \u0438\u0437 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0435\u0449\u0451 \u043D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u043B\u0438\u0441\u044C \u0432 \u0446\u0435\u043D\u0442\u0440\u0435.", "muted"));
        const table2 = tableOf(["\u2116", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0446\u0435\u043D\u043A\u0430", "\u0412\u0435\u0441", "\u0411\u0430\u043B\u043B", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439", "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A"], data.map((x) => {
          const select = el("select");
          select.name = "stage43_score_" + x.id;
          for (const v of [0, 0.3, 0.7, 1]) {
            const o = el("option", String(v).replace(".", ","));
            o.value = String(v);
            select.append(o);
          }
          select.value = String(x.score);
          select.disabled = !editable;
          const note = fieldInput("stage43_note_" + x.id, x.comment);
          note.maxLength = 2e3;
          note.disabled = !editable;
          const cell = el("span", (x.score * x.weight).toFixed(2)), origin = el("span", stage43SourceLabels[x.scoreSource], "muted"), item2 = { x, select, note, cell, origin, changed: false };
          items.push(item2);
          select.onchange = () => {
            item2.changed = true;
            refresh2();
          };
          note.oninput = refresh2;
          return [x.id, x.req, select, x.weight, cell, note, origin];
        }));
        const current = () => items.map(({ x, select, note, changed }) => ({ ...x, score: Number(select.value), comment: note.value, scoreSource: changed ? "manual" : x.scoreSource }));
        const save2 = btn("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0447\u0435\u043A-\u043B\u0438\u0441\u0442 \u0421\u041E\u041F", () => run(async () => {
          const payload = { revision_id: revision2.id, source, rows: current(), actor_id: actor.value || null };
          const e = old ? { ...contentEvent("sop_stage43_checklist", payload), entity_id: old.id, operation: "update", expected_revision: old.rev } : contentEvent("sop_stage43_checklist", payload);
          await ws.applyContentEvents([e], readContent2);
          evaluationSelected = revision2.id;
          evaluationTab = "weighted";
          page = "sop_evaluation";
          return "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u0421\u041E\u041F \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
        }), "primary", !editable);
        actor.disabled = !editable;
        panel.append(personInputField("\u041E\u0446\u0435\u043D\u0449\u0438\u043A (\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)", actor), table2, progress, el("p", "\u041F\u0440\u0430\u0432\u043A\u0438 \u043E\u0446\u0435\u043D\u043A\u0438 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u044E\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0421\u041E\u041F, \u0435\u0433\u043E \u043F\u0430\u0441\u043F\u043E\u0440\u0442 \u0438\u043B\u0438 \u0441\u0442\u0430\u0442\u0443\u0441. \u0414\u043B\u044F \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u0435\u0447\u0430\u0442\u043D\u043E\u0433\u043E \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430 \u0441\u043A\u0430\u0447\u0430\u0439\u0442\u0435 \u043E\u0442\u0447\u0451\u0442 \u0437\u0434\u0435\u0441\u044C; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 XLSX Stage43 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u0442 \u043F\u0435\u0440\u0432\u043E\u043D\u0430\u0447\u0430\u043B\u044C\u043D\u0443\u044E \u043E\u0446\u0435\u043D\u043A\u0443.", "muted"), add(el("div", void 0, "row"), save2, btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0447\u0435\u043A-\u043B\u0438\u0441\u0442 XLSX", () => run(async () => {
          await stage43Xlsx(doc, revision2, source, current(), actor.selectedName);
          return "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 XLSX \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
        }, { save: false }))));
        appendHistory();
      } catch (e) {
        if (panel.isConnected) panel.replaceChildren(el("h2", "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0421\u041E\u041F"), el("p", e.message, "bad"));
      }
    })();
    return panel;
  }
  function evaluationDetail(doc, v, source, { registry: registry2 = false } = {}) {
    const active4 = sopMethods(ws.working).find((m) => m.state === "active"), count = active4 ? sopCriteria(ws.working, active4.id).length : BUILTIN_SOP.criteria.length;
    const root2 = el("div"), tabs = el("div", void 0, "library-tabs evaluation-tabs"), content = el("div", void 0, "evaluation-content"), panels = /* @__PURE__ */ new Map(), buttons = /* @__PURE__ */ new Map();
    function show2(kind) {
      if (registry2) evaluationTab = kind;
      if (!panels.has(kind)) {
        const body = kind === "weighted" ? stage43Panel(doc, v, source) : pane("\u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \xB7 " + count + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432", evaluationHistory(v, source), ...!v.archived ? [evaluationForm(v, source)] : []);
        panels.set(kind, body);
        content.append(body);
      }
      for (const [k, body] of panels) body.hidden = k !== kind;
      for (const [k, b] of buttons) {
        b.classList.toggle("selected", k === kind);
        b.setAttribute("aria-pressed", String(k === kind));
      }
    }
    for (const [kind, name] of [["weighted", "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 (13 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432)"], ["corporate", "\u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 (" + count + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432)"]]) {
      const b = btn(name, () => show2(kind), "library-tab");
      buttons.set(kind, b);
      tabs.append(b);
    }
    root2.append(tabs, content);
    show2(registry2 ? evaluationTab : "weighted");
    return root2;
  }
  function evaluationRegistry() {
    const p = pane("\u0420\u0435\u0435\u0441\u0442\u0440 \u043E\u0446\u0435\u043D\u043E\u043A \u0421\u041E\u041F"), options = relatedRevisions(), v = options.find((x) => x.id === evaluationSelected);
    if (v) {
      const doc = { ...v, id: v.doc_id }, source = JSON.parse(v.payload_json).source;
      p.append(add(el("div", void 0, "row"), btn("\u041A \u0441\u043F\u0438\u0441\u043A\u0443 \u043E\u0446\u0435\u043D\u043E\u043A", () => {
        evaluationSelected = null;
        evaluationTab = "weighted";
        render();
      }), btn("\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0421\u041E\u041F", () => goDocument(doc.id, v.id))), el("h2", v.code + " \xB7 " + v.title + " \xB7 \u0432\u0435\u0440\u0441\u0438\u044F " + v.version_no), el("p", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F: " + refName("operation", v.operation_id) + " \xB7 " + (v.archived ? "\u0410\u0440\u0445\u0438\u0432" : revisionLabels[v.state] || v.state), "muted"), evaluationDetail(doc, v, source, { registry: true }));
      return p;
    }
    const search = fieldInput("evaluation_search", evaluationSearch, "search"), out = el("div");
    search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043A\u043E\u0434\u0443, \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E \u0438\u043B\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438";
    p.append(el("p", "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0443\u0436\u043D\u0443\u044E \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044E \u0421\u041E\u041F. \u0427\u0435\u043A-\u043B\u0438\u0441\u0442 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430 \u0438 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u0432\u0435\u0434\u0443\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.", "muted"), search, out);
    let generation2 = 0;
    function draw() {
      const epoch = ++generation2, q = search.value.trim().toLocaleLowerCase("ru-RU");
      evaluationSearch = search.value;
      const list2 = options.filter((x) => [x.code, x.title, refName("operation", x.operation_id)].some((s) => String(s || "").toLocaleLowerCase("ru-RU").includes(q))), entries = [];
      if (!list2.length) {
        out.replaceChildren(el("p", options.length ? "\u041D\u0435\u0442 \u0421\u041E\u041F \u043F\u043E \u0437\u0430\u0434\u0430\u043D\u043D\u043E\u043C\u0443 \u043F\u043E\u0438\u0441\u043A\u0443." : "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0421\u041E\u041F \u0432 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0435, \u0447\u0442\u043E\u0431\u044B \u043E\u0446\u0435\u043D\u0438\u0432\u0430\u0442\u044C \u0435\u0433\u043E \u0432\u0435\u0440\u0441\u0438\u0438.", "muted"));
        return;
      }
      const t = tableOf(["\u0421\u041E\u041F", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", "\u0412\u0435\u0440\u0441\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441 \u0421\u041E\u041F", "\u0427\u0435\u043A-\u043B\u0438\u0441\u0442 (13)", "\u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0441\u043A\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430", ""], list2.map((v2) => {
        const source = JSON.parse(v2.payload_json).source, cell = el("span", "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F\u2026", "muted");
        const latest2 = one(ws.working, "SELECT * FROM sop_evaluation WHERE revision_id=? AND source_sha256=? ORDER BY evaluated_on DESC,recorded_at DESC LIMIT 1", [v2.id, source.sha256]);
        const old = latest2 ? null : one(ws.working, "SELECT id FROM sop_evaluation WHERE revision_id=? LIMIT 1", [v2.id]);
        const result = latest2 ? evaluationResult(rows(ws.working, "SELECT value FROM sop_evaluation_response WHERE evaluation_id=?", [latest2.id]), sopCriteria(ws.working, latest2.method_id).length) : null;
        const corporate = latest2 ? result.yes + "/" + result.total + " \xB7 " + (result.fraction * 100).toFixed(0) + "%" : old ? "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0435\u0436\u043D\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A" : "\u041D\u0435 \u043E\u0446\u0435\u043D\u0451\u043D";
        entries.push({ v: v2, source, cell });
        return [v2.code + " \xB7 " + v2.title, refName("operation", v2.operation_id), v2.version_no, v2.archived ? "\u0410\u0440\u0445\u0438\u0432" : revisionLabels[v2.state] || v2.state, cell, corporate, btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
          evaluationSelected = v2.id;
          evaluationTab = "weighted";
          render();
        }, "primary")];
      }));
      out.replaceChildren(t);
      void (async () => {
        for (const { v: v2, source, cell } of entries) {
          if (epoch !== generation2 || !out.isConnected) break;
          try {
            const saved = stage43Checks(ws.working, v2.id).find((x) => x.source_sha256 === source.sha256);
            const data = saved ? JSON.parse(saved.rows_json) : stage43Checklist(JSON.parse(await readContent2(source)).constructor);
            if (epoch !== generation2 || !cell.isConnected) break;
            if (!data.length) {
              cell.textContent = "\u041D\u0435\u0442 \u0447\u0435\u043A-\u043B\u0438\u0441\u0442\u0430";
              continue;
            }
            const result = weightedResult(data);
            cell.textContent = (result.fraction * 100).toFixed(1) + "% \xB7 " + (result.seed ? "\u041F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u043E" : saved ? "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D" : "\u0418\u0437 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430");
          } catch (e) {
            cell.textContent = "\u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D";
            cell.className = "bad";
          }
        }
      })();
    }
    search.oninput = draw;
    draw();
    return p;
  }
  function sopEvaluationScreen(main) {
    const p = pane("\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F", el("p", "\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 4 \u0432\u0441\u0442\u0440\u043E\u0435\u043D\u043E \u0438 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u043F\u0440\u0438 \u043F\u0435\u0440\u0432\u043E\u0439 \u043E\u0446\u0435\u043D\u043A\u0435. \u041C\u043E\u0436\u043D\u043E \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u0438\u0437 DOCX \u0438\u043B\u0438 JSON (1\u2013100 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0430 lean-sop-checklist-v2); \u043F\u0440\u043E\u0448\u043B\u044B\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F.", "muted"));
    p.append(btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 DOCX", () => {
      const i = el("input");
      i.type = "file";
      i.accept = ".docx";
      i.onchange = () => {
        const file = i.files?.[0];
        if (!file) return;
        run(async () => {
          invariant(file.size <= 12 * 1024 * 1024, "\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439");
          const bytes = new Uint8Array(await file.arrayBuffer()), criteria = await sopCriteriaFromDocx(bytes), m = validateChecklist({ format: criteria.length === 20 ? "lean-sop-checklist-v1" : "lean-sop-checklist-v2", title: file.name.slice(0, 200), source_sha256: await sha256(bytes), criteria });
          if (!confirm(m.title + "\n" + criteria.length + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432. \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0432\u0435\u0440\u0441\u0438\u044E?\n\n" + criteria.map((x) => x.code + ". " + x.question).join("\n"))) return "\u0418\u043C\u043F\u043E\u0440\u0442 \u043E\u0442\u043C\u0435\u043D\u0451\u043D";
          await ws.applyContentEvents([contentEvent("checklist_version", m)]);
          return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0430, \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
        });
      };
      i.click();
    }, "primary", !!ws.conflicts.length));
    p.append(btn("\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0443 JSON", () => {
      const i = el("input");
      i.type = "file";
      i.accept = ".json";
      i.onchange = () => {
        if (!i.files?.[0]) return;
        run(async () => {
          invariant(i.files[0].size <= 128e3, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0444\u0430\u0439\u043B \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438");
          const m = validateChecklist(JSON.parse(await i.files[0].text()));
          if (!confirm(m.title + "\n" + m.criteria.length + " \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432. \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043D\u0435\u0438\u0437\u043C\u0435\u043D\u044F\u0435\u043C\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E \u043C\u0435\u0442\u043E\u0434\u0438\u043A\u0438?")) return "\u0418\u043C\u043F\u043E\u0440\u0442 \u043E\u0442\u043C\u0435\u043D\u0451\u043D";
          await ws.applyContentEvents([contentEvent("checklist_version", m)]);
          return "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0430 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0430, \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438.";
        });
      };
      i.click();
    }, "primary", !!ws.conflicts.length));
    if (!sopMethods(ws.working).length) p.append(tableOf(["\u2116", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435"], BUILTIN_SOP.criteria.map((q) => [q.code, q.question])));
    for (const m of sopMethods(ws.working)) {
      const data = JSON.parse(m.methodology_json), d = el("details");
      d.append(el("summary", "\u0412\u0435\u0440\u0441\u0438\u044F " + m.version_no + " \xB7 " + data.title + " \xB7 " + (m.state === "active" ? "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442" : "\u0410\u0440\u0445\u0438\u0432")), el("p", "SHA-256 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430: " + data.source_sha256, "source-hash"), tableOf(["\u2116", "\u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0435"], sopCriteria(ws.working, m.id).map((q) => [q.position, q.question])));
      p.append(d);
    }
    const methods = el("details", void 0, "panel evaluation-methods");
    methods.append(el("summary", "\u041C\u0435\u0442\u043E\u0434\u0438\u043A\u0438 \u043E\u0446\u0435\u043D\u043A\u0438 \u0421\u041E\u041F"), p);
    main.append(evaluationRegistry(), methods);
  }
  function passportForm(c, revision2) {
    const form2 = el("form"), format = el("select");
    format.name = "print_format";
    for (const [v, n] of [["", "\u2014 \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u2014"], ["portrait", "\u04103 \u043A\u043D\u0438\u0436\u043D\u044B\u0439 (9 \u0448\u0430\u0433\u043E\u0432)"], ["landscape", "\u04103 \u0430\u043B\u044C\u0431\u043E\u043C\u043D\u044B\u0439 (12 \u0448\u0430\u0433\u043E\u0432)"]]) {
      const o = el("option", n);
      o.value = v;
      format.append(o);
    }
    format.value = revision2.print_format || "";
    const changed = fieldInput("changed_on", revision2.changed_on || "", "date");
    changed.required = true;
    format.required = true;
    const save2 = el("button", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u0430\u0441\u043F\u043E\u0440\u0442", "primary");
    save2.type = "submit";
    save2.disabled = busy || !!ws.conflicts.length;
    form2.onsubmit = (e) => {
      e.preventDefault();
      run(async () => {
        await ws.applyContentEvents([libraryEvent(c, { command: "passport", revision_id: revision2.id, print_format: format.value, changed_on: changed.value })]);
        return "\u041F\u0430\u0441\u043F\u043E\u0440\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D: \u0441\u0440\u043E\u043A \u043F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440\u0430 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D \u043E\u0442 \u0434\u0430\u0442\u044B \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F.";
      });
    };
    form2.append(add(el("div", void 0, "formgrid"), inputField("\u0424\u043E\u0440\u043C\u0430\u0442 \u043F\u0435\u0447\u0430\u0442\u0438", format), inputField("\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0434\u0430\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", changed)), el("p", "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0438 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0431\u0435\u0440\u0443\u0442\u0441\u044F \u0438\u0437 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0430 \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0433\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043F\u0430\u0441\u043F\u043E\u0440\u0442\u0430.", "muted"), save2);
    return form2;
  }
  function sourcePassport(data) {
    const panel = el("div"), open = btn("\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u043F\u0430\u0441\u043F\u043E\u0440\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0430", async () => {
      open.disabled = true;
      try {
        const p = JSON.parse(await readContent2(data.source)), s = p.constructor, m = s.meta || {};
        panel.replaceChildren(tableOf(["\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442", "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435"], [["\u0424\u0438\u043B\u0438\u0430\u043B", m.branch], ["\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", m.department], ["\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E", m.workplace], ["\u0418\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u0438", m.executor], ["\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", m.operation], ["\u041D\u043E\u043C\u0435\u0440", m.sopNumber], ["\u0414\u0430\u0442\u0430", m.date], ["\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u044C / \u0421\u0418\u0417", m.safety], ["\u0418\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B", m.tools], ["\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B", m.material], ["\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u0433\u0440\u0443\u043F\u043F\u0430", (s.responsibles || []).join("; ")], ["\u0421\u043E\u0433\u043B\u0430\u0441\u0443\u044E\u0449\u0438\u0435", (s.agreedList || []).map((x) => [x.post, x.name].filter(Boolean).join(" ")).join("; ")], ["\u0423\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E\u0449\u0438\u0439", [m.approverPost, m.approverName].filter(Boolean).join(" ")]]));
      } catch (e) {
        panel.append(el("p", e.message, "bad"));
        open.disabled = false;
      }
    });
    panel.append(open);
    return panel;
  }
  function materialsPanel(data) {
    const panel = el("div"), button = btn("\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0444\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438 \u0448\u0430\u0433\u043E\u0432", async () => {
      button.disabled = true;
      try {
        const p = JSON.parse(await readContent2(data.source));
        const grid = el("div", void 0, "material-grid");
        for (const [i, s] of p.constructor.steps.entries()) {
          const a = p.photoAssets[String(s.id)];
          if (!a) continue;
          const img = el("img");
          img.alt = "\u0412\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u0448\u0430\u0433\u0430 " + (i + 1);
          img.loading = "lazy";
          img.src = a.rendered || a.original;
          grid.append(add(el("figure"), img, el("figcaption", i + 1 + ". " + s.action)));
        }
        panel.replaceChildren(grid, el("p", "\u0412 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u043C JSON \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044B \u0438 \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0430.", "muted"));
      } catch (e) {
        panel.append(el("p", e.message, "bad"));
        button.disabled = false;
      }
    });
    panel.append(button);
    return panel;
  }
  function constructorScreen(main) {
    main.append(pane("\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0421\u041E\u041F", el("p", "\u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u043E\u0432\u044B\u0439 \u0421\u041E\u041F \u0438\u043B\u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0438\u0437 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430. \u0418\u043C\u043F\u043E\u0440\u0442 Excel \u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0432 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0435.", "muted"), btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0421\u041E\u041F", () => launchEditor(libraryContext("sop")), "primary", !!ws.conflicts.length), btn("\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u0421\u041E\u041F", () => navigate("sop"))));
    if (editorSession && editorSession.host.hidden) main.append(el("p", "\u041E\u0442\u043A\u0440\u044B\u0442\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0447\u0435\u0440\u0435\u0437 \u043A\u043D\u043E\u043F\u043A\u0443 \u043D\u0430 \u0432\u0435\u0440\u0445\u043D\u0435\u0439 \u043F\u0430\u043D\u0435\u043B\u0438.", "muted"));
  }
  function editableRevision(doc, rev) {
    return !doc.archived && (rev.state === "draft" || ["effective", "superseded", "withdrawn"].includes(rev.state) && !one(ws.working, "SELECT id FROM document_revision WHERE document_id=? AND state IN ('draft','review','approved')", [doc.id]));
  }
  function relatedRevisions() {
    return rows(ws.working, "SELECT r.*,d.id doc_id,d.code,d.title,d.archived,d.operation_id FROM document_revision r JOIN document d ON d.id=r.document_id WHERE d.kind='sop' ORDER BY d.code,r.version_no DESC");
  }
  function frvOriginPanel(revision2) {
    const origin = frvOriginSnapshot(ws.working, revision2.id), panel = el("div");
    if (!origin) return panel;
    const out = el("div"), open = btn("\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0437\u0430\u043C\u0435\u0440\u044B \u0424\u0420\u0412", async () => {
      open.disabled = true;
      try {
        const raw = JSON.parse(await readContent2(origin.source)), s = frvSummary(raw);
        out.replaceChildren(
          el("p", "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0435 \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435: " + (raw.study.studyId || origin.title) + " \xB7 " + (raw.study.operationId || "") + " \xB7 " + (origin.current ? "\u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A" : "\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0430 \u043C\u043E\u043C\u0435\u043D\u0442 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0438 \u0432 \u0421\u041E\u041F"), "muted"),
          tableOf(["\u0426\u0438\u043A\u043B", "\u0413\u0440\u0443\u043F\u043F\u0430", "\u0418\u0437\u043C\u0435\u0440\u0435\u043D\u043E, \u0441\u0435\u043A", "\u041F\u043E\u043B\u043D\u043E\u0442\u0430"], s.cycles.map((c) => [c.index, c.phase, c.seconds, c.complete ? "\u041F\u043E\u043B\u043D\u044B\u0439" : "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0439"])),
          el("p", "\u0421\u0442\u0440\u043E\u043A \u0431\u0435\u0437 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F / \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F: " + s.missing, "muted")
        );
      } catch (e) {
        out.replaceChildren(el("p", e.message, "bad"));
        open.disabled = false;
      }
    });
    panel.append(el("p", "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u0421\u041E\u041F: " + origin.title + " \xB7 " + (origin.current ? "\u0422\u0435\u043A\u0443\u0449\u0438\u0435 \u0437\u0430\u043C\u0435\u0440\u044B" : "\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0437\u0430\u043C\u0435\u0440\u044B; \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u043B\u043E\u0441\u044C \u043F\u043E\u0441\u043B\u0435 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u0421\u041E\u041F"), "muted"), el("p", "SHA-256 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0437\u0430\u043C\u0435\u0440\u043E\u0432: " + origin.source.sha256, "source-hash"), add(el("div", void 0, "row"), open, btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0437\u0430\u043C\u0435\u0440\u044B JSON", () => run(async () => {
      downloadRaw("FRV-\u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A-" + origin.source.sha256.slice(0, 12) + ".json", await readContent2(origin.source));
      return "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0437\u0430\u043C\u0435\u0440\u044B \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u044B";
    }, { save: false })), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0442\u0435\u043A\u0443\u0449\u0435\u0435 \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0424\u0420\u0412", () => goResearch(origin.study_id))), out);
    return panel;
  }
  function relatedPanel(doc, rev, kind) {
    const data = JSON.parse(rev.payload_json), c = libraryContext("sop", doc.id, rev.id), out = el("div"), open = btn(kind === "frv" ? "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F" : "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043B\u0430\u043D \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 TWI", async () => {
      open.disabled = true;
      try {
        const raw = JSON.parse(await readContent2(data.source)), source = raw.constructor;
        if (kind === "frv") {
          const x = linkedFrv(source), t = x.totals, n = (v) => v === null ? "\u2014" : Number(v.toFixed(2)).toLocaleString("ru-RU");
          out.replaceChildren(
            el("p", "\u0420\u0430\u0441\u0447\u0451\u0442 \u043F\u043E \u0448\u0430\u0433\u0430\u043C \u0421\u041E\u041F, \u0432\u0435\u0440\u0441\u0438\u044F " + rev.version_no + ". \u042D\u0442\u043E \u043D\u0435 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0437\u0430\u043C\u0435\u0440\u044B.", "muted"),
            tableOf(["\u0412\u0440\u0435\u043C\u044F, \u0441\u0435\u043A", "\u0412\u0414\u0426, \u0441\u0435\u043A", "\u041C1, \u0441\u0435\u043A", "\u041C2, \u0441\u0435\u043A", "\u041D\u0435 \u0440\u0430\u0441\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u043E, \u0441\u0435\u043A", "\u041F\u0435\u0440\u0435\u043C\u0435\u0449\u0435\u043D\u0438\u0435, \u043C"], [[n(t.seconds), n(t.vdc), n(t.m1), n(t.m2), n(t.unclassified), n(t.distance)]]),
            ...x.invalid ? [el("p", "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0445 \u0441\u0442\u0440\u043E\u043A: " + x.invalid + ". \u0418\u0445 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043D\u0435 \u0432\u043A\u043B\u044E\u0447\u0435\u043D\u044B \u0432 \u0441\u0443\u043C\u043C\u0443.", "bad")] : [],
            tableOf(["\u2116", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435", "\u041D\u0430\u0447\u0430\u043B\u043E, \u0441\u0435\u043A", "\u0412\u0440\u0435\u043C\u044F, \u0441\u0435\u043A", "\u0412\u0414\u0426", "\u041C1", "\u041C2", "\u041D\u0435 \u0440\u0430\u0441\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u043E", "\u041F\u0435\u0440\u0435\u043C\u0435\u0449\u0435\u043D\u0438\u0435, \u043C", "\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], x.rows.map((q) => [q.position, q.action, n(q.start), n(q.seconds), n(q.vdc), n(q.m1), n(q.m2), n(q.unclassified), n(q.distance), q.valid ? q.comment : "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F: " + q.comment])),
            el("p", "\u041D\u0430\u0431\u043B\u044E\u0434\u0430\u043B\u0438: " + (x.meta.observers || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"), "muted")
          );
          out.append(frvOriginPanel(rev));
        } else {
          const x = linkedTwi(source);
          out.replaceChildren(el("p", "\u0421\u0442\u0430\u0442\u0443\u0441: " + x.status + " \xB7 " + x.filled + " \u0438\u0437 15 \u043F\u043E\u043B\u0435\u0439. \u041F\u043B\u0430\u043D \u0441\u0432\u044F\u0437\u0430\u043D \u0441 \u0432\u0435\u0440\u0441\u0438\u0435\u0439 " + rev.version_no + " \u0438 \u043D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\u043C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F.", x.outdated ? "warn" : "muted"));
          if (x.exists) out.append(el("p", "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440: " + (x.trainer || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") + " \xB7 \u041E\u0431\u0443\u0447\u0430\u0435\u043C\u044B\u0439: " + (x.trainee || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D"), "muted"), tableOf(["\u0420\u0430\u0437\u0434\u0435\u043B", "\u041F\u043E\u043B\u0435", "\u0421\u043E\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u0435"], x.fields.map((q) => [{ prepare: "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430", present: "\u041F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0440\u0430\u0431\u043E\u0442\u044B", tryOut: "\u041F\u0440\u043E\u0431\u043D\u043E\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435", followUp: "\u0421\u043E\u043F\u0440\u043E\u0432\u043E\u0436\u0434\u0435\u043D\u0438\u0435" }[q.section], q.label, q.value || "\u2014"])));
          else out.append(el("p", "\u041F\u043B\u0430\u043D \u0435\u0449\u0451 \u043D\u0435 \u0441\u043E\u0437\u0434\u0430\u043D. \u0421\u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0439\u0442\u0435 \u0435\u0433\u043E \u0438\u0437 \u0448\u0430\u0433\u043E\u0432 \u0421\u041E\u041F \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435.", "muted"));
        }
      } catch (e) {
        out.replaceChildren(el("p", e.message, "bad"));
        open.disabled = false;
      }
    });
    const buttons = add(el("div", void 0, "row"), open, btn("\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0421\u041E\u041F", () => goDocument(doc.id, rev.id)));
    if (kind === "twi" && rev.state === "effective" && !doc.archived) buttons.append(btn("\u041D\u0430\u0437\u043D\u0430\u0447\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", () => goTraining("twi", { mode: "new", revisionId: rev.id }), "primary", !!ws.conflicts.length));
    if (editableRevision(doc, rev)) buttons.append(btn(rev.state === "draft" ? kind === "frv" ? "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F" : "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u043B\u0430\u043D TWI" : "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044E \u0421\u041E\u041F", () => openRelated(c, kind), "primary", !!ws.conflicts.length));
    return add(el("div"), buttons, out);
  }
  function linkedRegistry(main, kind) {
    const filter = fieldInput("linked_search", "", "search");
    filter.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043A\u043E\u0434\u0443, \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E, \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438";
    const out = el("div"), info = el("p", kind === "frv" ? "\u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F \u2014 \u0440\u0430\u0441\u0447\u0451\u0442 \u043F\u043E \u0448\u0430\u0433\u0430\u043C, \u043D\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0439." : "\u041F\u043B\u0430\u043D\u044B \u043F\u0440\u0438\u0432\u044F\u0437\u0430\u043D\u044B \u043A \u0442\u043E\u0447\u043D\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u0421\u041E\u041F. \u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u043F\u043B\u0430\u043D \u043C\u043E\u0436\u043D\u043E \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438\u0437 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430.", "muted");
    main.append(pane(kind === "frv" ? "\u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F" : "\u0420\u0435\u0435\u0441\u0442\u0440 \u043F\u043B\u0430\u043D\u043E\u0432 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 TWI", info, filter, out));
    let drawGeneration = 0;
    function draw() {
      const epoch = ++drawGeneration, q = filter.value.trim().toLowerCase(), data = relatedRevisions().filter((v) => [v.code, v.title, refName("operation", v.operation_id)].some((x) => String(x || "").toLowerCase().includes(q)));
      if (!data.length) {
        out.replaceChildren(el("p", "\u041D\u0435\u0442 \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0445 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u0439 \u0421\u041E\u041F.", "muted"));
        return;
      }
      const body = el("div"), entries = [];
      const t = tableOf(["\u0421\u041E\u041F", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", "\u0412\u0435\u0440\u0441\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441 \u0421\u041E\u041F", kind === "frv" ? "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A" : "\u041F\u043B\u0430\u043D", ""], data.map((v) => {
        const cell = el("span", kind === "frv" ? "\u0428\u0430\u0433\u0438 \u0421\u041E\u041F" : "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F\u2026", "muted");
        entries.push({ v, cell });
        return [v.code + " \xB7 " + v.title, refName("operation", v.operation_id), v.version_no, v.archived ? "\u0410\u0440\u0445\u0438\u0432" : revisionLabels[v.state] || v.state, cell, btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
          body.replaceChildren(pane(v.code + " \xB7 " + v.title + " \xB7 v" + v.version_no, relatedPanel({ ...v, id: v.doc_id }, v, kind)));
        }, "primary")];
      }));
      out.replaceChildren(t, body);
      if (kind === "twi") void (async () => {
        for (const { v, cell } of entries) {
          if (epoch !== drawGeneration || !out.isConnected) break;
          try {
            const raw = JSON.parse(await readContent2(JSON.parse(v.payload_json).source));
            cell.textContent = linkedTwi(raw.constructor).status;
          } catch (e) {
            cell.textContent = "\u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D";
            cell.className = "bad";
          }
        }
      })();
    }
    filter.oninput = draw;
    draw();
  }
  function twiPlansScreen(main) {
    linkedRegistry(main, "twi");
  }
  function frvAnalysisPanel(v, data) {
    const panel = el("div"), button = btn("\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F \u0438 \u0430\u043D\u0430\u043B\u0438\u0437", async () => {
      button.disabled = true;
      try {
        const raw = JSON.parse(await readContent2(data.source)), s = frvSummary(raw), n = (x) => x === null ? "\u2014" : Number(x.toFixed(2)).toLocaleString("ru-RU");
        panel.replaceChildren(tableOf(["\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F", "\u0421\u0435\u043A\u0443\u043D\u0434\u044B", "\u041C\u0438\u043D\u0443\u0442\u044B"], Object.entries(s.totals).map(([k, x]) => [{ VA: "\u0412\u0414\u0426", NVA_Necessary: "\u041C2", NVA_Waste: "\u041C1", WAIT: "\u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435", BREAK: "\u041F\u0435\u0440\u0435\u0440\u044B\u0432", OTHER: "\u041D\u0435 \u043A\u043B\u0430\u0441\u0441\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043E" }[k], n(x), n(x / 60)])), tableOf(["\u0413\u0440\u0443\u043F\u043F\u0430", "\u041F\u043E\u043B\u043D\u044B\u0445 \u0446\u0438\u043A\u043B\u043E\u0432", "\u0421\u0440\u0435\u0434\u043D\u0435\u0435, \u0441\u0435\u043A"], [["\u0414\u043E", s.baselineCount, n(s.before)], ["\u041F\u043E\u0441\u043B\u0435", s.improvedCount, n(s.after)]]), el("p", "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0445 \u0441\u0442\u0440\u043E\u043A: " + s.missing + " \xB7 " + (s.comparable ? "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435: \u0440\u0430\u0437\u043D\u0438\u0446\u0430 " + n(s.delta) + " \u0441\u0435\u043A (" + n(s.percent) + "%)" : "\u042D\u0444\u0444\u0435\u043A\u0442 \u043D\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D: \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u0438\u043C\u043E\u0441\u0442\u044C \u0438 \u043F\u043E\u043B\u043D\u044B\u0435 \u0446\u0438\u043A\u043B\u044B \u0434\u043E/\u043F\u043E\u0441\u043B\u0435."), "muted"), tableOf(["\u0426\u0438\u043A\u043B", "\u0413\u0440\u0443\u043F\u043F\u0430", "\u0418\u0437\u043C\u0435\u0440\u0435\u043D\u043E, \u0441\u0435\u043A", "\u041F\u043E\u043B\u043D\u043E\u0442\u0430"], s.cycles.map((x) => [x.index, x.phase, n(x.seconds), x.complete ? "\u041F\u043E\u043B\u043D\u044B\u0439" : "\u041D\u0435\u043F\u043E\u043B\u043D\u044B\u0439"])));
      } catch (e) {
        panel.append(el("p", e.message, "bad"));
        button.disabled = false;
      }
    });
    const transfer = btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442 \u0421\u041E\u041F \u0438\u0437 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0433\u043E \u0424\u0420\u0412", async () => {
      if (busy) return;
      transfer.disabled = true;
      try {
        invariant(!libraryDraft, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440");
        const d = await draftFromFrv(await readContent2(data.source));
        launchEditor({ ...libraryContext("sop"), operation_id: v.operation_id, seedText: d.text, origin: { study_id: v.id, source_sha256: data.source.sha256 } });
      } catch (e) {
        message(e.message, true);
      } finally {
        transfer.disabled = false;
      }
    }, "primary", !!ws.conflicts.length);
    return add(el("div"), panel, add(el("div", void 0, "row"), button, ...v.state !== "archived" ? [transfer] : []));
  }
  function libraryContext(kind, id = null, revisionId = null) {
    const row = id ? one(ws.working, "SELECT * FROM " + (kind === "sop" ? "document" : "frv_study") + " WHERE id=?", [id]) : null;
    const revision2 = kind === "sop" && revisionId ? one(ws.working, "SELECT * FROM document_revision WHERE id=? AND document_id=?", [revisionId, id]) : null;
    invariant(!id || row, "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430");
    invariant(!revisionId || revision2, "\u0412\u0435\u0440\u0441\u0438\u044F \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430");
    return { kind, id, revisionId, expected: row?.rev || 0, database: meta(ws.base, "database_id"), title: row?.title || "", code: row?.code || "", operation_id: row?.operation_id || null, observed_at: row?.observed_at || "", command: !id ? "create" : kind === "frv" ? "save" : revision2?.state === "draft" ? "save" : "revise", source: revision2 ? JSON.parse(revision2.payload_json).source : kind === "frv" && row ? JSON.parse(row.context_json).source : null };
  }
  function editorPeople() {
    return directoryPeople(ws.working, today());
  }
  function assertContext(c) {
    invariant(c.database === meta(ws.base, "database_id"), "\u041E\u0442\u043A\u0440\u044B\u0442\u0430 \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u043C\u043E\u0436\u043D\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.");
    if (c.id) {
      const row = one(ws.working, "SELECT * FROM " + (c.kind === "sop" ? "document" : "frv_study") + " WHERE id=?", [c.id]);
      invariant(row && row.rev === c.expected, "\u0417\u0430\u043F\u0438\u0441\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430 \u043F\u043E\u0441\u043B\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F. \u041D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u0439\u0442\u0435 \u0435\u0451; \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 JSON \u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E.");
    }
  }
  function libraryEvent(c, payload, operation2 = c.id ? "update" : "create") {
    assertContext(c);
    return { id: uuid(), entity_type: c.kind === "sop" ? "document" : "frv_study", entity_id: c.id || uuid(), operation: operation2, expected_revision: c.expected, payload, occurred_at: (/* @__PURE__ */ new Date()).toISOString() };
  }
  async function chooseLibraryFile(kind, ctx = libraryContext(kind)) {
    if (libraryDraft) {
      message("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.", true);
      return;
    }
    const i = el("input");
    i.type = "file";
    i.accept = ".json,application/json";
    i.onchange = () => {
      const file = i.files?.[0];
      if (file) run(async () => {
        invariant(file.size <= MAX_CONTENT, "JSON \u0434\u043E 30 \u041C\u0411");
        const text4 = await file.text(), inspected = await inspectSource(text4, kind);
        assertContext(ctx);
        libraryDraft = { ctx, text: text4, ...inspected, editor: false };
        page = kind === "sop" ? "sop" : "frv";
        return "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D. \u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0441\u0432\u044F\u0437\u0438 \u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0430\u043F\u0438\u0441\u044C.";
      }, { save: false });
    };
    i.click();
  }
  function editorStatus(s, text4, bad = false) {
    if (editorSession !== s) return;
    s.note.textContent = text4;
    s.note.classList.toggle("bad", bad);
  }
  function editorRoute(c) {
    return c.kind === "frv" || c.editorTab === "frv" ? "frv" : c.editorTab === "twi" ? "twi_plans" : "sop_constructor";
  }
  function showEditor(s) {
    if (editorSession !== s) return;
    page = editorRoute(s.ctx);
    s.host.hidden = false;
    document.body.classList.add("editor-active");
    render();
    s.close.focus();
    if (s.loaded) s.frame.contentWindow.postMessage({ protocol: "lean-editor-v1", session: s.session, type: "directory", people: editorPeople(), theme: theme ? "dark" : "light" }, "*");
  }
  function hideEditor(s) {
    if (editorSession !== s) return;
    s.host.hidden = true;
    document.body.classList.remove("editor-active");
    root.querySelector("main")?.removeAttribute("inert");
  }
  function goDocument(id, revisionId = null) {
    navigate("sop", { retainEmployee: !!employeeReturn });
    libraryFilter = "all";
    librarySelected = id;
    libraryRevisionSelected = revisionId;
    render();
  }
  function goResearch(id) {
    navigate("frv", { retainEmployee: !!employeeReturn });
    libraryFilter = "all";
    librarySelected = id;
    render();
  }
  function openRelated(c, tab) {
    launchEditor({ ...c, editorTab: tab });
  }
  function disposeEditor(s, confirmed = false) {
    if (editorSession !== s) return false;
    if (!confirmed && !window.confirm("\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430? \u041D\u0435\u043F\u0435\u0440\u0435\u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043C\u043E\u0433\u0443\u0442 \u0431\u044B\u0442\u044C \u043F\u043E\u0442\u0435\u0440\u044F\u043D\u044B. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043A\u0430\u0447\u0430\u0439\u0442\u0435 JSON \u0438\u043B\u0438 \u043F\u0435\u0440\u0435\u0434\u0430\u0439\u0442\u0435 \u0432 Lean Center.")) return false;
    clearTimeout(s.timeout);
    hideEditor(s);
    s.host.remove();
    editorSession = null;
    return true;
  }
  function launchEditor(ctx) {
    if (libraryDraft) {
      message("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0438\u043B\u0438 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.", true);
      return;
    }
    if (editorSession) {
      const old = editorSession.ctx;
      if (old.kind === ctx.kind && old.id === ctx.id && old.revisionId === ctx.revisionId && old.editorTab === ctx.editorTab && !ctx.seedText) {
        showEditor(editorSession);
        message("\u0412\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435 \u043A \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0439 \u0440\u0430\u0431\u043E\u0447\u0435\u0439 \u043A\u043E\u043F\u0438\u0438 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430.");
        return;
      }
      if (!disposeEditor(editorSession)) return;
    }
    try {
      assertContext(ctx);
      const template = window.LC_EDITOR_HTML, marker = "window.LC_EDITOR_CONTEXT=null;/* LC_EMBED_CONTEXT */";
      invariant(typeof template === "string" && template.split(marker).length === 2, "\u0424\u0430\u0439\u043B \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D. \u0420\u0430\u0441\u043F\u0430\u043A\u0443\u0439\u0442\u0435 \u0432\u0435\u0441\u044C ZIP: index.html \u0438 \u043F\u0430\u043F\u043A\u0430 versions \u0434\u043E\u043B\u0436\u043D\u044B \u043D\u0430\u0445\u043E\u0434\u0438\u0442\u044C\u0441\u044F \u0440\u044F\u0434\u043E\u043C.");
      const session = uuid(), host = el("section", void 0, "editor-host"), bar = el("div", void 0, "editor-host-bar"), frame = el("iframe"), note = el("span", "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430\u2026", "editor-host-note");
      host.id = "lc-editor-host";
      host.setAttribute("aria-label", "\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430");
      host.setAttribute("role", "region");
      frame.id = "lc-editor-frame";
      frame.title = ctx.kind === "frv" ? "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0424\u0420\u0412" : ctx.editorTab === "twi" ? "\u041F\u043B\u0430\u043D \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 TWI" : ctx.editorTab === "frv" ? "\u0424\u0420\u0412 \u043F\u043E \u0421\u041E\u041F" : "\u041A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 \u0421\u041E\u041F";
      const s = { session, host, frame, note, ctx, loading: false, loaded: false, timeout: null, close: null };
      const back = btn("\u041A \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0435", () => {
        hideEditor(s);
        navigate(s.ctx.kind === "frv" ? "frv" : "sop");
      });
      const close = btn("\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440", () => {
        if (disposeEditor(s)) {
          message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0437\u0430\u043A\u0440\u044B\u0442. \u0411\u0430\u0437\u0430 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0430.");
          navigate(s.ctx.kind === "frv" ? "frv" : "sop");
        }
      });
      s.close = close;
      bar.append(el("strong", frame.title), note, back, close);
      host.append(bar, frame);
      editorSession = s;
      document.body.append(host);
      showEditor(s);
      s.timeout = setTimeout(() => {
        if (!s.loaded) {
          editorStatus(s, "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0443. \u0417\u0430\u043A\u0440\u043E\u0439\u0442\u0435 \u0435\u0433\u043E \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u0444\u0430\u0439\u043B\u043E\u0432 \u0438 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0430.", true);
          message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B \u0433\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C. \u0414\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u044B.", true);
        }
      }, 3e4);
      frame.srcdoc = template.replace(marker, () => "window.LC_EDITOR_CONTEXT=" + JSON.stringify({ session, kind: ctx.kind, tab: ctx.editorTab || null }) + ";/* LC_EMBED_CONTEXT */");
      message("\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430. \u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0433\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u0438.");
    } catch (e) {
      if (editorSession) disposeEditor(editorSession, true);
      message(e.message, true);
    }
  }
  window.addEventListener("message", async (e) => {
    const s = editorSession, m = e.data;
    if (!s || e.source !== s.frame.contentWindow || m?.protocol !== "lean-editor-v1" || m.session !== s.session) return;
    const reply = (message2) => {
      if (editorSession === s) s.frame.contentWindow?.postMessage({ protocol: "lean-editor-v1", session: s.session, type: "result", message: message2 }, "*");
    };
    if (m.type === "ready" && !s.loading && !s.loaded) {
      s.loading = true;
      try {
        assertContext(s.ctx);
        const text4 = s.ctx.seedText ?? (s.ctx.source ? await readContent2(s.ctx.source) : null);
        if (editorSession !== s) return;
        const op = s.ctx.operation_id ? one(ws.working, "SELECT * FROM operation WHERE id=?", [s.ctx.operation_id]) : null;
        s.frame.contentWindow.postMessage({ protocol: "lean-editor-v1", session: s.session, type: "load", text: text4, defaults: { operation: op?.name || "", unit: op ? refName("org_unit", op.unit_id) : "", people: editorPeople(), theme: theme ? "dark" : "light" } }, "*");
        editorStatus(s, "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u0439 \u043A\u043E\u043F\u0438\u0438\u2026");
      } catch (err) {
        clearTimeout(s.timeout);
        reply(err.message);
        editorStatus(s, err.message, true);
        message(err.message, true);
      } finally {
        s.loading = false;
      }
    } else if (m.type === "loaded") {
      clearTimeout(s.timeout);
      s.loaded = true;
      editorStatus(s, "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0433\u043E\u0442\u043E\u0432");
      message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0433\u043E\u0442\u043E\u0432. \u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u0432 \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0443 \u2014 \u043F\u043E\u0441\u043B\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F.");
    } else if (m.type === "source") {
      if (!s.loaded) {
        reply("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0435\u0449\u0451 \u043D\u0435 \u0433\u043E\u0442\u043E\u0432.");
        return;
      }
      if (busy) {
        reply("\u0426\u0435\u043D\u0442\u0440 \u0437\u0430\u043D\u044F\u0442. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0443 \u0438\u043B\u0438 \u0441\u043A\u0430\u0447\u0430\u0439\u0442\u0435 JSON.");
        return;
      }
      if (m.kind !== s.ctx.kind || typeof m.text !== "string" || m.text.length > MAX_CONTENT) {
        reply("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B");
        return;
      }
      if (libraryDraft) {
        reply("\u0412 \u0446\u0435\u043D\u0442\u0440\u0435 \u0443\u0436\u0435 \u0435\u0441\u0442\u044C \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B. \u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0435\u0433\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440.");
        return;
      }
      await run(async () => {
        assertContext(s.ctx);
        const inspected = await inspectSource(m.text, s.ctx.kind);
        invariant(editorSession === s, "\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0437\u0430\u043A\u0440\u044B\u0442");
        libraryDraft = { ctx: s.ctx, text: m.text, ...inspected, editor: true, origin: s.ctx.origin || null };
        page = s.ctx.kind === "sop" ? "sop" : "frv";
        return "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043B\u0435\u043D \u043A \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044E. \u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0440\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0430\u043F\u0438\u0441\u044C.";
      }, { save: false });
      if (error) {
        reply(status);
        showEditor(s);
      } else {
        reply("\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043B\u0435\u043D \u043A \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044E \u0432 Lean Center.");
        hideEditor(s);
        render();
      }
    } else if (m.type === "error") {
      clearTimeout(s.timeout);
      editorStatus(s, "\u041E\u0448\u0438\u0431\u043A\u0430: " + String(m.message || "\u043E\u0448\u0438\u0431\u043A\u0430"), true);
      message("\u0420\u0435\u0434\u0430\u043A\u0442\u043E\u0440: " + String(m.message || "\u043E\u0448\u0438\u0431\u043A\u0430"), true);
    }
  });
  window.addEventListener("beforeunload", (e) => {
    if (editorSession || libraryDraft) {
      e.preventDefault();
      e.returnValue = "";
    }
  });
  function sourceSummary(d) {
    const p = d.projection;
    return d.source.kind === "sop" ? "\u0428\u0430\u0433\u043E\u0432: " + p.steps.length + " \xB7 \u0424\u043E\u0442\u043E: " + p.photos + " \xB7 TWI: " + (p.twi ? "\u0435\u0441\u0442\u044C" : "\u043D\u0435\u0442") : "\u0426\u0438\u043A\u043B\u043E\u0432: " + p.cycles + " \xB7 \u041F\u043E\u043B\u043D\u044B\u0445: " + p.complete + " \xB7 \u0418\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0439: " + p.measurements.length + " \xB7 \u0411\u0435\u0437 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F/\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F: " + p.unmeasured;
  }
  function libraryPreview(main, kind) {
    if (!libraryDraft || libraryDraft.ctx.kind !== kind) return;
    const d = libraryDraft, c = d.ctx, p = d.projection, form2 = el("form");
    const code = fieldInput("library_code", c.code || (p.number && p.number !== "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A" ? p.number : ""));
    code.required = kind === "sop" && !c.id;
    const title = fieldInput("library_title", c.title || p.title);
    title.required = true;
    title.maxLength = 500;
    const op = selectRef("operation", "library_operation", c.operation_id);
    const observed = fieldInput("library_observed", c.observed_at, "date");
    observed.required = kind === "frv";
    const grid = el("div", void 0, "formgrid");
    if (kind === "sop") {
      if (c.id) grid.append(el("p", "\u041A\u043E\u0434 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430: " + c.code, "muted"));
      else grid.append(inputField("\u041A\u043E\u0434 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0432 Lean Center", code));
    }
    grid.append(inputField("\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", title), inputField("\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F (\u0434\u043B\u044F \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u044F \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u0430)", op));
    if (kind === "frv") grid.append(inputField("\u0424\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0434\u0430\u0442\u0430 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F", observed));
    const confirm2 = el("button", c.command === "create" ? "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u043E\u0432\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A" : c.command === "revise" ? "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043D\u043E\u0432\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E" : "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430", "primary");
    confirm2.type = "submit";
    confirm2.disabled = busy || !!ws.conflicts.length;
    form2.onsubmit = (e) => {
      e.preventDefault();
      run(async () => {
        assertContext(c);
        const payload = { command: c.command, title: title.value.trim(), operation_id: op.value || null, source: d.source, projection: p };
        if (kind === "sop") {
          if (c.command === "create") payload.code = code.value.trim();
          else payload.revision_id = c.command === "save" ? c.revisionId : null;
        } else payload.observed_at = observed.value;
        await contentStore.put(d.source, d.text);
        const ev = libraryEvent(c, payload);
        const events = [ev];
        if (d.origin) {
          invariant(c.command === "create", "\u041F\u0440\u043E\u0435\u043A\u0442 \u0438\u0437 \u0424\u0420\u0412 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043D\u043E\u0432\u044B\u043C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u043C");
          events.push({ id: uuid(), entity_type: "document", entity_id: ev.entity_id, operation: "update", expected_revision: 1, payload: { command: "origin", revision_id: ev.id, ...d.origin }, occurred_at: (/* @__PURE__ */ new Date()).toISOString() });
        }
        await ws.applyContentEvents(events, readContent2);
        await persist();
        libraryDraft = null;
        librarySelected = ev.entity_id;
        if (kind === "sop") libraryRevisionSelected = c.command === "save" ? c.revisionId : ev.id;
        if (d.editor && editorSession) disposeEditor(editorSession, true);
        return "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043E\u0431\u0449\u0435\u0439 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
      }, { save: false });
    };
    main.append(pane("\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B", el("p", sourceSummary(d)), el("p", "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0442\u0430\u0442\u0443\u0441 Stage43: " + (p.legacy_status || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") + " \xB7 \u041D\u043E\u043C\u0435\u0440: " + (p.number || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D") + " \xB7 " + Math.ceil(d.source.size / 1024) + " \u041A\u0411", "muted"), el("p", "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0441\u0442\u0430\u0442\u0443\u0441 \u043D\u0435 \u0441\u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044F \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435\u043C \u0432 Lean Center. \u0421\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u0438 \u0444\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E \u043F\u043E SHA-256.", "muted"), add(form2, grid, add(el("div", void 0, "row"), confirm2, btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON", () => downloadRaw("Stage43-" + kind + ".json", d.text)), btn("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440", () => {
      if (window.confirm("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0438\u043C\u043F\u043E\u0440\u0442? \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u0441\u044F.")) {
        libraryDraft = null;
        render();
      }
    })))));
  }
  function libraryAction(c, command, label) {
    const panel = el("div", void 0, "library-action"), actor = selectRef("person", "decision_actor", null), note = fieldInput("decision_note");
    note.maxLength = 2e3;
    const ok = btn(label, () => run(async () => {
      const payload = c.kind === "sop" ? { command, revision_id: c.revisionId, actor_id: actor.value || null, note: note.value } : { command, actor_id: actor.value || null, note: note.value };
      await ws.applyContentEvents([libraryEvent(c, payload)], readContent2);
      return "\u0421\u0442\u0430\u0442\u0443\u0441 \u0438\u0437\u043C\u0435\u043D\u0451\u043D. \u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \u0431\u0430\u0437\u044B.";
    }), "primary", !!ws.conflicts.length);
    panel.append(inputField("\u041E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", actor), inputField("\u041F\u0440\u0438\u043C\u0435\u0447\u0430\u043D\u0438\u0435 / \u043F\u0440\u0438\u0447\u0438\u043D\u0430", note), ok);
    return panel;
  }
  function rawButton(source, name) {
    return btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C JSON", () => run(async () => {
      downloadRaw(name, await readContent2(source));
      return "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 JSON \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false }));
  }
  function sourceDetails(data) {
    const details = el("details"), summary = el("summary", "\u0421\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E\u0431 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0435"), p = data.projection;
    details.append(summary, el("p", sourceSummary(data), "muted"), el("p", "SHA-256: " + data.source.sha256, "source-hash"), el("p", "Stage43: " + (p.legacy_id || "\u0431\u0435\u0437 ID") + " / " + (p.legacy_version || "\u2014") + " / " + (p.legacy_status || "\u2014"), "muted"));
    return details;
  }
  function libraryHeader(main, kind) {
    const search = fieldInput("library_search", query, "search");
    search.placeholder = "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E, \u043A\u043E\u0434\u0443, \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438";
    const filter = el("select");
    filter.name = "library_filter";
    for (const [v, n] of [["all", "\u0412\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438"], ["active", "\u0411\u0435\u0437 \u0430\u0440\u0445\u0438\u0432\u0430"], ["archive", "\u0410\u0440\u0445\u0438\u0432"], ...kind === "sop" ? [["overdue", "\u041F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D \u043F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440"], ["missing_passport", "\u041D\u0435\u0442 \u043F\u0430\u0441\u043F\u043E\u0440\u0442\u0430"]] : []]) {
      const o = el("option", n);
      o.value = v;
      filter.append(o);
    }
    filter.value = libraryFilter;
    const controls = add(el("div", void 0, "row"), btn(kind === "sop" ? "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0421\u041E\u041F \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435" : "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0424\u0420\u0412", () => launchEditor(libraryContext(kind)), "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 JSON Stage43", () => chooseLibraryFile(kind), "", !!ws.conflicts.length), search, filter);
    const p = pane(kind === "sop" ? "\u041E\u0431\u0449\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0421\u041E\u041F" : "\u041E\u0431\u0449\u0430\u044F \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430 \u0424\u0420\u0412", el("p", "\u0421\u043E\u0437\u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430\u0445. \u0418\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0438, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B \u0438 \u0432\u0435\u0440\u0441\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u0432 \u043E\u0431\u0449\u0435\u0439 \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0435. \u041F\u0435\u0447\u0430\u0442\u043D\u044B\u0435 \u0444\u043E\u0440\u043C\u044B \u0438 \u0444\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B. \u0418\u0418 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u043F\u0440\u043E\u043A\u0441\u0438 Yandex Cloud \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E \u043A\u043E\u043C\u0430\u043D\u0434\u0435; \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0431\u0435\u0437 \u0441\u0435\u0442\u0438.", "muted"), controls);
    main.append(p);
    libraryPreview(main, kind);
    const out = el("div", void 0, "stack");
    main.append(out);
    return { search, filter, out };
  }
  function libraryScreen(main, kind) {
    const { search, filter, out } = libraryHeader(main, kind);
    function draw() {
      out.replaceChildren();
      const items = rows(ws.working, kind === "sop" ? "SELECT * FROM document ORDER BY code" : "SELECT * FROM frv_study ORDER BY observed_at DESC,title");
      const filtered = items.filter((v) => {
        const a = kind === "sop" ? !!v.archived : v.state === "archived";
        let visible = libraryFilter === "all" || libraryFilter === "active" && !a || libraryFilter === "archive" && a;
        if (kind === "sop" && !a && libraryFilter === "overdue") visible = !!one(ws.working, "SELECT id FROM document_revision WHERE document_id=? AND state='effective' AND review_due<?", [v.id, today()]);
        if (kind === "sop" && !a && libraryFilter === "missing_passport") visible = !!one(ws.working, "SELECT id FROM document_revision WHERE document_id=? AND state='draft' AND (print_format IS NULL OR workplace_id IS NULL)", [v.id]);
        return visible && [v.title, v.code, refName("operation", v.operation_id)].some((x) => String(x || "").toLowerCase().includes(query.toLowerCase()));
      });
      if (!filtered.length) {
        out.append(pane("\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439", el("p", "\u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435 \u0438\u043B\u0438 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0438\u043C\u044B\u0439 JSON Stage43.", "muted")));
        return;
      }
      if (!filtered.some((x) => x.id === librarySelected)) {
        librarySelected = null;
        libraryRevisionSelected = null;
      }
      if (!librarySelected) {
        out.append(pane(kind === "sop" ? "\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432" : "\u0416\u0443\u0440\u043D\u0430\u043B \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0439", tableOf(["\u041A\u043E\u0434 / \u0434\u0430\u0442\u0430", "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441", ""], filtered.map((v) => {
          const rev = kind === "sop" ? one(ws.working, "SELECT * FROM document_revision WHERE document_id=? ORDER BY CASE WHEN state='effective' THEN 0 ELSE 1 END,version_no DESC LIMIT 1", [v.id]) : null;
          return [v.code || v.observed_at, v.title, refName("operation", v.operation_id), v.archived ? "\u0410\u0440\u0445\u0438\u0432" : revisionLabels[rev?.state || v.state] || "\u2014", btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C", () => {
            librarySelected = v.id;
            libraryRevisionSelected = null;
            draw();
          }, "primary")];
        }))));
        return;
      }
      out.append(add(el("div", void 0, "row"), btn("\u041A \u0441\u043F\u0438\u0441\u043A\u0443", () => {
        librarySelected = null;
        libraryRevisionSelected = null;
        draw();
      })));
      for (const v of filtered.filter((x) => x.id === librarySelected)) {
        const p = pane((kind === "sop" ? v.code + " \xB7 " : "") + v.title, el("p", "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F: " + refName("operation", v.operation_id) + " \xB7 \u0420\u0435\u0432\u0438\u0437\u0438\u044F \u0437\u0430\u043F\u0438\u0441\u0438: " + v.rev, "muted"));
        if (kind === "sop") {
          const versions = rows(ws.working, "SELECT * FROM document_revision WHERE document_id=? ORDER BY version_no DESC", [v.id]);
          if (libraryRevisionSelected && !versions.some((x) => x.id === libraryRevisionSelected)) libraryRevisionSelected = null;
          if (libraryRevisionSelected) p.append(btn("\u0412\u0441\u0435 \u0432\u0435\u0440\u0441\u0438\u0438 \u0421\u041E\u041F", () => {
            libraryRevisionSelected = null;
            draw();
          }), el("p", "\u041E\u0442\u043A\u0440\u044B\u0442\u0430 \u0440\u0435\u0434\u0430\u043A\u0446\u0438\u044F \u043F\u043E \u0441\u0432\u044F\u0437\u0438 \u0438\u0437 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0440\u0430\u0437\u0434\u0435\u043B\u0430.", "muted"));
          for (const revision2 of versions.filter((x) => !libraryRevisionSelected || x.id === libraryRevisionSelected)) {
            const data = JSON.parse(revision2.payload_json), c = libraryContext(kind, v.id, revision2.id), section = el("div", void 0, "library-version");
            section.dataset.revisionId = revision2.id;
            const header2 = add(el("div", void 0, "row"), el("strong", "\u0412\u0435\u0440\u0441\u0438\u044F " + revision2.version_no), el("span", revisionLabels[revision2.state] || revision2.state, "pill"), el("span", revision2.created_at.slice(0, 10), "muted"));
            section.append(header2, el("p", sourceSummary(data), "muted"), el("p", "\u041F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440: " + (revision2.review_due || "\u0434\u0430\u0442\u0430 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u0430") + " \xB7 " + (revision2.print_format === "portrait" ? "\u04103 \u043A\u043D\u0438\u0436\u043D\u044B\u0439" : revision2.print_format === "landscape" ? "\u04103 \u0430\u043B\u044C\u0431\u043E\u043C\u043D\u044B\u0439" : "\u0444\u043E\u0440\u043C\u0430\u0442 \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D") + " \xB7 \u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E: " + (revision2.workplace_name || "\u043D\u0435 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u043E"), revision2.review_due && revision2.review_due < today() && revision2.state === "effective" ? "bad" : "muted"), sourceDetails(data));
            const tabs = el("div", void 0, "library-tabs"), body = el("div", void 0, "library-tab-body");
            const steps = () => tableOf(["\u2116", "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435", "\u0421\u0435\u043A", "\u041A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B", "\u041F\u043E\u0447\u0435\u043C\u0443 \u0432\u0430\u0436\u043D\u043E"], data.projection.steps.map((s, i) => [i + 1, s.action, s.seconds, s.key_points.join("\n"), s.reason]));
            const passport = () => add(el("div"), el("p", "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043C\u0435\u0441\u0442\u043E: " + (revision2.workplace_name || "\u2014") + " \xB7 \u041E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435: " + (revision2.equipment_name || "\u2014") + " \xB7 \u0414\u0430\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F: " + (revision2.changed_on || "\u2014")), sourcePassport(data), ...!v.archived && revision2.state === "draft" ? [passportForm(c, revision2)] : []);
            const assessments = () => add(el("div"), btn("\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u0432 \u0440\u0435\u0435\u0441\u0442\u0440 \u043E\u0446\u0435\u043D\u043E\u043A \u0421\u041E\u041F", () => goEvaluation(revision2.id)), evaluationDetail(v, revision2, data.source));
            const materials = () => materialsPanel(data);
            const history = () => add(el("div"), tableOf(["\u0412\u0435\u0440\u0441\u0438\u044F", "\u0421\u0442\u0430\u0442\u0443\u0441", "\u0421\u043E\u0437\u0434\u0430\u043D\u0430", "\u041F\u0435\u0440\u0435\u0441\u043C\u043E\u0442\u0440"], versions.map((x) => [x.version_no, revisionLabels[x.state] || x.state, x.created_at.slice(0, 10), x.review_due])), frvOriginPanel(revision2));
            const stages = el("div", void 0, "lifecycle");
            for (const [k, n] of [["draft", "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A"], ["review", "\u041D\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0438"], ["approved", "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D"], ["effective", "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442"]]) stages.append(el("span", n, "life-stage" + (revision2.state === k ? " current" : "")));
            section.append(stages);
            for (const [name, make] of [["\u0428\u0430\u0433\u0438 \u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B", steps], ["\u041F\u0430\u0441\u043F\u043E\u0440\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430", passport], ["\u0412\u0435\u0440\u0441\u0438\u0438", history], ["\u0424\u0420\u0412", () => relatedPanel(v, revision2, "frv")], ["\u041F\u043B\u0430\u043D TWI", () => relatedPanel(v, revision2, "twi")], ["\u041E\u0446\u0435\u043D\u043A\u0430 \u0421\u041E\u041F", assessments], ["\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B", materials]]) {
              const tab = btn(name, () => {
                for (const t of tabs.children) t.classList.remove("selected");
                tab.classList.add("selected");
                body.replaceChildren(make());
              }, "library-tab");
              tabs.append(tab);
            }
            tabs.firstChild.classList.add("selected");
            body.append(steps());
            section.append(tabs, body);
            const buttons = add(el("div", void 0, "row"), rawButton(data.source, "SOP-" + v.code + "-v" + revision2.version_no + ".json"));
            const open = versions.some((x) => ["draft", "review", "approved"].includes(x.state));
            if (!v.archived && (revision2.state === "draft" || !open && ["effective", "withdrawn", "superseded"].includes(revision2.state))) {
              buttons.append(btn(revision2.state === "draft" ? "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440" : "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0432\u0435\u0440\u0441\u0438\u044E \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435", () => launchEditor(c), "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 JSON", () => chooseLibraryFile(kind, c), "", !!ws.conflicts.length));
            }
            section.append(buttons);
            const actions = revision2.state === "draft" ? [["submit", "\u041D\u0430 \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u0438\u0435"]] : revision2.state === "review" ? [["approve", "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u0442\u044C"], ["return", "\u0412\u0435\u0440\u043D\u0443\u0442\u044C \u0432 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A"]] : revision2.state === "approved" ? [["effect", "\u0412\u0432\u0435\u0441\u0442\u0438 \u0432 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435"]] : revision2.state === "effective" ? [["withdraw", "\u0412\u044B\u0432\u0435\u0441\u0442\u0438 \u0438\u0437 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F"]] : [];
            if (!v.archived) for (const [cmd, label] of actions) {
              const det = el("details");
              det.append(el("summary", label), libraryAction(c, cmd, label));
              section.append(det);
            }
            const decisions = rows(ws.working, "SELECT * FROM document_approval WHERE revision_id=? ORDER BY decided_at", [revision2.id]);
            for (const a of decisions) section.append(el("p", (a.decision === "approved" ? "\u0421\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043B: " : "\u0412\u0435\u0440\u043D\u0443\u043B: ") + refName("person", a.actor_id) + " \xB7 " + a.decided_at.slice(0, 10) + (a.note ? " \xB7 " + a.note : ""), "muted"));
            p.append(section);
          }
          if (!v.archived && versions.length && versions.every((x) => ["superseded", "withdrawn"].includes(x.state))) p.append(btn("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0421\u041E\u041F", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0431\u0435\u0437 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u043E\u0440\u0438\u0438?")) run(async () => {
              await ws.applyContentEvents([libraryEvent(libraryContext(kind, v.id), null, "archive")], readContent2);
              return "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0432 \u0430\u0440\u0445\u0438\u0432\u0435";
            });
          }, "danger", !!ws.conflicts.length));
        } else {
          const data = JSON.parse(v.context_json), c = libraryContext(kind, v.id);
          p.append(el("p", revisionLabels[v.state] + " \xB7 \u0414\u0430\u0442\u0430 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u044F: " + v.observed_at), el("p", sourceSummary(data), "muted"), sourceDetails(data), frvAnalysisPanel(v, data));
          for (const link3 of rows(ws.working, "SELECT d.id,d.code,d.title,r.id revision_id,r.version_no,o.source_sha256 FROM sop_frv_origin o JOIN document_revision r ON r.id=o.revision_id JOIN document d ON d.id=r.document_id WHERE o.study_id=?", [v.id])) p.append(add(el("div", void 0, "row"), el("span", link3.code + " \xB7 v" + link3.version_no + " \xB7 " + (link3.source_sha256 === data.source.sha256 ? "\u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u0438\u043A" : "\u0420\u0430\u043D\u0435\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u0437\u0430\u043C\u0435\u0440\u044B"), "muted"), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0421\u041E\u041F", () => goDocument(link3.id, link3.revision_id))));
          const buttons = add(el("div", void 0, "row"), rawButton(data.source, "FRV-" + v.id + ".json"));
          if (v.state === "draft") {
            buttons.append(btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440", () => launchEditor(c), "primary", !!ws.conflicts.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 JSON", () => chooseLibraryFile(kind, c), "", !!ws.conflicts.length));
            const det = el("details");
            det.append(el("summary", "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435"), libraryAction(c, "finalize", "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435"));
            p.append(det);
          }
          if (v.state !== "archived") buttons.append(btn("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C", () => {
            if (confirm("\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0431\u0435\u0437 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0439?")) run(async () => {
              await ws.applyContentEvents([libraryEvent(c, null, "archive")], readContent2);
              return "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 \u0430\u0440\u0445\u0438\u0432\u0435";
            });
          }, "danger", !!ws.conflicts.length));
          p.append(buttons);
        }
        out.append(p);
      }
    }
    search.oninput = () => {
      query = search.value;
      draw();
    };
    filter.onchange = () => {
      libraryFilter = filter.value;
      draw();
    };
    draw();
    if (kind === "frv") linkedRegistry(main, "frv");
  }
  async function backupTransfer() {
    return makeTransfer("backup", await backup(ws), sourceRefs(), readContent2);
  }
  async function restoreBackupTransfer(value) {
    const { payload, contents } = unpackTransfer(value, "backup");
    const db = openDb(SQL, decode(payload.base));
    let refs;
    try {
      refs = unionRefs(refsForDb(db), refsForEvents(payload.pending));
    } finally {
      db.close();
    }
    await restoreContents(contents, refs, (r, t) => contentStore.put(r, t));
    return restore(SQL, payload, readContent2);
  }
  async function acceptManualTransfer(value) {
    const { payload, contents } = unpackTransfer(value, "package");
    await restoreContents(contents, refsForEvents(payload.events), (r, t) => contentStore.put(r, t));
    return ws.accept(payload, readContent2);
  }
  async function snapshotTransfer(s) {
    return makeTransfer("snapshot", { manifest: s.manifest, base: encode(s.bytes) }, refsForDb(ws.base), readContent2);
  }
  async function openSnapshotTransfer(value) {
    const { payload, contents } = unpackTransfer(value, "snapshot"), db = await readSnapshot(SQL, payload.manifest, decode(payload.base));
    try {
      await restoreContents(contents, refsForDb(db), (r, t) => contentStore.put(r, t));
    } catch (e) {
      db.close();
      throw e;
    }
    await useSnapshot(db);
  }
  async function useSnapshot(db) {
    if (meta(db, "database_id") === meta(ws.base, "database_id")) {
      ws.replaceBase(db);
      return;
    }
    if (!empty2()) {
      db.close();
      throw new Error("\u042D\u0442\u043E \u0434\u0440\u0443\u0433\u0430\u044F \u0431\u0430\u0437\u0430. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u0435\u0451 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E.");
    }
    replace(new Workspace(SQL, db));
  }
  async function refresh() {
    invariant(folder, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
    invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F");
    const s = await latestSnapshot(folder, SQL);
    invariant(s, "\u0412 \u043F\u0430\u043F\u043A\u0435 \u043D\u0435\u0442 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0431\u0430\u0437\u044B");
    await useSnapshot(s.db);
    return ws.conflicts.length ? "\u041E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u043E; \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439" : "\u0417\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0431\u0430\u0437\u0430";
  }
  async function publish() {
    invariant(master, "\u0412\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
    invariant(folder, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
    invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F");
    const snapshot = await prepareSnapshot(ws);
    await publishSnapshot(folder, SQL, snapshot, readContent2);
    const db = await readSnapshot(SQL, snapshot.manifest, snapshot.bytes);
    replace(new Workspace(SQL, db, { device: ws.device }));
    return "\u0411\u0430\u0437\u0430 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430 \u043F\u043E SHA-256";
  }
  function storage(main) {
    const mode = el("input");
    mode.type = "checkbox";
    mode.checked = master;
    mode.onchange = () => {
      master = mode.checked;
      render();
    };
    const summary = pane("\u0420\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F", el("p", "ID \u0431\u0430\u0437\u044B: " + meta(ws.base, "database_id"), "muted"), el("p", "\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F: " + (meta(ws.base, "publication_id") || "\u0435\u0449\u0451 \u043D\u0435\u0442"), "muted"), el("p", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F: " + ws.pending.length + " \xB7 \u041F\u0440\u0438\u043D\u044F\u0442\u043E, \u043D\u043E \u043D\u0435 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043E: " + (ws.dirty ? "\u0434\u0430" : "\u043D\u0435\u0442")), add(el("label", void 0, "row"), mode, el("span", "\u0420\u0435\u0436\u0438\u043C \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F (\u0442\u043E\u043B\u044C\u043A\u043E \u0443\u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0435\u043D\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A)")), el("p", "\u0420\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F \u2014 \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0430\u0442\u0435\u043B\u044C, \u043D\u0435 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u044F. \u041F\u0440\u0430\u0432\u0430 \u043F\u0430\u043F\u043A\u0438 \u043D\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u044E\u0442\u0441\u044F \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u044F.", "muted"));
    main.append(summary);
    const controls = add(el("div", void 0, "row"), btn("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u0435\u0442\u0435\u0432\u0443\u044E \u043F\u0430\u043F\u043A\u0443", () => run(async () => {
      folder = await chooseFolder();
      if (cache) await save(cache, "folder", folder);
      return "\u0412\u044B\u0431\u0440\u0430\u043D\u0430 \u043F\u0430\u043F\u043A\u0430: " + folder.name;
    }, { save: false }), "primary"), btn("\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0434\u043E\u0441\u0442\u0443\u043F", () => run(async () => {
      invariant(folder, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
      await testFolder(folder);
      return "\u0427\u0442\u0435\u043D\u0438\u0435, \u0437\u0430\u043F\u0438\u0441\u044C \u0438 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u0442\u0435\u0441\u0442\u043E\u0432\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B";
    }, { save: false }), "", !folder), btn("\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0438\u0437 \u043F\u0430\u043F\u043A\u0438", () => run(refresh), "", !folder), btn("\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", () => run(async () => {
      invariant(folder, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443");
      await sendPackage(folder, await ws.package(), readContent2);
      return "\u041F\u0430\u043A\u0435\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u0434\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0431\u0430\u0437\u043E\u0439";
    }, { save: false }), "", !folder || !ws.pending.length || !!ws.conflicts.length));
    main.append(pane("\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u043F\u0430\u043F\u043A\u0430", el("p", folder ? "\u041F\u0430\u043F\u043A\u0430: " + folder.name : "\u041D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u0430", "muted"), controls));
    const masterPanel = pane("\u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u0438 \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", el("p", "\u0418\u0437\u0434\u0430\u0442\u0435\u043B\u044C \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438 \u043F\u0443\u0431\u043B\u0438\u043A\u0443\u0435\u0442 \u043D\u043E\u0432\u0443\u044E \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u0443\u044E \u0432\u0435\u0440\u0441\u0438\u044E. \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0444\u0430\u0439\u043B\u044B \u043D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u044E\u0442\u0441\u044F.", "muted"), add(el("div", void 0, "row"), btn("\u041F\u0440\u0438\u043D\u044F\u0442\u044C \u0441\u0432\u043E\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", () => run(async () => {
      const n = await ws.acceptOwn(readContent2);
      return "\u041F\u0440\u0438\u043D\u044F\u0442\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439: " + n;
    }), "", !master || !ws.pending.length || !!ws.conflicts.length), btn("\u0421\u043F\u0438\u0441\u043E\u043A \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0445", () => run(async () => {
      invariant(await permission(folder, true), "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430");
      incoming = await listPackages(folder);
      return "\u041D\u0430\u0439\u0434\u0435\u043D\u043E \u043F\u0430\u043A\u0435\u0442\u043E\u0432: " + incoming.length;
    }, { save: false }), "", !folder || !master), btn("\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u0431\u0430\u0437\u0443", () => run(publish), "primary", !folder || !master || !!ws.pending.length), btn("\u0418\u043C\u043F\u043E\u0440\u0442 \u043F\u0430\u043A\u0435\u0442\u0430 \u0432\u0440\u0443\u0447\u043D\u0443\u044E", () => pick(".leanpkg,.json", async (p) => {
      invariant(master, "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
      const result = await acceptManualTransfer(p);
      return result.duplicate ? "\u041F\u0430\u043A\u0435\u0442 \u0443\u0436\u0435 \u043F\u0440\u0438\u043D\u044F\u0442" : "\u041F\u0440\u0438\u043D\u044F\u0442\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439: " + result.count;
    }, MAX_TRANSFER), "", !master)));
    for (const item2 of incoming) {
      const p = item2.p, known = p && one(ws.base, "SELECT id FROM exchange_package WHERE id=?", [p.id]);
      masterPanel.append(add(el("div", void 0, "row"), el("span", item2.name + " \xB7 " + (item2.error || (known ? "\u043F\u0440\u0438\u043D\u044F\u0442" : p.events?.length + " \u0441\u043E\u0431\u044B\u0442\u0438\u0439")), "muted"), btn("\u041F\u0440\u0438\u043D\u044F\u0442\u044C", () => run(async () => {
        const x = await ws.accept(p, readContent2);
        return x.duplicate ? "\u0423\u0436\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u043E" : "\u041F\u0440\u0438\u043D\u044F\u0442\u043E: " + x.count;
      }), "", !!known || !master || !p || !!ws.pending.length)));
    }
    main.append(masterPanel);
    main.append(pane("\u041F\u0435\u0440\u0435\u043D\u043E\u0441 \u0438 \u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435", add(el("div", void 0, "row"), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043F\u0430\u043A\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", () => run(async () => {
      const p = await ws.package();
      download("change-" + p.id + ".leanpkg", await makeTransfer("package", p, refsForEvents(p.events), readContent2));
      return "\u041F\u0430\u043A\u0435\u0442 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D";
    }, { save: false }), "", !ws.pending.length || !!ws.conflicts.length), btn("\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E", () => run(async () => {
      download("lean-" + uuid() + ".leanbackup", await backupTransfer());
      return "\u041A\u043E\u043F\u0438\u044F \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0430";
    }, { save: false })), btn("\u041A\u043E\u043F\u0438\u044F \u043D\u0430 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u0434\u0438\u0441\u043A", () => run(async () => {
      await saveBackup(folder, await backupTransfer());
      return "\u041A\u043E\u043F\u0438\u044F \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u0430 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430";
    }, { save: false }), "", !folder), btn("\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u043A\u043E\u043F\u0438\u044E", () => pick(".leanbackup,.json", async (obj2) => {
      const next = await restoreBackupTransfer(obj2);
      if (!empty2() && !confirm("\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E? \u0423\u0431\u0435\u0434\u0438\u0442\u0435\u0441\u044C, \u0447\u0442\u043E \u0441\u043A\u0430\u0447\u0430\u043B\u0438 \u0435\u0451 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) {
        next.close();
        return "\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
      }
      replace(next);
      return "\u041A\u043E\u043F\u0438\u044F \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 ID \u0431\u0430\u0437\u044B";
    })), btn("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A \u0434\u043B\u044F \u0440\u0443\u0447\u043D\u043E\u0433\u043E \u043E\u0431\u043C\u0435\u043D\u0430", () => run(async () => {
      invariant(master, "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F");
      const s = await prepareSnapshot(ws);
      download("snapshot-" + s.manifest.id + ".leansnapshot", await snapshotTransfer(s));
      replace(new Workspace(SQL, await readSnapshot(SQL, s.manifest, s.bytes), { device: ws.device }));
      return "\u0421\u043D\u0438\u043C\u043E\u043A \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0441\u043A\u0430\u0447\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u0439\u043B; \u0440\u0443\u0447\u043D\u0430\u044F \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430";
    }), "", !master || !!ws.pending.length || !!folder), btn("\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043D\u0438\u043C\u043E\u043A", () => pick(".leansnapshot,.json", async (obj2) => {
      await openSnapshotTransfer(obj2);
      return "\u0421\u043D\u0438\u043C\u043E\u043A \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D \u0438 \u043E\u0442\u043A\u0440\u044B\u0442";
    })))));
    if (ws.conflicts.length) {
      const p = pane("\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", el("p", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E. \u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0438\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u044B; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u043F\u0435\u0440\u0435\u0437\u0430\u043F\u0438\u0441\u0430\u043D\u044B.", "bad"));
      for (const c of ws.conflicts) {
        p.append(el("p", c.error, "bad"));
        const v = one(ws.working, "SELECT * FROM " + c.event.entity_type + " WHERE id=?", [c.event.entity_id]);
        p.append(el("pre", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435: " + JSON.stringify(c.event.payload, null, 2) + "\n\u0422\u0435\u043A\u0443\u0449\u0435\u0435: " + JSON.stringify(v, null, 2), "muted"));
      }
      p.append(add(el("div", void 0, "row"), btn("\u041E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", () => {
        if (confirm("\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0435\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435? \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
          ws.resolveConflict("discard");
          return "\u041A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0443\u044E\u0449\u0435\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435 \u043E\u0442\u043C\u0435\u043D\u0435\u043D\u043E";
        });
      }, "danger"), btn("\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0441\u0432\u043E\u0451 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435", () => {
        if (confirm("\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0432\u0430\u0448\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E\u0432\u0435\u0440\u0445 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0440\u0435\u0432\u0438\u0437\u0438\u0438? \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
          ws.resolveConflict("reapply");
          return "\u0421\u043E\u0437\u0434\u0430\u043D\u043E \u043D\u043E\u0432\u043E\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u0435; \u043E\u043D\u043E \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438";
        });
      }, "", Object.hasOwn(DOMAIN_TYPES, ws.conflicts[0].event.entity_type))));
      main.append(p);
    }
    main.append(pane("\u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u044F", el("p", "\u0422\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0443\u0441\u0442\u043E\u0439 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0439 \u0431\u0430\u0437\u0435. \u041D\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u043A\u0430\u043A \u0440\u0430\u0431\u043E\u0447\u0443\u044E.", "muted"), btn("\u041D\u043E\u0432\u0430\u044F \u043F\u0443\u0441\u0442\u0430\u044F \u0431\u0430\u0437\u0430", () => {
      if (confirm("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u0443\u044E \u043F\u0443\u0441\u0442\u0443\u044E \u0431\u0430\u0437\u0443 \u0432\u043C\u0435\u0441\u0442\u043E \u0442\u0435\u043A\u0443\u0449\u0435\u0439? \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E.")) run(async () => {
        replace(new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration)));
        folder = null;
        incoming = [];
        master = false;
        importState = null;
        libraryDraft = null;
        if (cache) await save(cache, "folder", null);
        return "\u041D\u043E\u0432\u0430\u044F \u043F\u0443\u0441\u0442\u0430\u044F \u0431\u0430\u0437\u0430 \u0441\u043E\u0437\u0434\u0430\u043D\u0430";
      });
    }, "danger"), btn("\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0434\u0435\u043C\u043E-\u0434\u0430\u043D\u043D\u044B\u043C\u0438", () => run(async () => {
      invariant(empty2(), "\u0414\u0435\u043C\u043E \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0443\u0441\u0442\u043E\u0439 \u0431\u0430\u0437\u0435");
      const u = ws.edit("org_unit", null, { code: "DEMO", name: "\u0423\u0447\u0435\u0431\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", kind: "\u041F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", parent_id: null });
      const v = ws.edit("org_unit", null, { code: "DEMO-M", name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0443\u0447\u0430\u0441\u0442\u043E\u043A", kind: "\u0423\u0447\u0430\u0441\u0442\u043E\u043A", parent_id: u });
      const p = ws.edit("profession", null, { code: "DEMO-MECH", name: "\u041C\u0435\u0445\u0430\u043D\u0438\u043A" });
      const a = ws.edit("person", null, { employee_code: "DEMO-001", display_name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A 01" });
      const e = ws.edit("equipment", null, { unit_id: v, code: "DEMO-E", name: "\u0423\u0447\u0435\u0431\u043D\u044B\u0439 \u0441\u0442\u0435\u043D\u0434" });
      ws.edit("operation", null, { unit_id: v, equipment_id: e, code: "DEMO-O", name: "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u0442\u0435\u043D\u0434\u0430", criticality: "normal" });
      ws.edit("person_assignment", null, { person_id: a, unit_id: v, profession_id: p, shift_code: "1", valid_from: "2026-11-25", valid_to: null });
      return "\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u044B \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438";
    }), "", !empty2())));
  }
  function render() {
    chart?.dispose();
    chart = null;
    document.documentElement.classList.toggle("dark", theme);
    const header2 = el("header", void 0, "corp-header");
    const brand = add(el("div", void 0, "brand-lockup"), el("div", void 0, "brand-mark"), add(el("div"), el("div", "LEAN CENTER", "brand"), el("div", "\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u043D\u0430 \u0440\u0430\u0431\u043E\u0447\u0435\u043C \u043C\u0435\u0441\u0442\u0435 \xB7 TWI", "brand-sub")));
    const metaPanel = add(el("div", void 0, "header-meta"), el("span", window.LC_BUILD.version || "lc3.7", "version"), btn(theme ? "\u0421\u0432\u0435\u0442\u043B\u0430\u044F \u0442\u0435\u043C\u0430" : "\u0422\u0451\u043C\u043D\u0430\u044F \u0442\u0435\u043C\u0430", () => {
      theme = !theme;
      render();
    }), btn("\u0425\u0440\u0430\u043D\u0435\u043D\u0438\u0435", () => navigate("storage")));
    if (editorSession && editorSession.host.hidden && !libraryDraft) metaPanel.append(btn("\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440", () => showEditor(editorSession), "primary"));
    header2.append(brand, metaPanel);
    const side = el("aside", void 0, "sidebar");
    side.setAttribute("aria-label", "\u041D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F");
    const group = (name, keys) => {
      side.append(el("div", name, "navgroup"));
      for (const k of keys) side.append(navButton(k));
    };
    for (const [name, keys] of navGroups) {
      const d = el("details", void 0, "nav-section");
      d.open = !collapsedNav.has(name) || keys.includes(page);
      d.append(el("summary", name, "navgroup"));
      for (const k of keys) d.append(navButton(k));
      d.addEventListener("toggle", () => {
        if (d.open) collapsedNav.delete(name);
        else collapsedNav.add(name);
      });
      side.append(d);
    }
    side.append(el("p", "\u25CF  \u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0440\u0430\u0437\u0434\u0435\u043B\u044B", "nav-hint"));
    const main = el("main", void 0, "main");
    const section = navGroups.find(([, keys]) => keys.includes(page))?.[0] || "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E";
    const top = add(el("div", void 0, "top"), add(el("div"), el("div", section, "eyebrow"), el("h1", labels2[page]), el("div", "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \xB7 " + ws.pending.length + " \u043E\u0436\u0438\u0434\u0430\u044E\u0449\u0438\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439", "muted")), el("span", folder ? "\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u043F\u0430\u043F\u043A\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u0430" : "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F", "pill"));
    main.append(top);
    const stat = el("div", status, "status" + (error ? " error" : ""));
    stat.id = "status";
    stat.setAttribute("role", "status");
    main.append(stat);
    if (!cache) main.append(el("p", "IndexedDB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u043F\u0430\u043C\u044F\u0442\u0438 \u2014 \u0441\u043A\u0430\u0447\u0438\u0432\u0430\u0439\u0442\u0435 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0434\u043E \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u044F.", "bad"));
    if (ws.conflicts.length) main.append(el("p", "\u0415\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \xAB\u0411\u0430\u0437\u0430 \u0438 \u043E\u0431\u043C\u0435\u043D\xBB.", "bad"));
    if (ws.dirty) main.append(el("p", "\u041F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0435\u0449\u0451 \u043D\u0435 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u044B.", "warn"));
    if (employeeReturn && page !== "person") main.append(add(el("div", void 0, "row employee-return"), btn("\u2190 \u041A \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430", () => openEmployee(employeeReturn, { restore: true })), el("span", refName("person", employeeReturn), "muted")));
    root.replaceChildren(add(el("div", void 0, "shell"), header2, side, main));
    main.inert = !!editorSession && !editorSession.host.hidden;
    if (editorSession?.loaded) editorSession.frame.contentWindow.postMessage({ protocol: "lean-editor-v1", session: editorSession.session, type: "theme", theme: theme ? "dark" : "light" }, "*");
    if (page === "home") home(main);
    else if (page === "storage") storage(main);
    else if (page === "import_xlsx") importScreen(main);
    else if (page === "sop_constructor") constructorScreen(main);
    else if (page === "twi_plans") twiPlansScreen(main);
    else if (page === "sop" || page === "frv") libraryScreen(main, page);
    else if (page === "sop_evaluation") sopEvaluationScreen(main);
    else if (Object.hasOwn(definitions, page)) registry(main, page);
    else if (TRAINING_PAGES.includes(page)) trainingScreen(main, page, { ws, el, add, btn, pane, tableOf, inputField, fieldInput, refName, refOption, today, run, render, go: goTraining, goDocument, readContent: readContent2, pick, downloadBytes, notify: message, openEmployee });
    else main.append(pane(labels2[page], el("p", "\u041C\u043E\u0434\u0443\u043B\u044C \u0437\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D \u043D\u0430 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0435 \u044D\u0442\u0430\u043F\u044B. \u0412 \u044D\u0442\u043E\u0439 \u0441\u0431\u043E\u0440\u043A\u0435 \u0433\u043E\u0442\u043E\u0432\u0438\u0442\u0441\u044F \u0435\u0434\u0438\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \u0438 \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u0430.", "muted")));
    main.append(el("p", (LC_BUILD.version || "Lean Center") + " \xB7 \u0430\u0432\u0442\u043E\u043D\u043E\u043C\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0447\u0430\u044F \u043A\u043E\u043F\u0438\u044F \xB7 \u043E\u0431\u0449\u0438\u0439 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u043E\u0431\u043C\u0435\u043D", "foot"));
  }
  window.addEventListener("resize", () => chart?.resize());
  async function init() {
    configureMigrations(LC_BUILD.migration3, LC_BUILD.migration4, LC_BUILD.migration5, LC_BUILD.migration6, LC_BUILD.migration7, LC_BUILD.migration8, LC_BUILD.migration9, LC_BUILD.migration10);
    SQL = await window.initSqlJs({ wasmBinary: decode(window.LC_BUILD.wasm) });
    try {
      cache = await openCache();
      const s = await load(cache, "workspace");
      generation = s?.generation || 0;
      folder = await load(cache, "folder");
      ws = s ? new Workspace(SQL, openDb(SQL, s.state.base), s.state) : new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration));
      if (!s) await persist();
      if (folder && await permission(folder, false)) {
        const prev = ws.state();
        try {
          const remote = await latestSnapshot(folder, SQL);
          if (remote) {
            await useSnapshot(remote.db);
            await persist();
            message(ws.conflicts.length ? "\u0411\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430, \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u044B" : "\u0411\u0430\u0437\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430 \u0438\u0437 \u0441\u0435\u0442\u0435\u0432\u043E\u0439 \u043F\u0430\u043F\u043A\u0438");
          }
        } catch (e) {
          replace(new Workspace(SQL, openDb(SQL, prev.base), prev));
          message("\u0421\u0435\u0442\u0435\u0432\u0430\u044F \u0431\u0430\u0437\u0430 \u043D\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0430: " + e.message, true);
        }
      }
    } catch (e) {
      if (!cache) {
        ws = new Workspace(SQL, createDb(SQL, LC_BUILD.schema, LC_BUILD.migration));
        message("IndexedDB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D, \u0440\u0443\u0447\u043D\u043E\u0439 \u0440\u0435\u0436\u0438\u043C: " + e.message, true);
      } else if (ws) {
        message("\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u043E\u043F\u0438\u044F \u043D\u0435 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u0430: " + e.message, true);
        cache = null;
      } else throw e;
    }
    render();
  }
  init().catch((e) => {
    console.error(e);
    root.replaceChildren(el("h1", "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C Lean Center"), el("p", e.message), el("p", "\u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u0443\u0434\u0430\u043B\u0435\u043D\u044B. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0431\u0440\u0430\u0443\u0437\u0435\u0440 \u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E."));
  });
})();
